# -*- coding: utf-8 -*-
"""Several copies of the same film or episode: what picture quality each is (SD, 720p, 1080p, 4K), the extra
copies you could remove, and the StashBox Bin they go to (so a removal can be undone until you empty it)."""
import re
import struct
import time

import xbmcvfs

import db
import names
import places
import vfs
from common import (location_for, log, npath, rel, setting_int, under)

LABEL = {2160: "4K", 1080: "1080p", 720: "720p", 480: "SD", 0: "?"}
LONG = {2160: "4K (UHD)", 1080: "1080p (Full HD)", 720: "720p (HD)", 480: "SD", 0: "quality not known"}
ORDER = (2160, 1080, 720, 480)
BIN = "StashBox Bin"
BIN_FILE = "bin.json"

_SD = re.compile(r"(?i)(?:^|[\s._\-\[\(])(?:480p|576p|480i|576i|sd|dvdrip|dvd|dvd5|dvd9|dvdr|xvid|divx|vhs|vhsrip|"
                 r"tvrip|pdtv|dsr|satrip|ntsc|pal|ppvrip|r5|vcd|svcd)(?=$|[\s._\-\]\)])")
_PART = re.compile(r"(?i)[\s._-]*(?:cd|disc|disk|part|pt)[\s._-]*\d{1,2}(?=\.[a-z0-9]{2,5}$)")
_PART_DIR = re.compile(r"(?i)^(?:cd|disc|disk|part|pt)[\s._-]*\d{1,2}$")
SIDECAR = (".srt", ".sub", ".idx", ".ass", ".ssa", ".smi", ".vtt", ".nfo", ".jpg", ".jpeg", ".png", ".tbn", ".txt",
           ".sfv", ".md5")


# ---------------------------------------------------------------- picture quality
def name_res(path):
    """2160 / 1080 / 720 / 480 from the file's name, else its folder's; 0 if neither says."""
    if names.is_disc_path(path):
        d = names.disc_folder(path)
        r = name_res(d + "/x.mkv") if d else 0
        return r or (1080 if names.disc_kind(path) == "Blu-ray" else 480)
    for s in (vfs.basename(path), vfs.basename(vfs.parent(path))):
        r = names.resolution(s)
        if r != "SD?":
            return {"2160p": 2160, "1080p": 1080, "720p": 720, "480p": 480}[r]
        if _SD.search(names.tidy(s)):
            return 480
    return 0


def _klass(w, h=0):
    if w >= 3000 or h >= 1900:
        return 2160
    if w >= 1700 or h >= 1000:
        return 1080
    if w >= 1100 or h >= 700:
        return 720
    if w >= 200:
        return 480
    return 0


def _mkv(b):
    """PixelWidth (0xB0) followed by PixelHeight (0xBA) in a Matroska header."""
    i = 0
    while True:
        i = b.find(b"\xb0", i)
        if i < 0 or i > len(b) - 8:
            return 0, 0
        n = b[i + 1]
        if n in (0x81, 0x82):
            ln = n & 0x7F
            w = int.from_bytes(b[i + 2:i + 2 + ln], "big")
            j = b.find(b"\xba", i + 2 + ln, i + 2 + ln + 10)
            if j > 0 and b[j + 1] in (0x81, 0x82):
                hl = b[j + 1] & 0x7F
                h = int.from_bytes(b[j + 2:j + 2 + hl], "big")
                if 120 <= w <= 8192 and 90 <= h <= 4400:
                    return w, h
        i += 1


def _avi(b):
    i = b.find(b"avih")
    if i < 0 or len(b) < i + 48:
        return 0, 0
    w, h = struct.unpack_from("<II", b, i + 8 + 32)
    return (w, h) if 120 <= w <= 8192 and 90 <= h <= 4400 else (0, 0)


def _mp4(b):
    best = (0, 0)
    i = 0
    while True:
        i = b.find(b"tkhd", i)
        if i < 0:
            return best
        off = i + 4 + (88 if b[i + 4:i + 5] == b"\x01" else 76)
        if len(b) >= off + 8:
            w, h = struct.unpack_from(">II", b, off)
            w, h = w >> 16, h >> 16
            if 120 <= w <= 8192 and 90 <= h <= 4400 and w > best[0]:
                best = (w, h)
        i += 4


def probe(path):
    """The picture size from the file's own header (MKV, MP4, AVI) -> 2160 / 1080 / 720 / 480, 0 if unreadable."""
    e = names.ext(path)
    if e not in (".mkv", ".webm", ".mk3d", ".avi", ".mp4", ".m4v", ".mov"):
        return 0
    f = None
    try:
        f = xbmcvfs.File(path)
        head = bytes(f.readBytes(1 << 20))
        if e in (".mkv", ".webm", ".mk3d"):
            w, h = _mkv(head)
        elif e == ".avi":
            w, h = _avi(head)
        else:
            w, h = _mp4(head)
            if not w:  # the 'moov' box is often at the end
                size = f.size()
                if size > (1 << 20):
                    f.seek(max(0, size - (4 << 20)), 0)
                    w, h = _mp4(bytes(f.readBytes(4 << 20)))
        return _klass(w, h)
    except Exception as ex:
        log("Reading the picture size of %s: %s" % (vfs.basename(path), ex), "debug")
        return 0
    finally:
        try:
            f and f.close()
        except Exception:
            pass


def res_map(files):
    """{path: 2160/1080/720/480/0}: what the file's header said (when it's been read), else what its name says."""
    qm = dict((r["path"], r) for r in db.q("SELECT * FROM quality"))
    out = {}
    for f in files:
        q = qm.get(f["path"])
        if q and q["res"] and q["res"] > 0 and (q["size"] or 0) == (f["size"] or 0):
            out[f["path"]] = q["res"]
        else:
            out[f["path"]] = name_res(f["path"])
    return out


def unread(files):
    """Files whose header hasn't been read yet (at this size)."""
    qm = dict((r["path"], r["size"]) for r in db.q("SELECT path, size FROM quality"))
    return [f for f in files if f["path"] not in qm or (qm[f["path"]] or 0) != (f["size"] or 0)]


def read_headers(files, progress=None):
    """Read the picture size of each file from its header (a little of the start of each file). progress(i, n,
    name) -> True to stop. -> how many were read."""
    n = 0
    for i, f in enumerate(files):
        if progress and progress(i, len(files), vfs.basename(f["path"])):
            break
        r = probe(f["path"])
        db.run("INSERT OR REPLACE INTO quality(path, size, res, src, ts) VALUES(?,?,?,?,?)",
               (f["path"], f["size"] or 0, r or -1, "header", time.time()), commit=False)
        n += 1
        if n % 20 == 0:
            db.commit()
    db.commit()
    return n


def summary(resv):
    """[1080, 1080, 480] -> '1080p x2, SD'"""
    counts = {}
    for r in resv:
        counts[r] = counts.get(r, 0) + 1
    return ", ".join("%s%s" % (LABEL[r], " x%d" % counts[r] if counts[r] > 1 else "")
                     for r in list(ORDER) + [0] if r in counts)


# ---------------------------------------------------------------- copies
def copy_key(path):
    """Which copy a file belongs to: CD1 / CD2 parts (or CD1 / CD2 folders) of one copy share a key."""
    if names.is_disc_path(path):
        return npath(names.disc_folder(path))
    base = vfs.basename(path)
    par = vfs.parent(path)
    if _PART_DIR.match(vfs.basename(par)):
        return npath(vfs.parent(par))
    if _PART.search(base):
        return npath(vfs.join(par, _PART.sub("", base)))
    return npath(path)


def _main_roots():
    from common import load_locations
    return set(npath(locs[0]["path"]) for locs in load_locations().values() if locs)


def _copies(files, rm):
    mains = _main_roots()
    by = {}
    for f in files:
        by.setdefault(copy_key(f["path"]), []).append(f)
    out = []
    for k, fs in by.items():
        out.append({"key": k, "files": fs, "size": sum(f["size"] or 0 for f in fs),
                    "res": max(rm.get(f["path"], 0) for f in fs), "path": fs[0]["path"],
                    "place": places.place_label(vfs.parent(fs[0]["path"]))})
    # best first: picture quality, then size; a tie goes to the copy in a section's main folder (not a backup)
    return sorted(out, key=lambda c: (-c["res"], -c["size"], not any(under(c["path"], r) for r in mains), c["path"]))


def groups(section=None, item_ids=None):
    """Every film / episode you have more than one copy of -> [{"item", "what", "season", "episode", "copies"}]
    (copies best first: picture quality, then size)."""
    where, args = ["f.item_id IS NOT NULL"], []
    if section:
        where.append("f.section=?")
        args.append(section)
    if item_ids:
        where.append("f.item_id IN (%s)" % ",".join("?" * len(item_ids)))
        args += list(item_ids)
    rows = db.q("SELECT f.*, i.kind FROM files f JOIN items i ON i.id=f.item_id WHERE %s" % " AND ".join(where), args)
    films, eps = {}, {}
    for r in rows:
        if r["kind"] == "movie":
            films.setdefault(r["item_id"], []).append(r)
        elif r["episode"] is not None and r["season"] is not None and not names.is_disc_path(r["path"]):
            eps.setdefault((r["item_id"], r["season"], r["episode"], r["ep_end"]), []).append(r)
    cand = [fs for fs in films.values() if len(set(copy_key(f["path"]) for f in fs)) > 1] + \
        [fs for fs in eps.values() if len(fs) > 1]
    rm = res_map([f for fs in cand for f in fs])
    items = {}
    out = []
    for fs in cand:
        iid = fs[0]["item_id"]
        it = items.get(iid) or db.item(iid)
        items[iid] = it
        cs = _copies(fs, rm)
        if len(cs) < 2:
            continue
        f0 = fs[0]
        what = it["title"] if it["kind"] == "movie" else "%s S%02dE%02d" % (it["title"], f0["season"], f0["episode"])
        out.append({"item": it, "what": what, "season": f0["season"] if it["kind"] == "show" else None,
                    "episode": f0["episode"] if it["kind"] == "show" else None, "copies": cs})
    return sorted(out, key=lambda g: (g["item"]["kind"] != "movie", g["what"].lower()))


def extras(gs, mode):
    """What could go. mode 'same': copies at the same picture quality as a better (bigger) one of the same
    quality; 'lower': copies of a lower quality than the best one. A copy whose quality isn't known never goes.
    -> [(group, keep, [copies to remove])]"""
    out = []
    for g in gs:
        cs = g["copies"]
        best = cs[0]
        if mode == "same":
            gone = []
            for r in ORDER:
                same = [c for c in cs if c["res"] == r]
                gone += same[1:]  # already biggest first
        else:
            gone = [c for c in cs if best["res"] and 0 < c["res"] < best["res"]]
        if gone:
            keep = [c for c in cs if c not in gone]
            out.append((g, keep, gone))
    return out


# ---------------------------------------------------------------- a show in several folders
def show_report(item_id):
    """Each folder a show is in: its picture quality, how many episodes, and whether it's complete.
    -> (rows, total episodes TMDB lists)"""
    it = db.item(item_id)
    hs = places.homes(item_id)
    eps_all = [f for h in hs for f in h["files"]]
    rm = res_map(eps_all)
    counts = dict((s["n"], s.get("count") or 0) for s in db.seasons_of(it) if s.get("n"))
    try:  # the newest season may still be airing: only count what's been on
        import tmdb
        if it["tmdb"] and counts and tmdb.have_key():
            last = max(counts)
            aired = [e for e in tmdb.season(it["tmdb"], last).get("episodes") or []
                     if tmdb.aired(e.get("air_date") or "")]
            counts[last] = len(aired)
    except Exception:
        pass
    want = set((s, e) for s, n in counts.items() for e in range(1, n + 1))
    rows = []
    for h in hs:
        have = set()
        for f in h["files"]:
            if f["episode"] is not None and f["season"]:
                have.add((f["season"], f["episode"]))
                if f["ep_end"]:
                    have |= set((f["season"], e) for e in range(f["episode"], f["ep_end"] + 1))
        missing = sorted(want - have)
        rows.append({"home": h, "have": have, "res": [rm.get(f["path"], 0) for f in h["files"]],
                     "missing": missing, "complete": bool(want) and not missing,
                     "quality": summary([rm.get(f["path"], 0) for f in h["files"]])})
    return rows, len(want)


def missing_text(missing, most=6):
    if not missing:
        return ""
    seasons = {}
    for s, e in missing:
        seasons.setdefault(s, []).append(e)
    parts = ["S%02dE%02d" % (s, e) for s, e in missing[:most]]
    whole = [s for s, es in seasons.items() if len(es) >= 3]
    if len(missing) > most and whole:
        return "missing %d episodes (seasons %s ...)" % (len(missing), ", ".join(str(s) for s in sorted(whole)[:6]))
    return "missing " + ", ".join(parts) + (" +%d more" % (len(missing) - most) if len(missing) > most else "")


def plan_best(item_id):
    """Keep the best copy of every episode (picture quality, then size); the rest go. -> [files to remove]"""
    gone = []
    for _g, _keep, cs in extras(groups(item_ids=[item_id]), "same") + extras(groups(item_ids=[item_id]), "lower"):
        for c in cs:
            gone += c["files"]
    seen, out = set(), []
    for f in gone:
        if f["path"] not in seen:
            seen.add(f["path"])
            out.append(f)
    return out


def plan_keep(item_id, folder):
    """Keep everything in 'folder'; episodes it has that other folders also have go from those folders.
    Episodes only another folder has stay where they are. -> [files to remove]"""
    folder = npath(folder)
    rows, _n = show_report(item_id)
    keep = next((r for r in rows if npath(r["home"]["folder"]) == folder), None)
    if not keep:
        return []
    out = []
    for r in rows:
        if r is keep:
            continue
        for f in r["home"]["files"]:
            if f["episode"] is not None and f["season"] and (f["season"], f["episode"]) in keep["have"]:
                out.append(f)
    return out


# ---------------------------------------------------------------- removing copies (into the StashBox Bin)
def _units(paths):
    """What to move: a film's / show's OWN folder (the one it was named from - never a category like 'Old Films')
    when everything in it is going, so its posters, subtitles and .nfo go too; otherwise the files one by one.
    -> [(kind, path, [library files in it])]"""
    paths = set(npath(p) for p in paths)
    out, done = [], set()
    for p in sorted(paths):
        if p in done:
            continue
        d = names.disc_folder(p) if names.is_disc_path(p) else vfs.parent(p)
        if _PART_DIR.match(vfs.basename(d)):
            d = vfs.parent(d)
        _s, loc = location_for(p)
        root = npath(loc["path"]) if loc else ""
        if root and npath(d) != root and under(d, root) and names.season_from_dir(vfs.basename(d)) is None:
            n = len(npath(d))
            inside = db.q("SELECT path, item_id, mkey FROM files WHERE substr(path, 1, ?) IN (?, ?)",
                          (n + 1, npath(d) + "/", npath(d) + "\\"))
            own = ("movie:" + npath(d), "show:" + npath(d))
            if inside and all(npath(r["path"]) in paths for r in inside) and \
                    len(set(r["item_id"] for r in inside)) == 1 and all(npath(r["mkey"] or "") in own for r in inside):
                out.append(("dir", npath(d), [npath(r["path"]) for r in inside]))
                done |= set(npath(r["path"]) for r in inside)
                continue
        out.append(("file", p, [p]))
        done.add(p)
    return out


def _sidecars(path, listing):
    """'Film.2009.720p.srt', 'Film.2009.720p.en.srt', 'Film.2009.720p-thumb.jpg' next to 'Film.2009.720p.mkv'."""
    stem = names.stem(vfs.basename(path))
    return [x for x in listing if x != vfs.basename(path) and not names.is_video(x) and
            (x.startswith(stem + ".") or x.startswith(stem + "-")) and names.ext(x) in SIDECAR]


def _free_name(p, taken):
    if not vfs.exists(p) and p not in taken:
        return p
    base, e = (p[:-len(names.ext(p))], names.ext(p)) if names.ext(p) else (p, "")
    n = 2
    while vfs.exists("%s (%d)%s" % (base, n, e)) or "%s (%d)%s" % (base, n, e) in taken:
        n += 1
    return "%s (%d)%s" % (base, n, e)


def remove(files, title):
    """Take these files (with their subtitles / .nfo) out of the library: into the StashBox Bin on the same
    drive (undo from Downloads, or empty the bin when you're sure), or deleted straight away if that's how
    Settings > Library is set. Runs in the background. -> [new jobs]"""
    import downloads
    delete = setting_int("remove_mode", 0) == 1
    by = {}
    for f in files:
        sec, loc = location_for(f["path"])
        if loc is None:
            continue
        by.setdefault((f["section"] or sec, npath(loc["path"])), []).append(f)
    jobs = []
    for (sec, root), fs in sorted(by.items()):
        sizes = dict((npath(f["path"]), f["size"] or 0) for f in fs)
        moves, taken, tidy, listings = [], set(), set(), {}
        for kind, p, inside in _units([f["path"] for f in fs]):
            size = sum(sizes.get(x, 0) for x in inside)
            if kind == "dir":
                dst = None if delete else _free_name(vfs.join(root, BIN, rel(p, root)), taken)
                taken.add(dst)
                moves.append({"src": p, "dst": dst, "size": size, "dir": True, "video": True, "delete": delete,
                              "inside": inside})
                tidy.add(npath(vfs.parent(p)))
            else:
                par = vfs.parent(p)
                if par not in listings:
                    res = vfs.listdir(par)
                    listings[par] = res[1] if res else []
                for x in [vfs.basename(p)] + _sidecars(p, listings[par]):
                    src = vfs.join(par, x)
                    dst = None if delete else _free_name(vfs.join(root, BIN, rel(src, root)), taken)
                    taken.add(dst)
                    moves.append({"src": src, "dst": dst, "size": size if x == vfs.basename(p) else 0,
                                  "video": x == vfs.basename(p), "delete": delete, "inside": [p] if x == vfs.basename(p)
                                  else []})
                tidy.add(npath(par))
        tidy = sorted(t for t in tidy if npath(t) != root and under(t, root))
        n_vid = sum(1 for m in moves if m["video"])
        jobs.append(downloads.add({
            "title": "%s %s" % ("Delete" if delete else "Remove", title) if len(by) == 1 else
            "%s %s (%s)" % ("Delete" if delete else "Remove", title, places.place_label(root)),
            "section": sec, "root": root, "kind": "remove", "source": {"type": "organise"},
            "moves": moves, "tidy": tidy, "media": {}, "want": {}, "videos": n_vid,
            "size": sum(m["size"] for m in moves)}))
    from common import request
    request("downloads")
    return jobs


# ---------------------------------------------------------------- the bin
def bin_entries():
    from common import load_json
    return [e for e in load_json(BIN_FILE, {}).get("entries", []) if e.get("bin")]


def bin_add(entries):
    from common import load_json, save_json
    d = load_json(BIN_FILE, {})
    d["entries"] = (d.get("entries") or []) + entries
    save_json(BIN_FILE, d)


def bin_forget(bin_paths):
    from common import load_json, save_json
    gone = set(npath(p) for p in bin_paths)
    d = load_json(BIN_FILE, {})
    d["entries"] = [e for e in d.get("entries") or [] if npath(e["bin"]) not in gone]
    save_json(BIN_FILE, d)


def _rmtree(p):
    res = vfs.listdir(p)
    if res is None:
        return vfs.delete(p)
    ok = True
    for f in res[1]:
        ok = vfs.delete(vfs.join(p, f)) and ok
    for d in res[0]:
        ok = _rmtree(vfs.join(p, d)) and ok
    try:
        xbmcvfs.rmdir(vfs.as_dir(p))
    except Exception:
        ok = False
    return ok and not vfs.exists(p)


def delete_for_good(p, is_dir):
    return _rmtree(p) if is_dir else vfs.delete(p)


def empty_bin(progress=None):
    """Delete everything in the StashBox Bin for good. -> (deleted, failed, bytes freed)"""
    es = bin_entries()
    done, failed, freed, roots = [], 0, 0, set()
    for i, e in enumerate(es):
        if progress and progress(i, len(es), vfs.basename(e["bin"])):
            break
        if not vfs.exists(e["bin"]) or delete_for_good(e["bin"], e.get("dir")):
            done.append(e["bin"])
            freed += e.get("size") or 0
        else:
            failed += 1
        roots.add(e.get("root") or "")
    bin_forget(done)
    for r in roots:  # the empty folders left in each bin
        if r:
            _prune_empty(vfs.join(r, BIN))
    log("Emptied the StashBox Bin: %d deleted, %d couldn't be" % (len(done), failed))
    return len(done), failed, freed


def _prune_empty(p):
    res = vfs.listdir(p)
    if res is None:
        return
    for d in res[0]:
        _prune_empty(vfs.join(p, d))
    vfs.rmdir_if_empty(p)
