# -*- coding: utf-8 -*-
import datetime
import json
import os
import re
import sys
import time
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
sys.path.insert(0, os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))

from torbox_api import TorBoxAPI, TorBoxError  # noqa: E402
import scrapers  # noqa: E402
import zipremote  # noqa: E402
import zipproxy  # noqa: E402
import ddl  # noqa: E402
import cfsolve  # noqa: E402
import tublog  # noqa: E402
import debrid  # noqa: E402
import binge  # noqa: E402
import artwork  # noqa: E402
import watched  # noqa: E402
import catalog as catalog_mod  # noqa: E402
import cocoleech  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1])
VIDEO_EXT = (".mkv", ".mp4", ".avi", ".mov", ".ts", ".m4v", ".webm", ".wmv", ".mpg", ".mpeg", ".m2ts", ".iso")
SECTIONS = (("torrents", "My Torrents"), ("usenet", "My Usenet"), ("webdl", "My Web Downloads"))


PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def store_load(name, default):
    try:
        with open(os.path.join(PROFILE, name), "r") as f:
            return json.load(f)
    except Exception:
        return default


def store_save(name, data):
    try:
        xbmcvfs.mkdirs(PROFILE)
        with open(os.path.join(PROFILE, name), "w") as f:
            json.dump(data, f)
    except Exception as e:
        xbmc.log("[TorBox] could not save %s: %s" % (name, e), xbmc.LOGWARNING)


def url(**q):
    return BASE + "?" + urlencode({k: v for k, v in q.items() if v not in (None, "")})


def popup(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=4000):
    """Show a pop-up the way Settings > Messages says: normal, stealth (problems only, short, silent) or off."""
    mode = ADDON.getSetting("notify_mode") or "0"
    if mode == "2":
        return
    if mode == "1":
        if icon == xbmcgui.NOTIFICATION_INFO and xbmcgui.NOTIFICATION_INFO != xbmcgui.NOTIFICATION_ERROR:
            return
        return xbmcgui.Dialog().notification(NAME, msg, icon, 2000, False)
    xbmcgui.Dialog().notification(NAME, msg, icon, ms)


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO):
    if icon == xbmcgui.NOTIFICATION_ERROR:
        tublog.error(msg)
    elif icon == xbmcgui.NOTIFICATION_WARNING:
        tublog.warn(msg)
    else:
        tublog.debug("shown: %s" % msg)
    popup(msg, icon)


def get_api():
    key = ADDON.getSetting("api_key").strip()
    if not key:
        notify("No API key set - choose 'Log in' in the main menu", xbmcgui.NOTIFICATION_WARNING)
        return None
    return TorBoxAPI(key, ADDON.getSetting("search_host"))


def set_info(li, title, plot="", year=None, media=None, playcount=None, premiered=None, country=None):
    try:  # Kodi 20+
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if premiered and re.match(r"\d{4}-\d{2}-\d{2}$", premiered):
            tag.setPremiered(premiered)
        if country:
            tag.setCountries([COUNTRY_NAMES.get(c.strip(), c.strip()) for c in country.split(",") if c.strip()])
        if plot:
            tag.setPlot(plot)
        if year and str(year).isdigit():
            tag.setYear(int(year))
        if media:
            tag.setMediaType(media)
        if playcount is not None:
            tag.setPlaycount(playcount)
    except AttributeError:
        info = {"title": title, "plot": plot}
        if year and str(year).isdigit():
            info["year"] = int(year)
        if media:
            info["mediatype"] = media
        if playcount is not None:
            info["playcount"] = playcount
        if premiered:
            info["premiered"] = premiered
        li.setInfo("video", info)


def set_music_info(li, title, artist="", album="", track=0, year=None, released=None):
    try:  # Kodi 20+
        tag = li.getMusicInfoTag()
        tag.setTitle(title)
        if year and str(year)[:4].isdigit():
            tag.setYear(int(str(year)[:4]))
        if released:
            tag.setReleaseDate(released)
        if artist:
            tag.setArtist(artist)
        if album:
            tag.setAlbum(album)
        if track:
            tag.setTrack(int(track))
    except AttributeError:
        info = {"title": title, "artist": artist, "album": album}
        if year and str(year)[:4].isdigit():
            info["year"] = int(str(year)[:4])
        if track:
            info["tracknumber"] = int(track)
        li.setInfo("music", info)


def fmt_size(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return "%.1f %s" % (n, u)
        n /= 1024


def is_video(name):
    return name.lower().endswith(VIDEO_EXT)


FANART = os.path.join(ADDON.getAddonInfo("path"), "fanart.jpg")
MEDIA = os.path.join(ADDON.getAddonInfo("path"), "resources", "media")


def ic(name):
    path = os.path.join(MEDIA, name + ".png")
    if not os.path.exists(path) and "_" in name:
        path = os.path.join(MEDIA, name.split("_")[0] + ".png")
    return path


def live_bg(section):
    """A trending backdrop for the section (changes every visit), else the section's own background."""
    if section and ADDON.getSetting("dyn_art") != "false" and (section == "home" or section in artwork.LIVE_SECTIONS):
        a = artwork.pick(section)
        if a and a.get("fanart"):
            return a["fanart"]
    return bg(section or "home")


ITEM_GLYPH = {"buffer_setup": "play", "search_menu": "search", "coco_menu": "link", "recent": "clock", "aired": "calendar", "search": "search", "anime_search": "search",
              "kdrama_search": "search", "music_search": "search", "music_free": "search", "genres": "tag",
              "music_genres": "tag", "catalog": "flame", "stream_services": "play", "anime_season": "sparkle",
              "music_artists": "mic", "add_magnet": "plus", "history": "clock", "coco_play": "link",
              "coco_login": "key", "coco_settings": "sliders", "tmdb_login": "key", "sites": "globe",
              "usenet_setup": "newspaper", "test_scrapers": "check", "account": "account", "login": "key",
              "import_keys": "download", "settings": "gear", "data_check": "check", "log_view": "newspaper", "rd_menu": "key", "svc_cloud": "magnet"}


def item_icon(mm, params):
    a = params.get("action")
    g = ITEM_GLYPH.get(a)
    if a == "anime_list":
        g = "flame" if params.get("src") == "trending" else "star"
    elif a == "kdrama_list":
        g = {"popular": "flame", "top": "star", "airing": "calendar"}.get(params.get("mode"), "flame")
    elif a == "music_albums":
        g = "sparkle" if params.get("src") == "new" else "vinyl"
    elif a == "list":
        g = {"torrents": "magnet", "usenet": "newspaper", "webdl": "download"}.get(params.get("kind"))
    return ic("%s_%s" % (mm, g)) if g else ic(mm)


def bg(name):
    path = os.path.join(MEDIA, "bg_%s.jpg" % name)
    return path if os.path.exists(path) else FANART


CUR_BG = [FANART]


def add_dir(label, params, folder=True, ctx=None, playable=False, plot="", art=None, icon=None, year=None, media=None,
            seen=None, premiered=None, country=None):
    if seen:
        label = "[COLOR lightgreen]\u2713[/COLOR] " + label
    li = xbmcgui.ListItem(label=label)
    set_info(li, label, plot, year, media, None if seen is None else (1 if seen else 0), premiered, country)
    a = {"fanart": CUR_BG[0]}
    if icon:
        a.update({"icon": icon, "thumb": icon})
    if art:
        a.update({k: v for k, v in art.items() if v})
    li.setArt(a)
    if playable:
        li.setProperty("IsPlayable", "true")
    if ctx:
        li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(HANDLE, url(**params), li, folder)


def login():
    how = xbmcgui.Dialog().select("Log in to TorBox", ["Log in with a code (no typing - recommended)",
                                                     "Type or paste the API key"])
    if how < 0:
        return
    if how == 0:
        return login_torbox_code()
    key = xbmcgui.Dialog().input("Paste your TorBox API key (torbox.app > Settings)",
                                 defaultt=ADDON.getSetting("api_key")).strip()
    if not key:
        return
    try:
        u = TorBoxAPI(key).user()
    except TorBoxError as e:
        return xbmcgui.Dialog().ok(NAME, "That key did not work:\n%s" % e)
    ADDON.setSetting("api_key", key)
    xbmcgui.Dialog().ok(NAME, "Logged in as %s" % u.get("email", "your TorBox account"))
    xbmc.executebuiltin("Container.Refresh")


def track(wk):
    """Tell the watched service what is about to play, and add it to Just watched."""
    try:
        xbmcgui.Window(10000).setProperty("tub.playing", json.dumps({"wk": wk or "", "addon": ADDON.getAddonInfo("id")}))
    except Exception:
        pass
    if wk:
        watched.add_recent(wk)


def seen_ctx(wk):
    return [("Mark as watched", "RunPlugin(%s)" % url(action="mark", wk=wk, on=1)),
            ("Mark as unwatched", "RunPlugin(%s)" % url(action="mark", wk=wk, on=0))]


def season_ctx(prefix, n):
    return [("Mark season as watched", "RunPlugin(%s)" % url(action="mark_season", prefix=prefix, n=n, on=1)),
            ("Mark season as unwatched", "RunPlugin(%s)" % url(action="mark_season", prefix=prefix, n=n, on=0))]


def watch_key(p):
    """-> (key, info) describing what a results page is for; (None, None) when it isn't tracked."""
    if p.get("music") or p.get("pack") or p.get("show"):
        return None, None
    title, poster = p.get("title") or p.get("q", ""), p.get("poster")
    if p.get("anime") and p.get("kitsu"):
        k = p["kitsu"]
        show = "an:%s" % k
        if p.get("movie"):
            return show, {"section": "anime", "show": show, "title": title, "last": "Movie", "poster": poster,
                          "open": {kk: p.get(kk) for kk in ("action", "q", "kitsu", "title", "alt", "year", "anime", "movie", "poster")}}
        if not p.get("ep"):
            return None, None
        return "%s:%s" % (show, int(p["ep"])), {
            "section": "anime", "show": show, "title": title, "last": "Episode %s" % p["ep"], "poster": poster,
            "open": {"action": "anime_eps", "kitsu": k, "title": title, "alt": p.get("alt"), "year": p.get("year"),
                     "anime": 1, "eps": p.get("eps"), "poster": poster}}
    if p.get("season") and p.get("ep"):
        sid = p.get("imdb") or ("tmdb%s" % p["tmdb"] if p.get("tmdb") else None) or \
            ("tvm%s" % p["tvm"] if p.get("tvm") else None)
        if not sid:
            return None, None
        sec = "kdrama" if p.get("kdrama") else "tv"
        s, e = int(p["season"]), int(p["ep"])
        if sec == "kdrama" and p.get("tmdb"):
            open_ = {"action": "tmdb_episodes", "id": p["tmdb"], "season": s, "title": title, "year": p.get("year"),
                     "imdb": p.get("imdb"), "poster": poster}
        else:
            open_ = {"action": "episodes", "imdb": p.get("imdb"), "title": title, "year": p.get("year"), "season": s,
                     "poster": poster, "kdrama": p.get("kdrama")}
        return "%s:%s:%d:%d" % (sec, sid, s, e), {"section": sec, "show": "%s:%s" % (sec, sid), "title": title,
                                                   "last": "S%02dE%02d" % (s, e), "poster": poster, "open": open_}
    if p.get("imdb") and not p.get("season"):
        key = "mv:%s" % p["imdb"]
        return key, {"section": "movie", "show": key, "title": title, "last": "Movie", "poster": poster,
                     "open": {kk: p.get(kk) for kk in ("action", "q", "imdb", "title", "year", "name", "poster")}}
    return None, None


SECTION_NAMES = {"tv": "TV", "anime": "Anime", "kdrama": "K-Drama", "movie": "Movie"}


def recent(p):
    sec = p.get("section")
    items = watched.recent(sec)
    if not items:
        add_dir("Nothing here yet - play something and it will show up", {"action": "menu", "m": sec or "tools"},
                folder=False, icon=ic("recent"))
    for r in items:
        label = "%s  [COLOR grey]%s[/COLOR]" % (r.get("title", "?"), r.get("last", ""))
        if not sec:
            label = "[%s] %s" % (SECTION_NAMES.get(r.get("section"), "?"), label)
        add_dir(label, r.get("open") or {}, art={"poster": r.get("poster"), "thumb": r.get("poster")},
                ctx=[("Remove from Just watched", "RunPlugin(%s)" % url(action="recent_remove", show=r.get("show")))])
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# ---------------- service status ----------------
STATE_TAG = {"ok": "[COLOR lightgreen][B]OK[/B][/COLOR]  ", "warn": "[COLOR orange][B]!![/B][/COLOR]  ",
             "down": "[COLOR red][B]DOWN[/B][/COLOR]"}


def has_music():
    return "music_albums" in globals()


def status_check(show_progress=True):
    import health
    prog = None
    if show_progress:
        prog = xbmcgui.DialogProgress()
        prog.create(NAME, "Checking your services...")
    c = rd_client()
    if c and c.auth.get("expires") and time.time() > c.auth["expires"] - 120:
        try:
            c._refresh()
        except Exception as e:
            tublog.warn("Real-Debrid login renewal: %s" % e)
    try:
        st = health.run(ADDON.getSetting, PROFILE, rd_auth().get("token", ""), has_music())
    finally:
        if prog:
            prog.close()
    tublog.debug("Status check: " + ", ".join("%s=%s" % (i["name"], i["state"]) for i in st["items"]))
    return st


def ago(ts):
    s = int(time.time() - (ts or 0))
    return "just now" if s < 60 else ("%d min ago" % (s // 60)) if s < 3600 else ("%d h ago" % (s // 3600))


def status_screen(p):
    import health
    st = health.load(PROFILE)
    if p.get("now") or not st or time.time() - st.get("ts", 0) > 3600:
        st = status_check()
    add_dir("[B]Check again now[/B]  [COLOR grey]last checked %s[/COLOR]" % ago(st.get("ts")), {"action": "status_now"},
            folder=False, icon=ic("tools_check"))
    groups = []
    for i in st.get("items") or []:
        if i["group"] not in groups:
            groups.append(i["group"])
    for g in groups:
        add_dir("[COLOR deepskyblue][B]%s[/B][/COLOR]" % g, {"action": "noop"}, folder=False)
        for i in [x for x in st["items"] if x["group"] == g]:
            add_dir("    %s %s  [COLOR grey]%s  (%.1fs)[/COLOR]" % (STATE_TAG.get(i["state"], i["state"]), i["name"],
                                                                   i["detail"], i["ms"] / 1000.0),
                    {"action": "noop"}, folder=False, plot="%s: %s" % (i["name"], i["detail"]))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def status_line():
    """The one-line summary for the main menu (reads the last check - no waiting)."""
    import health
    st = health.load(PROFILE)
    col, txt = health.summary(st)
    when = ("  [COLOR grey]%s[/COLOR]" % ago(st["ts"])) if st else ""
    return "[COLOR %s]\u25cf %s[/COLOR]%s" % (col, txt, when)


def main_menu():
    if ADDON.getSetting("status_menu") != "false":
        add_dir(status_line(), {"action": "status"}, icon=ic("tools_check"), art={"fanart": bg("tools")})
    if not ADDON.getSetting("api_key").strip():
        add_dir("[B]Log in: enter TorBox API key[/B]", {"action": "login"}, folder=False, icon=ic("tools"))
    try:
        continue_items()
    except Exception:
        tublog.exc("Continue watching list failed")
    try:
        new_items()
    except Exception:
        tublog.exc("New episodes list failed")
    add_dir("Just watched", {"action": "recent"}, icon=ic("recent"), art={"fanart": bg("recent")})
    for label, mm in (("Movies", "movies"), ("TV Shows", "tv"), ("Anime", "anime"), ("K-Dramas", "kdrama"),
                       ("Music", "music")):
        add_dir(label, {"action": "menu", "m": mm}, icon=ic(mm), art={"fanart": live_bg(mm)})
    add_dir("Search", {"action": "search_menu"}, icon=ic("search"), art={"fanart": bg("search")})
    add_dir("My TorBox", {"action": "menu", "m": "cloud"}, icon=ic("cloud"), art={"fanart": bg("cloud")})
    add_dir("Tools & settings", {"action": "menu", "m": "tools"}, icon=ic("tools"), art={"fanart": bg("tools")})
    xbmcplugin.endOfDirectory(HANDLE)


MENUS = {
    "movies": [("Popular movies", {"action": "catalog", "kind": "movie"}, True),
               ("Top 10 on streaming services", {"action": "stream_services"}, True),
               ("Browse by genre", {"action": "genres", "kind": "movie"}, True),
               ("Search movies", {"action": "search_menu", "t": "movie"}, True)],
    "tv": [("Just watched", {"action": "recent", "section": "tv"}, True),
           ("Aired this week", {"action": "aired", "src": "tv"}, True),
           ("Popular TV shows", {"action": "catalog", "kind": "series"}, True),
           ("Browse by genre", {"action": "genres", "kind": "series"}, True),
           ("Search TV shows", {"action": "search_menu", "t": "tv"}, True)],
    "anime": [("Just watched", {"action": "recent", "section": "anime"}, True),
           ("Aired this week", {"action": "aired", "src": "anime"}, True),
           ("This season", {"action": "anime_season"}, True),
           ("Trending now", {"action": "anime_list", "src": "trending"}, True),
              ("Most popular", {"action": "anime_list", "src": "popular"}, True),
              ("Search anime", {"action": "search_menu", "t": "anime"}, True)],
    "kdrama": [("Just watched", {"action": "recent", "section": "kdrama"}, True),
           ("Aired this week", {"action": "aired", "src": "kdrama"}, True),
           ("Popular K-dramas", {"action": "kdrama_list", "mode": "popular"}, True),
               ("Top rated", {"action": "kdrama_list", "mode": "top"}, True),
               ("Airing recently", {"action": "kdrama_list", "mode": "airing"}, True),
               ("Search K-dramas", {"action": "search_menu", "t": "kdrama"}, True)],
    "music": [("Top albums", {"action": "music_albums", "src": "chart"}, True),
              ("New releases", {"action": "music_albums", "src": "new"}, True),
              ("Top artists", {"action": "music_artists", "src": "chart"}, True),
              ("Browse by genre", {"action": "music_genres"}, True),
              ("Search artists", {"action": "music_search", "t": "artist"}, False),
              ("Search albums", {"action": "music_search", "t": "album"}, False),
              ("Search torrents by name...", {"action": "music_free"}, False)],
    "cloud": [("My Torrents", {"action": "list", "kind": "torrents"}, True),
              ("My Usenet", {"action": "list", "kind": "usenet"}, True),
              ("My Web Downloads", {"action": "list", "kind": "webdl"}, True),
              ("My Real-Debrid torrents", {"action": "svc_cloud", "svc": "rd"}, True),
              ("My Cocoleech torrents", {"action": "svc_cloud", "svc": "cl"}, True),
              ("Add magnet link...", {"action": "add_magnet"}, False),
              ("Cocoleech (file-host links)", {"action": "coco_menu"}, True)],
    "tools": [              ("Cocoleech (file-host links)", {"action": "coco_menu"}, True),
              ("CocoScrapers: choose providers", {"action": "coco_settings"}, False),
              ("Set TMDB key (K-Dramas)", {"action": "tmdb_login"}, False),
              ("Torrent sites: on/off & web addresses", {"action": "sites"}, False),
              ("Usenet: set up indexers", {"action": "usenet_setup"}, False),
              ("Test scrapers", {"action": "test_scrapers"}, False),
              ("Account info", {"action": "account"}, False),
              ("Change TorBox API key", {"action": "login"}, False),
              ("Import keys from the older TorBox add-on", {"action": "import_keys"}, False),
              ("Check saved data (watched list)", {"action": "data_check"}, False),
              ("Error log", {"action": "log_view"}, False),
              ("Smoother streaming (bigger video buffer)...", {"action": "buffer_setup"}, False),
              ("Real-Debrid account (log in with a code)", {"action": "rd_menu"}, False),
              ("Settings", {"action": "settings"}, False)],
}


def submenu(mm):
    for label, params, folder in MENUS.get(mm, []):
        add_dir(label, params, folder=folder, icon=item_icon(mm, params))
    xbmcplugin.endOfDirectory(HANDLE)


def fail(msg):
    notify(msg, xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.endOfDirectory(HANDLE, False)


COUNTRY_NAMES = {"US": "USA", "GB": "UK", "UK": "UK", "JP": "Japan", "KR": "South Korea", "CN": "China", "TW": "Taiwan",
                 "HK": "Hong Kong", "FR": "France", "DE": "Germany", "ES": "Spain", "IT": "Italy", "IN": "India",
                 "CA": "Canada", "AU": "Australia", "NZ": "New Zealand", "IE": "Ireland", "SE": "Sweden", "DK": "Denmark",
                 "NO": "Norway", "FI": "Finland", "NL": "Netherlands", "BE": "Belgium", "BR": "Brazil", "MX": "Mexico",
                 "TH": "Thailand", "PH": "Philippines", "TR": "Turkey", "RU": "Russia", "PL": "Poland", "AR": "Argentina",
                 "United States": "USA", "United Kingdom": "UK"}
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def nice_date(iso):
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", iso or "")
    if not m:
        return ""
    return "%d %s %s" % (int(m.group(3)), MONTHS[int(m.group(2)) - 1], m.group(1))


def when_text(released, country="", verb="released"):
    """Grey ' - released 1 Mar 2024 (USA)' bit for list labels; '' if there's no full date."""
    nd = nice_date(released)
    if not nd:
        return ""
    names = [COUNTRY_NAMES.get(c.strip(), c.strip()) for c in (country or "").split(",") if c.strip()]
    if verb == "released" and not names:
        verb = "first released"
    return "  [COLOR grey]%s %s%s[/COLOR]" % (verb, nd, (" (%s)" % ", ".join(names[:2])) if names else "")


def dated(name, year, it, verb="released"):
    return year_label(name, year) + when_text(it.get("released"), it.get("country"), verb)


def year_label(name, year):
    return "%s (%s)" % (name, year) if year else name


def catalog(p):
    kind, genre, skip, q = p["kind"], p.get("genre"), int(p.get("skip") or 0), p.get("q")
    try:
        items = catalog_mod.cinemeta_catalog(kind, genre, skip, search=q)
    except Exception as e:
        items, err = None, e
    tm = {cm: tg for _, cm, tg in catalog_mod.TV_GENRES if cm and tg}
    if not items and kind != "movie" and genre in tm and not skip and ADDON.getSetting("tmdb_key").strip():
        try:  # Cinemeta had nothing for this genre: use TMDB's list instead
            return tv_genre_tmdb({"action": "tmdb_genre", "genre": tm[genre]}, catalog_mod.tmdb_tv_discover(
                ADDON.getSetting("tmdb_key").strip(), 1, tm[genre]), 1)
        except Exception as e:
            tublog.warn("TMDB %s list: %s" % (genre, e))
    if items is None:
        return fail("Could not load %s: %s" % ("search results" if q else "catalog", err))
    if not items and not q:
        add_dir("[COLOR orange]Nothing found here right now[/COLOR]%s" % (
            "  [COLOR grey]- a free TMDB key (Settings > 1. Accounts) gives a backup list[/COLOR]" if genre in tm else ""),
            {"action": "noop"}, folder=False)
    if q and not items:
        add_dir("[COLOR orange]No %s called \"%s\" found[/COLOR]" % ("movies" if kind == "movie" else "TV shows", q),
                {"action": "noop"}, folder=False)
        add_dir("Search torrents for \"%s\" as free text instead" % q, {"action": "results", "q": q}, icon=ic("search"))
    wdata = watched.load()
    for it in items:
        art = {"poster": it["poster"], "thumb": it["poster"], "fanart": it["fanart"]}
        if kind == "movie":
            params = {"action": "results", "q": it["name"], "imdb": it["imdb"], "title": it["name"],
                      "year": it["year"], "name": (it["name"] + " " + it["year"]).strip()}
        else:
            params = {"action": "seasons", "imdb": it["imdb"], "title": it["name"], "year": it["year"],
                      "poster": it["poster"]}
        if q:
            params["fs"] = 1  # opened from a search: remember it in recent searches
        if kind == "movie":
            params["poster"] = it["poster"]
            wk = "mv:%s" % it["imdb"]
            add_dir(dated(it["name"], it["year"], it), params, art=art, plot=it["plot"], year=it["year"],
                    media="movie", seen=wk in wdata["watched"], ctx=seen_ctx(wk), premiered=it.get("released"),
                    country=it.get("country"))
            continue
        add_dir(dated(it["name"], it["year"], it, "first aired"), params, art=art, plot=it["plot"], year=it["year"],
                media="tvshow", premiered=it.get("released"), country=it.get("country"))
    if items and not q:
        add_dir("[B]Next page >>[/B]", {"action": "catalog", "kind": kind, "genre": genre, "skip": skip + len(items)})
    xbmcplugin.setContent(HANDLE, "movies" if kind == "movie" else "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def tv_genre_tmdb(p, items, page):
    """TV shows from TMDB (opened by looking up their IMDb id) - used for dating shows and as a fallback."""
    for it in items:
        art = {"poster": it["poster"], "thumb": it["poster"], "fanart": it["fanart"]}
        add_dir(dated(it["title"], it["year"], it, "first aired"),
                {"action": "tv_open", "id": it["id"], "title": it["title"], "year": it["year"], "poster": it["poster"]},
                art=art, plot=it["plot"], year=it["year"], media="tvshow", premiered=it.get("released"),
                country=it.get("country"))
    if len(items) >= 20:
        add_dir("[B]Next page >>[/B]", dict(p, page=page + 1))
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def dating(p):
    """Dating shows: TMDB's dating-show tags when you have a TMDB key, else reality shows with dating-type names."""
    key = ADDON.getSetting("tmdb_key").strip()
    page = int(p.get("page") or 1)
    if key:
        try:
            kws = cached_call("tmdb_dating_kw", 30 * 86400, catalog_mod.tmdb_dating_keywords, key)
            items = cached_call("tmdb_tv_discover", 6 * 3600, catalog_mod.tmdb_tv_discover, key, page, 10764, kws) if kws else []
            if items or page > 1:
                return tv_genre_tmdb(p, items, page)
        except Exception as e:
            tublog.warn("TMDB dating shows: %s - using Cinemeta's reality list instead" % e)
    skip, found, raw = int(p.get("skip") or 0), [], 0
    try:
        for _ in range(5):  # look through a few pages of reality shows for dating-type names
            batch = cached_call("cinemeta", 6 * 3600, catalog_mod.cinemeta_catalog, "series", "Reality-TV", skip + raw)
            if not batch:
                break
            raw += len(batch)
            found += [it for it in batch if catalog_mod.DATING_RX.search(it["name"])]
            if len(found) >= 20:
                break
    except Exception as e:
        return fail("Could not load dating shows: %s" % e)
    if not key and skip == 0:
        add_dir("[COLOR grey]Tip: add a free TMDB key (Settings > 1. Accounts) for a fuller dating-show list[/COLOR]",
                {"action": "noop"}, folder=False)
    for it in found:
        art = {"poster": it["poster"], "thumb": it["poster"], "fanart": it["fanart"]}
        add_dir(dated(it["name"], it["year"], it, "first aired"),
                {"action": "seasons", "imdb": it["imdb"], "title": it["name"], "year": it["year"], "poster": it["poster"]},
                art=art, plot=it["plot"], year=it["year"], media="tvshow", premiered=it.get("released"),
                country=it.get("country"))
    if raw:
        add_dir("[B]Next page >>[/B]", dict(p, skip=skip + raw))
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def tv_open(p):
    """A TMDB show -> its IMDb id -> the normal seasons list."""
    key = ADDON.getSetting("tmdb_key").strip()
    imdb = ""
    try:
        imdb = cached_call("tmdb_show", 30 * 86400, catalog_mod.tmdb_show, key, p["id"]).get("imdb") or ""
    except Exception as e:
        tublog.warn("TMDB show %s: %s" % (p.get("id"), e))
    if imdb:
        return seasons({"imdb": imdb, "title": p.get("title"), "year": p.get("year"), "poster": p.get("poster")})
    notify("No IMDb id for this show - searching by name instead", xbmcgui.NOTIFICATION_WARNING)
    return results({"action": "results", "q": p.get("title"), "title": p.get("title"), "name": p.get("title"),
                    "year": p.get("year"), "show": 1, "poster": p.get("poster")})


def genres(kind):
    if kind != "movie":  # TV-only genres first: Reality, Dating shows, Game shows
        for label, cm, _ in catalog_mod.TV_GENRES:
            add_dir(label, {"action": "catalog", "kind": kind, "genre": cm} if cm else {"action": "dating"}, icon=ic("tv_tag"))
    for g in catalog_mod.GENRES:
        add_dir(g, {"action": "catalog", "kind": kind, "genre": g}, icon=ic("movies_tag" if kind == "movie" else "tv_tag"))
    xbmcplugin.endOfDirectory(HANDLE)


def seasons(p):
    try:
        eps, meta = catalog_mod.cinemeta_episodes(p["imdb"])
    except Exception as e:
        return fail("Could not load episodes: %s" % e)
    poster = p.get("poster") or meta.get("poster")
    base = {"imdb": p["imdb"], "title": p.get("title"), "year": p.get("year"), "poster": poster, "kdrama": p.get("kdrama")}
    nums = sorted(set(e["season"] for e in eps))
    wdata = watched.load()
    if p.get("fs"):
        hist_add("kdrama" if p.get("kdrama") else "tv", year_label(p.get("title") or meta.get("name") or "?", p.get("year")),
                 {k: v for k, v in p.items() if k != "fs"})
    about = [x for x in (meta.get("releaseInfo") or p.get("year"), ", ".join((meta.get("genres") or [])[:3]),
                         ("IMDb %s" % meta["imdbRating"]) if meta.get("imdbRating") else "",
                         "%d season%s" % (len([n for n in nums if n]), "" if len([n for n in nums if n]) == 1 else "s")) if x]
    add_dir("[COLOR deepskyblue][B]About this show[/B][/COLOR]  [COLOR grey]%s[/COLOR]" % " | ".join(about),
            {"action": "show_about", "imdb": p["imdb"], "title": p.get("title")}, folder=False,
            plot=meta.get("description") or "", art={"poster": poster, "thumb": poster, "fanart": meta.get("background")},
            icon=ic("tv"))
    add_dir("[B]Search the whole show (all seasons & episodes)[/B]",
            {"action": "results", "q": p.get("title"), "imdb": p["imdb"], "title": p.get("title"), "year": p.get("year"), "name": p.get("title"), "show": 1,
             "kdrama": p.get("kdrama"), "poster": poster}, icon=ic("search"))
    sec = "kdrama" if p.get("kdrama") else "tv"
    for s in nums:
        count = len([e for e in eps if e["season"] == s])
        prefix = "%s:%s:%d:" % (sec, p["imdb"], s)
        done = watched.count_prefix(wdata, prefix)
        firsts = sorted(e["aired"] for e in eps if e["season"] == s and e.get("aired"))
        when = (" | %s" % firsts[0][:4]) if firsts else ""
        prog_ = ("[COLOR lightgreen]%d/%d watched[/COLOR]" % (done, count)) if done else "%d episodes" % count
        add_dir(("Season %d" % s if s else "Specials") + "  [COLOR grey]%s%s[/COLOR]" % (prog_, when),
                dict(base, action="episodes", season=s), art={"poster": poster, "thumb": poster}, media="season",
                seen=(done >= count > 0) or None, ctx=season_ctx(prefix, count))
    add_dir("Enter season / episode number...", dict(base, action="manual_ep"), folder=False, icon=ic("search"))
    xbmcplugin.setContent(HANDLE, "seasons")
    xbmcplugin.endOfDirectory(HANDLE)


def episode_params(base, season, ep):
    return {"action": "results", "q": base.get("title"), "imdb": base.get("imdb"), "title": base.get("title"),
            "year": base.get("year"), "name": base.get("title"), "season": season, "ep": ep,
            "kdrama": base.get("kdrama"), "tmdb": base.get("tmdb"), "poster": base.get("poster")}


def episodes(p):
    try:
        eps, _ = catalog_mod.cinemeta_episodes(p["imdb"])
    except Exception as e:
        return fail("Could not load episodes: %s" % e)
    s = int(p["season"])
    wdata = watched.load()
    sec = "kdrama" if p.get("kdrama") else "tv"
    add_dir("[B]Full season pack (Season %d)[/B]" % s, dict(episode_params(p, s, None), pack=1, action="results"),
            icon=ic("tv"))
    for e in sorted([x for x in eps if x["season"] == s], key=lambda x: x["episode"]):
        wk = "%s:%s:%d:%d" % (sec, p["imdb"], s, e["episode"])
        add_dir("%d. %s" % (e["episode"], e["title"] or "Episode %d" % e["episode"]),
                episode_params(p, s, e["episode"]), plot=e["plot"], art={"thumb": e["thumb"] or p.get("poster")},
                media="episode", seen=wk in wdata["watched"], ctx=seen_ctx(wk))
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def manual_ep(p):
    d = xbmcgui.Dialog()
    s = d.input("Season number", type=xbmcgui.INPUT_NUMERIC).strip()
    e = d.input("Episode number", type=xbmcgui.INPUT_NUMERIC).strip()
    if s.isdigit() and e.isdigit():
        xbmc.executebuiltin("Container.Update(%s)" % url(**episode_params(p, int(s), int(e))))


# ---------------- anime (Kitsu) ----------------
def anime_list(p):
    src, off, q = p.get("src"), int(p.get("offset") or 0), p.get("q")
    try:
        if src == "search":
            items = catalog_mod.kitsu_search(q, off)
        elif src == "popular":
            items = catalog_mod.kitsu_popular(off)
        else:
            items = catalog_mod.kitsu_trending()
    except Exception as e:
        return fail("Could not load anime: %s" % e)
    for it in items:
        movie = it["subtype"] == "movie"
        base = {"kitsu": it["id"], "title": it["title"], "alt": it["alt"], "year": it["year"], "anime": 1,
                "poster": it["poster"]}
        params = dict(base, action="results", q=it["title"], movie=1) if movie else \
            dict(base, action="anime_eps", eps=it["episodes"] or 0)
        label = year_label(it["title"], it["year"]) + (" [movie]" if movie else "") + \
            when_text(it.get("released"), it.get("country"), "released" if movie else "first aired")
        add_dir(label, params, art={"poster": it["poster"], "thumb": it["poster"], "fanart": it["fanart"]},
                plot=it["plot"], year=it["year"], media="movie" if movie else "tvshow", premiered=it.get("released"),
                country=it.get("country"))
    if src != "trending" and len(items) >= 20:
        add_dir("[B]Next page >>[/B]", {"action": "anime_list", "src": src, "q": q, "offset": off + 20})
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def anime_search():
    q = xbmcgui.Dialog().input("Search anime").strip()
    xbmcplugin.endOfDirectory(HANDLE, False)
    if q:
        xbmc.executebuiltin("Container.Update(%s)" % url(action="anime_list", src="search", q=q))


def anime_eps(p):
    kid = p.get("kitsu")
    info = {"show": {}, "eps": {}}
    if kid:
        try:
            info = cached_call("anime_eps_%s" % kid, 6 * 3600, catalog_mod.anime_episode_info, kid)
        except Exception as e:
            tublog.warn("Episode names for '%s' unavailable: %s" % (p.get("title"), e))
    show, names = info.get("show") or {}, info.get("eps") or {}
    total = int(p.get("eps") or 0) or int(show.get("eps") or 0) or max([int(n) for n in names] or [0])
    base = {k: p.get(k) for k in ("kitsu", "title", "alt", "year", "anime", "poster", "eps")}
    poster = p.get("poster") or show.get("poster")
    about = show.get("plot") or ""
    wdata = watched.load()
    if about:
        bits = [x for x in ((show.get("type") or "").upper(), show.get("year"), ("%s episodes" % show["eps"]) if show.get("eps") else "",
                            ("%s min each" % show["length"]) if show.get("length") else "",
                            {"current": "still airing", "finished": "finished"}.get(show.get("status"), ""),
                            ("rated %s%%" % show["rating"]) if show.get("rating") else "", show.get("age")) if x]
        add_dir("[COLOR deepskyblue][B]About this show[/B][/COLOR]  [COLOR grey]%s[/COLOR]" % " | ".join(bits),
                {"action": "anime_about", "kitsu": kid, "title": p.get("title")}, folder=False, plot=about,
                art={"thumb": poster, "poster": poster, "fanart": show.get("fanart")}, icon=ic("anime"))
    add_dir("[B]Search the whole show (any episode)[/B]", dict(base, action="results", q=p.get("title"), show=1),
            icon=ic("search"), plot=about)
    add_dir("[B]Full series / batch pack[/B]", dict(base, action="results", q=p.get("title"), pack=1), icon=ic("anime_list"),
            plot=about)
    add_dir("[B]Enter episode number...[/B]", dict(base, action="anime_manual", eps=total), folder=False, icon=ic("search"))
    for n in range(1, (total or 12) + 1):
        wk = "an:%s:%d" % (kid, n)
        e = names.get(str(n)) or {}
        label = "%d. %s" % (n, e["title"]) if e.get("title") else "Episode %d" % n
        if e.get("filler"):
            label += "  [COLOR orange](filler)[/COLOR]"
        elif e.get("recap"):
            label += "  [COLOR orange](recap)[/COLOR]"
        if e.get("aired"):
            label += "  [COLOR grey]%s[/COLOR]" % e["aired"][:10]
        plot = e.get("plot") or ("%s\n\n%s" % (e.get("title") or "Episode %d" % n, about) if about else "")
        add_dir(label, dict(base, action="results", q=p.get("title"), ep=n), media="episode", plot=plot,
                art={"thumb": e.get("thumb") or poster, "fanart": show.get("fanart")}, seen=wk in wdata["watched"],
                ctx=seen_ctx(wk))
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def anime_about(p):
    kid = p.get("kitsu")
    try:
        info = cached_call("anime_eps_%s" % kid, 6 * 3600, catalog_mod.anime_episode_info, kid)
    except Exception as e:
        return notify("Couldn't load the details: %s" % e, xbmcgui.NOTIFICATION_WARNING)
    s = info.get("show") or {}
    head = s.get("title") or p.get("title") or ""
    if s.get("jp") and s["jp"] != head:
        head += "  [COLOR grey](%s)[/COLOR]" % s["jp"]
    xbmcgui.Dialog().textviewer(NAME + " - " + (s.get("title") or p.get("title") or ""),
                                "[B]%s[/B]\n\n%s" % (head, s.get("plot") or "No description available."))


def anime_manual(p):
    n = xbmcgui.Dialog().input("Episode number", type=xbmcgui.INPUT_NUMERIC).strip()
    if n.isdigit():
        params = {k: p.get(k) for k in ("kitsu", "title", "alt", "year", "anime", "poster", "eps")}
        xbmc.executebuiltin("Container.Update(%s)" % url(action="results", q=p.get("title"), ep=int(n), **params))


# ---------------- K-dramas (TMDB) ----------------
# ---------------- music (Deezer) ----------------
def album_params(a, artist=None):
    artist = a.get("artist") or artist or ""
    return {"action": "results", "music": 1, "artist": artist, "title": a["title"],
            "q": ("%s %s" % (artist, a["title"])).strip(), "year": a.get("year"), "cover": a.get("cover"),
            "released": a.get("released")}


def fill_album_info(items):
    """Chart / search lists from Deezer leave out release dates - look them up (remembered, so only once each)."""
    known = store_load("dz_albums.json", {})
    need = [a for a in items if not a.get("released") and str(a.get("id")) not in known][:50]
    if need:
        from concurrent.futures import ThreadPoolExecutor

        def one(a):
            try:
                return str(a["id"]), catalog_mod.deezer_album_info(a["id"])
            except Exception:
                return str(a["id"]), None
        with ThreadPoolExecutor(max_workers=8) as ex:
            for k, v in ex.map(one, need):
                if v:
                    known[k] = v
        if len(known) > 3000:
            known = dict(list(known.items())[-2000:])
        store_save("dz_albums.json", known)
    for a in items:
        k = known.get(str(a.get("id"))) or {}
        for f in ("released", "type", "tracks"):
            if not a.get(f) and k.get(f):
                a[f] = k[f]
        if not a.get("year") and a.get("released"):
            a["year"] = a["released"][:4]


def show_albums(items, artist=None):
    try:
        fill_album_info(items)
    except Exception as e:
        tublog.warn("Album dates: %s" % e)
    for a in items:
        who = a.get("artist") or artist or ""
        bits = [x for x in (nice_date(a.get("released")) or a.get("year"),
                            {"album": "Album", "ep": "EP", "single": "Single", "compile": "Compilation"}.get(a.get("type"), ""),
                            ("%d tracks" % a["tracks"]) if a.get("tracks") else "") if x]
        label = "%s  [COLOR grey]- %s[/COLOR]" % (a["title"], who) if who else a["title"]
        if bits:
            label += "  [COLOR grey](%s)[/COLOR]" % " | ".join(bits)
        li_plot = "%s\nby %s\n%s" % (a["title"], who, " | ".join(bits))
        add_dir(label, album_params(a, artist), art={"poster": a.get("cover"), "thumb": a.get("cover")},
                year=a.get("year"), media="album", plot=li_plot)
    xbmcplugin.setContent(HANDLE, "albums")


def show_artists(items):
    for a in items:
        add_dir(a["name"], {"action": "music_artist", "id": a["id"], "artist": a["name"]},
                art={"poster": a.get("picture"), "thumb": a.get("picture")}, media="artist")
    xbmcplugin.setContent(HANDLE, "artists")


def music_albums(p):
    src = p.get("src")
    try:
        if src == "new":
            items = catalog_mod.deezer_new()
        elif src == "genre":
            items = catalog_mod.deezer_chart_albums(p.get("genre", 0))
        elif src == "search":
            items = catalog_mod.deezer_search_albums(p.get("q", ""))
        else:
            items = catalog_mod.deezer_chart_albums()
    except Exception as e:
        return fail("Could not load music: %s" % e)
    show_albums(items)
    xbmcplugin.endOfDirectory(HANDLE)


def music_artists(p):
    try:
        items = (catalog_mod.deezer_search_artists(p.get("q", "")) if p.get("src") == "search"
                 else catalog_mod.deezer_chart_artists())
    except Exception as e:
        return fail("Could not load music: %s" % e)
    show_artists(items)
    xbmcplugin.endOfDirectory(HANDLE)


def music_genres():
    try:
        genres_ = catalog_mod.deezer_genres()
    except Exception as e:
        return fail("Could not load genres: %s" % e)
    for g in genres_:
        add_dir(g["name"], {"action": "music_albums", "src": "genre", "genre": g["id"]}, icon=ic("music_tag"))
    xbmcplugin.endOfDirectory(HANDLE)


def music_artist(p):
    try:
        items = catalog_mod.deezer_artist_albums(p["id"])
    except Exception as e:
        return fail("Could not load albums: %s" % e)
    add_dir("[B]Find %s torrents (discography / any)[/B]" % p.get("artist", "artist"),
            {"action": "results", "music": 1, "artist": p.get("artist"), "title": "discography", "q": p.get("artist")},
            icon=ic("music"))
    show_albums(items, p.get("artist"))
    xbmcplugin.endOfDirectory(HANDLE)


def music_search(t):
    q = xbmcgui.Dialog().input("Search artists" if t == "artist" else "Search albums").strip()
    xbmcplugin.endOfDirectory(HANDLE, False)
    if q:
        xbmc.executebuiltin("Container.Update(%s)" % url(action="music_artists" if t == "artist" else "music_albums",
                                                          src="search", q=q))


def music_free():
    q = xbmcgui.Dialog().input("Artist / album / torrent name").strip()
    xbmcplugin.endOfDirectory(HANDLE, False)
    if q:
        xbmc.executebuiltin("Container.Update(%s)" % url(action="results", music=1, q=q, title=q))


def tmdb_login(force=False):
    key = ADDON.getSetting("tmdb_key").strip()
    if key and not force:
        return key
    key = xbmcgui.Dialog().input("Paste your free TMDB API key (v3) - themoviedb.org > Settings > API",
                                 defaultt=ADDON.getSetting("tmdb_key")).strip()
    if not key:
        return ""
    try:
        catalog_mod.tmdb_check(key)
    except Exception as e:
        xbmcgui.Dialog().ok(NAME, "TMDB rejected that key:\n%s" % e)
        return ""
    ADDON.setSetting("tmdb_key", key)
    notify("TMDB key saved")
    return key


def tmdb_key():
    return tmdb_login()


def set_host(key, label, default):
    h = xbmcgui.Dialog().input(label, defaultt=ADDON.getSetting(key) or default).strip()
    if h:
        if not h.startswith("http"):
            h = "https://" + h
        ADDON.setSetting(key, h.rstrip("/"))
        notify("Address saved")


def kdrama_list(p):
    key = tmdb_key()
    if not key:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    mode, page, q = p.get("mode", "popular"), int(p.get("page") or 1), p.get("q")
    try:
        items = catalog_mod.kdrama_list(key, mode, page, q)
    except Exception as e:
        return fail("TMDB error: %s" % e)
    for it in items:
        add_dir(dated(it["title"], it["year"], it, "first aired"),
                {"action": "tmdb_seasons", "id": it["id"], "title": it["title"], "year": it["year"], "poster": it["poster"]},
                art={"poster": it["poster"], "thumb": it["poster"], "fanart": it["fanart"]},
                plot=it["plot"], year=it["year"], media="tvshow", premiered=it.get("released"), country=it.get("country"))
    if items:
        add_dir("[B]Next page >>[/B]", {"action": "kdrama_list", "mode": mode, "q": q, "page": page + 1})
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def kdrama_search():
    if not tmdb_key():
        return xbmcplugin.endOfDirectory(HANDLE, False)
    q = xbmcgui.Dialog().input("Search K-dramas").strip()
    xbmcplugin.endOfDirectory(HANDLE, False)
    if q:
        xbmc.executebuiltin("Container.Update(%s)" % url(action="kdrama_list", mode="search", q=q))


def tmdb_seasons(p):
    key = tmdb_key()
    if not key:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    try:
        show = catalog_mod.tmdb_show(key, p["id"])
    except Exception as e:
        return fail("TMDB error: %s" % e)
    wdata = watched.load()
    sid = show["imdb"] or "tmdb%s" % p["id"]
    add_dir("[B]Search the whole show (all seasons & episodes)[/B]",
            {"action": "results", "q": show["title"], "imdb": show["imdb"], "title": show["title"], "year": show["year"], "name": show["title"], "show": 1,
             "kdrama": 1, "poster": p.get("poster")}, icon=ic("search"))
    for s in show["seasons"]:
        prefix = "kdrama:%s:%d:" % (sid, s["season"])
        done = watched.count_prefix(wdata, prefix)
        poster = s["poster"] or p.get("poster")
        add_dir("%s (%d/%d watched)" % (s["name"], done, s["count"]),
                {"action": "tmdb_episodes", "id": p["id"], "season": s["season"], "title": show["title"],
                 "year": show["year"], "imdb": show["imdb"], "poster": p.get("poster") or poster},
                plot=s["plot"], art={"poster": poster, "thumb": poster}, media="season",
                seen=(done >= s["count"] > 0) or None, ctx=season_ctx(prefix, s["count"]))
    xbmcplugin.setContent(HANDLE, "seasons")
    xbmcplugin.endOfDirectory(HANDLE)


def tmdb_episodes(p):
    key = tmdb_key()
    if not key:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    try:
        eps = catalog_mod.tmdb_episodes(key, p["id"], p["season"])
    except Exception as e:
        return fail("TMDB error: %s" % e)
    base = {"title": p.get("title"), "year": p.get("year"), "imdb": p.get("imdb"), "kdrama": 1, "tmdb": p["id"],
            "poster": p.get("poster")}
    wdata = watched.load()
    sid = p.get("imdb") or "tmdb%s" % p["id"]
    add_dir("[B]Full season pack (Season %s)[/B]" % p["season"],
            dict(episode_params(base, p["season"], None), pack=1, action="results"), icon=ic("kdrama"))
    for e in eps:
        wk = "kdrama:%s:%d:%d" % (sid, int(p["season"]), e["episode"])
        add_dir("%d. %s" % (e["episode"], e["title"] or "Episode %d" % e["episode"]),
                episode_params(base, p["season"], e["episode"]), plot=e["plot"],
                art={"thumb": e["thumb"] or p.get("poster")}, media="episode", seen=wk in wdata["watched"],
                ctx=seen_ctx(wk))
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def list_items(kind):
    api = get_api()
    if not api:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    try:
        items = api.mylist(kind)
    except TorBoxError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    for it in items:
        ready = it.get("download_finished") or it.get("download_present") or it.get("cached")
        state = "READY" if ready else (it.get("download_state") or "pending").upper()
        label = "%s [%s | %s]" % (it.get("name", "?"), fmt_size(it.get("size")), state)
        ctx = [("Delete from TorBox",
                "RunPlugin(%s)" % url(action="delete", kind=kind, id=it["id"]))]
        add_dir(label, {"action": "files", "kind": kind, "id": it["id"]}, ctx=ctx)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


_TECH = re.compile(r"(?i)\b(?:\d{1,2}[ ._-]?bits?|hi10p?|10bpp|ma10p?|(?:dd|ddp|eac3|e-ac-3|ac3|aac|flac|opus|dts|truehd|atmos|lpcm)"
                   r"[ ._-]?\d(?:[ ._]\d)?|\d\.\d(?:ch)?|\d{3,4}[pi]|\d{3,4}x\d{3,4}|[xh][ ._-]?26[45]|hevc|avc|av1|"
                   r"(?:19|20)\d\d|s\d{1,2}(?![ ._-]*e\d))\b|\[[0-9a-f]{8}\]|\([0-9a-f]{8}\)")


def ep_name(name):
    """File name without the technical tags that look like episode numbers ("10-bit", "5.1", "1080p", years...)."""
    return _TECH.sub(" ", os.path.splitext(os.path.basename(name or ""))[0])


def pick_video(files, season=None, ep=None, anime=False, fname=None):
    """Pick the right video file. Returns None when a multi-file torrent has no clear match for the episode
    (the caller then lets you choose) instead of guessing."""
    vids = [f for f in files if is_video(f.get("name", ""))]
    if not vids:
        return None
    if fname:  # exact file name supplied by the scraper (Torrentio etc.)
        want = os.path.basename(fname).lower()
        hit = [f for f in vids if os.path.basename(f.get("name", "")).lower() == want]
        if hit:
            return hit[0]
    if not ep or ADDON.getSetting("pick_episode") == "false" or len(vids) == 1:
        return max(vids, key=lambda f: f.get("size", 0)) if (len(vids) == 1 or not ep) else None
    e = int(ep)
    pats = []
    if season:
        s = int(season)
        pats.append(r"s0*%d[ ._-]*e0*%d(?!\d)|\b0*%dx0*%d(?!\d)" % (s, e, s, e))
    else:
        pats.append(r"s\d{1,2}[ ._-]*e0*%d(?!\d)" % e)                       # S01E01 inside anime batches
    pats.append(r"(?:\be|\bep|episode)[ ._-]*0*%d(?!\d)" % e)                # E01 / Ep 1 / Episode 1
    if anime or not season:
        pats.append(r"(?:^|[\s._\-\[(])0*%d(?:v\d)?(?=$|[\s._\-\])])" % e)  # " - 01 ", "[01]"
    for k, pat in enumerate(pats):
        rx = re.compile(pat, re.I)
        hit = [f for f in vids if rx.search(ep_name(f.get("name", "")))]
        if len(hit) > 1 and k == len(pats) - 1 and (anime or not season):
            # loose "- 10" style match found several files: try the usual " - 10 " spot, else let you choose
            strict = re.compile(r"(?:^|\s)-\s*0*%d(?:v\d)?(?=$|[\s._\])\[])|_0*%d_" % (e, e), re.I)
            hit = [f for f in hit if strict.search(ep_name(f.get("name", "")))]
            if len(set(os.path.basename(f.get("name", "")) for f in hit)) != 1:
                return None
        if hit:
            return max(hit, key=lambda f: f.get("size", 0))
    return None


def list_files(kind, item_id):
    api = get_api()
    if not api:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    try:
        item = api.mylist(kind, item_id)
    except TorBoxError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    files = (item or {}).get("files") or []
    if not files:
        notify("No files yet - TorBox may still be downloading this item")
        return xbmcplugin.endOfDirectory(HANDLE, False)
    for f in sorted(files, key=lambda f: f.get("name", "")):
        name = f.get("short_name") or os.path.basename(f.get("name", "")) or str(f.get("id"))
        vid = is_video(f.get("name", ""))
        dl = [("Download to...", "RunPlugin(%s)" % url(action="file_download", kind=kind, id=item_id, file=f["id"],
                                                         name=name))]
        if vid:
            add_dir("%s [%s]" % (name, fmt_size(f.get("size"))),
                    {"action": "play", "kind": kind, "id": item_id, "file": f["id"]},
                    folder=False, playable=True, ctx=dl)
        else:
            tag = "  [COLOR orange](zip - play inside or extract)[/COLOR]" if name.lower().endswith(".zip") else \
                ("  [COLOR orange](archive - download & extract)[/COLOR]" if is_archive(name) else "")
            add_dir("%s [%s]%s" % (name, fmt_size(f.get("size")), tag),
                    {"action": "tb_file", "kind": kind, "id": item_id, "file": f["id"], "name": name,
                     "size": f.get("size") or 0}, folder=False, ctx=dl)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)


def resolve(kind, item_id, file_id, p=None):
    api = get_api()
    if not api:
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    try:
        link = api.request_dl(kind, item_id, file_id)
    except TorBoxError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)
        link = None
    if not link:
        link = api.redirect_url(kind, item_id, file_id)
    li = xbmcgui.ListItem(path=link)
    if p and p.get("m"):
        set_music_info(li, p.get("title", ""), p.get("artist", ""), p.get("album", ""), p.get("track") or 0, p.get("y"))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play(kind, item_id, file_id, p=None):
    track(None)
    resolve(kind, item_id, file_id, p)


def delete(kind, item_id):
    if not xbmcgui.Dialog().yesno(NAME, "Delete this item from your TorBox account?"):
        return
    api = get_api()
    try:
        api.delete(kind, item_id)
        notify("Deleted")
        xbmc.executebuiltin("Container.Refresh")
    except TorBoxError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)


def add_magnet(magnet=None):
    api = get_api()
    if not api:
        return
    if not magnet:
        magnet = xbmcgui.Dialog().input("Paste magnet link or infohash").strip()
    if not magnet:
        return
    if not magnet.startswith("magnet:"):
        magnet = "magnet:?xt=urn:btih:" + magnet
    try:
        api.add_magnet(magnet)
        notify("Added to TorBox")
    except TorBoxError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)


def scraper_ctx(p):
    ctx = {"timeout": int(ADDON.getSetting("scrape_timeout") or 15), "query": p.get("q", ""),
           "imdb": p.get("imdb"), "season": p.get("season"), "episode": p.get("ep"),
           "title": p.get("title"), "year": p.get("year"),
           "nyaa_host": ADDON.getSetting("nyaa_host").strip(),
           "apibay_host": ADDON.getSetting("apibay_host").strip()}
    if p.get("music"):
        ctx.update(imdb=None, season=None, episode=None, music=True, media="music", title=p.get("q", ""), alt=None,
                   nyaa_cat="2_0", nyaa_ep="")
        return ctx
    pack = bool(p.get("pack"))
    if p.get("anime"):
        movie, ep = bool(p.get("movie")), p.get("ep")
        epn = "batch" if pack else (("%02d" % int(ep)) if ep and not movie else "")
        ctx.update(imdb=None, season=None, episode=None, anime=True, media="anime", alt=p.get("alt"), audio=p.get("audio", "any"),
                   sid=None if not p.get("kitsu") else
                   ("kitsu:%s" % p["kitsu"] if movie else "kitsu:%s:%s" % (p["kitsu"], 1 if (pack or p.get("show")) else ep)),
                   kind="movie" if movie else "series", nyaa_cat="1_0", nyaa_ep=epn, pack=pack,
                   query=("%s %s" % (p.get("title", ""), epn)).strip())
        ctx["show"] = bool(p.get("show"))
        return ctx
    if p.get("show"):  # whole show: no season / episode in the search
        ctx.update(season=None, episode=None, show=True, query=(p.get("title") or p.get("q", "")).strip())
        if p.get("imdb"):
            ctx.update(sid="%s:1:1" % p["imdb"], kind="series")
        if p.get("kdrama"):
            ctx.update(nyaa_cat="4_0", nyaa_ep="")
        ctx["media"] = "kdrama" if p.get("kdrama") else "tv"
        return ctx
    if pack and p.get("season"):
        se = "S%02d" % int(p["season"])
        ctx.update(episode="1", pack=True)  # Torrentio/Coco list season packs alongside episode 1
    else:
        se = ("S%02d" % int(p["season"]) + "E%02d" % int(p["ep"])) if p.get("season") and p.get("ep") else ""
    if p.get("imdb"):
        ctx["query"] = (p.get("name", "") + " " + se).strip()
    elif se:
        ctx["query"] = ("%s %s" % (p.get("title") or p.get("q", ""), se)).strip()
    if p.get("kdrama"):
        ctx.update(nyaa_cat="4_0", nyaa_ep=se)
    ctx["media"] = "kdrama" if p.get("kdrama") else ("tv" if p.get("season") else ("movie" if p.get("imdb") else "free"))
    return ctx


# ---------------- search menus (each with its own recent searches) ----------------
SEARCH_KINDS = {"movie": "Movies", "tv": "TV", "anime": "Anime", "kdrama": "K-Dramas", "free": "Torrent name"}


def hist_kind(h):
    if h.get("kind"):
        return h["kind"]
    pp = h.get("params") or {}
    if pp.get("action") in ("seasons", "tmdb_seasons") or pp.get("season") or pp.get("show") or pp.get("kind") == "series":
        return "kdrama" if pp.get("kdrama") or pp.get("action") == "tmdb_seasons" else "tv"
    if pp.get("anime") or pp.get("action") in ("anime_list", "anime_eps"):
        return "anime"
    if pp.get("imdb") or pp.get("kind") == "movie":
        return "movie"
    return "free"


def hist_add(kind, label, params):
    params = {k: v for k, v in params.items() if v not in (None, "") and k != "fs"}
    hist = [h for h in store_load("history.json", []) if h.get("params") != params]
    hist.insert(0, {"kind": kind, "label": label, "params": params, "ts": int(time.time())})
    store_save("history.json", hist[:80])


def search_menu(p):
    t = p.get("t") or ""
    what = {"movie": "movie", "tv": "TV show", "anime": "anime", "kdrama": "K-drama"}.get(t, "")
    add_dir("[B]New %ssearch...[/B]" % (what + " " if what else ""), {"action": "search_new", "t": t}, folder=False,
            icon=ic("search"))
    if not t:
        add_dir("Search by torrent name (free text)...", {"action": "search_new", "t": "free"}, folder=False,
                icon=ic("search"))
    hist = [h for h in store_load("history.json", []) if not t or hist_kind(h) == t]
    if hist:
        add_dir("[COLOR grey]Recent searches[/COLOR]", {"action": "noop"}, folder=False)
    for h in hist[:30]:
        k = hist_kind(h)
        tag = "" if t else "[COLOR grey][%s][/COLOR] " % SEARCH_KINDS.get(k, k)
        add_dir("    " + tag + h["label"], h["params"], icon=ic("tools_clock"),
                ctx=[("Remove from recent searches", "RunPlugin(%s)" % url(action="hist_remove", i=json.dumps(h["params"],
                                                                                                       sort_keys=True)))])
    if hist:
        add_dir("[COLOR grey]Clear %srecent searches[/COLOR]" % ((SEARCH_KINDS.get(t, "") + " ") if t else "all "),
                {"action": "clear_history", "t": t}, folder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def search_new(p):
    d = xbmcgui.Dialog()
    t = p.get("t") or ""
    if not t:
        i = d.select("Search for", ["Movies", "TV shows", "Anime", "K-dramas", "Torrent name (free text)"])
        if i < 0:
            return
        t = ["movie", "tv", "anime", "kdrama", "free"][i]
    q = d.input({"movie": "Movie title", "tv": "TV show title", "anime": "Anime title", "kdrama": "K-drama title"}
                .get(t, "Torrent name / any words")).strip()
    if not q:
        return
    if t == "movie":
        params = {"action": "catalog", "kind": "movie", "q": q}
    elif t == "tv":
        params = {"action": "catalog", "kind": "series", "q": q}
    elif t == "anime":
        params = {"action": "anime_list", "src": "search", "q": q}
    elif t == "kdrama":
        if not tmdb_key():
            return
        params = {"action": "kdrama_list", "mode": "search", "q": q}
    else:
        params = {"action": "results", "q": q}
    hist_add(t, '"%s"' % q, params)
    xbmc.executebuiltin("Container.Update(%s)" % url(**params))


PK_KINDS = (("ep", "Single episodes"), ("pack", "Season packs"), ("multi", "Complete series / several seasons"))


def pk_set(p):
    if p.get("pk"):
        return {x for x in p["pk"].split(",") if x in ("ep", "pack", "multi")}
    return {"ep", "pack", "multi"}


def pk_toggle(p):
    flip = p.pop("flip", "")
    s = pk_set(p) ^ {flip}
    p["pk"] = ",".join(k for k, _ in PK_KINDS if k in s) or "none"
    p["action"] = "results"
    xbmc.executebuiltin("Container.Update(%s,replace)" % url(**p))


def show_about(p):
    try:
        eps, meta = catalog_mod.cinemeta_episodes(p["imdb"])
    except Exception as e:
        return notify("Couldn't load the details: %s" % e, xbmcgui.NOTIFICATION_WARNING)
    bits = []
    for lab, val in (("First aired", nice_date((meta.get("released") or "")[:10]) or meta.get("releaseInfo")),
                     ("Country", meta.get("country")), ("Genres", ", ".join(meta.get("genres") or [])),
                     ("IMDb rating", meta.get("imdbRating")), ("Episode length", meta.get("runtime")),
                     ("Starring", ", ".join((meta.get("cast") or [])[:6]))):
        if val:
            bits.append("[B]%s:[/B] %s" % (lab, val))
    xbmcgui.Dialog().textviewer("%s - %s" % (NAME, meta.get("name") or p.get("title") or ""),
                                "%s\n\n%s" % (meta.get("description") or "No description available.", "\n".join(bits)))


# ---------------- smoother playback: heavy-file warnings + a bigger video buffer ----------------
def est_mbps(r, p):
    """Rough bitrate of a single-file result (size over a typical running time) - None for packs."""
    if p.get("pack") or p.get("show") or p.get("music") or r.get("pk") in ("pack", "multi"):
        return None
    if (p.get("season") or p.get("anime")) and scrapers.pack_kind(r["name"], p.get("season"), bool(p.get("anime"))) != "ep":
        return None
    mins = 24 if p.get("anime") and not p.get("movie") else 60 if p.get("kdrama") else 45 if p.get("season") else 125
    size = r.get("size") or 0
    return size * 8 / (mins * 60.0) / 1e6 if size else None


def net_speed():
    try:
        return max(int(ADDON.getSetting("net_speed") or 0), 0)
    except ValueError:
        return 0


def mbps_limits():
    """(orange from, red from) in Mb/s: from your internet speed when it's set, else typical figures."""
    sp = net_speed()
    return (sp * 0.45, sp * 0.7) if sp else (20, 45)


def heavy(r, p):
    mb = est_mbps(r, p)
    n = r["name"].lower()
    sp = net_speed()
    if sp:  # you've said how fast your connection is: heavy = more than it can comfortably stream
        return bool((mb and mb >= sp * 0.7) or (not mb and "remux" in n))
    return bool((mb and mb >= 35) or "remux" in n or re.search(r"\bav1\b", n))


def _rpc(method, params):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except Exception:
        return {}


def buffer_setup():
    """Give Kodi a bigger video buffer (helps high-bitrate Blu-ray files stream without stuttering)."""
    d = xbmcgui.Dialog()
    i = d.select("Smoother streaming - bigger video buffer", [
        "Large buffer (256 MB) - Nvidia Shield, Chromecast with Google TV, PC",
        "Medium buffer (128 MB) - Fire TV Stick and boxes with 2 GB of memory or less",
        "Put Kodi's normal settings back",
        "Other tips for stuttering playback",
        "Set my internet speed (now: %s)" % (("%d Mb/s" % net_speed()) if net_speed() else "not set")])
    if i < 0:
        return
    if i == 4:
        v = d.numeric(0, "Internet speed in Mb/s (test it at fast.com) - 0 to clear", str(net_speed() or ""))
        if v is not None and str(v).strip().isdigit():
            ADDON.setSetting("net_speed", str(int(v)))
            notify("Internet speed: %s" % (("%d Mb/s" % int(v)) if int(v) else "not set"))
        return
    if i == 3:
        return d.textviewer(NAME + " - stuttering playback", TIPS)
    mb = {0: 256, 1: 128}.get(i)
    try:
        kodi = int((xbmc.getInfoLabel("System.BuildVersion") or "0").split(".")[0] or 0)
    except ValueError:
        kodi = 0
    done = False
    if kodi >= 21:  # Kodi 21+: these are normal settings (Settings > Services > Caching)
        keys = ("filecache.buffermode", "filecache.memorysize", "filecache.readfactor")
        cur = {k: (_rpc("Settings.GetSettingValue", {"setting": k}).get("result") or {}).get("value") for k in keys}
        if cur["filecache.memorysize"] is not None:
            if mb is None:
                done = all(_rpc("Settings.ResetSettingValue", {"setting": k}).get("result") for k in keys)
            else:
                big = (cur["filecache.memorysize"] or 0) > 100000  # bytes rather than MB
                ok_mem = any(_rpc("Settings.SetSettingValue", {"setting": "filecache.memorysize",
                                                               "value": v * 1048576 if big else v}).get("result")
                             for v in (mb, 200, 128, 100))
                pct = (cur["filecache.readfactor"] or 0) >= 100
                ok_rf = any(_rpc("Settings.SetSettingValue", {"setting": "filecache.readfactor",
                                                              "value": v * 100 if pct else v}).get("result")
                            for v in (8, 10, 6, 5))
                _rpc("Settings.SetSettingValue", {"setting": "filecache.buffermode", "value": 1})
                done = ok_mem and ok_rf
            tublog.info("Buffer settings (Kodi %d): was %s -> %s" % (kodi, cur, "reset" if mb is None else "%d MB" % mb))
    if not done:  # Kodi 20 and older (or the settings above refused): advancedsettings.xml
        import xml.etree.ElementTree as ET
        path = xbmcvfs.translatePath("special://profile/advancedsettings.xml")
        try:
            root = ET.parse(path).getroot()
        except Exception:
            root = ET.Element("advancedsettings", {"version": "1.0"})
        old = root.find("cache")
        if old is not None:
            root.remove(old)
        if mb is not None:
            c = ET.SubElement(root, "cache")
            ET.SubElement(c, "buffermode").text = "1"
            ET.SubElement(c, "memorysize").text = str(mb * 1048576)
            ET.SubElement(c, "readfactor").text = "8"
        try:
            ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
            done = True
            tublog.info("advancedsettings.xml cache -> %s" % ("removed" if mb is None else "%d MB" % mb))
        except Exception as e:
            return d.ok(NAME, "Couldn't save the buffer setting: %s" % e)
        return d.ok(NAME, ("Kodi's normal buffer settings are back." if mb is None else
                           "Bigger buffer set (%d MB, reads ahead 8x faster than playback)." % mb) +
                    "\n[B]Restart Kodi[/B] for it to take effect.")
    d.ok(NAME, ("Kodi's normal buffer settings are back." if mb is None else
                "Bigger buffer set (%d MB, reads ahead 8x faster than playback).\nIt takes effect from the next video." % mb))


TIPS = """[B]Why Blu-ray files can stutter[/B]
Blu-ray rips (REMUX especially) can be 30-80 Mb/s - several times a normal web release. Your connection or the box
may not keep up. Results show an estimated bitrate (e.g. ~45 Mb/s) so you can spot them.

[B]Things that help[/B]
1. Bigger video buffer: Tools > Smoother streaming (this menu).
2. Settings > 3. Search results > "Put heavy files lower": REMUX / AV1 / very high bitrate go below lighter versions.
   Set your internet speed (this menu) and the Mb/s warnings and "heavy" are worked out for your connection.
3. Pick a web or smaller Blu-ray encode (x265 / HEVC) instead of a REMUX - usually looks almost the same.
4. Judder on films (smooth then jerky, regularly): Kodi Settings > Player > Videos >
   "Adjust display refresh rate" = On start/stop. Blu-rays are 23.976 fps and a 60 Hz screen can't show that evenly.
5. AV1 files: many boxes can't decode AV1 in hardware, so they stutter however fast your internet is - pick HEVC/x264.
6. Wired network (or 5 GHz Wi-Fi) for the TV box makes a big difference with high-bitrate files."""


def search_start(t=None):
    d = xbmcgui.Dialog()
    kind = {"movie": 0, "tv": 1, "free": 2}.get(t)
    if kind is None:
        kind = d.select("Search for", ["Movie", "TV episode", "Torrent name (free text)"])
    if kind < 0:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    q = d.input("Title").strip()
    if not q:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    params = {"action": "results", "q": q}
    label = q
    if kind in (0, 1):
        try:
            metas = scrapers.cinemeta(q, "movie" if kind == 0 else "series")
        except Exception as e:
            metas = []
            notify("Title lookup failed (%s) - using free text" % e, xbmcgui.NOTIFICATION_WARNING)
        if metas:
            i = d.select("Pick title", ["%s (%s)" % (x["name"], x["year"]) if x["year"] else x["name"] for x in metas])
            if i < 0:
                return xbmcplugin.endOfDirectory(HANDLE, False)
            meta = metas[i]
            params.update({"imdb": meta["imdb"], "title": meta["name"], "year": meta["year"],
                           "name": meta["name"] + (" " + meta["year"] if kind == 0 and meta["year"] else "")})
            label = meta["name"]
            if kind == 1:
                how = d.select(meta["name"], ["Choose a season & episode", "Search the whole show (all seasons & episodes)",
                                              "Browse seasons & episodes"])
                if how < 0:
                    return xbmcplugin.endOfDirectory(HANDLE, False)
                if how == 2:
                    xbmcplugin.endOfDirectory(HANDLE, False)
                    return xbmc.executebuiltin("Container.Update(%s)" % url(action="seasons", imdb=meta["imdb"],
                                                                            title=meta["name"], year=meta["year"]))
                if how == 1:
                    params.update({"show": 1, "name": meta["name"]})
                    label = "%s (whole show)" % meta["name"]
                else:
                    s = d.input("Season number", type=xbmcgui.INPUT_NUMERIC).strip()
                    e = d.input("Episode number", type=xbmcgui.INPUT_NUMERIC).strip()
                    if not (s.isdigit() and e.isdigit()):
                        return xbmcplugin.endOfDirectory(HANDLE, False)
                    params.update({"season": int(s), "ep": int(e)})
                    label = "%s S%02dE%02d" % (meta["name"], int(s), int(e))
        else:
            notify("No title match - searching as free text")
    hist = [h for h in store_load("history.json", []) if h["params"] != params]
    hist.insert(0, {"label": label, "params": params})
    store_save("history.json", hist[:20])
    xbmcplugin.endOfDirectory(HANDLE, False)
    xbmc.executebuiltin("Container.Update(%s)" % url(**params))


def history():
    for h in store_load("history.json", []):
        add_dir(h["label"], h["params"])
    add_dir("[Clear history]", {"action": "clear_history"}, folder=False)
    xbmcplugin.endOfDirectory(HANDLE)


SKIP_FOR = 30 * 60  # seconds a failing site is left out of searches


def get_results(p, progress=False):
    """Scrape (with 10 min cache) -> (sorted results, report). progress: show the searching window."""
    key = json.dumps({k: v for k, v in p.items() if k not in ("aud", "flip", "pk", "fs")}, sort_keys=True)
    cache = store_load("cache.json", {})
    now = time.time()
    hit = cache.get(key)
    if hit and now - hit[0] < 600:
        return hit[1], hit[2]
    api = get_api()
    jobs = scrapers.build(ADDON.getSetting, api)
    if not jobs:
        return [], [("-", None, "No scrapers enabled - see Settings > Scrapers", 0)]
    fails = {k: v for k, v in store_load("site_fails.json", {}).items() if now - v < SKIP_FOR}
    skipped = [(l, None, "n/a - skipped for %d min after failing" % max(1, int((SKIP_FOR - (now - fails[l])) // 60)), 0)
               for l, _ in jobs if l in fails]
    jobs = [j for j in jobs if j[0] not in fails]
    prog, pre = None, {"sent": set(), "futs": []}
    if progress and jobs:
        prog = xbmcgui.DialogProgress()
        prog.create(NAME, "Searching...")

        def prog_cb(done, total, found, waiting):
            prog.update(int(100 * done / max(total, 1)),
                        "Searching %d sources: %d done, [B]%d found[/B]\nWaiting for: %s\n"
                        "[COLOR grey]Cancel = show what's been found so far[/COLOR]" % (
                            total, done, found, ", ".join(waiting[:4]) + (" ..." if len(waiting) > 4 else "")))
            return prog.iscanceled()
    from concurrent.futures import ThreadPoolExecutor as _Pool
    pool = _Pool(max_workers=4) if api else None

    def on_batch(batch):  # ask TorBox what's cached while the slower sites are still searching
        hs = [r["hash"] for r in batch if "cached" not in r and r.get("hash") and r["hash"] not in pre["sent"]]
        if hs and pool:
            pre["sent"].update(hs)
            pre["futs"].append(pool.submit(api.check_cached_full, hs))
    try:
        res, report = scrapers.run_all(jobs, scraper_ctx(p), progress=prog_cb if prog else None,
                                       quick=ADDON.getSetting("search_speed") != "1", on_batch=on_batch) if jobs else ([], [])
    finally:
        if prog:
            prog.close()
    for l, n, e, s in report:
        if e and "n/a" not in e:
            fails[l] = now
        elif l in fails:
            fails.pop(l, None)
    store_save("site_fails.json", fails)
    report = report + skipped
    for l, n, e, s in report:
        if e and "n/a" not in e:
            tublog.warn("Search '%s' - %s failed: %s" % (p.get("q") or p.get("title") or "?", l, e))
    tublog.debug("Search '%s' %s: %s" % (p.get("q") or p.get("title") or "?",
                                         " ".join("%s=%s" % (k, p[k]) for k in ("season", "ep", "anime", "pack") if p.get(k)),
                                         ", ".join("%s %s (%.1fs)" % (l, n if n is not None else "x", s or 0)
                                                   for l, n, e, s in report)))
    need = [r["hash"] for r in res if "cached" not in r]
    cached, tb_failed, errs = {}, not api, []
    for f in pre["futs"]:  # answers to the early TorBox checks
        try:
            part, err = f.result(timeout=15)
        except Exception as e:
            part, err = {}, str(e)
        cached.update(part)
        if err:
            errs.append(err)
    if pool:
        pool.shutdown(wait=False)
    if need and api:
        rest = [h for h in need if h not in pre["sent"]]
        if rest and not errs:
            part, err = api.check_cached_full(rest)
            cached.update(part)
            if err:
                errs.append(err)
        tb_failed = bool(errs)
        if tb_failed:
            tublog.warn("TorBox cache check failed (%s) - TorBox may be down" % errs[0])
            down = store_load("svc_down.json", {})
            down["tb"] = time.time()
            store_save("svc_down.json", down)
    if need and tb_failed and coco_key():
        cl = debrid.CocoleechTorrents(coco_key())
        top = sorted([r for r in res if "cached" not in r], key=lambda r: -r.get("seeds", 0))[:25]
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=8) as ex:
            hits = list(ex.map(lambda r: cl.cached(r["hash"]), top))
        for r, hit in zip(top, hits):
            if hit:
                r["cached"], r["cached_on"] = True, "cl"
    if tb_failed:
        for r in res:
            r.setdefault("tb_unknown", True)
    for r in res:
        if "cached" not in r:
            r["cached"] = cached.get(r["hash"], False)
    res = filter_results(res, p)
    if p.get("music"):
        lossless = ADDON.getSetting("music_lossless") != "false"
        res.sort(key=lambda r: (not r["cached"], -(scrapers.music_rank(r["name"]) if lossless else 0), -r.get("seeds", 0)))
        res = res[:150]
        cache = {k: v for k, v in cache.items() if now - v[0] < 600}
        cache[key] = [now, res, report]
        store_save("cache.json", cache)
        return res, report
    epmode = bool(p.get("ep")) and (p.get("season") or p.get("anime"))
    for r in res:  # anime: a release that names a different episode goes to the bottom, marked in red
        n = scrapers.named_episode(r["name"]) if (p.get("anime") and p.get("ep") and not p.get("pack")) else None
        r["wrong_ep"] = n if (n is not None and n != int(p["ep"])) else None
    res.sort(key=lambda r: (bool(r.get("wrong_ep")), not r["cached"],
                            bool(epmode and scrapers.pack_kind(r["name"], p.get("season"), bool(p.get("anime"))) != "ep"),
                            -scrapers.res_rank(r["name"]), -r.get("seeds", 0)))
    if p.get("show"):  # complete series first, then season packs, then single episodes
        res.sort(key=lambda r: (not r["cached"],
                                {"multi": 0, "pack": 1}.get(scrapers.pack_kind(r["name"], None, bool(p.get("anime"))), 2),
                                -scrapers.res_rank(r["name"]), -r.get("seeds", 0)))
    res = res[:150]
    cache = {k: v for k, v in cache.items() if now - v[0] < 600}
    cache[key] = [now, res, report]
    store_save("cache.json", cache)
    return res, report


def filter_results(res, p=None):
    p = p or {}
    out = []
    max_res = {0: 9, 1: 4, 2: 3, 3: 2}.get(int(ADDON.getSetting("max_res") or 0), 9)
    min_seeds = int(ADDON.getSetting("min_seeders") or 0)
    aud = p.get("audio", "any") if p.get("anime") else "any"
    for r in res:
        if ADDON.getSetting("hide_uncached") == "true" and not r["cached"]:
            continue
        if ADDON.getSetting("filter_cam_ts") == "true" and scrapers.CAM.search(r["name"]):
            continue
        if not p.get("music") and scrapers.res_rank(r["name"]) > max_res:
            continue
        if not r["cached"] and r.get("seeds") and r["seeds"] < min_seeds:
            continue
        k = scrapers.audio_kind(r["name"])
        if (aud == "dub" and k == "sub") or (aud == "sub" and k == "dub"):
            continue
        if p.get("season") or p.get("anime"):
            pk = scrapers.pack_kind(r["name"], p.get("season"), bool(p.get("anime")))
            if p.get("pack") and pk not in ("pack", "multi"):
                continue
            if not p.get("pack") and pk == "other":
                continue
        out.append(r)
    return out


AUD_KINDS = (("dub", "English dub"), ("sub", "Japanese audio + subtitles"), ("dual", "Dual / multi audio"))


def aud_set(p):
    """Which anime audio kinds to show: from the on/off buttons, else the old choice, else Settings."""
    if p.get("aud"):
        return {x for x in p["aud"].split(",") if x in ("dub", "sub", "dual")}
    a = p.get("audio")
    if not a or a == "all":
        a = {2: "dub", 3: "sub"}.get(int(ADDON.getSetting("anime_audio") or 0), "any")
    return {"dub": {"dub", "dual"}, "sub": {"sub", "dual"}}.get(a, {"dub", "sub", "dual"})


def aud_toggle(p):
    flip = p.pop("flip", "")
    s = aud_set(p) ^ {flip}
    p.pop("audio", None)
    p["aud"] = ",".join(k for k, _ in AUD_KINDS if k in s) or "none"
    p["action"] = "results"
    xbmc.executebuiltin("Container.Update(%s,replace)" % url(**p))


def results(p):
    if p.get("fs"):
        hist_add("movie", year_label(p.get("title") or p.get("q") or "?", p.get("year")),
                 {k: v for k, v in p.items() if k != "fs"})
        p = {k: v for k, v in p.items() if k != "fs"}
    view, shown = dict(p), set()
    if p.get("anime"):
        shown = aud_set(p)
        view = dict(p)
        # search for everything once (cached 10 min) - the buttons then just filter, no new search
        p = {k: v for k, v in p.items() if k not in ("aud", "audio")}
        p["audio"] = "all"
    try:  # remember how this show is searched (for play-next / Continue watching), even if nothing is found
        _wk, _wi = watch_key(p)
        if _wk and _wi and binge.show_of(_wk):
            binge.set_search(PROFILE, _wi["show"], dict(p, aud=view.get("aud") or ",".join(sorted(shown)))
                             if p.get("anime") else p, _wi.get("title"), _wi.get("poster"))
    except Exception:
        tublog.exc("Saving the show's search failed")
    if p.get("usenet"):
        return usenet_results(dict(p, aud=view.get("aud") or ",".join(sorted(shown))) if p.get("anime") else p)
    res, report = get_results(p, progress=True)
    summary = "  ".join("%s:%s" % (l, (n if n is not None else ("skip" if e and "skipped" in e else "x")))
                        for l, n, e, s in report if not (e and "n/a" in e and "skipped" not in e))
    if not res and not p.get("music") and ADDON.getSetting("usenet_enable") != "false":
        if usenet_ready():
            if ADDON.getSetting("usenet_ask") == "false" or xbmcgui.Dialog().yesno(
                    NAME, "No torrents found.\nSearch Usenet newsgroups instead?\n(Usenet downloads need a TorBox Pro plan)"):
                return usenet_results(p)
        else:
            notify("No torrents found - set up a Usenet indexer (Tools & settings) to search newsgroups too")
    if not res:
        errs = "; ".join("%s %s" % (l, e) for l, n, e, s in report if e and "n/a" not in e)
        notify(errs or ("No season packs found - try single episodes" if p.get("pack") else
                        "No results (try loosening filters in Settings > Results)"), xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    notify("Found %d  [%s]" % (len(res), summary))
    failed = [("%s: %s" % (l, e)) for l, n, e, s in report if e and "n/a" not in e]
    if failed:
        popup("Scraper problem - " + "; ".join(failed)[:140], xbmcgui.NOTIFICATION_WARNING)  # already in the log
    extra = {k: p[k] for k in ("season", "ep", "anime") if p.get(k)}
    wk, winfo = watch_key(p)
    if wk:
        watched.remember(wk, winfo)
        extra["wk"] = wk
    if ADDON.getSetting("fav_release") != "false" and not p.get("music"):
        mine, favs = binge.usual_groups(PROFILE, (winfo or {}).get("show"))
        last = binge.usual(PROFILE, (winfo or {}).get("show")) if winfo else {}
        for r in res:
            g = binge.release_group(r["name"])
            same_src = (not mine and last.get("source") not in ("", "Web", None) and
                        binge.release_source(r["name"]) == last.get("source") and scrapers.res_rank(r["name"]) == last.get("res"))
            r["fav"] = 2 if ((mine and g == mine) or same_src) else (1 if g and g in favs else 0)
        res.sort(key=lambda r: (bool(r.get("wrong_ep")), not r["cached"], -r.get("fav", 0)))
    if ADDON.getSetting("smooth_first") == "true" and not p.get("music"):
        res.sort(key=lambda r: (bool(r.get("wrong_ep")), not r["cached"], heavy(r, p)))
    packmode = bool(p.get("pack"))
    music = bool(p.get("music"))
    if music and (p.get("artist") or p.get("title")):
        add_dir("[COLOR deepskyblue][B]%s[/B][/COLOR]  [COLOR grey]by %s%s[/COLOR]" % (
            p.get("title") or "", p.get("artist") or "?", (" - " + (nice_date(p.get("released")) or p.get("year") or ""))
            if (p.get("released") or p.get("year")) else ""), {"action": "noop"}, folder=False,
            art={"thumb": p.get("cover"), "poster": p.get("cover")})
    if p.get("anime"):  # dub / sub / dual on-off buttons
        counts = {}
        for r in res:
            k = scrapers.audio_kind(r["name"])
            counts[k] = counts.get(k, 0) + 1
        for k, label in AUD_KINDS:
            on = k in shown
            add_dir("%s  %s  [COLOR grey](%s)[/COLOR]" % (
                "[COLOR lightgreen][B]ON [/B][/COLOR]" if on else "[COLOR grey]OFF[/COLOR]",
                label if on else "[COLOR grey]%s[/COLOR]" % label,
                ("%d found" % counts[k]) if counts.get(k) else "none found"),
                dict(view, action="aud_toggle", flip=k), folder=False, icon=ic("search"))
        res = [r for r in res if scrapers.audio_kind(r["name"]) in shown]
        if not res:
            add_dir("[COLOR orange]Nothing with the audio switched on above - switch another one on[/COLOR]",
                    {"action": "noop"}, folder=False)
            xbmcplugin.setContent(HANDLE, "videos")
            return xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        p = view
    if not p.get("music") and not p.get("pack") and (p.get("season") or p.get("anime") or p.get("show")) \
            and not p.get("movie"):  # single episodes / season packs / complete series on-off buttons
        want = pk_set(p)
        counts = {}
        for r in res:
            k = scrapers.pack_kind(r["name"], p.get("season"), bool(p.get("anime")))
            k = "pack" if (k == "pack" or (p.get("anime") and k not in ("ep", "multi"))) else k
            r["pk"] = k
            counts[k] = counts.get(k, 0) + 1
        for k, lab in PK_KINDS:
            if p.get("anime") and k == "multi" and not counts.get(k):
                continue
            on = k in want
            add_dir("%s  %s  [COLOR grey](%s)[/COLOR]" % (
                "[COLOR lightgreen][B]ON [/B][/COLOR]" if on else "[COLOR grey]OFF[/COLOR]",
                lab if on else "[COLOR grey]%s[/COLOR]" % lab, ("%d found" % counts[k]) if counts.get(k) else "none found"),
                dict(p, action="pk_toggle", flip=k), folder=False, icon=ic("tv"))
        res = [r for r in res if r.get("pk") in want]
        if not res:
            add_dir("[COLOR orange]Nothing left with those switched off - switch one back on above[/COLOR]",
                    {"action": "noop"}, folder=False)
            xbmcplugin.setContent(HANDLE, "videos")
            return xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    top = next((r for r in res if not r.get("wrong_ep")), res[0])
    if top["cached"] and not top.get("wrong_ep") and not packmode and not music and not p.get("show"):
        add_dir("[B]> Play best cached:[/B] %s" % top["name"],
                dict(action="play_hash", hash=top["hash"], name=top["name"], fname=top.get("file"),
                     c=("cl" if top.get("cached_on") == "cl" else "1"), **{k: v for k, v in extra.items() if k != "c"}),
                folder=False, playable=True)
    for r in res:
        tag = ("[COLOR lightgreen]CACHED[/COLOR]" + (" [COLOR grey](Cocoleech)[/COLOR]" if r.get("cached_on") == "cl" else "")
               if r["cached"] else "[COLOR gold]uncached[/COLOR]")
        extra["c"] = ("cl" if r.get("cached_on") == "cl" else "1") if r["cached"] else ("" if r.get("tb_unknown") else "0")
        if r.get("fav"):
            tag += " [COLOR gold][B]%s[/B][/COLOR]" % ("YOUR USUAL" if r["fav"] == 2 else "FAVOURITE GROUP")
        mbps = est_mbps(r, p)
        lo, hi = mbps_limits()
        if mbps and mbps >= lo:
            tag += " [COLOR %s]~%d Mb/s[/COLOR]" % ("red" if mbps >= hi else "orange", round(mbps))
        if p.get("anime"):
            tag += {"dub": " [COLOR orange]DUB[/COLOR]", "dual": " [COLOR orange]DUAL[/COLOR]", "sub": " [COLOR skyblue]SUB[/COLOR]"}[scrapers.audio_kind(r["name"])]
        label = "%s  %s | %s | %s seeds | %s\n%s" % (tag, scrapers.music_tags(r["name"]) if music else (scrapers.tags(r["name"]) + (
            " " + binge.release_source(r["name"]) if binge.release_source(r["name"]) not in ("", "Web") else "")), fmt_size(r["size"]),
                                                    r.get("seeds", 0), r.get("source", "?"), r["name"])
        pk = None
        if p.get("season") or p.get("anime") or p.get("show"):
            pk = scrapers.pack_kind(r["name"], p.get("season"), bool(p.get("anime")))
            label = {"pack": "[COLOR gold][B]SEASON PACK[/B][/COLOR] ", "multi": "[COLOR orange][B]MULTI-SEASON[/B][/COLOR] ",
                     "ep": "[COLOR grey]EPISODE[/COLOR] "}.get(pk, "") + label
            if r.get("wrong_ep"):
                label = "[COLOR red][B]EPISODE %d - NOT %s?[/B][/COLOR] " % (r["wrong_ep"], p.get("ep")) + label
        as_pack = bool(packmode or (p.get("show") and pk in ("pack", "multi")))
        add_dir(label.replace("\n", " - "),
                dict(action="music_open" if music else ("pack_open" if as_pack else "play_hash"), hash=r["hash"],
                     name=r["name"], fname=None if (music or as_pack) else r.get("file"), artist=p.get("artist"), album=p.get("title") if music else None,
                     cover=p.get("cover"), y=p.get("year") if music else None, rel=p.get("released") if music else None, **extra),
                folder=as_pack or music, playable=not (as_pack or music), plot=r["name"],
                ctx=[("Download in the cloud to watch later...", "RunPlugin(%s)" % url(action="send_to", hash=r["hash"],
                                                                                         name=r["name"]))])
    if not p.get("music") and ADDON.getSetting("usenet_enable") != "false":
        add_dir("[COLOR violet][B]Search Usenet (newsgroups) for this...[/B][/COLOR]", dict(p, usenet=1), icon=ic("search"))
    if not p.get("music") and coco_key():
        add_dir("[COLOR deepskyblue][B]Search file-host links for this (Cocoleech)...[/B][/COLOR]", dict(p, action="ddl_results"),
                icon=ic("tools_link"))
    xbmcplugin.setContent(HANDLE, "albums" if music else "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


SITE_MEDIA = [('movie', 'Movies'), ('tv', 'TV shows'), ('anime', 'Anime'), ('kdrama', 'K-dramas'), ('music', 'Music')]


def set_bool(k, v):
    try:
        ADDON.setSettingBool(k, v)
    except Exception:
        ADDON.setSetting(k, "true" if v else "false")


def sites_menu():
    d = xbmcgui.Dialog()
    keys = list(scrapers.SITES) + ["nyaa"]

    def addr(k):
        if k == "nyaa":
            return (ADDON.getSetting("nyaa_host") or "https://nyaa.si").rstrip("/")
        return scrapers.site_host(ADDON.getSetting, k)

    def name(k):
        return "Nyaa" if k == "nyaa" else scrapers.SITES[k][0]
    while True:
        rows = []
        for k in keys:
            if k == "nyaa":
                on = "anime, K-dramas%s" % (", music" if any(m == "music" for m, _ in SITE_MEDIA) else "") \
                    if ADDON.getSetting("nyaa_enable") != "false" else "off"
            else:
                cur = scrapers.site_media(ADDON.getSetting, k)
                on = ", ".join(lbl for m, lbl in SITE_MEDIA if m in cur) or "off"
            rows.append("%s  [COLOR grey](%s)  %s[/COLOR]" % (name(k), on, addr(k)))
        i = d.select("Torrent sites", rows)
        if i < 0:
            return
        k = keys[i]
        j = d.select(name(k), ["Turn on/off for each type", "Change web address (now %s)" % addr(k),
                               "Reset web address to default"])
        if j == 0:
            if k == "nyaa":
                set_bool("nyaa_enable", d.yesno(name(k), "Use Nyaa for anime and K-drama searches?", nolabel="Off",
                                                yeslabel="On"))
            else:
                cur = scrapers.site_media(ADDON.getSetting, k)
                sel = d.multiselect("%s - search for" % name(k), [lbl for _, lbl in SITE_MEDIA],
                                    preselect=[n for n, (m, _) in enumerate(SITE_MEDIA) if m in cur])
                if sel is not None:
                    for n, (m, _) in enumerate(SITE_MEDIA):
                        set_bool("%s_%s" % (k, m), n in sel)
            notify("Saved")
        elif j in (1, 2):
            host_id = "nyaa_host" if k == "nyaa" else scrapers.SITES[k][1]
            default = "https://nyaa.si" if k == "nyaa" else scrapers.SITES[k][2]
            if j == 2:
                h = default
            else:
                h = d.input("%s web address" % name(k), defaultt=addr(k)).strip()
            if h:
                if not h.startswith("http"):
                    h = "https://" + h
                ADDON.setSetting(host_id, h.rstrip("/"))
                notify("Address saved")


# ---------------- Usenet (newsgroups) ----------------
def usenet_ready():
    if ADDON.getSetting("usenet_enable") == "false":
        return False
    has_indexer = any(ADDON.getSetting("nzb%s_url" % n).strip() and ADDON.getSetting("nzb%s_key" % n).strip()
                      for n in ("1", "2"))
    return has_indexer or ADDON.getSetting("tb_usenet_search") == "true"


def fmt_age(days):
    if days is None:
        return ""
    if days < 1:
        return "today"
    if days < 365:
        return "%dd old" % days
    return "%.1fy old" % (days / 365.0)


def usenet_results(p):
    """List Usenet (NZB) results for the same search, in this listing."""
    api = get_api()
    if not api:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    if not usenet_ready():
        xbmcgui.Dialog().ok(NAME, "No Usenet indexer set up yet.\nAdd one in Tools & settings > Usenet: set up indexers "
                            "(you need an account with a Newznab indexer such as NZBGeek or DrunkenSlug).")
        return xbmcplugin.endOfDirectory(HANDLE, False)
    ctx = scraper_ctx(p)
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Searching Usenet newsgroups...")
    res, report = scrapers.usenet_search(ADDON.getSetting, ADDON.getSetting("api_key").strip(), ctx)
    prog.close()
    max_res = {0: 9, 1: 4, 2: 3, 3: 2}.get(int(ADDON.getSetting("max_res") or 0), 9)
    shown = aud_set(p) if p.get("anime") else None
    keep = []
    for r in res:
        if ADDON.getSetting("filter_cam_ts") == "true" and scrapers.CAM.search(r["name"]):
            continue
        if scrapers.res_rank(r["name"]) > max_res:
            continue
        if shown is not None and scrapers.audio_kind(r["name"]) not in shown:
            continue
        pk = scrapers.pack_kind(r["name"], p.get("season"), bool(p.get("anime"))) if (p.get("season") or p.get("anime") or p.get("show")) else None
        if p.get("pack") and pk not in ("pack", "multi"):
            continue
        if pk == "other":
            continue
        r["pk"] = pk
        keep.append(r)
    keep.sort(key=lambda r: (not r.get("cached"), -scrapers.res_rank(r["name"]), -r.get("grabs", 0), -r.get("size", 0)))
    errs = ["%s: %s" % (l, e) for l, n, e, s in report if e and "n/a" not in e]
    bad = store_load("indexer_errors.json", {})
    for l, n, e, s in report:
        if e and "n/a" not in e:
            bad[l] = {"ts": time.time(), "err": str(e).replace("ValueError: ", "")[:120]}
        elif n is not None:
            bad.pop(l, None)
    store_save("indexer_errors.json", bad)
    if not keep:
        notify("No Usenet results" + (" - " + "; ".join(errs)[:120] if errs else ""), xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    notify("Usenet: %d results  [%s]" % (len(keep), "  ".join("%s:%s" % (l, n if n is not None else "x") for l, n, e, s in report)))
    if errs:
        notify("Indexer problem - " + "; ".join(errs)[:140], xbmcgui.NOTIFICATION_WARNING)
    extra = {k: p[k] for k in ("season", "ep", "anime") if p.get(k)}
    wk, winfo = watch_key(p)
    if wk:
        watched.remember(wk, winfo)
        extra["wk"] = wk
    for r in keep[:150]:
        bits = [scrapers.tags(r["name"]), fmt_size(r["size"]) if r["size"] else "", ("%d grabs" % r["grabs"]) if r.get("grabs") else "",
                fmt_age(r.get("age")), r["source"]]
        tag = "[COLOR violet]USENET[/COLOR]" + (" [COLOR lightgreen]CACHED[/COLOR]" if r.get("cached") else "")
        if p.get("anime"):
            tag += {"dub": " [COLOR orange]DUB[/COLOR]", "dual": " [COLOR orange]DUAL[/COLOR]", "sub": " [COLOR skyblue]SUB[/COLOR]"}[scrapers.audio_kind(r["name"])]
        pre = {"pack": "[COLOR gold][B]SEASON PACK[/B][/COLOR] ", "multi": "[COLOR orange][B]MULTI-SEASON[/B][/COLOR] ",
               "ep": "[COLOR grey]EPISODE[/COLOR] "}.get(r.get("pk"), "")
        as_pack = bool(p.get("pack") or (p.get("show") and r.get("pk") in ("pack", "multi")))
        add_dir("%s%s  %s - %s" % (pre, tag, " | ".join(b for b in bits if b), r["name"]),
                dict(action="nzb_play", nzb=r["nzb"], mode=r.get("mode", "file"), name=r["name"], pack=1 if as_pack else None,
                     **extra),
                folder=as_pack, playable=not as_pack, plot=r["name"],
                ctx=[("Send to TorBox only (download later)", "RunPlugin(%s)" % url(action="nzb_add", nzb=r["nzb"],
                                                                                    mode=r.get("mode", "file"), name=r["name"]))])
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def nzb_send(api, p):
    """Fetch the NZB here and upload it to TorBox (falls back to giving TorBox the link)."""
    import requests
    data = None
    if p.get("mode") != "link":
        try:
            r = requests.get(p["nzb"], headers=scrapers.NZB_UA, timeout=30)
            r.raise_for_status()
            if b"<nzb" in r.content[:4096].lower():
                data = r.content
        except Exception:
            data = None
    uid = api.add_nzb(data, None if data else p["nzb"], p.get("name"))
    if not uid:  # older API replies: find it in the usenet list
        want = re.sub(r"\W+", "", (p.get("name") or "").lower())
        for it in api.mylist("usenet"):
            if re.sub(r"\W+", "", (it.get("name") or "").lower()) == want:
                uid = it.get("id")
                break
    return uid


def nzb_add(p):
    api = get_api()
    if not api:
        return
    try:
        nzb_send(api, p)
        notify("Sent to TorBox Usenet - find it in My TorBox > My Usenet")
    except TorBoxError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)


def nzb_play(p):
    api = get_api()
    fail = lambda: xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem()) if not p.get("pack") else \
        xbmcplugin.endOfDirectory(HANDLE, False)  # noqa: E731
    if not api:
        return fail()
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Sending to TorBox Usenet...")
    try:
        uid = nzb_send(api, p)
        if not uid:
            prog.close()
            notify("TorBox accepted the NZB but didn't say where it is - check My TorBox > My Usenet")
            return fail()
        deadline = time.time() + int(ADDON.getSetting("usenet_wait") or 600)
        item = None
        while time.time() < deadline and not prog.iscanceled():
            it = api.mylist("usenet", uid) or {}
            if it.get("files") and (it.get("download_finished") or it.get("download_present")):
                item = it
                break
            pct = int(float(it.get("progress") or 0) * 100)
            state = (it.get("download_state") or "queued").replace("_", " ")
            prog.update(pct, "Downloading from Usenet on TorBox: %s %d%%\n%s" % (state, pct, p.get("name", "")[:80]))
            xbmc.sleep(3000)
        prog.close()
    except TorBoxError as e:
        prog.close()
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)
        return fail()
    if not item:
        notify("Still downloading on TorBox - it will be in My TorBox > My Usenet when done")
        return fail()
    if p.get("pack"):
        return list_files("usenet", uid)
    f = pick_video(item["files"], p.get("season"), p.get("ep"), bool(p.get("anime")))
    if not f:
        vids = sorted([x for x in item["files"] if is_video(x.get("name", ""))], key=lambda x: x.get("name", ""))
        if not vids:
            notify("No video file in this download", xbmcgui.NOTIFICATION_WARNING)
            return fail()
        i = xbmcgui.Dialog().select("Pick the file", [os.path.basename(x["name"]) for x in vids])
        if i < 0:
            return fail()
        f = vids[i]
    track(p.get("wk"))
    resolve("usenet", uid, f["id"])


def usenet_setup():
    d = xbmcgui.Dialog()
    while True:
        rows = []
        for n in ("1", "2"):
            u = ADDON.getSetting("nzb%s_url" % n).strip()
            rows.append("Indexer %s: %s" % (n, u or "[COLOR grey]not set[/COLOR]"))
        rows.append("TorBox's own Usenet search: %s" % ("on" if ADDON.getSetting("tb_usenet_search") == "true" else "off"))
        rows.append("Ask before searching Usenet: %s" % ("yes" if ADDON.getSetting("usenet_ask") != "false" else "no - search straight away"))
        rows.append("Test Usenet search")
        i = d.select("Usenet (newsgroups)", rows)
        if i < 0:
            return
        if i in (0, 1):
            n = str(i + 1)
            u = d.input("Indexer address (e.g. https://api.nzbgeek.info) - leave empty to remove",
                        defaultt=ADDON.getSetting("nzb%s_url" % n)).strip()
            if not u:
                ADDON.setSetting("nzb%s_url" % n, "")
                ADDON.setSetting("nzb%s_key" % n, "")
                notify("Indexer %s removed" % n)
                continue
            k = d.input("API key for %s (from your account page on the indexer)" % u,
                        defaultt=ADDON.getSetting("nzb%s_key" % n)).strip()
            if k:
                ADDON.setSetting("nzb%s_url" % n, u if u.startswith("http") else "https://" + u)
                ADDON.setSetting("nzb%s_key" % n, k)
                notify("Indexer %s saved" % n)
        elif i == 2:
            set_bool("tb_usenet_search", ADDON.getSetting("tb_usenet_search") != "true")
        elif i == 3:
            set_bool("usenet_ask", ADDON.getSetting("usenet_ask") == "false")
        else:
            ctx = scraper_ctx({"imdb": "tt0133093", "title": "The Matrix", "year": "1999", "name": "The Matrix 1999",
                               "q": "The Matrix"})
            prog = xbmcgui.DialogProgress()
            prog.create(NAME, "Testing Usenet search...")
            res, report = scrapers.usenet_search(ADDON.getSetting, ADDON.getSetting("api_key").strip(), ctx)
            prog.close()
            lines = ["%s: %s  (%.1fs)" % (l, ("%d results" % n) if e is None else "FAILED - %s" % e, s) for l, n, e, s in report]
            d.textviewer(NAME + " - Usenet test (The Matrix)", "\n".join(lines))


def test_scrapers():
    api = get_api()
    if not api:
        return
    jobs = scrapers.build(ADDON.getSetting, api)
    if not jobs:
        return xbmcgui.Dialog().ok(NAME, "No scrapers enabled. Turn some on in Settings > Scrapers.")
    base = {"timeout": int(ADDON.getSetting("scrape_timeout") or 15)}
    tests = [("MOVIE test (The Matrix)", scraper_ctx({"imdb": "tt0133093", "title": "The Matrix", "year": "1999",
                                                     "name": "The Matrix 1999", "q": "The Matrix"})),
             ("TV test (Breaking Bad S1E1)", scraper_ctx({"imdb": "tt0903747", "title": "Breaking Bad", "year": "2008",
                                                         "name": "Breaking Bad", "season": 1, "ep": 1})),
             ("ANIME test (Frieren, episode 5)", scraper_ctx({"anime": 1, "kitsu": "46474", "title": "Frieren",
                                                              "alt": "Sousou no Frieren", "year": "2023", "ep": 5,
                                                              "audio": "any"})),
             ("K-DRAMA test (Crash Landing on You S1E1)", scraper_ctx({"kdrama": 1, "title": "Crash Landing on You",
                                                                       "year": "2019", "imdb": "tt10850932",
                                                                       "name": "Crash Landing on You", "season": 1, "ep": 1}))]
    tests.append(("MUSIC test (Daft Punk - Random Access Memories)",
                  scraper_ctx({"music": 1, "q": "Daft Punk Random Access Memories"})))
    lines = []
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Testing scrapers...")
    for title, ctx in tests:
        ctx["timeout"] = base["timeout"]
        res, report = scrapers.run_all(jobs, ctx)
        lines.append("== %s ==" % title)
        for l, n, e, s in report:
            status = ("%d results" % n) if e is None else ("skipped (not used for this type)" if "n/a" in e else "FAILED - %s" % e)
            lines.append("%s: %s  (%.1fs)" % (l, status, s))
        lines.append("")
    prog.close()
    xbmcgui.Dialog().textviewer(NAME + " - scraper test", "\n".join(lines))


# ---------------- torrent services: TorBox, Real-Debrid, Cocoleech ----------------
SVC_NAMES = {"tb": "TorBox", "rd": "Real-Debrid", "cl": "Cocoleech"}


def _rd_file():
    return os.path.join(xbmcvfs.translatePath("special://profile/tub_backup/%s/" % ADDON.getAddonInfo("id")),
                        "rd_auth.json")


def rd_auth():
    try:
        with open(_rd_file(), "r") as f:
            return json.load(f)
    except Exception:
        return {}


def rd_save(a):
    try:
        os.makedirs(os.path.dirname(_rd_file()), exist_ok=True)
        with open(_rd_file(), "w") as f:
            json.dump(a or {}, f)
    except Exception as e:
        tublog.warn("Couldn't save the Real-Debrid login: %s" % e)


def rd_client():
    a = rd_auth()
    return debrid.RealDebrid(a, rd_save) if a.get("token") else None


def svc_ready(s):
    return {"tb": bool(tb_key()), "rd": bool(rd_auth().get("token")), "cl": bool(coco_key())}[s]


class _TorBoxSvc(object):
    """TorBox wearing the same face as the other services."""
    label = "TorBox"

    def __init__(self):
        self.api = TorBoxAPI(tb_key(), ADDON.getSetting("search_host"))

    def start(self, h, name):
        try:
            tid = self.api.add_magnet("magnet:?xt=urn:btih:%s&dn=%s" % (h, name))
            if not tid:
                for t in self.api.mylist("torrents"):
                    if (t.get("hash") or "").lower() == h.lower():
                        tid = t["id"]
        except TorBoxError as e:
            raise debrid.DebridError(str(e))
        if not tid:
            raise debrid.DebridError("TorBox didn't accept the torrent")
        return str(tid)

    def status(self, hd):
        try:
            it = self.api.mylist("torrents", hd) or {}
        except TorBoxError as e:
            raise debrid.DebridError(str(e))
        ready = bool(it.get("files") and (it.get("download_finished") or it.get("download_present")))
        return {"ready": ready, "progress": int(float(it.get("progress") or 0) * 100),
                "state": (it.get("download_state") or "queued").replace("_", " "), "name": it.get("name") or "",
                "files": [{"id": f["id"], "name": f.get("name", ""), "size": f.get("size") or 0}
                          for f in it.get("files") or []] if ready else [], "error": None}

    def link(self, hd, fid):
        try:
            return self.api.request_dl("torrents", hd, fid) or self.api.redirect_url("torrents", hd, fid)
        except TorBoxError:
            return self.api.redirect_url("torrents", hd, fid)


def svc_obj(s):
    if s == "tb":
        return _TorBoxSvc()
    if s == "rd":
        c = rd_client()
        if not c:
            raise debrid.DebridError("not logged in to Real-Debrid")
        return c
    return debrid.CocoleechTorrents(coco_key())


def choose_services(cached=""):
    """Which service(s) to use for a torrent, in order (first = the one picked). [] = cancelled / none set up.
    cached: "1" TorBox has it cached, "cl" Cocoleech has it cached, "0" TorBox hasn't, "" unknown."""
    avail = [s for s in ("tb", "rd", "cl") if svc_ready(s)]
    if not avail:
        notify("Log in to TorBox, Real-Debrid or Cocoleech first (Tools & settings)", xbmcgui.NOTIFICATION_ERROR)
        return []
    is_cached = {"tb": cached == "1", "cl": cached == "cl"}
    down = store_load("svc_down.json", {})
    auto = sorted(avail, key=lambda s: (time.time() - down.get(s, 0) < 600, not is_cached.get(s),
                                        ("tb", "rd", "cl").index(s)))
    mode = ADDON.getSetting("torrent_service") or "0"
    fixed = {"2": "tb", "3": "rd", "4": "cl"}.get(mode)
    known_cached = any(is_cached.values())
    ask_uncached = (ADDON.getSetting("ask_uncached") != "false" and not known_cached and cached == "0"
                    and len(avail) > 1 and mode != "0")
    if fixed in avail and not ask_uncached:
        return [fixed] + [s for s in auto if s != fixed]
    if (mode == "1" or len(avail) == 1) and not ask_uncached:
        return auto
    if ask_uncached and fixed in avail:
        auto = [fixed] + [s for s in auto if s != fixed]
    labels = []
    for s in auto:
        if is_cached.get(s):
            tag = "[COLOR lightgreen]cached - plays straight away[/COLOR]"
        elif s == "tb" and cached == "0":
            tag = "[COLOR grey]not cached - downloads first[/COLOR]"
        elif s == "rd":
            tag = "[COLOR grey]plays straight away if Real-Debrid has it[/COLOR]"
        else:
            tag = "[COLOR grey]plays straight away if it's cached there[/COLOR]"
        if time.time() - down.get(s, 0) < 600:
            tag = "[COLOR red]failed a few minutes ago[/COLOR]"
        labels.append("%s  %s" % (SVC_NAMES[s], tag))
    i = xbmcgui.Dialog().select("Not cached - which service should download it?" if ask_uncached else
                                "Play it through...", labels)
    if i < 0:
        return []
    return [auto[i]] + [s for s in auto if s != auto[i]]


def pick_next_service(rest, why):
    """Let you choose which of the remaining services to try (instead of just the next one)."""
    if len(rest) <= 1:
        return rest
    i = xbmcgui.Dialog().select(why, [SVC_NAMES[s] for s in rest])
    if i < 0:
        return []
    return [rest[i]] + [s for s in rest if s != rest[i]]


def send_to(p):
    """Context menu: start a torrent downloading in the cloud now, to watch later."""
    avail = [s for s in ("tb", "rd", "cl") if svc_ready(s)]
    if not avail:
        return notify("Log in to TorBox, Real-Debrid or Cocoleech first", xbmcgui.NOTIFICATION_ERROR)
    i = xbmcgui.Dialog().select("Download it in the cloud with...", [SVC_NAMES[s] for s in avail]) if len(avail) > 1 else 0
    if i < 0:
        return
    s = avail[i]
    try:
        hd = svc_obj(s).start(p["hash"], p.get("name", ""))
    except debrid.DebridError as e:
        return notify("%s: %s" % (SVC_NAMES[s], e), xbmcgui.NOTIFICATION_ERROR)
    where = {"tb": "My TorBox > My Torrents", "rd": "My TorBox > My Real-Debrid torrents",
             "cl": "My TorBox > My Cocoleech torrents"}[s]
    tublog.info("Sent '%s' to %s (id %s)" % (p.get("name", "")[:60], SVC_NAMES[s], hd))
    notify("Downloading on %s - it'll be in %s" % (SVC_NAMES[s], where))


def _wait_files(s, obj, hd, name, what, has_next):
    """-> files list, "next" (try another service) or "cancel"."""
    prog = xbmcgui.DialogProgress()
    title = "Opening the %s on %s..." % (what, SVC_NAMES[s])
    prog.create(NAME, title)
    end = time.time() + int(ADDON.getSetting("add_timeout") or 20)
    try:
        while True:
            st = obj.status(hd)
            if st.get("error"):
                raise debrid.DebridError(st["error"])
            if st.get("ready") and st.get("files"):
                return st["files"]
            if prog.iscanceled():
                return "cancel"
            if time.time() > end:
                prog.close()
                opts = ["Keep waiting (5 more minutes)"] + (["Download it with another service instead"] if has_next else []) + \
                       ["Stop - leave it downloading on %s" % SVC_NAMES[s]]
                i = xbmcgui.Dialog().select("%s hasn't got it ready (%d%% - %s)" % (SVC_NAMES[s], st.get("progress", 0),
                                                                                   st.get("state", "")), opts)
                if i == 0:
                    end = time.time() + 300
                    prog = xbmcgui.DialogProgress()
                    prog.create(NAME, title)
                    continue
                if has_next and i == 1:
                    return "next"
                return "cancel"
            prog.update(min(99, st.get("progress") or 0), "%s: %s %d%%\n%s" % (
                SVC_NAMES[s], st.get("state") or "", st.get("progress") or 0, (st.get("name") or name)[:70]))
            xbmc.sleep(2000)
    finally:
        try:
            prog.close()
        except Exception:
            pass


def get_torrent(h, name, what, services):
    """Add the torrent to the chosen service and wait for its files, falling back to the others if a service fails.
    -> (service, handle, files) or None."""
    errors = []
    auto = (ADDON.getSetting("torrent_service") or "0") == "1"
    for n, s in enumerate(services):
        nxt = services[n + 1] if n + 1 < len(services) else None
        try:
            obj = svc_obj(s)
            hd = obj.start(h, name)
            res = _wait_files(s, obj, hd, name, what, bool(nxt))
        except Exception as e:  # any surprise from a service = that service failed; offer the others
            if not isinstance(e, debrid.DebridError):
                tublog.exc("%s gave an unexpected reply" % SVC_NAMES[s])
                e = debrid.DebridError("unexpected reply (%s)" % e.__class__.__name__)
            errors.append("%s: %s" % (SVC_NAMES[s], e))
            tublog.warn("%s couldn't open '%s': %s" % (SVC_NAMES[s], name[:60], e))
            down = store_load("svc_down.json", {})
            down[s] = time.time()
            store_save("svc_down.json", down)
            if nxt and auto:
                continue
            if nxt:
                rest = pick_next_service(services[n + 1:], "%s couldn't do it (%s) - try which instead?" % (
                    SVC_NAMES[s], str(e)[:60]))
                if not rest:
                    break
                services[n + 1:] = rest
                continue
            break
        if res == "cancel":
            return None
        if res == "next":
            rest = pick_next_service(services[n + 1:], "Download it with which service instead?")
            if not rest:
                return None
            services[n + 1:] = rest
            continue
        down = store_load("svc_down.json", {})
        if down.pop(s, None):
            store_save("svc_down.json", down)
        tublog.debug("Opened '%s' on %s" % (name[:60], SVC_NAMES[s]))
        return s, hd, res
    if errors:
        notify(" | ".join(errors)[:200], xbmcgui.NOTIFICATION_ERROR)
    return None


def resolve_svc(s, hd, fid, p=None):
    if s == "tb":
        return resolve("torrents", hd, fid, p) if p else resolve("torrents", hd, fid)
    try:
        link = svc_obj(s).link(hd, fid)
    except debrid.DebridError as e:
        notify("%s: %s" % (SVC_NAMES.get(s, s), e), xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    li = xbmcgui.ListItem(path=link)
    if p and p.get("m"):
        set_music_info(li, p.get("title", ""), p.get("artist", ""), p.get("album", ""), p.get("track") or 0, p.get("y"))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def svc_files_list(s, hd):
    """Pack contents on Real-Debrid / Cocoleech (TorBox uses its own richer file list)."""
    try:
        st = svc_obj(s).status(hd)
    except debrid.DebridError as e:
        return fail("%s: %s" % (SVC_NAMES[s], e))
    if not st.get("ready"):
        return fail("Still on its way on %s (%d%% - %s) - try again in a bit" % (SVC_NAMES[s], st.get("progress") or 0,
                                                                                st.get("state") or "queued"))
    files = st.get("files") or []
    vids = sorted([f for f in files if f["name"].lower().endswith(debrid.PLAY_EXT)], key=lambda f: f["name"])
    if not vids:
        return fail("Nothing playable in this torrent (or it's still downloading)")
    for f in vids:
        add_dir("%s  [COLOR grey]%s | %s[/COLOR]" % (os.path.basename(f["name"]), fmt_size(f.get("size")), SVC_NAMES[s]),
                {"action": "dplay", "svc": s, "id": hd, "file": f["id"]}, folder=False, playable=True,
                plot=f["name"])
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def svc_cloud(p):
    """What's on your Real-Debrid / Cocoleech account - open one to play it again."""
    s = p.get("svc")
    if not svc_ready(s):
        rd_menu() if s == "rd" else coco_login()
        if not svc_ready(s):
            return xbmcplugin.endOfDirectory(HANDLE, False)
    try:
        items = svc_obj(s).list()
    except debrid.DebridError as e:
        return fail("%s: %s" % (SVC_NAMES[s], e))
    if not items:
        add_dir("Nothing on %s yet - torrents you play through it show up here" % SVC_NAMES[s], {"action": "noop"},
                folder=False)
    for it in items:
        state = "[COLOR lightgreen]ready[/COLOR]" if it["ready"] else "[COLOR gold]%d%% %s[/COLOR]" % (
            it["progress"], it["state"])
        add_dir("%s  [COLOR grey]%s[/COLOR]  %s" % (it["name"], fmt_size(it.get("size")), state),
                {"action": "svc_files", "svc": s, "id": it["id"]}, plot=it["name"],
                ctx=[("Delete from %s" % SVC_NAMES[s], "RunPlugin(%s)" % url(action="svc_delete", svc=s, id=it["id"]))])
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def svc_delete(p):
    if not xbmcgui.Dialog().yesno(NAME, "Delete this from your %s account?" % SVC_NAMES.get(p.get("svc"), "")):
        return
    try:
        svc_obj(p["svc"]).delete(p["id"])
        notify("Deleted")
    except debrid.DebridError as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)
    xbmc.executebuiltin("Container.Refresh")


def rd_menu():
    d = xbmcgui.Dialog()
    c = rd_client()
    if c:
        try:
            u = c.user()
            info = "Logged in as %s\nAccount: %s\nPremium until: %s" % (u.get("username", "?"), u.get("type", "?"),
                                                                          (u.get("expiration") or "n/a")[:10])
        except debrid.DebridError as e:
            info = "Logged in, but Real-Debrid says: %s" % e
        i = d.select("Real-Debrid", [info.replace("\n", " | "), "Log out of Real-Debrid"])
        if i == 1 and d.yesno(NAME, "Log out of Real-Debrid on this add-on?"):
            rd_save({})
            notify("Logged out of Real-Debrid")
        return
    try:
        dd = debrid.RealDebrid.device_start()
    except Exception as e:
        return d.ok(NAME, "Couldn't start the Real-Debrid log in: %s" % e)
    auth = code_login(NAME + " - Real-Debrid log in", re.sub(r"^https?://", "", dd.get("verification_url") or
                                                              "real-debrid.com/device"),
                      dd.get("user_code") or "?", lambda: debrid.RealDebrid.device_poll(dd["device_code"]),
                      int(dd.get("interval") or 5), int(dd.get("expires_in") or 600))
    if not auth:
        return
    rd_save(auth)
    try:
        u = debrid.RealDebrid(auth, rd_save).user()
        d.ok(NAME, "Real-Debrid logged in as %s" % u.get("username", "?"))
    except debrid.DebridError:
        d.ok(NAME, "Real-Debrid logged in")


# ---------------- binge-watching: play next, continue watching, your usual releases ----------------
def binge_np(wk, s, hd, files, h, name, f, season, ep, anime):
    """What's playing now, for 'play next' and 'Continue watching'."""
    show = binge.show_of(wk)
    if not show:
        return None
    vids = [{"id": x["id"], "name": x.get("name", ""), "size": x.get("size") or 0} for x in files
            if is_video(x.get("name", ""))][:400]
    return {"wk": wk, "show": show, "season": int(season) if season else None, "ep": int(ep), "anime": bool(anime),
            "svc": s, "hd": hd, "hash": h, "name": name, "files": vids, "file": f.get("id"),
            "group": binge.release_group(name) or binge.release_group(f.get("name", "")),
            "res": scrapers.res_rank(name), "audio": scrapers.audio_kind(name) if anime else "",
            "source": binge.release_source(name) or binge.release_source(f.get("name", ""))}


def next_target(show, np):
    """(season, episode) after the one in np, or None when the show has run out."""
    info = binge.load(PROFILE)["shows"].get(show) or {}
    search = info.get("search") or {}
    e = int(np["ep"])
    if show.startswith("an:"):
        eps = int(search.get("eps") or 0)
        return None if eps and e + 1 > eps else (None, e + 1)
    s = int(np.get("season") or 1)
    imdb = search.get("imdb")
    if imdb:
        try:
            eps, _ = catalog_mod.cinemeta_episodes(imdb)
            today = datetime.date.today().isoformat()
            later = sorted((x["season"], x["episode"]) for x in eps if x["season"] > 0 and (x["season"], x["episode"]) > (s, e)
                           and (not x.get("aired") or x["aired"][:10] <= today))
            return later[0] if later else None
        except Exception as ex:
            tublog.debug("Next episode list for %s: %s" % (show, ex))
    return (s, e + 1)


def _open_quiet(s, h, name, wait=25):
    """Open a torrent without any dialogs (cached ones are ready in seconds). -> (handle, files) or None."""
    try:
        obj = svc_obj(s)
        hd = obj.start(h, name)
        end = time.time() + wait
        while time.time() < end:
            st = obj.status(hd)
            if st.get("error"):
                return None
            if st.get("ready") and st.get("files"):
                return hd, st["files"]
            xbmc.sleep(1500)
    except Exception as e:
        tublog.debug("Quiet open on %s failed: %s" % (SVC_NAMES.get(s, s), e))
    return None


def find_next(np, interactive=False):
    """Get the next episode ready: from the same pack if it's in there, otherwise the same release group's next
    episode (cached), else the best cached one. -> dict with a playable url, or None (with the reason logged)."""
    show = np["show"]
    target = next_target(show, np)
    if not target:
        tublog.info("Up next: %s has no more episodes" % show)
        return None
    s2, e2 = target
    anime = show.startswith("an:")
    info = binge.load(PROFILE)["shows"].get(show) or {}
    title = info.get("title") or ""
    base = {"show": show, "season": s2, "ep": e2, "anime": anime, "wk": binge.make_wk(show, s2, e2),
            "label": "%s - %s" % (title, binge.ep_label(show, s2, e2)), "title": title}
    # 1) the same pack already has it
    files = np.get("files") or []
    if len(files) > 1:
        f = pick_video(files, s2, e2, anime)
        if f and f["id"] != np.get("file"):
            try:
                url_ = svc_obj(np["svc"]).link(np["hd"], f["id"])
                return dict(base, url=url_, svc=np["svc"], hd=np["hd"], hash=np["hash"], name=np["name"], files=files,
                            file=f["id"], group=np.get("group"), res=np.get("res"), audio=np.get("audio"),
                            source=np.get("source"),
                            how="same pack")
            except Exception as e:
                tublog.debug("Up next from the same pack failed: %s" % e)
    # 2) search for the next episode
    search = dict(info.get("search") or {})
    if not search:
        tublog.info("Up next: no search saved for %s" % show)
        return None
    sp = dict(search, action="results", ep=e2)
    if s2:
        sp["season"] = s2
    scrape = {k: v for k, v in sp.items() if k not in ("aud", "audio")}
    if anime:
        scrape["audio"] = "all"
    try:
        res, _ = get_results(scrape)
    except Exception as e:
        tublog.warn("Up next search failed: %s" % e)
        return None
    shown = aud_set({"aud": info.get("aud") or search.get("aud") or ""}) if anime else None
    mine = np.get("group") or info.get("group") or ""

    def score(r):
        g = binge.release_group(r["name"])
        src = binge.release_source(r["name"])
        return ((100 if mine and g == mine else 0) + (50 if r.get("cached") else 0) +
                (20 if src and src == np.get("source") else 0) +
                (10 if scrapers.res_rank(r["name"]) == np.get("res") else 0) +
                (5 if anime and scrapers.audio_kind(r["name"]) == np.get("audio") else 0) + min(r.get("seeds", 0), 999) / 1000.0)
    cands = []
    for r in res:
        n = scrapers.named_episode(r["name"])
        if n is not None and n != e2:
            continue
        if shown is not None and scrapers.audio_kind(r["name"]) not in shown:
            continue
        if scrapers.pack_kind(r["name"], s2, anime) == "other":
            continue
        if not interactive and not r.get("cached"):
            continue
        cands.append(r)
    cands.sort(key=lambda r: -score(r))
    for r in cands[:3]:
        svc = "cl" if r.get("cached_on") == "cl" else ("tb" if r.get("cached") and svc_ready("tb") else np.get("svc") or "tb")
        if not svc_ready(svc):
            continue
        got = _open_quiet(svc, r["hash"], r["name"])
        if not got:
            continue
        hd, fl = got
        f = pick_video(fl, s2, e2, anime, r.get("file"))
        if not f:
            continue
        try:
            url_ = svc_obj(svc).link(hd, f["id"])
        except Exception as e:
            tublog.debug("Up next link failed: %s" % e)
            continue
        vids = [{"id": x["id"], "name": x.get("name", ""), "size": x.get("size") or 0} for x in fl if is_video(x.get("name", ""))][:400]
        return dict(base, url=url_, svc=svc, hd=hd, hash=r["hash"], name=r["name"], files=vids, file=f["id"],
                    group=binge.release_group(r["name"]), res=scrapers.res_rank(r["name"]),
                    audio=scrapers.audio_kind(r["name"]) if anime else "", source=binge.release_source(r["name"]),
                    how="same release" if mine and binge.release_group(r["name"]) == mine else (
                        "same source" if np.get("source") and binge.release_source(r["name"]) == np.get("source")
                        else "best cached"))
    tublog.info("Up next: nothing cached for %s %s" % (title, binge.ep_label(show, s2, e2)))
    return dict(base, url=None, search=sp)


def np_from(nx):
    return {k: nx.get(k) for k in ("wk", "show", "season", "ep", "anime", "svc", "hd", "hash", "name", "files", "file",
                                   "group", "res", "audio", "source")}


def prep_next(p):
    """Called by the background service near the end of an episode."""
    np = binge.nowplaying(PROFILE)
    if not np or np.get("wk") != p.get("wk"):
        return
    nx = find_next(np) or {}
    if nx.get("url"):
        w, info = watch_key(dict(nx.get("search") or (binge.load(PROFILE)["shows"].get(nx["show"]) or {}).get("search") or {},
                                 ep=nx["ep"], **({"season": nx["season"]} if nx.get("season") else {})))
        if w and info:
            watched.remember(w, info)
        tublog.info("Up next ready: %s (%s, %s)" % (nx["label"], nx.get("how"), SVC_NAMES.get(nx.get("svc"), "")))
    d = binge.load(PROFILE)
    if np["show"] in d["shows"] and nx.get("label"):
        d["shows"][np["show"]]["next"] = {"label": nx["label"], "season": nx.get("season"), "ep": nx.get("ep")}
        binge.save(PROFILE, d)
    binge.set_next(PROFILE, dict(nx, **{"for": np["wk"]}))


def continue_items():
    if ADDON.getSetting("cw_menu") == "false":
        return
    d = binge.load(PROFILE)
    shows = sorted([(k, v) for k, v in d["shows"].items() if v.get("np") and v.get("search")],
                   key=lambda kv: kv[1].get("ts", 0), reverse=True)[:int(ADDON.getSetting("cw_count") or 3)]
    fresh = binge.newep_load(PROFILE) if ADDON.getSetting("newep_alerts") != "false" else {}
    for show, v in shows:
        nxt = v.get("next") or {}
        last = v.get("last") or {}
        np = v.get("np") or {}
        rp = binge.resume_get(PROFILE, np.get("wk"))
        if rp and np.get("ep") and ADDON.getSetting("resume_mode") != "2":
            add_dir("[COLOR deepskyblue]Resume:[/COLOR] %s - [B]%s[/B]  [COLOR grey](from %s of %s)[/COLOR]" % (
                v.get("title") or show, binge.ep_label(show, np.get("season"), np["ep"]), binge.clock(rp["pos"]),
                binge.clock(rp["total"])), {"action": "cw_play", "show": show, "resume": 1}, folder=False, playable=True,
                art={"thumb": v.get("poster"), "poster": v.get("poster")}, icon=ic("recent"),
                ctx=[("Play the next episode instead", "PlayMedia(%s)" % url(action="cw_play", show=show)),
                     ("Remove from Continue watching", "RunPlugin(%s)" % url(action="cw_remove", show=show))])
            continue
        if nxt.get("ep"):
            lab = binge.ep_label(show, nxt.get("season"), nxt["ep"])
        elif last.get("ep"):
            eps = int((v.get("search") or {}).get("eps") or 0)
            if show.startswith("an:") and eps and int(last["ep"]) >= eps:
                continue  # finished
            lab = binge.ep_label(show, last.get("season"), int(last["ep"]) + 1)
        else:
            continue
        rel = " | ".join(x for x in (v.get("group") or "", v.get("source") if v.get("source") != "Web" else "",
                                     {4: "4K", 3: "1080p", 2: "720p"}.get(v.get("res"), "")) if x)
        new = "  [COLOR gold][B]NEW[/B][/COLOR]" if show in fresh else ""
        add_dir("[COLOR deepskyblue]Continue:[/COLOR] %s - [B]%s[/B]%s%s" % (v.get("title") or show, lab, new,
                                                                            ("  [COLOR grey](%s)[/COLOR]" % rel) if rel else ""),
                {"action": "cw_play", "show": show}, folder=False, playable=True,
                art={"thumb": v.get("poster"), "poster": v.get("poster")}, icon=ic("recent"),
                ctx=[("Remove from Continue watching", "RunPlugin(%s)" % url(action="cw_remove", show=show))])


def new_items():
    """'New episode' rows on the home screen for shows not already in Continue watching."""
    if ADDON.getSetting("newep_alerts") == "false":
        return
    fresh = binge.newep_load(PROFILE)
    if not fresh:
        return
    d = binge.load(PROFILE)
    if ADDON.getSetting("cw_menu") != "false":
        shown = {k for k, v in sorted([(k, v) for k, v in d["shows"].items() if v.get("np") and v.get("search")],
                                      key=lambda kv: kv[1].get("ts", 0), reverse=True)[:int(ADDON.getSetting("cw_count") or 3)]}
    else:
        shown = set()
    for show, e in sorted(fresh.items(), key=lambda kv: kv[1].get("aired", ""), reverse=True):
        if show in shown or show not in d["shows"]:
            continue
        s, ep = e["next"]
        more = ("  [COLOR grey](%d new)[/COLOR]" % e["count"]) if e.get("count", 1) > 1 else ""
        add_dir("[COLOR gold]New episode:[/COLOR] %s - [B]%s[/B]%s" % (e.get("title") or show, binge.ep_label(show, s, ep), more),
                {"action": "cw_play", "show": show}, folder=False, playable=True,
                art={"thumb": e.get("poster"), "poster": e.get("poster")}, icon=ic("recent"),
                ctx=[("Dismiss", "RunPlugin(%s)" % url(action="newep_dismiss", show=show))])


def newep_dismiss(show):
    d = binge.newep_load(PROFILE)
    d.pop(show, None)
    binge.newep_save(PROFILE, d)
    xbmc.executebuiltin("Container.Refresh")


def cw_play(p):
    """One click: the next episode of a show, same release as last time if it's cached (or carry on the one you
    stopped part-way through)."""
    show = p.get("show")
    v = binge.load(PROFILE)["shows"].get(show) or {}
    np = v.get("np")
    fail_ = lambda: xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())  # noqa: E731
    if not np:
        return fail_()
    if p.get("resume") and np.get("hd") and np.get("file") is not None:
        try:
            link = svc_obj(np.get("svc") or "tb").link(np["hd"], np["file"])
        except Exception as e:
            tublog.info("Resume: the file has gone from %s (%s) - finding it again" % (SVC_NAMES.get(np.get("svc"), "?"), e))
            link = None
        if link:
            binge.started(PROFILE, np)
            track(np["wk"])
            xbmcgui.Window(10000).setProperty("tub.resume_now", np["wk"])  # carry on without asking
            li = xbmcgui.ListItem(path=link)
            set_info(li, "%s - %s" % (v.get("title") or "", binge.ep_label(show, np.get("season"), np["ep"])), media="episode")
            return xbmcplugin.setResolvedUrl(HANDLE, True, li)
        sp = dict(v.get("search") or {}, action="results", ep=np["ep"])
        if np.get("season"):
            sp["season"] = np["season"]
        fail_()
        return xbmc.executebuiltin("Container.Update(%s)" % url(**sp))
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Getting the next episode of %s ready..." % (v.get("title") or ""))
    try:
        nx = find_next(np, interactive=True) or {}
    finally:
        prog.close()
    if not nx.get("label"):
        notify("%s has no more episodes" % (v.get("title") or "That show"))
        return fail_()
    if not nx.get("url"):  # nothing cached - show the list for that episode instead
        notify("Nothing cached for %s - here's the list" % nx["label"])
        fail_()
        return xbmc.executebuiltin("Container.Update(%s)" % url(**(nx.get("search") or {})))
    binge.started(PROFILE, np_from(nx))
    track(nx["wk"])
    li = xbmcgui.ListItem(path=nx["url"])
    set_info(li, nx["label"], media="episode")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_hash(h, name, season=None, ep=None, anime=False, fname=None, wk=None, cached=""):
    fail_ = lambda: xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())  # noqa: E731
    services = choose_services(cached)
    if not services:
        return fail_()
    got = get_torrent(h, name, "torrent", services)
    if not got:
        return fail_()
    s, hd, files = got
    f = pick_video(files, season, ep, anime, fname)
    if not f:
        vids = sorted([x for x in files if is_video(x.get("name", ""))], key=lambda x: x.get("name", ""))
        if not vids:
            notify("No video file found", xbmcgui.NOTIFICATION_WARNING)
            return fail_()
        i = xbmcgui.Dialog().select("Couldn't spot episode %s - pick the file" % (ep or ""),
                                    [os.path.basename(x["name"]) for x in vids])
        if i < 0:
            return fail_()
        f = vids[i]
    try:
        np = binge_np(wk, s, hd, files, h, name, f, season, ep, anime) if (wk and ep) else None
        if np:
            binge.started(PROFILE, np)
        elif wk:
            g = binge.release_group(name)
            if g:  # films: just count the release group for "your usual"
                d = binge.load(PROFILE)
                d["groups"][g] = d["groups"].get(g, 0) + 1
                binge.save(PROFILE, d)
    except Exception:
        tublog.exc("Remembering what's playing failed")
    track(wk)
    resolve_svc(s, hd, f["id"])


def open_torrent(h, name, what="torrent", cached=""):
    """Add a torrent on the chosen service and wait for its files. -> (service, handle, {"files": [...]}) or Nones."""
    services = choose_services(cached)
    got = get_torrent(h, name, what, services) if services else None
    if not got:
        return None, None, None
    s, hd, files = got
    return s, hd, {"files": files}


def pack_open(h, name, cached=""):
    """Open a season pack on the chosen service and show its files so you can pick episodes."""
    services = choose_services(cached)
    got = get_torrent(h, name, "season pack", services) if services else None
    if not got:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    s, hd, files = got
    if s == "tb":
        return list_files("torrents", hd)
    svc_files_list(s, hd)


AUDIO_EXT = (".flac", ".mp3", ".m4a", ".ogg", ".opus", ".wav", ".ape", ".wv", ".aac", ".alac", ".aiff", ".wma")


def track_info(name):
    base = os.path.splitext(os.path.basename(name))[0]
    mt = re.match(r"^\s*(?:cd\s*\d+[ ._-]*)?(\d{1,3})[ ._\-)\]]+\s*(.+)$", base, re.I)
    if mt:
        return int(mt.group(1)), mt.group(2).strip()
    return 0, base


def audio_files(item):
    files = [f for f in (item.get("files") or []) if f.get("name", "").lower().endswith(AUDIO_EXT)]
    return sorted(files, key=lambda f: f.get("name", ""))


def track_params(tid, f, artist, album, svc="tb"):
    n, title = track_info(f["name"])
    if svc != "tb":
        return {"action": "dplay", "svc": svc, "id": tid, "file": f["id"], "m": 1, "title": title,
                "artist": artist, "album": album, "track": n or None}
    return {"action": "play", "kind": "torrents", "id": tid, "file": f["id"], "m": 1, "title": title,
            "artist": artist, "album": album, "track": n or None}


def music_open(p):
    svc, tid, item = open_torrent(p["hash"], p.get("name", ""), "album", p.get("c", ""))
    if not item:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    files = audio_files(item)
    if not files:
        notify("No audio files found in this torrent", xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    artist, album, cover = p.get("artist") or "", p.get("album") or "", p.get("cover")
    year, reldate = p.get("y") or "", p.get("rel") or ""
    tops = set(f["name"].split("/")[0] for f in files if "/" in f["name"])
    strip = len(tops) == 1 and all("/" in f["name"] for f in files)
    add_dir("[B]Play all (%d tracks)[/B]" % len(files),
            {"action": "play_album", "id": tid, "svc": svc, "artist": artist, "album": album, "y": year}, folder=False,
            art={"thumb": cover, "poster": cover}, icon=ic("music"))
    for f in files:
        rel = f["name"].split("/", 1)[1] if strip else f["name"]
        prm = track_params(tid, f, artist, album, svc)
        prm["y"] = year or None
        tn = prm.get("track")
        li = xbmcgui.ListItem(label="%s%s  [COLOR grey]%s%s%s | %s[/COLOR]" % (
            ("%02d. " % tn) if tn else "", prm["title"], artist or "", (" - " + album) if album else "",
            (" (%s)" % year) if year else "", fmt_size(f.get("size"))))
        set_music_info(li, prm["title"], artist, album, prm.get("track") or 0, year, reldate)
        li.setArt({"thumb": cover, "icon": cover, "fanart": FANART} if cover else {"fanart": FANART})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url(**prm), li, False)
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE)


def play_album(p):
    s = p.get("svc") or "tb"
    try:
        if s == "tb":
            api = get_api()
            if not api:
                return xbmcplugin.endOfDirectory(HANDLE, False)
            files = audio_files(api.mylist("torrents", p["id"]) or {})
        else:
            files = audio_files({"files": svc_obj(s).status(p["id"]).get("files") or []})
    except (TorBoxError, debrid.DebridError) as e:
        notify(str(e), xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    if not files:
        notify("No audio files found", xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    pl.clear()
    for f in files:
        prm = track_params(p["id"], f, p.get("artist", ""), p.get("album", ""), s)
        li = xbmcgui.ListItem(label=prm["title"])
        prm["y"] = p.get("y") or None
        set_music_info(li, prm["title"], prm["artist"], prm["album"], prm.get("track") or 0, p.get("y"))
        li.setProperty("IsPlayable", "true")
        pl.add(url(**prm), li)
    xbmcplugin.endOfDirectory(HANDLE, False)
    xbmc.Player().play(pl)


def coco_key():
    return ADDON.getSetting("cocoleech_key").strip()


def coco_login():
    how = xbmcgui.Dialog().select("Log in to Cocoleech", ["Log in with a code (no typing - recommended)",
                                                     "Type or paste the API key"])
    if how < 0:
        return
    if how == 0:
        return login_coco_code()
    key = xbmcgui.Dialog().input("Paste your Cocoleech API key (members.cocoleech.com/settings)",
                                 defaultt=coco_key()).strip()
    if not key:
        return
    try:
        i = cocoleech.info(key)
    except cocoleech.CocoleechError as e:
        return xbmcgui.Dialog().ok(NAME, "That key did not work:\n%s" % e)
    ADDON.setSetting("cocoleech_key", key)
    xbmcgui.Dialog().ok(NAME, "Cocoleech OK\nUser: %s\nPackage: %s\nExpires: %s" % (
        i.get("username", "?"), i.get("package", i.get("type", "?")), i.get("expire_date", "n/a")))


COCO_HELP = """[B]What Cocoleech does[/B]
Cocoleech is a premium "link unlocker" for file-hosting sites (Rapidgator, Nitroflare, 1fichier, Turbobit, DDownload and
many more). Normally those sites are slow or limited unless you pay for each one; Cocoleech gives you full-speed direct
links for all of them with one account.

[B]Finding links[/B]
"Search file-host links" looks through release blogs (set in Settings > Cocoleech) for posts with file-host links -
movies, TV, or anything else (software, games, books, music). Pick a post, then a link.

[B]Not a video?[/B]
If a file isn't something Kodi can play (an archive, program, disc image, book...) you're asked whether to download it.
Downloads go to your Downloads folder unless you choose another in Settings > Cocoleech. Releases split into parts
(.part1.rar, .part2.rar...) have a "download all parts" option - extract them on your computer afterwards.

[B]How to use it here[/B]
1. Find a file-host link (for example a Rapidgator link on a release blog or forum).
2. Choose "Play links" and paste it - you can paste several at once (one per line or separated by spaces).
   On Android, long-press in the keyboard box and choose Paste.
3. Pick one to play. Links you play are kept under "Recent links".

[B]Tips[/B]
- "Supported sites" shows every host Cocoleech handles and whether it's working right now.
- Videos (.mkv, .mp4) play straight away. Archives (.rar, .zip) can't be played - pick a link to the video file.
- Torrents and Usenet go through TorBox; Cocoleech is your extra route for file-host links.
- TorBox (paid plan) can unlock many of the same hosts too. If Cocoleech can't do a link, TorBox is tried
  automatically (change the order in Settings > Cocoleech). Pixeldrain links play directly, no account needed.
- Log in with a code instead of typing keys: Tools > Change API key, or Cocoleech > Change API key."""

VIDEO_AUDIO = (".mkv", ".mp4", ".avi", ".mov", ".ts", ".m4v", ".webm", ".wmv", ".mpg", ".mpeg", ".m2ts", ".flac", ".mp3",
               ".m4a", ".ogg", ".opus", ".wav", ".aac")


def coco_menu():
    if not coco_key():
        add_dir("[B]Log in: enter your Cocoleech API key[/B]", {"action": "coco_login"}, folder=False, icon=ic("tools_key"))
    add_dir("[B]Search file-host links[/B]", {"action": "ddl_search"}, folder=False, icon=ic("search"))
    add_dir("Play links (paste one or more)...", {"action": "coco_links"}, icon=ic("tools_link"))
    add_dir("Recent links", {"action": "coco_recent"}, icon=ic("tools_clock"))
    add_dir("Supported sites & status", {"action": "coco_hosts"}, icon=ic("tools_globe"))
    add_dir("Account", {"action": "coco_account"}, folder=False, icon=ic("tools_account"))
    add_dir("Change API key", {"action": "coco_login"}, folder=False, icon=ic("tools_key"))
    if xbmcgui.Window(10000).getProperty("tub.dl_active") == "1":
        add_dir("[COLOR orange]Cancel the download in progress[/COLOR]", {"action": "dl_cancel"}, folder=False,
                icon=ic("tools_download"))
    add_dir("Test release blogs", {"action": "ddl_test"}, folder=False, icon=ic("tools_check"))
    add_dir("What is Cocoleech for?", {"action": "coco_help"}, folder=False, icon=ic("tools_check"))
    xbmcplugin.endOfDirectory(HANDLE)


def coco_remember(link):
    hist = [h for h in store_load("coco_recent.json", []) if h.get("link") != link]
    hist.insert(0, {"link": link, "name": cocoleech.name_from_link(link), "host": cocoleech.host_of(link),
                    "when": int(time.time())})
    store_save("coco_recent.json", hist[:40])


def coco_link_item(link, ctx_extra=None, label_prefix=""):
    name, host = cocoleech.name_from_link(link), cocoleech.host_of(link)
    warn = "" if (name.lower().endswith(VIDEO_AUDIO) or not re.search(r"\.\w{2,4}$", name)) else \
        "  [COLOR orange](not media - can download)[/COLOR]"
    ctx = ctx_extra or []
    add_dir("%s%s  [COLOR grey]%s[/COLOR]%s" % (label_prefix, name, host, warn), {"action": "coco_open", "link": link},
            folder=False, ctx=ctx)


def coco_links(prefill=""):
    if not need_unlocker():
        return xbmcplugin.endOfDirectory(HANDLE, False)
    text = xbmcgui.Dialog().input("Paste file-host link(s) - several are fine", defaultt=prefill).strip()
    links = []
    for u in re.findall(r"https?://[^\s<>\"']+", text):
        u = u.rstrip(".,);]")
        if u not in links:
            links.append(u)
    if not links:
        if text:
            notify("No links found in that text", xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    for u in links:
        coco_link_item(u)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def coco_resolve(link):
    try:
        direct, _, via = unlock(link)
    except UnlockError as e:
        notify("Couldn't unlock it: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    coco_remember(link)
    track(None)
    li = xbmcgui.ListItem(path=direct)
    set_info(li, cocoleech.name_from_link(link))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def coco_recent():
    hist = store_load("coco_recent.json", [])
    if not hist:
        add_dir("Nothing yet - links you play show up here", {"action": "coco_links"}, icon=ic("tools_link"))
    for h in hist:
        coco_link_item(h["link"], [("Remove from Recent links", "RunPlugin(%s)" % url(action="coco_forget", link=h["link"]))])
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def coco_hosts():
    try:
        hs = cocoleech.hosts()
    except cocoleech.CocoleechError as e:
        return fail("Cocoleech: %s" % e)
    on = [h for h, ok in hs if ok]
    off = [h for h, ok in hs if not ok]
    add_dir("[B]%d sites working now, %d not working[/B]" % (len(on), len(off)), {"action": "coco_hosts"},
            icon=ic("tools_globe"))
    for h in on:
        add_dir("[COLOR lightgreen]\u25cf[/COLOR] %s" % h, {"action": "coco_hosts"}, icon=ic("tools_check"))
    for h in off:
        add_dir("[COLOR red]\u25cf[/COLOR] %s  [COLOR grey](not working right now)[/COLOR]" % h, {"action": "coco_hosts"},
                icon=ic("tools_globe"))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def coco_account():
    if not coco_key():
        return coco_login()
    try:
        i = cocoleech.info(coco_key())
    except cocoleech.CocoleechError as e:
        return xbmcgui.Dialog().ok(NAME, "Cocoleech: %s" % e)
    traffic = i.get("traffic_left")
    if traffic and str(traffic).isdigit():
        traffic = fmt_size(int(traffic))
    xbmcgui.Dialog().ok(NAME + " - Cocoleech", "User: %s\nPlan: %s\nExpires: %s\nTraffic left: %s" % (
        i.get("username", "?"), i.get("package") or i.get("type") or "?", i.get("expire_date") or "n/a",
        traffic or "n/a"))


# ---------------- file-host link search + downloads ----------------
def platform_name():
    for k, n in (("Android", "android"), ("Windows", "windows"), ("OSX", "mac"), ("IOS", "ios"), ("TVOS", "tvos"),
                 ("Linux", "linux")):
        try:
            if xbmc.getCondVisibility("System.Platform.%s" % k):
                return n
        except Exception:
            pass
    return "other"


def is_pc():
    return platform_name() in ("windows", "mac", "linux")


def download_folder():
    f = ADDON.getSetting("dl_folder").strip()
    if f:
        return xbmcvfs.translatePath(f)
    if platform_name() == "android":
        return "/storage/emulated/0/Download"
    if is_pc():
        return os.path.join(os.path.expanduser("~"), "Downloads")
    return xbmcvfs.translatePath("special://home/downloads")


# ---------------- turning a file-host link into a direct link: Pixeldrain (free), Cocoleech, TorBox ----------------
class UnlockError(Exception):
    pass


def tb_key():
    return ADDON.getSetting("api_key").strip()


def can_unlock():
    return bool(coco_key() or tb_key() or rd_auth().get("token"))


def need_unlocker():
    """True when Cocoleech or TorBox is logged in (asks to log in to one if neither is)."""
    if can_unlock():
        return True
    i = xbmcgui.Dialog().select("Log in to unlock file-host links", ["Cocoleech", "TorBox (paid plan: web downloads)"])
    if i == 0:
        coco_login()
    elif i == 1:
        login()
    return can_unlock()


def unlock_order():
    return {"1": ("torbox", "coco"), "2": ("coco",), "3": ("torbox",)}.get(ADDON.getSetting("unlock_order"),
                                                                           ("coco", "torbox"))


def tb_hostset():
    """File hosts TorBox can fetch from (cached for a day)."""
    c = store_load("tb_hosts.json", {})
    if c.get("hosts") is not None and time.time() - c.get("ts", 0) < 86400:
        return c["hosts"]
    if not tb_key():
        return []
    hs = []
    try:
        for h in TorBoxAPI(tb_key()).webdl_hosters():
            if h.get("status") is False:
                continue
            hs.extend((x or "").lower() for x in (h.get("domains") or []))
    except Exception as e:
        tublog.warn("TorBox file-host list: %s" % e)
        hs = c.get("hosts") or []
    store_save("tb_hosts.json", {"ts": time.time(), "hosts": hs})
    return hs


def host_in(h, hosts):
    h = (h or "").lower()
    return any(h == s or h.endswith("." + s) for s in hosts if s)


def pixeldrain_direct(link):
    m = re.search(r"pixeldrain\.(?:com|net)/(?:u|api/file)/([0-9A-Za-z\-]+)", link)
    return "https://pixeldrain.com/api/file/%s" % m.group(1) if m else None


def wait_ready(direct, name):
    """Cocoleech sometimes hands out the link before the file is ready on its server - wait for it (as ResolveURL does)."""
    import requests

    def ready():
        try:
            r = requests.head(direct, allow_redirects=True, timeout=12, headers={"User-Agent": "Kodi-TorUtilityBox"})
            return r.status_code < 400 or r.status_code == 405
        except requests.RequestException:
            return False
    if ready():
        return True
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Cocoleech is getting the file ready...\n%s" % name[:70])
    start = time.time()
    while time.time() - start < 180 and not prog.iscanceled():
        for _ in range(10):
            xbmc.sleep(500)
            if prog.iscanceled():
                break
        if ready():
            prog.close()
            return True
        prog.update(min(95, int((time.time() - start) / 1.8)), "Cocoleech is getting the file ready... (%ds)\n%s" % (
            time.time() - start, name[:70]))
    prog.close()
    tublog.warn("Cocoleech link still not ready after %ds: %s" % (time.time() - start, name))
    return False


def webdl_unlock(link, name):
    """Have TorBox fetch the link (shows progress), -> (direct url, file name)."""
    api = TorBoxAPI(tb_key())
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Sending the link to TorBox...\n%s" % name[:70])
    item, wid = None, None
    try:
        wid = api.add_webdl(link)
        if not wid:
            raise UnlockError("TorBox didn't accept the link")
        end = time.time() + 30 * 60
        while time.time() < end:
            it = api.mylist("webdl", wid) or {}
            if it.get("files") and (it.get("download_present") or it.get("download_finished")):
                item = it
                break
            if prog.iscanceled():
                prog.close()
                if not xbmcgui.Dialog().yesno(NAME, "Keep fetching it on TorBox in the background?\n"
                                                    "(It'll appear in My TorBox > My Web Downloads.)"):
                    try:
                        api.delete("webdl", wid)
                    except TorBoxError:
                        pass
                raise UnlockError("cancelled")
            pct = int(float(it.get("progress") or 0) * 100)
            eta = it.get("eta")
            prog.update(pct, "TorBox is fetching the file: %s %d%%%s\n%s" % (
                (it.get("download_state") or "queued").replace("_", " "), pct,
                (" - %s left" % fmt_time(eta)) if isinstance(eta, (int, float)) and eta > 0 else "",
                (it.get("name") or name)[:70]))
            xbmc.sleep(2000)
    except TorBoxError as e:
        raise UnlockError(str(e))
    finally:
        try:
            prog.close()
        except Exception:
            pass
    if not item:
        raise UnlockError("TorBox is taking a long time - it may still finish (My TorBox > My Web Downloads)")
    files = item.get("files") or []
    vids = [f for f in files if (f.get("name") or f.get("short_name") or "").lower().endswith(VIDEO_AUDIO)]
    f = max(vids or files, key=lambda x: x.get("size") or 0)
    try:
        direct = api.request_dl("webdl", wid, f.get("id"))
    except TorBoxError:
        direct = api.redirect_url("webdl", wid, f.get("id"))
    return direct, f.get("short_name") or f.get("name") or name


def unlock(link):
    """-> (direct url, file name, service). Raises UnlockError saying why each service couldn't do it."""
    name = cocoleech.name_from_link(link)
    pd = pixeldrain_direct(link)
    if pd:
        return pd, name, "Pixeldrain"
    host = cocoleech.host_of(link)
    errs = []
    for svc in unlock_order():
        if svc == "coco":
            if not coco_key():
                errs.append("Cocoleech: not logged in")
                continue
            try:
                direct = cocoleech.generate(coco_key(), link)
            except cocoleech.CocoleechError as e:
                errs.append("Cocoleech: %s" % e)
                continue
            wait_ready(direct, name)
            return direct, name, "Cocoleech"
        if not tb_key():
            errs.append("TorBox: not logged in")
            continue
        hs = tb_hostset()
        if hs and not host_in(host, hs):
            errs.append("TorBox: doesn't support %s" % host)
            continue
        try:
            direct, fname = webdl_unlock(link, name)
            return direct, fname, "TorBox"
        except UnlockError as e:
            if "cancelled" in str(e):
                raise
            errs.append("TorBox: %s" % e)
    if rd_client():
        try:
            return rd_client().unrestrict(link), name, "Real-Debrid"
        except debrid.DebridError as e:
            errs.append("Real-Debrid: %s" % e)
    raise UnlockError(" | ".join(errs) or "log in to Cocoleech, TorBox or Real-Debrid first")


# ---------------- log in with a code ----------------
def code_login(title, where, code, check, interval=5, expires=600):
    """Show the web address + code and wait until it's been entered. -> result of check() or None."""
    prog = xbmcgui.DialogProgress()
    prog.create(title, "Go to [B]%s[/B]\nEnter the code: [B][COLOR yellow]%s[/COLOR][/B]" % (where, code))
    end = time.time() + expires
    while time.time() < end and not prog.iscanceled():
        left = int(end - time.time())
        prog.update(int(100 * left / expires), "Go to [B]%s[/B] on your phone or computer\nEnter the code: "
                    "[B][COLOR yellow]%s[/COLOR][/B]\nWaiting for you... %d:%02d left" % (where, code, left // 60, left % 60))
        for _ in range(int(interval * 2)):
            xbmc.sleep(500)
            if prog.iscanceled():
                break
        try:
            res = check()
        except Exception as e:
            tublog.debug("code login check: %s" % e)
            res = None
        if res:
            prog.close()
            return res
    prog.close()
    return None


def login_torbox_code():
    import torbox_api
    try:
        dd = torbox_api.device_start("TorUtilityBox")
    except Exception as e:
        tublog.warn("TorBox code login: %s" % e)
        return xbmcgui.Dialog().ok(NAME, "Couldn't start the code login (%s).\nUse 'Type the API key' instead." % e)
    where = dd.get("friendly_verification_url") or dd.get("verification_url") or "torbox.app/link"
    key = code_login(NAME + " - TorBox log in", re.sub(r"^https?://", "", where), dd.get("code") or "?",
                     lambda: torbox_api.device_token(dd["device_code"]), int(dd.get("interval") or 5))
    if not key:
        return
    try:
        u = TorBoxAPI(key).user()
    except TorBoxError as e:
        return xbmcgui.Dialog().ok(NAME, "TorBox gave a key but it didn't work:\n%s" % e)
    ADDON.setSetting("api_key", key)
    store_save("tb_hosts.json", {})
    xbmcgui.Dialog().ok(NAME, "Logged in as %s" % u.get("email", "your TorBox account"))
    xbmc.executebuiltin("Container.Refresh")


def login_coco_code():
    try:
        dd = cocoleech.device_start("Kodi TorUtilityBox")
    except Exception as e:
        tublog.warn("Cocoleech code login: %s" % e)
        return xbmcgui.Dialog().ok(NAME, "Couldn't start the code login (%s).\nUse 'Type the API key' instead." % e)
    where = re.sub(r"^https?://", "", dd.get("base_url") or dd.get("user_url") or "members.cocoleech.com")
    key = code_login(NAME + " - Cocoleech log in", where, dd["pin"], lambda: cocoleech.device_check(dd["pin"], dd["check"]),
                     5, int(dd.get("expires_in") or 300))
    if not key:
        return
    ADDON.setSetting("cocoleech_key", key)
    try:
        i = cocoleech.info(key)
        xbmcgui.Dialog().ok(NAME, "Cocoleech logged in\nUser: %s\nPackage: %s" % (i.get("username", "?"),
                                                                                    i.get("package", i.get("type", "?"))))
    except cocoleech.CocoleechError:
        xbmcgui.Dialog().ok(NAME, "Cocoleech logged in")


def coco_hostset():
    """Hosts Cocoleech supports (cached for a day) - used to spot file-host links on blogs."""
    c = store_load("coco_hosts.json", {})
    if c.get("hosts") and time.time() - c.get("ts", 0) < 86400:
        return c["hosts"]
    try:
        hs = [h for h, ok in cocoleech.hosts()]
    except Exception:
        hs = c.get("hosts") or []
    store_save("coco_hosts.json", {"ts": time.time(), "hosts": hs})
    return hs


def ddl_sites():
    return [ADDON.getSetting("ddl%s_url" % n).strip() for n in ("1", "2", "3") if ADDON.getSetting("ddl%s_url" % n).strip()]


def ddl_search_start():
    d = xbmcgui.Dialog()
    kind = d.select("Search file-host links for", ["A movie", "A TV episode", "A whole TV season",
                                                    "Anything (software, games, books, music...)"])
    if kind < 0:
        return
    q = d.input("Title" if kind < 3 else "What are you looking for?").strip()
    if not q:
        return
    p = {"action": "ddl_results", "q": q}
    if kind == 3:
        p["free"] = 1
    else:
        try:
            metas = scrapers.cinemeta(q, "movie" if kind == 0 else "series")
        except Exception:
            metas = []
        if metas:
            i = d.select("Pick title", ["%s (%s)" % (x["name"], x["year"]) if x["year"] else x["name"] for x in metas])
            if i < 0:
                return
            meta = metas[i]
            p.update(imdb=meta["imdb"], title=meta["name"], year=meta["year"],
                     name=(meta["name"] + " " + meta["year"]).strip() if kind == 0 else meta["name"])
        else:
            p.update(title=q, name=q)
        if kind in (1, 2):
            s = d.input("Season number", type=xbmcgui.INPUT_NUMERIC).strip()
            if not s.isdigit():
                return
            p["season"] = int(s)
            if kind == 1:
                e = d.input("Episode number", type=xbmcgui.INPUT_NUMERIC).strip()
                if not e.isdigit():
                    return
                p["ep"] = int(e)
            else:
                p["pack"] = 1
    xbmc.executebuiltin("Container.Update(%s)" % url(**p))


def ddl_results(p):
    if not need_unlocker():
        return xbmcplugin.endOfDirectory(HANDLE, False)
    sites = ddl_sites()
    if not sites:
        xbmcgui.Dialog().ok(NAME, "No release blogs set.\nAdd one or more in Settings > Cocoleech.")
        return xbmcplugin.endOfDirectory(HANDLE, False)
    free = bool(p.get("free"))
    ctx = None if free else scraper_ctx(p)
    q = p.get("q", "") if free else ctx["query"]
    timeout = int(ADDON.getSetting("scrape_timeout") or 15)
    hosts = coco_hostset()
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Searching release blogs for file-host links...\n%s" % q)

    def one(site):
        t0 = time.time()
        try:
            return site, ddl.search_site(site, q, timeout, hosts, int(ADDON.getSetting("ddl_posts") or 6)), None, time.time() - t0
        except Exception as e:
            return site, None, "%s" % e, time.time() - t0
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=len(sites)) as ex:
        rows = list(ex.map(one, sites))
    prog.close()
    posts, report = [], []
    for site, got, err, secs in rows:
        name = ddl.host_of(site if site.startswith("http") else "https://" + site)
        report.append("%s:%s" % (name, len(got) if got is not None else "x"))
        if err:
            notify("%s - %s" % (name, err[:100]), xbmcgui.NOTIFICATION_WARNING)
        for post in got or []:
            if ctx and not scrapers.relevant(post["title"], ctx):
                continue
            posts.append(post)
    seen, uniq = set(), []
    for post in posts:
        k = re.sub(r"\W+", "", post["title"].lower())
        if k not in seen:
            seen.add(k)
            uniq.append(post)
    if not uniq:
        notify("No file-host links found  [%s]" % "  ".join(report), xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    notify("Found %d posts  [%s]" % (len(uniq), "  ".join(report)))
    key = "%x" % (abs(hash(json.dumps(p, sort_keys=True))) & 0xffffffff)
    store_save("ddl_last.json", {"key": key, "posts": uniq})
    for i, post in enumerate(uniq):
        groups = ddl.group_links(post["links"])
        bits = []
        for h, items in sorted(groups.items(), key=lambda kv: kv[0]):
            parts = [x for x in items if x[1]]
            bits.append("%s x%d parts" % (h.split(".")[0], len(parts)) if len(parts) > 1 else h.split(".")[0])
        tag = scrapers.tags(post["title"]) if not free else ""
        add_dir("%s  [COLOR grey]%s%s | %s[/COLOR]" % (post["title"], (tag + " | ") if tag else "", ", ".join(bits),
                                                      post.get("source", "")),
                {"action": "ddl_post", "key": key, "i": i}, plot=post["title"], icon=ic("tools_link"))
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def ddl_post(p):
    last = store_load("ddl_last.json", {})
    try:
        post = last["posts"][int(p["i"])]
    except Exception:
        notify("That list has expired - search again", xbmcgui.NOTIFICATION_WARNING)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    coco_ok = set(coco_hostset()) if coco_key() else set()
    tb_ok = set(tb_hostset()) if tb_key() and "torbox" in unlock_order() else set()
    for h, items in sorted(ddl.group_links(post["links"]).items()):
        by = [n for n, hs in (("Cocoleech", coco_ok), ("TorBox", tb_ok)) if hs and host_in(h, hs)]
        if "pixeldrain" in h:
            note = "  [COLOR lightgreen](free - plays direct)[/COLOR]"
        elif not (coco_ok or tb_ok):
            note = ""
        elif by:
            note = "  [COLOR grey](via %s)[/COLOR]" % " or ".join(by)
        else:
            note = "  [COLOR red](neither Cocoleech nor TorBox supports this host)[/COLOR]"
        parts = [x for x in items if x[1]]
        if len(parts) > 1:
            add_dir("[B]%s - download all %d parts[/B]%s" % (h, len(parts), note),
                    {"action": "dl_many", "links": " ".join(x[2] for x in items), "title": post["title"]},
                    folder=False, icon=ic("tools_download"))
        for name, part, link in items:
            coco_link_item(link, label_prefix="[COLOR grey]%s[/COLOR]  " % h.split(".")[0])
    add_dir("[COLOR grey]Open the blog post in a web browser: %s[/COLOR]" % post.get("url", ""), {"action": "noop"},
            folder=False)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def probe(direct, name):
    """-> (is_media, file_name, size)"""
    n = (name or "").lower()
    if n.endswith(VIDEO_AUDIO):
        return True, name, 0
    import requests
    ctype, size, fname = "", 0, name
    try:
        r = requests.head(direct, allow_redirects=True, timeout=12, headers={"User-Agent": "Kodi-TorUtilityBox"})
        ctype = (r.headers.get("Content-Type") or "").lower()
        size = int(r.headers.get("Content-Length") or 0)
        cd = r.headers.get("Content-Disposition") or ""
        mm = re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)", cd, re.I)
        if mm:
            from urllib.parse import unquote
            fname = unquote(mm.group(1))
    except Exception:
        pass
    media = ctype.startswith(("video/", "audio/")) or fname.lower().endswith(VIDEO_AUDIO)
    return media, fname, size


def kind_of(name):
    n = name.lower()
    for exts, what in (((".rar", ".zip", ".7z", ".tar", ".gz"), "an archive"), ((".exe", ".msi", ".dmg", ".apk", ".pkg"),
                       "a program / installer"), ((".iso", ".img", ".bin", ".cue", ".chd"), "a disc image"),
                       ((".pdf", ".epub", ".mobi", ".azw3", ".cbz", ".cbr"), "a book / document")):
        if n.endswith(exts) or re.search(r"\.(r\d\d|\d{3}|part\d+\.rar)$", n) and what == "an archive":
            return what
    return "not a video or music file"


def coco_open(p):
    """Unlock a file-host link: play it if it's video/music, otherwise offer to download it."""
    if not need_unlocker():
        return
    link = p["link"]
    try:
        direct, fname0, via = unlock(link)
    except UnlockError as e:
        return notify("Couldn't unlock it: %s" % e, xbmcgui.NOTIFICATION_ERROR)
    tublog.debug("Unlocked with %s: %s" % (via, fname0))
    coco_remember(link)
    media, fname, size = probe(direct, fname0)
    if media:
        li = xbmcgui.ListItem(path=direct)
        set_info(li, fname)
        return xbmc.Player().play(direct, li)
    file_menu(fname, size, lambda: direct,
              heading="%s is %s - Kodi can't play it. What now?" % (fname[:45], kind_of(fname)))


def dl_many(p):
    links = [u for u in (p.get("links") or "").split() if u]
    if not links:
        return
    if not need_unlocker():
        return
    folder = pick_folder("Save all %d parts to..." % len(links))
    if not folder:
        return
    extract = any(is_archive(cocoleech.name_from_link(u)) for u in links) and xbmcgui.Dialog().yesno(
        NAME, "Extract the files once all %d parts have downloaded?" % len(links), nolabel="Just download",
        yeslabel="Extract too")
    todo = []
    for u in links:
        try:
            direct, fname, via = unlock(u)
            todo.append((direct, fname))
            coco_remember(u)
        except UnlockError as e:
            notify("%s: %s" % (cocoleech.name_from_link(u), e), xbmcgui.NOTIFICATION_ERROR)
            if "cancelled" in str(e):
                break
    if todo:
        download_links(todo, p.get("title", ""), folder, extract=extract)


class Cancelled(Exception):
    pass


ARCHIVE_EXT = (".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".bz2", ".xz")


def is_archive(name):
    n = (name or "").lower()
    return n.endswith(ARCHIVE_EXT) or bool(re.search(r"\.(r\d\d|z\d\d|\d{3})$", n))


def is_first_part(name):
    n = name.lower()
    mm = re.search(r"\.part0*(\d+)\.rar$", n)
    if mm:
        return int(mm.group(1)) == 1
    if re.search(r"\.(r\d\d|z\d\d)$", n):
        return False
    mm = re.search(r"\.(\d{3})$", n)
    if mm:
        return mm.group(1) == "001"
    return True


def pick_folder(heading="Where should it be saved?"):
    """Folder picker (starts at the last folder used). None if cancelled."""
    last = store_load("last_folder.json", {}).get("path") or download_folder()
    if ADDON.getSetting("dl_ask") == "false":
        return last
    try:
        f = xbmcgui.Dialog().browse(3, heading, "files", "", False, False, last)
    except Exception:
        f = last
    if not f:
        return None
    f = xbmcvfs.translatePath(f)
    store_save("last_folder.json", {"path": f})
    return f


class Progress(object):
    """On-screen progress (with cancel) or a small bar in the corner, per the Downloads setting."""

    def __init__(self, heading):
        self.fg = ADDON.getSetting("dl_progress") != "1"
        self.heading = heading
        self.win = xbmcgui.Window(10000)
        self.win.setProperty("tub.dl_cancel", "")
        self.win.setProperty("tub.dl_active", "1")
        self.mon = xbmc.Monitor()
        self.d = xbmcgui.DialogProgress() if self.fg else xbmcgui.DialogProgressBG()
        self.d.create(heading, "Starting...")

    def update(self, pct, line1, line2=""):
        pct = max(0, min(100, int(pct)))
        if self.fg:
            self.d.update(pct, line1 + ("\n" + line2 if line2 else ""))
        else:
            self.d.update(pct, self.heading, line1)

    def cancelled(self):
        if self.mon.abortRequested() or self.win.getProperty("tub.dl_cancel") == "1":
            return True
        return bool(self.fg and self.d.iscanceled())

    def close(self):
        self.d.close()
        self.win.setProperty("tub.dl_active", "")


def fmt_time(sec):
    sec = int(sec)
    if sec >= 3600:
        return "%dh %02dm" % (sec // 3600, sec % 3600 // 60)
    return "%dm %02ds" % (sec // 60, sec % 60) if sec >= 60 else "%ds" % sec


def download_links(items, title, folder=None, extract=False):
    """items = [(direct_url, file_name)] -> downloads them one after another, then (optionally) extracts."""
    import requests
    folder = folder or download_folder()
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception as e:
        return xbmcgui.Dialog().ok(NAME, "Can't use this folder:\n%s\n%s" % (folder, e))
    prog = Progress(NAME + " - downloading")
    saved = []
    try:
        for idx, (direct, name) in enumerate(items, 1):
            safe = re.sub(r'[\\/:*?"<>|]+', "_", name).strip() or "download"
            path = os.path.join(folder, safe[:180])
            tmp = path + ".downloading"
            t0 = time.time()
            try:
                with requests.get(direct, stream=True, timeout=30, headers={"User-Agent": "Kodi-TorUtilityBox"}) as r:
                    r.raise_for_status()
                    total = int(r.headers.get("Content-Length") or 0)
                    got, last = 0, 0
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(1 << 20):
                            if prog.cancelled():
                                raise Cancelled()
                            f.write(chunk)
                            got += len(chunk)
                            if time.time() - last > 0.7:
                                last = time.time()
                                speed = got / max(0.1, last - t0)
                                left = (total - got) / speed if total and speed else 0
                                prog.update(got * 100.0 / total if total else 0,
                                            "%s%s" % (("File %d of %d: " % (idx, len(items))) if len(items) > 1 else "", safe[:60]),
                                            "%s%s  -  %s/s%s" % (fmt_size(got), (" of " + fmt_size(total)) if total else "",
                                                                  fmt_size(speed), ("  -  %s left" % fmt_time(left)) if left else ""))
                os.replace(tmp, path)
                saved.append(path)
            except Cancelled:
                try:
                    os.remove(tmp)
                except Exception:
                    pass
                prog.close()
                notify("Download cancelled")
                return []
            except Exception as e:
                try:
                    os.remove(tmp)
                except Exception:
                    pass
                notify("Download failed: %s - %s" % (safe[:40], e), xbmcgui.NOTIFICATION_ERROR)
        if extract and saved:
            out = []
            for path in saved:
                if is_archive(path) and is_first_part(os.path.basename(path)):
                    out += extract_archive(path, prog) or []
            prog.close()
            return after_extract(out, folder)
    finally:
        try:
            prog.close()
        except Exception:
            pass
    if saved:
        notify("Saved %d file%s to %s" % (len(saved), "" if len(saved) == 1 else "s", folder))
    return saved


def archive_base(path):
    n = os.path.basename(path)
    n = re.sub(r"(\.part0*1)?\.(zip|rar|7z|tar|tgz|gz|bz2|xz|001)$", "", n, flags=re.I)
    n = re.sub(r"\.tar$", "", n, flags=re.I)
    return os.path.join(os.path.dirname(path), n or "extracted")


def extract_archive(path, prog=None):
    """Extract into a folder named after the archive. Zip is built in; rar/7z use Kodi's archive add-ons."""
    import zipfile
    dest = archive_base(path)
    own = prog is None
    prog = prog or Progress(NAME + " - extracting")
    done_files = []
    try:
        os.makedirs(dest, exist_ok=True)
        if path.lower().endswith(".zip"):
            with zipfile.ZipFile(path) as zf:
                members = [mi for mi in zf.infolist() if not mi.is_dir()]
                total = float(sum(mi.file_size for mi in members) or 1)
                done = 0
                root = os.path.normpath(dest)
                for mi in members:
                    target = os.path.normpath(os.path.join(dest, mi.filename))
                    if not (target == root or target.startswith(root + os.sep)):
                        continue  # never write outside the folder
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(mi) as src, open(target, "wb") as out:
                        while True:
                            if prog.cancelled():
                                raise Cancelled()
                            chunk = src.read(1 << 20)
                            if not chunk:
                                break
                            out.write(chunk)
                            done += len(chunk)
                            prog.update(done * 100 / total, "Extracting: %s" % os.path.basename(mi.filename)[:60],
                                        "%s of %s" % (fmt_size(done), fmt_size(total)))
                    done_files.append(target)
        else:
            files = vfs_archive_files(path)
            if files is None:
                xbmcgui.Dialog().ok(NAME, "Kodi needs its archive add-on to open %s files.\n"
                                    "Add-ons > Install from repository > Kodi Add-on repository > VFS add-ons > "
                                    "Archive support (and RAR archive support for .rar), then try again."
                                    % os.path.splitext(path)[1])
                return []
            for i, (src, rel) in enumerate(files, 1):
                if prog.cancelled():
                    raise Cancelled()
                target = os.path.normpath(os.path.join(dest, rel))
                if not target.startswith(os.path.normpath(dest)):
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                prog.update(i * 100.0 / len(files), "Extracting %d of %d: %s" % (i, len(files), os.path.basename(rel)[:50]))
                if xbmcvfs.copy(src, target):
                    done_files.append(target)
        if done_files and ADDON.getSetting("dl_delete_archive") == "true":
            for f in archive_parts(path):
                try:
                    os.remove(f)
                except Exception:
                    pass
    except Cancelled:
        notify("Extracting cancelled")
    except RuntimeError as e:
        xbmcgui.Dialog().ok(NAME, "Couldn't extract (it may need a password):\n%s" % e)
    except Exception as e:
        xbmcgui.Dialog().ok(NAME, "Couldn't extract %s:\n%s" % (os.path.basename(path), e))
    finally:
        if own:
            prog.close()
    return done_files


def archive_parts(path):
    folder, n = os.path.dirname(path), os.path.basename(path)
    stem = re.sub(r"(\.part0*1)?\.(zip|rar|7z|001)$", "", n, flags=re.I)
    try:
        return [os.path.join(folder, f) for f in os.listdir(folder) if f.startswith(stem) and is_archive(f)]
    except Exception:
        return [path]


def vfs_archive_files(path):
    from urllib.parse import quote
    for scheme in ("archive", "rar"):
        root = "%s://%s/" % (scheme, quote(path, safe=""))
        found = []

        def walk(p, rel, depth=0):
            dirs, files = xbmcvfs.listdir(p)
            for f in files:
                found.append((p + f, rel + f))
            if depth < 8:
                for dd in dirs:
                    walk(p + dd + "/", rel + dd + "/", depth + 1)
        try:
            walk(root, "")
        except Exception:
            found = []
        if found:
            return found
    return None


def after_extract(files, folder):
    if not files:
        return []
    vids = sorted([f for f in files if f.lower().endswith(VIDEO_AUDIO)])
    where = os.path.dirname(os.path.commonprefix(files)) or folder
    if vids:
        i = xbmcgui.Dialog().select("Extracted %d files to %s - play one?" % (len(files), where),
                                    ["Don't play anything now"] + [os.path.basename(v) for v in vids])
        if i > 0:
            xbmc.Player().play(vids[i - 1], xbmcgui.ListItem(path=vids[i - 1]))
    else:
        notify("Extracted %d files to %s" % (len(files), where))
    return files


def file_menu(name, size, get_url, heading=None):
    """What to do with a file Kodi can't just play (archives, programs...) - or any file via Download to..."""
    opts = []
    if name.lower().endswith(".zip"):
        opts.append(("Play from inside the zip (no download)", "zip"))
    opts.append(("Download to...", "dl"))
    if is_archive(name):
        opts.append(("Download and extract to...", "dlx"))
    i = xbmcgui.Dialog().select(heading or "%s%s" % (name[:70], (" (%s)" % fmt_size(size)) if size else ""),
                                [o[0] for o in opts])
    if i < 0:
        return
    choice = opts[i][1]
    try:
        direct = get_url()
    except Exception as e:
        return notify("Couldn't get the link: %s" % e, xbmcgui.NOTIFICATION_ERROR)
    if not direct:
        return notify("Couldn't get the link", xbmcgui.NOTIFICATION_ERROR)
    if choice == "zip":
        return xbmc.executebuiltin("Container.Update(%s)" % url(action="zip_list", u=direct, name=name))
    folder = pick_folder("Save %s to..." % name[:40])
    if folder:
        download_links([(direct, name)], name, folder, extract=(choice == "dlx"))


def tb_file(p):
    api = get_api()
    if not api:
        return
    file_menu(p.get("name", "file"), int(p.get("size") or 0),
              lambda: api.request_dl(p["kind"], p["id"], p["file"]) or api.redirect_url(p["kind"], p["id"], p["file"]))


def zip_list(p):
    u, name = p["u"], p.get("name", "archive.zip")
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Reading what's inside %s..." % name[:50])
    try:
        members = zipremote.list_zip(u)
    except Exception as e:
        prog.close()
        notify("Can't read inside this zip: %s - download and extract it instead" % e, xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.endOfDirectory(HANDLE, False)
    prog.close()
    vids = [mm for mm in members if mm[0].lower().endswith(VIDEO_AUDIO)]
    others = [mm for mm in members if mm not in vids]
    add_dir("[COLOR grey]%s - %d files, %d videos[/COLOR]" % (name, len(members), len(vids)), {"action": "noop"}, folder=False)
    for fname, size, stored, hoff in sorted(vids, key=lambda x: x[0].lower()):
        label = "%s  [COLOR grey]%s[/COLOR]" % (os.path.basename(fname), fmt_size(size))
        if stored:
            add_dir(label, {"action": "zip_play", "u": u, "h": hoff, "n": size, "name": os.path.basename(fname)},
                    folder=False, playable=True, media="video")
        else:
            add_dir(label + "  [COLOR orange](compressed - download and extract to watch)[/COLOR]", {"action": "noop"},
                    folder=False)
    for fname, size, stored, hoff in others:
        add_dir("[COLOR grey]%s  %s[/COLOR]" % (os.path.basename(fname), fmt_size(size)), {"action": "noop"}, folder=False)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def zip_play(p):
    from urllib.parse import urlencode
    try:
        off = zipremote.data_offset(p["u"], int(p["h"]))
    except Exception as e:
        notify("Can't play from the zip: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    port = zipproxy.port_for(ADDON.getAddonInfo("id"))
    stream = "http://127.0.0.1:%d/z?%s" % (port, urlencode({"u": p["u"], "o": off, "n": p["n"], "name": p.get("name", "")}))
    track(None)
    li = xbmcgui.ListItem(path=stream)
    set_info(li, p.get("name", ""))
    li.setMimeType(zipproxy.TYPES.get(os.path.splitext(p.get("name", ""))[1].lower(), "video/x-matroska"))
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def file_download(p):
    """Context menu 'Download to...' for any TorBox file (videos included)."""
    api = get_api()
    if not api:
        return
    folder = pick_folder("Save %s to..." % p.get("name", "")[:40])
    if not folder:
        return
    try:
        direct = api.request_dl(p["kind"], p["id"], p["file"]) or api.redirect_url(p["kind"], p["id"], p["file"])
    except TorBoxError as e:
        return notify(str(e), xbmcgui.NOTIFICATION_ERROR)
    download_links([(direct, p.get("name", "download"))], p.get("name", ""), folder)


LOG_COL = {"ERROR": "red", "WARN": "orange", "INFO": "lightgreen", "DEBUG": "grey"}


def log_text(ents):
    if not ents:
        return "Nothing logged yet."
    out = []
    for when, lvl, txt in ents:
        out.append("[COLOR %s]%s %s[/COLOR]  %s" % (LOG_COL.get(lvl, "white"), when[5:16], lvl, txt))
    return "\n".join(out)


def log_view():
    d = xbmcgui.Dialog()
    while True:
        ents = tublog.entries()
        errs = [e for e in ents if e[1] in ("ERROR", "WARN")]
        dbg = ADDON.getSetting("debug_log") == "true"
        rows = ["View problems only (%d)" % len(errs), "View everything (%d entries)" % len(ents),
                "Save a copy of the log to a folder...", "Clear the log",
                "Detailed logging: %s" % ("[COLOR lightgreen]on[/COLOR] - logs every screen and search" if dbg else
                                          "off - only problems are logged")]
        i = d.select(NAME + " - error log", rows)
        if i < 0:
            return
        if i == 0:
            d.textviewer(NAME + " - problems, newest first", log_text(errs))
        elif i == 1:
            d.textviewer(NAME + " - log, newest first", log_text(ents))
        elif i == 2:
            folder = pick_folder("Save the log where?")
            if folder:
                target = os.path.join(xbmcvfs.translatePath(folder), "%s-log-%s.txt" % (
                    ADDON.getAddonInfo("id"), time.strftime("%Y%m%d-%H%M")))
                try:
                    with open(tublog.path(), "r", encoding="utf-8", errors="replace") as f, \
                            open(target, "w", encoding="utf-8") as g:
                        g.write(f.read())
                    d.ok(NAME, "Saved:\n%s" % target)
                except Exception as e:
                    d.ok(NAME, "Couldn't save it: %s" % e)
        elif i == 3:
            if d.yesno(NAME, "Clear the error log?"):
                tublog.clear()
                notify("Log cleared")
        elif i == 4:
            set_bool("debug_log", not dbg)
            tublog.info("Detailed logging turned %s" % ("off" if dbg else "on"))


def ddl_test():
    sites = ddl_sites()
    if not sites:
        return xbmcgui.Dialog().ok(NAME, "No release blogs set. Add them in Settings > Cocoleech.")
    q = xbmcgui.Dialog().input("Test search for (a recent film or show works best)",
                               defaultt=store_load("ddl_test_q.json", {}).get("q", "1080p")).strip()
    if not q:
        return
    store_save("ddl_test_q.json", {"q": q})
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Testing release blogs for '%s'..." % q)
    hosts = coco_hostset()
    ok, msg = cfsolve.check()
    lines = ["FlareSolverr (for Cloudflare-protected blogs): %s" % msg, ""]
    from concurrent.futures import ThreadPoolExecutor

    def one(site):
        t0, diag = time.time(), []
        try:
            got = ddl.search_site(site, q, int(ADDON.getSetting("scrape_timeout") or 15), hosts, 3, diag)
            head = "[B]%s[/B]: %d posts with file-host links  (%.1fs)" % (site, len(got), time.time() - t0)
            if got:
                diag.append("e.g. %s - %s" % (got[0]["title"][:70], ", ".join(sorted(ddl.group_links(got[0]["links"])))))
        except Exception as e:
            head = "[B]%s[/B]: [COLOR red]FAILED[/COLOR] - %s  (%.1fs)" % (site, e, time.time() - t0)
        return [head] + ["   - " + x for x in diag] + [""]
    with ThreadPoolExecutor(max_workers=len(sites)) as ex:
        for block in ex.map(one, sites):
            lines += block
    prog.close()
    heads = " ".join(b for b in lines if b.startswith("[B]http"))
    if "Cloudflare" in heads and not ok:
        lines += ["[B]Blocked by Cloudflare?[/B] Kodi can't pass Cloudflare's browser check by itself. FlareSolverr is a free "
                  "helper that runs a hidden web browser on a PC, NAS or Raspberry Pi on your network and passes the check "
                  "for Kodi. Install it (Docker: ghcr.io/flaresolverr/flaresolverr, or the Windows download from its GitHub "
                  "releases page), then put its address in Settings > Torrent sites > FlareSolverr address, "
                  "e.g. 192.168.1.20:8191. It helps BitSearch and other torrent sites too.", ""]
    if ": 0 posts" in heads:
        lines += ["[B]0 posts?[/B] The lines under each blog show how far the search got. Swap a blog for another in "
                  "Settings > Cocoleech if it keeps finding nothing."]
    xbmcgui.Dialog().textviewer(NAME + " - release blog test", "\n".join(lines))


def coco_play(link=None):
    if not need_unlocker():
        return
    if not link:
        link = xbmcgui.Dialog().input("File-host link (Rapidgator etc.)").strip()
    if not link:
        return
    coco_open({"link": link})

def account():
    api = get_api()
    if not api:
        return
    try:
        u = api.user()
    except TorBoxError as e:
        return xbmcgui.Dialog().ok(NAME, "Could not reach TorBox:\n%s" % e)
    plans = {0: "Free", 1: "Essential", 2: "Pro", 3: "Standard"}
    xbmcgui.Dialog().ok(NAME, "Email: %s\nPlan: %s\nPremium expires: %s" % (
        u.get("email", "?"), plans.get(u.get("plan"), u.get("plan")), u.get("premium_expires_at", "n/a")))


PRESET_INDEXER = ("", "")  # no built-in indexer: keys are typed in Settings > Usenet and stay on that box


def apply_presets():
    """Put a built-in Usenet indexer into a free slot once (none is built in - the add-on is shared publicly)."""
    u, k = PRESET_INDEXER
    if not (u and k):
        return
    slots = [(n, ADDON.getSetting("nzb%s_url" % n).strip(), ADDON.getSetting("nzb%s_key" % n).strip()) for n in ("1", "2")]
    if any("nzbfinder" in su.lower() for _, su, _ in slots):
        return
    if store_load("preset_done.json", False):
        return  # added before and removed on purpose - leave it
    free = [n for n, su, sk in slots if not su]
    if not free:
        return
    ADDON.setSetting("nzb%s_url" % free[0], u)
    ADDON.setSetting("nzb%s_key" % free[0], k)
    set_bool("usenet_enable", True)
    store_save("preset_done.json", True)
    tublog.info("Added the NZBFinder indexer to Usenet slot %s" % free[0])
    notify("NZBFinder indexer added - Usenet search is ready")


def migrate_old(force=False):
    """Copy keys/choices from the older 'TorBox' add-on. Runs once automatically, or on demand from Tools."""
    if not force and store_load("migrated.json", False):
        return 0
    try:
        old = xbmcaddon.Addon("plugin.video.torbox")
    except Exception:
        if force:
            notify("The older TorBox add-on isn't installed", xbmcgui.NOTIFICATION_WARNING)
        return 0
    store_save("migrated.json", True)
    keys = ("api_key", "cocoleech_key", "tmdb_key", "nyaa_host", "stremio1_enable", "stremio1_url", "stremio2_enable",
            "stremio2_url", "torznab_enable", "torznab_url", "torznab_key", "enable_prowlarr", "prowlarr_host",
            "prowlarr_api_key", "coco_enable", "anime_audio", "hide_uncached", "max_res", "filter_cam_ts",
            "min_seeders", "scrape_timeout", "add_timeout", "region", "dyn_art", "ddl1_url", "ddl2_url", "ddl3_url", "ddl_posts", "flaresolverr_url", "dl_folder", "dl_ask", "dl_progress", "dl_delete_archive", "usenet_enable", "usenet_ask", "usenet_wait", "nzb1_url", "nzb1_key", "nzb2_url",
            "nzb2_key", "tb_usenet_search", "tb_search_host", "nyaa_enable", "apibay_host", "knaben_host", "bitsearch_host") + \
        tuple("%s_%s" % (s, m) for s in ("tpb", "knaben", "bitsearch") for m in ('movie', 'tv', 'anime', 'kdrama', 'music'))
    n = 0
    for k in keys:
        try:
            v = old.getSetting(k)
            if v and v != ADDON.getSetting(k):
                ADDON.setSetting(k, v)
                n += 1
        except Exception:
            pass
    return n


# ---------------- what's been on / streaming top 10 ----------------
def cached_call(name, ttl, fn, *args):
    store = store_load("discover_cache.json", {})
    key = json.dumps([name] + [str(a) for a in args])
    hit = store.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    data = fn(*args)
    store = {k: v for k, v in store.items() if time.time() - v[0] < 6 * 3600}
    store[key] = [time.time(), data]
    store_save("discover_cache.json", store)
    return data


def region():
    r = (ADDON.getSetting("region") or "GB").strip().upper()
    return r if len(r) == 2 else "GB"


COUNTRIES = [('GB', 'United Kingdom'), ('IE', 'Ireland'), ('US', 'United States'), ('CA', 'Canada'), ('AU', 'Australia'), ('NZ', 'New Zealand'), ('AR', 'Argentina'), ('AT', 'Austria'), ('BE', 'Belgium'), ('BR', 'Brazil'), ('DK', 'Denmark'), ('FI', 'Finland'), ('FR', 'France'), ('DE', 'Germany'), ('IN', 'India'), ('IT', 'Italy'), ('JP', 'Japan'), ('MX', 'Mexico'), ('NL', 'Netherlands'), ('NO', 'Norway'), ('PH', 'Philippines'), ('PL', 'Poland'), ('PT', 'Portugal'), ('ZA', 'South Africa'), ('KR', 'South Korea'), ('ES', 'Spain'), ('SE', 'Sweden'), ('CH', 'Switzerland'), ('TR', 'Turkey')]


def country_name(code):
    return dict(COUNTRIES).get(code, code)


def country_bar(what, section):
    """Top-of-list buttons: change country (a pop-up list, no settings menus) and refresh."""
    add_dir("[B]Country:[/B] %s  [COLOR grey]- tap to change[/COLOR]" % country_name(region()),
            {"action": "region_pick"}, folder=False, icon=ic("tools_globe"))
    add_dir("[COLOR grey]Refresh this list[/COLOR]", {"action": "list_refresh", "what": what}, folder=False,
            icon=ic(section + "_clock"))


def region_pick():
    cur = region()
    codes = [c for c, _ in COUNTRIES]
    names = [("[B]%s[/B]  [COLOR lightgreen](now)[/COLOR]" % n) if c == cur else n for c, n in COUNTRIES]
    i = xbmcgui.Dialog().select("Which country's TV and streaming?", names + ["Another country (type its 2-letter code)..."],
                                preselect=codes.index(cur) if cur in codes else 0)
    if i < 0:
        return
    if i == len(codes):
        c = (xbmcgui.Dialog().input("2-letter country code, e.g. GB, US, DE", defaultt=cur) or "").strip().upper()
        if not re.match(r"^[A-Z]{2}$", c):
            return notify("That isn't a 2-letter country code", xbmcgui.NOTIFICATION_WARNING) if c else None
    else:
        c = codes[i]
    if c != cur:
        ADDON.setSetting("region", c)
        tublog.info("Country changed %s -> %s" % (cur, c))
        notify("Country: %s" % country_name(c))
    xbmc.executebuiltin("Container.Refresh")


def list_refresh(what):
    """Forget the saved copy of a list (TV schedule / streaming top 10s) and load it again."""
    names = {"aired": ("tvmaze_aired",), "stream": ("tmdb_services", "tmdb_stream")}.get(what, ())
    store = store_load("discover_cache.json", {})
    keep = {k: v for k, v in store.items() if not any(k.startswith('["%s"' % n) for n in names)}
    store_save("discover_cache.json", keep)
    xbmc.executebuiltin("Container.Refresh")


def day_label(iso_date):
    try:
        dt = datetime.date.fromisoformat(iso_date[:10])
    except ValueError:
        return ""
    diff = (datetime.date.today() - dt).days
    return "Today" if diff == 0 else "Yesterday" if diff == 1 else dt.strftime("%a %d %b")


def aired(p):
    src = p.get("src", "tv")
    wdata = watched.load()
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Fetching what's been on...")
    try:
        if src == "anime":
            try:
                items = anilist_call("anilist_aired", 1800, catalog_mod.anilist_aired, 7)
            except Exception as e:
                if "skipped" not in str(e):
                    tublog.warn("AniList refused the airing schedule (%s) - using MyAnimeList's schedule instead" % e)
                prog.update(30, "Using MyAnimeList's schedule (AniList isn't answering)...")
                items = cached_call("jikan_aired", 1800, catalog_mod.jikan_aired, 7)
        else:
            items = cached_call("tvmaze_aired", 1800, catalog_mod.tvmaze_aired, region(), 7, src == "kdrama")
    except Exception as e:
        if src != "tv":
            prog.close()
            return fail("Could not load the schedule: %s" % e)
        notify("Could not load the schedule: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        items = None  # keep the country / refresh buttons so you can try again
    prog.close()
    if src == "tv":
        country_bar("aired", "tv")
    if items == []:
        notify("Nothing found for the last 7 days")
    for it in items or []:
        if src == "anime":
            when = day_label(datetime.datetime.fromtimestamp(it["aired"]).date().isoformat())
            if it.get("episode"):
                label = "%s - Episode %d  [COLOR grey]%s[/COLOR]" % (it["title"], it["episode"], when)
            else:  # MyAnimeList schedule: episode number is only an estimate, so open the episode list
                label = "%s - new episode%s  [COLOR grey]%s[/COLOR]" % (
                    it["title"], (" (about ep %d)" % it["estimate"]) if it.get("estimate") else "", when)
            params = {"action": "al_open", "anilist": it["anilist"], "mal": it.get("mal"), "title": it["title"],
                      "alt": it.get("alt"), "year": it.get("year"), "poster": it.get("poster"), "ep": it["episode"],
                      "eps": it.get("eps")}
            add_dir(label, params, art={"poster": it.get("poster"), "thumb": it.get("poster"), "fanart": it.get("fanart")},
                    media="episode",
                    ctx=[("Open show", "Container.Update(%s)" % url(**dict(params, ep=None)))])
            continue
        kd = src == "kdrama"
        label = "%s S%02dE%02d%s  [COLOR grey]%s%s[/COLOR]" % (
            it["show"], it["season"], it["episode"], (" - " + it["title"]) if it["title"] else "",
            day_label(it["airdate"]), (" · " + it["channel"]) if it["channel"] else "")
        params = {"action": "results", "q": it["show"], "imdb": it["imdb"], "title": it["show"], "year": it["year"],
                  "name": it["show"], "season": it["season"], "ep": it["episode"], "poster": it["poster"],
                  "kdrama": 1 if kd else None, "tvm": it.get("tvm")}
        sid = it["imdb"] or ("tvm%s" % it["tvm"] if it.get("tvm") else "")
        wk = "%s:%s:%d:%d" % ("kdrama" if kd else "tv", sid, it["season"], it["episode"]) if sid else None
        ctx = seen_ctx(wk) if wk else []
        if it["imdb"]:
            ctx.append(("Open show", "Container.Update(%s)" % url(action="seasons", imdb=it["imdb"], title=it["show"],
                                                                  year=it["year"], poster=it["poster"],
                                                                  kdrama=1 if kd else None)))
        add_dir(label, params, plot=it["plot"], art={"poster": it["poster"], "thumb": it["poster"]}, media="episode",
                seen=(wk in wdata["watched"]) if wk else None, ctx=ctx)
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def anime_season():
    try:
        items = anilist_call("anilist_season", 6 * 3600, catalog_mod.anilist_season)
    except Exception as e:
        if "skipped" not in str(e):
            tublog.warn("AniList refused this season's list (%s) - using Kitsu instead" % e)
        try:
            items = [{"kitsu": k["id"], "anilist": None, "mal": None, "title": k["title"], "alt": k.get("alt"),
                      "released": k.get("released"), "country": k.get("country"),
                      "year": k.get("year"), "poster": k.get("poster"), "fanart": k.get("fanart"),
                      "eps": k.get("episodes") or 0, "movie": k.get("subtype") == "movie"}
                     for k in cached_call("kitsu_season", 6 * 3600, catalog_mod.kitsu_season)]
        except Exception as e2:
            return fail("Could not load this season: AniList %s, Kitsu %s" % (e, e2))
    for it in items:
        params = {"action": "al_open", "kitsu": it.get("kitsu"), "anilist": it["anilist"], "mal": it.get("mal"), "title": it["title"],
                  "alt": it.get("alt"), "year": it.get("year"), "poster": it.get("poster"), "eps": it.get("eps"),
                  "movie": 1 if it.get("movie") else None}
        add_dir(year_label(it["title"], it.get("year")) + (" [movie]" if it.get("movie") else "") +
                when_text(it.get("released"), it.get("country"), "released" if it.get("movie") else "first aired"), params,
                art={"poster": it.get("poster"), "thumb": it.get("poster"), "fanart": it.get("fanart")}, media="tvshow",
                premiered=it.get("released"), country=it.get("country"))
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def anilist_call(name, ttl, fn, *args):
    """AniList, unless it refused us in the last 6 hours (then go straight to the fallback)."""
    down = store_load("anilist_down.json", 0)
    if time.time() - down < 6 * 3600:
        raise RuntimeError("skipped - AniList refused recently")
    try:
        return cached_call(name, ttl, fn, *args)
    except Exception:
        store_save("anilist_down.json", time.time())
        raise


def kitsu_id(anilist, mal=None):
    maps = store_load("kitsu_map.json", {})
    mk = ("al%s" % anilist) if anilist else ("mal%s" % mal)
    if mk in maps:
        return maps[mk]
    k = catalog_mod.kitsu_from_anilist(anilist, mal)
    if k:
        maps[mk] = k
        store_save("kitsu_map.json", maps)
    return k


def al_open(p):
    """AniList item -> Kitsu id (what Torrentio uses for anime), then episode list or results, in this listing."""
    k = p.get("kitsu") or kitsu_id(p.get("anilist"), p.get("mal"))
    if not k:
        notify("No exact match for this show - searching by title instead", xbmcgui.NOTIFICATION_WARNING)
    base = {"kitsu": k, "title": p.get("title"), "alt": p.get("alt"), "year": p.get("year"), "anime": 1,
            "poster": p.get("poster"), "eps": p.get("eps")}
    if p.get("movie"):
        return results(dict(base, action="results", q=p.get("title"), movie=1))
    if p.get("ep"):
        return results(dict(base, action="results", q=p.get("title"), ep=int(p["ep"])))
    return anime_eps(base)


def stream_services():
    key = tmdb_key()
    if not key:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    try:
        svcs = cached_call("tmdb_services", 24 * 3600, catalog_mod.streaming_services, key, region())
    except Exception as e:
        notify("TMDB error: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        svcs = None
    country_bar("stream", "movies")
    if svcs == []:
        notify("No streaming services found for %s" % country_name(region()), xbmcgui.NOTIFICATION_WARNING)
    for s in svcs or []:
        add_dir("Top 10 on %s" % s["name"], {"action": "stream_top", "prov": s["id"], "svc": s["name"]},
                art={"thumb": s.get("logo"), "icon": s.get("logo"), "poster": s.get("logo")})
    xbmcplugin.endOfDirectory(HANDLE)


def stream_top(p):
    key = tmdb_key()
    if not key:
        return xbmcplugin.endOfDirectory(HANDLE, False)
    n = int(p.get("n") or 0)
    try:
        page = cached_call("tmdb_stream", 3 * 3600, catalog_mod.streaming_movies, key, region(), p["prov"], n // 20 + 1)
    except Exception as e:
        return fail("TMDB error: %s" % e)
    items = page[n % 20:n % 20 + 10]
    for i, it in enumerate(items):
        params = {"action": "tmdb_movie", "tmdb": it["tmdb"], "title": it["title"], "year": it["year"],
                  "poster": it["poster"]}
        add_dir("%d. %s" % (n + i + 1, dated(it["title"], it["year"], it)), params, plot=it["plot"],
                art={"poster": it["poster"], "thumb": it["poster"], "fanart": it["fanart"]}, year=it["year"],
                media="movie", premiered=it.get("released"))
    if len(items) == 10:
        add_dir("[B]Next 10 >>[/B]", {"action": "stream_top", "prov": p["prov"], "svc": p.get("svc"), "n": n + 10})
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)


def tmdb_movie(p):
    imdb = None
    key = tmdb_key()
    if key:
        try:
            imdb = cached_call("tmdb_imdb", 30 * 86400, catalog_mod.tmdb_movie_imdb, key, p["tmdb"])
        except Exception:
            imdb = None
    name = (p.get("title", "") + " " + (p.get("year") or "")).strip()
    return results({"action": "results", "q": name, "imdb": imdb, "title": p.get("title"), "year": p.get("year"),
                    "name": name, "poster": p.get("poster")})


SECTION_OF = {"dating": "tv", "tv_open": "tv", "tmdb_genre": "tv", "search_menu": "search", "show_about": "tv", "status": "tools", "anime_about": "anime", "svc_cloud": "cloud", "svc_files": "cloud", "aud_toggle": "anime", "ddl_results": "tools", "ddl_post": "tools", "coco_menu": "tools", "coco_links": "tools", "coco_recent": "tools", "coco_hosts": "tools", "aired": None, "anime_season": "anime", "al_open": "anime", "stream_services": "movies",
              "stream_top": "movies", "tmdb_movie": "movies", "anime_list": "anime", "anime_eps": "anime",
              "anime_search": "anime", "anime_manual": "anime", "kdrama_list": "kdrama", "kdrama_search": "kdrama",
              "tmdb_seasons": "kdrama", "tmdb_episodes": "kdrama", "list": "cloud", "files": "cloud",
              "add_magnet": "cloud", "history": "tools", "recent": "recent", "test_scrapers": "tools",
              "music_albums": "music", "music_artists": "music", "music_genres": "music", "music_artist": "music",
              "music_open": "music", "search": "search"}


def section_for(p):
    a = p.get("action")
    if not a:
        return "home"
    if a == "menu":
        return p.get("m")
    if a == "aired":
        return p.get("src", "tv")
    if a in ("region_pick", "list_refresh"):
        return None
    if a == "catalog" or a == "genres":
        return "movies" if p.get("kind") == "movie" else "tv"
    if a in ("seasons", "episodes", "manual_ep", "results", "pack_open", "play_hash"):
        if p.get("music"):
            return "music"
        if p.get("anime"):
            return "anime"
        if p.get("kdrama"):
            return "kdrama"
        return "tv" if (p.get("season") or p.get("show") or a in ("seasons", "episodes", "manual_ep")) else "movies"
    return SECTION_OF.get(a)


def route():
    p = dict(parse_qsl(sys.argv[2].lstrip("?")))
    a = p.get("action")
    cfsolve.setup(ADDON.getSetting("flaresolverr_url"), os.path.join(PROFILE, "cf_cookies.json"))
    CUR_BG[0] = live_bg(section_for(p) or "home")
    try:
        apply_presets()
    except Exception:
        tublog.exc("Adding the NZBFinder indexer failed")
    if not a:
        migrate_old()
        main_menu()
    elif a == "music_albums":
        music_albums(p)
    elif a == "music_artists":
        music_artists(p)
    elif a == "music_genres":
        music_genres()
    elif a == "music_artist":
        music_artist(p)
    elif a == "music_search":
        music_search(p.get("t"))
    elif a == "music_free":
        music_free()
    elif a == "recent":
        recent(p)
    elif a == "recent_remove":
        watched.remove_recent(p.get("show"))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "mark":
        watched.mark(p["wk"], p.get("on") == "1")
        xbmc.executebuiltin("Container.Refresh")
    elif a == "mark_season":
        watched.mark_many(["%s%d" % (p["prefix"], n) for n in range(1, int(p.get("n") or 0) + 1)], p.get("on") == "1")
        xbmc.executebuiltin("Container.Refresh")
    elif a == "menu":
        submenu(p.get("m"))
    elif a == "aired":
        aired(p)
    elif a == "anime_season":
        anime_season()
    elif a == "al_open":
        al_open(p)
    elif a == "stream_services":
        stream_services()
    elif a == "region_pick":
        region_pick()
    elif a == "list_refresh":
        list_refresh(p.get("what"))
    elif a == "stream_top":
        stream_top(p)
    elif a == "tmdb_movie":
        tmdb_movie(p)
    elif a == "catalog":
        catalog(p)
    elif a == "genres":
        genres(p["kind"])
    elif a == "dating":
        dating(p)
    elif a == "tv_open":
        tv_open(p)
    elif a == "tmdb_genre":
        page = int(p.get("page") or 1)
        try:
            tv_genre_tmdb(p, catalog_mod.tmdb_tv_discover(ADDON.getSetting("tmdb_key").strip(), page, p.get("genre")), page)
        except Exception as e:
            fail("TMDB error: %s" % e)
    elif a == "seasons":
        seasons(p)
    elif a == "episodes":
        episodes(p)
    elif a == "manual_ep":
        manual_ep(p)
    elif a == "anime_list":
        anime_list(p)
    elif a == "anime_search":
        anime_search()
    elif a == "anime_eps":
        anime_eps(p)
    elif a == "anime_manual":
        anime_manual(p)
    elif a == "kdrama_list":
        kdrama_list(p)
    elif a == "kdrama_search":
        kdrama_search()
    elif a == "tmdb_seasons":
        tmdb_seasons(p)
    elif a == "tmdb_episodes":
        tmdb_episodes(p)
    elif a == "list":
        list_items(p["kind"])
    elif a == "files":
        list_files(p["kind"], p["id"])
    elif a == "play":
        play(p["kind"], p["id"], p["file"], p)
    elif a == "delete":
        delete(p["kind"], p["id"])
    elif a == "add_magnet":
        add_magnet(p.get("magnet"))
    elif a == "search":  # old shortcut: open the search menu instead
        search_menu(p)
    elif a == "results":
        results(p)
    elif a == "history":
        search_menu(p)
    elif a == "buffer_setup":
        buffer_setup()
    elif a == "search_menu":
        search_menu(p)
    elif a == "search_new":
        search_new(p)
    elif a == "pk_toggle":
        pk_toggle(p)
    elif a == "show_about":
        show_about(p)
    elif a == "hist_remove":
        store_save("history.json", [h for h in store_load("history.json", [])
                                    if json.dumps(h.get("params"), sort_keys=True) != p.get("i")])
        xbmc.executebuiltin("Container.Refresh")
    elif a == "clear_history":
        t = p.get("t")
        if xbmcgui.Dialog().yesno(NAME, "Clear %srecent searches?" % ((SEARCH_KINDS.get(t, "") + " ") if t else "all ")):
            store_save("history.json", [h for h in store_load("history.json", []) if t and hist_kind(h) != t])
            xbmc.executebuiltin("Container.Refresh")
    elif a == "coco_settings":
        try:
            xbmcaddon.Addon("script.module.cocoscrapers").openSettings()
        except Exception:
            xbmcgui.Dialog().ok(NAME, "CocoScrapers module is not installed.\nInstall script.module.cocoscrapers from its repository first.")
    elif a == "import_keys":
        n = migrate_old(True)
        if n:
            notify("Imported %d settings from the older add-on" % n)
        elif n == 0 and store_load("migrated.json", False):
            notify("Nothing new to import - settings already match")
    elif a == "tmdb_login":
        tmdb_login(True)
    elif a == "nyaa_host":
        set_host("nyaa_host", "Nyaa address (e.g. https://nyaa.si or a mirror)", "https://nyaa.si")
    elif a == "apibay_host":
        set_host("apibay_host", "Pirate Bay address for music search", "https://apibay.org")
    elif a == "nzb_play":
        nzb_play(p)
    elif a == "nzb_add":
        nzb_add(p)
    elif a == "usenet_setup":
        usenet_setup()
    elif a == "sites":
        sites_menu()
    elif a == "test_scrapers":
        test_scrapers()
    elif a == "music_open":
        music_open(p)
    elif a == "play_album":
        play_album(p)
    elif a == "pack_open":
        pack_open(p["hash"], p.get("name", ""), p.get("c", ""))
    elif a == "play_hash":
        play_hash(p["hash"], p.get("name", ""), p.get("season"), p.get("ep"), bool(p.get("anime")), p.get("fname"),
                  p.get("wk"), p.get("c", ""))
    elif a == "dplay":
        track(None)
        resolve_svc(p["svc"], p["id"], p["file"], p)
    elif a == "anime_about":
        anime_about(p)
    elif a == "status":
        status_screen(p)
    elif a == "status_now":
        status_check()
        xbmc.executebuiltin("Container.Refresh")
    elif a == "prep_next":
        prep_next(p)
    elif a == "cw_play":
        cw_play(p)
    elif a == "newep_dismiss":
        newep_dismiss(p.get("show"))
    elif a == "cw_remove":
        dd = binge.load(PROFILE)
        dd["shows"].pop(p.get("show"), None)
        binge.save(PROFILE, dd)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "send_to":
        send_to(p)
    elif a == "svc_cloud":
        svc_cloud(p)
    elif a == "svc_files":
        svc_files_list(p["svc"], p["id"])
    elif a == "svc_delete":
        svc_delete(p)
    elif a == "rd_menu":
        rd_menu()
    elif a == "login":
        login()
    elif a == "tb_file":
        tb_file(p)
    elif a == "file_download":
        file_download(p)
    elif a == "zip_list":
        zip_list(p)
    elif a == "zip_play":
        zip_play(p)
    elif a == "ddl_search":
        ddl_search_start()
    elif a == "ddl_results":
        ddl_results(p)
    elif a == "ddl_post":
        ddl_post(p)
    elif a == "aud_toggle":
        aud_toggle(p)
    elif a == "log_view":
        log_view()
    elif a == "data_check":
        xbmcgui.Dialog().textviewer(NAME + " - saved data", watched.report())
    elif a == "ddl_test":
        ddl_test()
    elif a == "coco_open":
        coco_open(p)
    elif a == "dl_many":
        dl_many(p)
    elif a == "dl_cancel":
        xbmcgui.Window(10000).setProperty("tub.dl_cancel", "1")
        notify("Cancelling download...")
    elif a == "noop":
        pass
    elif a == "coco_menu":
        coco_menu()
    elif a == "coco_links":
        coco_links()
    elif a == "coco_resolve":
        coco_resolve(p["link"])
    elif a == "coco_recent":
        coco_recent()
    elif a == "coco_forget":
        store_save("coco_recent.json", [h for h in store_load("coco_recent.json", []) if h.get("link") != p.get("link")])
        xbmc.executebuiltin("Container.Refresh")
    elif a == "coco_hosts":
        coco_hosts()
    elif a == "coco_account":
        coco_account()
    elif a == "coco_help":
        xbmcgui.Dialog().textviewer("Cocoleech", COCO_HELP)
    elif a == "coco_login":
        coco_login()
    elif a == "coco_play":
        coco_play(p.get("link"))
    elif a == "account":
        account()
    elif a == "settings":
        ADDON.openSettings()
    else:
        main_menu()


try:
    tublog.debug("open %s" % (sys.argv[2] if len(sys.argv) > 2 else ""))
    route()
except SystemExit:
    raise
except Exception:
    tublog.exc("Crashed while opening %s" % (sys.argv[2] if len(sys.argv) > 2 else "?"))
    popup("Something went wrong - details in Tools > Error log", xbmcgui.NOTIFICATION_ERROR, 5000)
    try:
        xbmcplugin.endOfDirectory(HANDLE, False)
    except Exception:
        pass
