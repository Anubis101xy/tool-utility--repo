# -*- coding: utf-8 -*-
"""New-episode alerts: for shows you've watched lately, has an episode come out that you haven't seen yet?

Runs in the background service every few hours. Results go in newep.json:
  {show: {"title", "poster", "next": [season, ep], "count": unwatched aired, "latest": [season, ep],
          "aired": "YYYY-MM-DD" of the newest, "ts", "told": [season, ep] last one you were told about}}"""
import datetime
import time

import binge
import catalog

ACTIVE_DAYS = 45     # shows watched in the last 45 days are checked
FRESH_DAYS = 10      # 'new' = came out in the last 10 days (older unwatched episodes are just a backlog)
MAX_SHOWS = 20


def _aired_eps(show, info):
    """[(season, ep, aired date)] that have aired, oldest first."""
    today = datetime.date.today().isoformat()
    out = []
    if show.startswith("an:"):
        kid = show.split(":")[1]
        eps = catalog.kitsu_episodes(kid) or {}
        for n, e in eps.items():
            if e.get("aired") and e["aired"][:10] <= today:
                out.append((None, int(n), e["aired"][:10]))
        if not out:  # Kitsu can lag behind for shows airing now: ask MyAnimeList
            try:
                mal = catalog.kitsu_show(kid).get("mal")
                if mal:
                    for n, e in (catalog.jikan_episodes(mal, 2) or {}).items():
                        if e.get("aired") and e["aired"][:10] <= today:
                            out.append((None, int(n), e["aired"][:10]))
            except Exception:
                pass
    else:
        imdb = (info.get("search") or {}).get("imdb") or show.split(":")[1]
        if not str(imdb).startswith("tt"):
            return []
        eps, _ = catalog.cinemeta_episodes(imdb)
        for e in eps:
            if e["season"] > 0 and e.get("aired") and e["aired"] <= today:
                out.append((e["season"], e["episode"], e["aired"]))
    return sorted(out, key=lambda x: ((x[0] or 0), x[1]))


def check(profile, log=None):
    """-> list of (show, entry) that are newly out since you were last told."""
    d = binge.load(profile)
    store = binge.newep_load(profile)
    now = time.time()
    fresh_from = (datetime.date.today() - datetime.timedelta(days=FRESH_DAYS)).isoformat()
    shows = sorted([(k, v) for k, v in d["shows"].items() if v.get("last") and now - v.get("ts", 0) < ACTIVE_DAYS * 86400],
                   key=lambda kv: kv[1].get("ts", 0), reverse=True)[:MAX_SHOWS]
    tell, keep = [], {}
    for show, v in shows:
        try:
            aired = _aired_eps(show, v)
        except Exception as e:
            if log:
                log("New episodes: couldn't check %s (%s)" % (v.get("title") or show, e))
            if show in store:
                keep[show] = store[show]
            continue
        last = v.get("last") or {}
        mine = ((int(last.get("season") or 0) if not show.startswith("an:") else 0), int(last.get("ep") or 0))
        unseen = [a for a in aired if ((a[0] or 0), a[1]) > mine]
        if not unseen or unseen[-1][2] < fresh_from:
            continue  # all caught up, or only an old backlog
        newest = unseen[-1]
        old = store.get(show) or {}
        entry = {"title": v.get("title") or show, "poster": v.get("poster"), "next": [unseen[0][0], unseen[0][1]],
                 "count": len(unseen), "latest": [newest[0], newest[1]], "aired": newest[2], "ts": now,
                 "told": old.get("told")}
        if old.get("told") != entry["latest"]:
            entry["told"] = entry["latest"]
            tell.append((show, entry))
        keep[show] = entry
        time.sleep(0.3)
    binge.newep_save(profile, keep)
    return tell
