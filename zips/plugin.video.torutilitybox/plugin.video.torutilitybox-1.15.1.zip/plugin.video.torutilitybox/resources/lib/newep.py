# -*- coding: utf-8 -*-
"""Episode schedules for the shows you're watching: what's come out that you haven't seen (new-episode alerts),
and when the next one is out (shown on Continue watching).

Runs in the background service every few hours, and for a single show when you stop watching it.
  newep.json   {show: {"title", "poster", "next": [season, ep], "count", "latest": [season, ep], "aired", "ts", "told"}}
  airing.json  {show: {"eps": {"S:E": [unix time, exact time?]}, "status": "running"|"ended"|"", "ts", "ids": {...}}}
Sources: TV - TVmaze (exact air times), then Cinemeta (dates). Anime - AniList's airing schedule (exact times),
then MyAnimeList's weekly broadcast slot (via Jikan), then Kitsu (dates)."""
import calendar
import datetime
import time

import binge
import catalog

ACTIVE_DAYS = 45     # shows watched in the last 45 days are checked
FRESH_DAYS = 10      # 'new' = came out in the last 10 days (older unwatched episodes are just a backlog)
MAX_SHOWS = 20
TVMAZE = "https://api.tvmaze.com"


def _iso_time(s):
    """'2026-11-14T02:00:00+00:00' -> unix time."""
    s = (s or "").strip()
    if not s:
        return None
    try:
        d = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=datetime.timezone.utc)
        return d.timestamp()
    except ValueError:
        return None


def _day(s):
    """'2026-11-14' -> unix time of that day (00:00 UTC) - date only, no time."""
    try:
        return calendar.timegm(time.strptime((s or "")[:10], "%Y-%m-%d"))
    except ValueError:
        return None


# ---------------- TV ----------------
def tv_schedule(imdb, ids):
    """-> ({(season, ep): (unix, exact?)}, status)"""
    eps, status = {}, ""
    try:
        tvm = ids.get("tvmaze")
        if not tvm:
            show = catalog._get(TVMAZE + "/lookup/shows", {"imdb": imdb}) or {}
            tvm = show.get("id")
            if tvm:
                ids["tvmaze"] = tvm
        if tvm:
            show = catalog._get(TVMAZE + "/shows/%s" % tvm, {"embed": "episodes"}) or {}
            st = (show.get("status") or "").lower()
            status = "ended" if st == "ended" else "running" if st in ("running", "to be determined", "in development") else ""
            for e in (show.get("_embedded") or {}).get("episodes") or []:
                if not e.get("season") or e.get("number") is None or e.get("type") not in (None, "regular"):
                    continue
                at = _iso_time(e.get("airstamp"))
                if at:
                    eps[(int(e["season"]), int(e["number"]))] = (at, True)
                elif e.get("airdate"):
                    d = _day(e["airdate"])
                    if d:
                        eps[(int(e["season"]), int(e["number"]))] = (d, False)
    except Exception:
        eps = {}
    if not eps:  # TVmaze doesn't know it: Cinemeta (dates only)
        got, _ = catalog.cinemeta_episodes(imdb)
        for e in got:
            d = _day(e.get("aired"))
            if e["season"] > 0 and d:
                eps[(e["season"], e["episode"])] = (d, False)
    return eps, status


# ---------------- anime ----------------
_AL_Q = ("query($m:Int){Media(idMal:$m,type:ANIME){status episodes "
         "airingSchedule(notYetAired:true,perPage:8){nodes{episode airingAt}}}}")
_DAYS = {"mondays": 0, "tuesdays": 1, "wednesdays": 2, "thursdays": 3, "fridays": 4, "saturdays": 5, "sundays": 6}
_JST = datetime.timezone(datetime.timedelta(hours=9))


def _jikan_next(mal):
    """MyAnimeList's weekly slot ('Saturdays at 01:30 JST') -> unix time of the next one, or None."""
    a = (catalog._jikan("/anime/%s" % mal, {}) or {}).get("data") or {}
    if not a.get("airing"):
        return None
    b = a.get("broadcast") or {}
    day = _DAYS.get((b.get("day") or "").lower())
    hm = (b.get("time") or "").split(":")
    if day is None or len(hm) != 2:
        return None
    now = datetime.datetime.now(_JST)
    t = now.replace(hour=int(hm[0]), minute=int(hm[1]), second=0, microsecond=0)
    t += datetime.timedelta(days=(day - now.weekday()) % 7)
    if t <= now:
        t += datetime.timedelta(days=7)
    return t.timestamp()


def anime_schedule(kid, ids):
    """-> ({(None, ep): (unix, exact?)}, status)"""
    eps, status = {}, ""
    try:
        for n, e in (catalog.kitsu_episodes(kid) or {}).items():
            d = _day(e.get("aired"))
            if d:
                eps[(None, int(n))] = (d, False)
    except Exception:
        pass
    mal = ids.get("mal")
    if not mal:
        try:
            ks = catalog.kitsu_show(kid)
            mal = ks.get("mal")
            ids["mal"] = mal
            status = {"finished": "ended", "current": "running", "upcoming": "running"}.get(ks.get("status") or "", "")
        except Exception:
            pass
    if not mal:
        return eps, status
    try:
        m = (catalog._anilist(_AL_Q, {"m": int(mal)}) or {}).get("Media") or {}
        status = {"FINISHED": "ended", "RELEASING": "running", "NOT_YET_RELEASED": "running",
                  "HIATUS": "running"}.get(m.get("status") or "", status)
        for node in (m.get("airingSchedule") or {}).get("nodes") or []:
            if node.get("episode") and node.get("airingAt"):
                eps[(None, int(node["episode"]))] = (float(node["airingAt"]), True)
        return eps, status
    except Exception:
        pass
    try:  # AniList unreachable: work out the next one from MyAnimeList's weekly slot
        at = _jikan_next(mal)
        if at:
            status = "running"
            now = time.time()
            done = [k[1] for k, (t, _) in eps.items() if t <= now]
            nxt = (max(done) + 1) if done else 1
            eps[(None, nxt)] = (at, True)
    except Exception:
        pass
    return eps, status


def schedule(show, info, ids):
    if show.startswith("an:"):
        return anime_schedule(show.split(":")[1], ids)
    imdb = (info.get("search") or {}).get("imdb") or show.split(":")[1]
    if not str(imdb).startswith("tt"):
        return {}, ""
    return tv_schedule(imdb, ids)


def is_out(at, exact, now=None):
    now = now or time.time()
    if exact:
        return at <= now
    return time.strftime("%Y-%m-%d", time.gmtime(at)) <= datetime.date.today().isoformat()


def ekey(s, e):
    return "%s:%d" % (s if s is not None else "-", int(e))


def _mine(show, v):
    last = v.get("last") or {}
    return ((int(last.get("season") or 0) if not show.startswith("an:") else 0), int(last.get("ep") or 0))


def _store_airing(airing, show, v, eps, status, ids, now):
    mine = _mine(show, v)
    later = sorted([(k, x) for k, x in eps.items() if ((k[0] or 0), k[1]) > mine], key=lambda kx: ((kx[0][0] or 0), kx[0][1]))
    airing[show] = {"eps": {ekey(*k): list(x) for k, x in later[:40]}, "status": status, "ts": now, "ids": ids}


def refresh_one(profile, show):
    """Update one show's schedule (when you stop watching it)."""
    d = binge.load(profile)
    v = d["shows"].get(show)
    if not v:
        return
    airing = binge.airing_load(profile)
    ids = dict((airing.get(show) or {}).get("ids") or {})
    eps, status = schedule(show, v, ids)
    if eps or status:
        _store_airing(airing, show, v, eps, status, ids, time.time())
        binge.airing_save(profile, airing)


def check(profile, log=None):
    """-> list of (show, entry) that are newly out since you were last told. Also refreshes airing.json."""
    d = binge.load(profile)
    store = binge.newep_load(profile)
    airing = binge.airing_load(profile)
    now = time.time()
    fresh_from = (datetime.date.today() - datetime.timedelta(days=FRESH_DAYS)).isoformat()
    shows = sorted([(k, v) for k, v in d["shows"].items() if v.get("last") and now - v.get("ts", 0) < ACTIVE_DAYS * 86400],
                   key=lambda kv: kv[1].get("ts", 0), reverse=True)[:MAX_SHOWS]
    tell, keep, keep_air = [], {}, {}
    for show, v in shows:
        ids = dict((airing.get(show) or {}).get("ids") or {})
        try:
            eps, status = schedule(show, v, ids)
        except Exception as e:
            if log:
                log("Episode schedule: couldn't check %s (%s)" % (v.get("title") or show, e))
            for src, dst in ((store, keep), (airing, keep_air)):
                if show in src:
                    dst[show] = src[show]
            continue
        _store_airing(keep_air, show, v, eps, status, ids, now)
        mine = _mine(show, v)
        aired = sorted([(k[0], k[1], time.strftime("%Y-%m-%d", time.gmtime(at)))
                        for k, (at, exact) in eps.items() if is_out(at, exact, now)], key=lambda x: ((x[0] or 0), x[1]))
        unseen = [a for a in aired if ((a[0] or 0), a[1]) > mine]
        if not unseen or unseen[-1][2] < fresh_from:
            continue  # all caught up, or only an old backlog
        newest = unseen[-1]
        old = store.get(show) or {}
        entry = {"title": v.get("title") or show, "poster": v.get("poster"), "next": [unseen[0][0], unseen[0][1]],
                 "count": len(unseen), "latest": [newest[0], newest[1]], "aired": newest[2], "ts": now,
                 "told": old.get("told")}
        if old.get("told") != entry["latest"]:
            entry["told"] = entry["latest"]
            tell.append((show, entry))
        keep[show] = entry
        time.sleep(0.3)
    binge.newep_save(profile, keep)
    binge.airing_save(profile, keep_air)
    return tell


# ---------------- 'out Thu 21:00' ----------------
def when(at, exact):
    """unix time -> 'today 21:00' / 'tomorrow 21:00' / 'Thu 21:00' / 'Thu 19 Nov' (your local time)."""
    if exact:
        lt = time.localtime(at)
        day = datetime.date(lt.tm_year, lt.tm_mon, lt.tm_mday)
        hm = " %02d:%02d" % (lt.tm_hour, lt.tm_min)
    else:
        gt = time.gmtime(at)
        day = datetime.date(gt.tm_year, gt.tm_mon, gt.tm_mday)
        hm = ""
    diff = (day - datetime.date.today()).days
    if diff <= 0:
        return "today" + hm
    if diff == 1:
        return "tomorrow" + hm
    if diff < 7:
        return day.strftime("%a") + hm
    return "%s %d %s" % (day.strftime("%a"), day.day, day.strftime("%b"))


def next_out(profile, show, season, ep, airing=None):
    """For Continue watching: ('out Thu 21:00' | 'no date yet' | 'no more episodes' | '', unix or None)."""
    a = (airing if airing is not None else binge.airing_load(profile)).get(show)
    if not a:
        return "", None
    eps = a.get("eps", {})
    x = eps.get(ekey(None if show.startswith("an:") else season, ep))
    if not x and eps and not show.startswith("an:") and int(ep) > 1:
        # 'S02E11' after a finale: the schedule's next episode is really S03E01
        k, x = next(iter(eps.items()))
        s2, e2 = k.split(":")
        if s2 != "-" and int(s2) > int(season or 0):
            return ("S%02dE%02d " % (int(s2), int(e2))) + (
                "out now" if is_out(*x) else "out " + when(*x)), (None if is_out(*x) else x[0])
        x = None
    if x:
        at, exact = x
        return ("", None) if is_out(at, exact) else ("out " + when(at, exact), at)
    if a.get("status") == "ended":
        return "no more episodes", None
    if a.get("status") == "running":
        return "no date yet", None
    return "", None
