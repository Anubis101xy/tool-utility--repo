# -*- coding: utf-8 -*-
"""Binge-watching memory, shared by the add-on and the background service.

binge.json      {"shows": {show: {...}}, "groups": {release group: times picked}}
nowplaying.json what's playing now (show, episode, service, torrent, its files) - for "play next"
next_up.json    the next episode, made ready while the current one plays"""
import json
import os
import re
import time

_LEAD = re.compile(r"^\s*\[([^\]]{2,30})\]")
_TAIL = re.compile(r"-([A-Za-z0-9][A-Za-z0-9_]{1,20})\s*$")
_EXT = re.compile(r"\.(mkv|mp4|avi|ts|m4v|webm|mov|wmv)$", re.I)


def release_group(name):
    """'[FLE] Solo Leveling - S02E04 ...' -> 'FLE'; 'Solo Leveling - S02E03 ... 2160p -Mesc.mkv' -> 'Mesc'."""
    n = (name or "").strip()
    m = _LEAD.match(n)
    if m:
        return m.group(1).strip()
    n = _EXT.sub("", n)
    m = re.search(r"-\[([^\]]{2,30})\]\s*$", n)  # "...AMZN-[y2flix.cc]"
    if m:
        return m.group(1).strip()
    n = re.sub(r"\s*\[[^\]]*\]\s*$", "", n)  # trailing [site] / [hash] tags
    m = _TAIL.search(n)
    return m.group(1) if m else ""


_SOURCES = [  # (tag in the release name, where it was ripped from, any case?) - short tags must be in capitals
    (r"AMZN", "Amazon", False), (r"AMAZON", "Amazon", True), (r"NF", "Netflix", False), (r"NETFLIX", "Netflix", True),
    (r"DSNP|DSNY", "Disney+", False), (r"DISNEY\+?", "Disney+", True), (r"ATVP|APTV", "Apple TV+", False),
    (r"HMAX|MAX", "Max", False), (r"HULU", "Hulu", False), (r"PCOK", "Peacock", False), (r"PMTP", "Paramount+", False),
    (r"iP", "BBC iPlayer", False), (r"iPLAYER", "BBC iPlayer", True), (r"ITVX", "ITVX", False), (r"NOWTV", "NOW", False),
    (r"STAN", "Stan", False), (r"CR", "Crunchyroll", False), (r"CRUNCHYROLL", "Crunchyroll", True),
    (r"HIDI|HIDIVE", "HIDIVE", False), (r"ADN", "ADN", False), (r"B-?Global", "Bilibili", True), (r"VIKI", "Viki", False),
    (r"TVING", "TVING", False), (r"KOCOWA", "Kocowa", True),
    (r"BLU-?RAY|BDRIP|BDREMUX|BD-?REMUX|REMUX", "Blu-ray", True), (r"BD", "Blu-ray", False),
    (r"WEB-?DL|WEB-?RIP|WEB", "Web", True)]
_SRC_RX = [(re.compile(r"(?<![A-Za-z0-9])(?:%s)(?![A-Za-z0-9])" % rx, re.I if anycase else 0), nm)
           for rx, nm, anycase in _SOURCES]


def release_source(name):
    """'High.Potential.S01E01.1080p.AMZN-[y2flix.cc]' -> 'Amazon'; '[Yameii] ... [CR WEB-DL 1080p]' -> 'Crunchyroll'."""
    n = name or ""
    for rx, nm in _SRC_RX:
        if rx.search(n):
            return nm
    return ""


def _p(profile, name):
    return os.path.join(profile, name)


def _load(profile, name, default):
    try:
        with open(_p(profile, name)) as f:
            return json.load(f)
    except Exception:
        return default


def _save(profile, name, data):
    try:
        os.makedirs(profile, exist_ok=True)
        tmp = _p(profile, name + ".tmp")
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, _p(profile, name))
    except Exception:
        pass


def load(profile):
    d = _load(profile, "binge.json", {})
    d.setdefault("shows", {})
    d.setdefault("groups", {})
    return d


def save(profile, d):
    shows = d.get("shows") or {}
    if len(shows) > 60:  # keep the 60 most recent shows
        d["shows"] = dict(sorted(shows.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)[:60])
    _save(profile, "binge.json", d)


def show_of(wk):
    """'an:48671:10' -> 'an:48671'; 'tv:tt123:1:7' -> 'tv:tt123'; movies -> None (no 'next episode')."""
    parts = (wk or "").split(":")
    if parts[0] == "an" and len(parts) == 3:
        return ":".join(parts[:2])
    if parts[0] in ("tv", "kdrama") and len(parts) == 4:
        return ":".join(parts[:2])
    return None


def make_wk(show, season, ep):
    return "%s:%d" % (show, int(ep)) if show.startswith("an:") else "%s:%d:%d" % (show, int(season or 1), int(ep))


def ep_label(show, season, ep):
    return ("Episode %d" % int(ep)) if show.startswith("an:") else "S%02dE%02d" % (int(season or 1), int(ep))


def set_search(profile, show, params, title=None, poster=None):
    """Remember how this show's episodes are searched (from its results page)."""
    d = load(profile)
    s = d["shows"].setdefault(show, {})
    s["search"] = {k: v for k, v in params.items() if k not in ("ep", "flip", "c", "wk", "audio", "action") and v not in (None, "")}
    if params.get("aud"):
        s["aud"] = params["aud"]
    s["title"] = title or s.get("title") or params.get("title") or params.get("q") or ""
    s["poster"] = poster or params.get("poster") or s.get("poster")
    save(profile, d)


def started(profile, np):
    """An episode started: remember it as now playing, and as the show's last episode + release."""
    _save(profile, "nowplaying.json", dict(np, ts=time.time()))
    show = np.get("show")
    d = load(profile)
    g = np.get("group") or ""
    if g:
        d["groups"][g] = d["groups"].get(g, 0) + 1
    if show:
        s = d["shows"].setdefault(show, {})
        s.update(np=np, group=g or s.get("group", ""), res=np.get("res"), source=np.get("source", ""), ts=time.time(),
                 last={"season": np.get("season"), "ep": np.get("ep")})
        s.pop("next", None)
    save(profile, d)


def nowplaying(profile):
    return _load(profile, "nowplaying.json", {})


def set_next(profile, data):
    _save(profile, "next_up.json", dict(data, ts=time.time()))


def next_up(profile):
    return _load(profile, "next_up.json", {})


def usual_groups(profile, show=None):
    """(the group you used for this show, groups you've picked 3+ times anywhere)"""
    d = load(profile)
    mine = ((d["shows"].get(show) or {}).get("group") or "") if show else ""
    favs = {g for g, n in d["groups"].items() if n >= 3}
    return mine, favs


def usual(profile, show):
    """What you played last for this show: {"group", "source", "res"}"""
    s = load(profile)["shows"].get(show) or {}
    return {"group": s.get("group") or "", "source": s.get("source") or "", "res": s.get("res")}


# ---------------- resume points: where you stopped, per episode / film ----------------
def _resume(profile):
    return _load(profile, "resume.json", {})


def resume_get(profile, wk):
    return _resume(profile).get(wk) if wk else None


def resume_set(profile, wk, pos, total):
    if not wk:
        return
    d = _resume(profile)
    d[wk] = {"pos": int(pos), "total": int(total), "ts": time.time()}
    if len(d) > 300:
        d = dict(sorted(d.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)[:300])
    _save(profile, "resume.json", d)


def resume_clear(profile, wk):
    d = _resume(profile)
    if wk in d:
        d.pop(wk)
        _save(profile, "resume.json", d)


def clock(secs):
    secs = int(secs or 0)
    return "%d:%02d:%02d" % (secs // 3600, secs % 3600 // 60, secs % 60) if secs >= 3600 else "%d:%02d" % (secs // 60, secs % 60)


# ---------------- new-episode alerts ----------------
def newep_load(profile):
    return _load(profile, "newep.json", {})


def newep_save(profile, d):
    _save(profile, "newep.json", d)


def airing_load(profile):
    return _load(profile, "airing.json", {})


def airing_save(profile, d):
    _save(profile, "airing.json", d)
