# -*- coding: utf-8 -*-
"""Start in English: when a video starts, pick the English soundtrack if there is one, otherwise English subtitles.
Anime (by default): Japanese soundtrack with English subtitles - or English audio if you'd rather.

Works on what Kodi reports for the file (Player.GetProperties: audiostreams / subtitles), so it doesn't matter
which track the release made the default."""
import re

_EN = re.compile(r"^(?:en|eng|english)\b|\benglish\b", re.I)
_JA = re.compile(r"^(?:ja|jp|jpn|japanese)\b|\bjapanese\b", re.I)
_EXTRA = re.compile(r"comment|director|descriptive|audio description|\bad\b", re.I)
_FORCED = re.compile(r"forced|foreign|signs?(?:\s*&\s*songs?)?\b|songs? ?& ?signs?", re.I)
_SDH = re.compile(r"\bsdh\b|\bcc\b|hearing|impaired", re.I)


def _lang(s):
    return "%s %s" % (s.get("language") or "", s.get("name") or "")


def is_en(s):
    return bool(_EN.search((s.get("language") or "").strip()) or _EN.search(s.get("name") or ""))


def is_ja(s):
    return bool(_JA.search((s.get("language") or "").strip()) or _JA.search(s.get("name") or ""))


def _best_audio(streams):
    """Main track first: not commentary / audio description, then the release's default, then more channels."""
    return sorted(streams, key=lambda a: (bool(_EXTRA.search(a.get("name") or "")), not a.get("isdefault"),
                                          -(a.get("channels") or 0), a.get("index", 0)))[0]


def _full_subs(subs):
    """English subtitles for the whole thing: not 'forced' / 'signs & songs'; plain before SDH."""
    full = [s for s in subs if is_en(s) and not s.get("isforced") and not _FORCED.search(s.get("name") or "")]
    return sorted(full, key=lambda s: (bool(s.get("isimpaired") or _SDH.search(s.get("name") or "")), s.get("index", 0)))


def _forced_subs(subs):
    return [s for s in subs if is_en(s) and (s.get("isforced") or _FORCED.search(s.get("name") or ""))]


def decide(props, anime=False, anime_mode="0"):
    """props = Player.GetProperties result -> (audio index or None, ("on", index) / ("off",) / None, note)."""
    audios = props.get("audiostreams") or []
    subs = props.get("subtitles") or []
    cur = props.get("currentaudiostream") or {}
    cur_sub = props.get("currentsubtitle") or {}
    subs_on = bool(props.get("subtitleenabled"))
    audio = None
    if anime and anime_mode == "0":  # Japanese + English subtitles
        jp = [a for a in audios if is_ja(a)]
        want = _best_audio(jp) if jp else None
        if want and not is_ja(cur):
            audio = want["index"]
        if jp or not any(is_en(a) for a in audios):
            full = _full_subs(subs)
            if full:
                return audio, ("on", full[0]["index"]), "Japanese audio, English subtitles"
            return audio, None, "Japanese audio (no English subtitles in this release)"
        # no Japanese track at all: treat it like anything else
    en = [a for a in audios if is_en(a)]
    if en:
        want = _best_audio(en)
        if not is_en(cur) or _EXTRA.search(cur.get("name") or ""):
            audio = want["index"]
        forced = _forced_subs(subs)
        if forced:  # English audio, but subtitles for the bits in other languages
            return audio, ("on", forced[0]["index"]), "English audio (+ subtitles for foreign-language parts)"
        if subs_on and cur_sub and not is_en(cur_sub):
            return audio, ("off",), "English audio (other-language subtitles turned off)"
        return audio, None, "English audio"
    full = _full_subs(subs) or [s for s in subs if is_en(s)]
    if full:
        return None, ("on", full[0]["index"]), "No English audio - English subtitles on"
    if not audios:
        return None, None, ""
    return None, None, "No English audio or English subtitles in this release"
