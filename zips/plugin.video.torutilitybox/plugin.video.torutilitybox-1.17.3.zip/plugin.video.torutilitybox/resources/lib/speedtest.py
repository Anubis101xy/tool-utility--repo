# -*- coding: utf-8 -*-
"""Speed test: how fast can this box download?

line()   - your internet: several connections at once to a big public test file (Cloudflare, then OVH)
stream() - like Kodi plays: ONE connection to a real file (one of your TorBox files when there is one)
Then recommend() turns the numbers into settings for this box."""
import threading
import time

import requests

LINE_URLS = ["https://speed.cloudflare.com/__down?bytes=500000000",
             "https://proof.ovh.net/files/1Gb.dat"]
UA = {"User-Agent": "Mozilla/5.0 (Kodi speed test)"}


def measure(url, seconds=8.0, conns=1, progress=None, headers=None, warmup=1.0):
    """Download for `seconds` over `conns` connections -> Mb/s (the first second is ignored: connections ramping up).
    progress(mbps_so_far, fraction_done) -> True to stop early."""
    lock = threading.Lock()
    state = {"bytes": 0, "warm": 0, "err": None, "stop": False}
    t0 = time.time()

    def worker():
        try:
            with requests.get(url, stream=True, timeout=10, headers=dict(UA, **(headers or {}))) as r:
                if r.status_code >= 400:
                    raise RuntimeError("HTTP %d" % r.status_code)
                for chunk in r.iter_content(65536):
                    with lock:
                        state["bytes"] += len(chunk)
                        if time.time() - t0 < warmup:
                            state["warm"] = state["bytes"]
                    if state["stop"]:
                        break
        except Exception as e:
            state["err"] = state["err"] or str(e)

    threads = [threading.Thread(target=worker) for _ in range(conns)]
    for t in threads:
        t.daemon = True
        t.start()
    last = 0.0
    while time.time() - t0 < seconds:
        time.sleep(0.25)
        el = time.time() - t0
        with lock:
            got = state["bytes"] - state["warm"]
        last = got * 8 / max(el - warmup, 0.25) / 1e6 if el > warmup else 0.0
        if not any(t.is_alive() for t in threads):
            break
        if progress and progress(last, min(el / seconds, 1.0)):
            state["stop"] = True
            return None
    state["stop"] = True
    el = time.time() - t0
    with lock:
        got = state["bytes"] - state["warm"]
    if state["bytes"] == 0:
        raise RuntimeError(state["err"] or "no data")
    return got * 8 / max(el - warmup, 0.25) / 1e6


def line(progress=None, seconds=8.0):
    """-> (Mb/s, server) - your internet with 4 connections."""
    err = None
    for u in LINE_URLS:
        try:
            v = measure(u, seconds, 4, progress)
            return v, u.split("/")[2]
        except Exception as e:
            err = e
    raise RuntimeError("couldn't reach a test server (%s)" % err)


def stream(url, progress=None, seconds=8.0):
    """-> Mb/s over one connection (how Kodi plays)."""
    return measure(url, seconds, 1, progress)


def box_memory_mb(label):
    """Kodi's 'System.Memory(total)' ('1898MB', '3.8 GB') -> MB."""
    import re
    m = re.search(r"([\d.,]+)\s*([KMGT]?)i?B", label or "", re.I)
    if not m:
        return 0
    v = float(m.group(1).replace(",", ""))
    return int(v * {"K": 1.0 / 1024, "M": 1, "G": 1024, "T": 1048576, "": 1.0 / 1048576}[m.group(2).upper()])


def recommend(stream_mbps, memory_mb):
    """-> {setting: value} with the reasons."""
    s = stream_mbps
    if s >= 25:
        res, why_res = "0", "4K is fine"
    elif s >= 8:
        res, why_res = "2", "4K files need about 15-80 Mb/s"
    else:
        res, why_res = "3", "even 1080p can struggle below 8 Mb/s"
    buf = 256 if memory_mb >= 3000 else 128 if memory_mb >= 1500 or not memory_mb else 64
    return {"net_speed": max(int(s), 1), "max_res": res, "why_res": why_res,
            "smooth_first": "true" if s < 60 else "false", "buffer": buf}
