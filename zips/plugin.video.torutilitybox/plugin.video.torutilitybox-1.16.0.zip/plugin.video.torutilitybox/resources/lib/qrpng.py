# -*- coding: utf-8 -*-
"""Draw a QR code as a PNG with no image libraries (Kodi has none) - qrcodegen (MIT, Project Nayuki) + zlib."""
import struct
import zlib

import qrcodegen


def make(text, path, scale=12, border=3):
    qr = qrcodegen.QrCode.encode_text(text, qrcodegen.QrCode.Ecc.MEDIUM)
    n = qr.get_size()
    size = (n + border * 2) * scale
    rows = []
    for y in range(size):
        my = y // scale - border
        line = bytearray(b"\x00")  # PNG filter type 0
        for x in range(size):
            mx = x // scale - border
            dark = 0 <= mx < n and 0 <= my < n and qr.get_module(mx, my)
            line.append(0 if dark else 255)
        rows.append(bytes(line))

    def chunk(kind, data):
        c = struct.pack(">I", len(data)) + kind + data
        return c + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 0, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)
    return path
