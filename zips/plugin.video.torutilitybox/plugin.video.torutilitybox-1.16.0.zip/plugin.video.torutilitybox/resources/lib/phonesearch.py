# -*- coding: utf-8 -*-
"""Search from your phone: a tiny web page on your home network, served by the add-on's background service.

Your phone opens http://<box>:<port>/?k=<code> (from the QR code on the TV), you type a search, and the results
open on the TV. The code stops anyone else on the network using it. Nothing leaves your home network."""
import html
import json
import os
import threading
from urllib.parse import parse_qs, urlencode, urlparse

try:
    from http.server import ThreadingHTTPServer as _Server, BaseHTTPRequestHandler
except ImportError:  # very old Python
    from http.server import HTTPServer as _Server, BaseHTTPRequestHandler

PORTS = range(8765, 8776)
KINDS = [("tv", "TV"), ("movie", "Films"), ("anime", "Anime"), ("kdrama", "K-drama"), ("free", "Any torrent")]


def _page(name, code, recent):
    rows = "".join('<button class="r" data-i="%d">%s <small>%s</small></button>' % (
        i, html.escape(r["label"]), html.escape(dict(KINDS).get(r.get("kind"), ""))) for i, r in enumerate(recent))
    kinds = "".join('<button class="k" data-t="%s">%s</button>' % (t, l) for t, l in KINDS)
    return """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>%(name)s search</title>
<style>
:root{--bg:#14161a;--card:#1f232a;--ink:#eef0f3;--dim:#9aa3ad;--acc:#3ba7ff}
*{box-sizing:border-box}body{margin:0;font:17px system-ui,sans-serif;background:var(--bg);color:var(--ink);padding:18px}
h1{font-size:20px;margin:0 0 14px}form{display:flex;gap:8px}
input{flex:1;font-size:18px;padding:14px;border-radius:12px;border:1px solid #333a44;background:var(--card);color:var(--ink)}
button{font-size:16px;border:0;border-radius:12px;padding:12px 14px;background:var(--card);color:var(--ink)}
#go{background:var(--acc);color:#fff;font-weight:600}.kinds{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0}
.k.on{background:var(--acc);color:#fff}.r{display:block;width:100%%;text-align:left;margin:6px 0}
small{color:var(--dim)}#msg{min-height:24px;margin:10px 2px;color:#7ddc8a}h2{font-size:15px;color:var(--dim);margin:22px 0 6px}
</style></head><body>
<h1>%(name)s - search on the TV</h1>
<form id="f"><input id="q" placeholder="What do you want to watch?" autocomplete="off" autofocus><button id="go">Go</button></form>
<div class="kinds">%(kinds)s</div><div id="msg"></div>
%(recent_h)s%(rows)s
<script>
var code=%(code)s, t=localStorage.getItem("tub_t")||"tv";
function mark(){document.querySelectorAll(".k").forEach(function(b){b.classList.toggle("on",b.dataset.t==t)})}
document.querySelectorAll(".k").forEach(function(b){b.onclick=function(){t=b.dataset.t;try{localStorage.setItem("tub_t",t)}catch(e){};mark()}});mark();
function send(u,what){fetch(u).then(function(r){return r.json()}).then(function(j){
 document.getElementById("msg").textContent=j.ok?("On the TV now: "+what):(j.error||"Didn't work")}).catch(function(){
 document.getElementById("msg").textContent="Couldn't reach the TV - is Kodi still on?"})}
document.getElementById("f").onsubmit=function(e){e.preventDefault();var q=document.getElementById("q").value.trim();
 if(!q)return;send("/s?k="+code+"&t="+t+"&q="+encodeURIComponent(q),q);document.getElementById("q").blur()};
document.querySelectorAll(".r").forEach(function(b){b.onclick=function(){send("/p?k="+code+"&i="+b.dataset.i,b.textContent)}});
</script></body></html>""" % {"name": html.escape(name), "kinds": kinds, "code": json.dumps(code), "rows": rows,
                              "recent_h": "<h2>Recent searches on the TV</h2>" if recent else ""}


class PhoneServer(object):
    def __init__(self, name, code, profile, on_search, on_open, log=None):
        self.name, self.code, self.profile = name, code, profile
        self.on_search, self.on_open, self.log = on_search, on_open, log or (lambda m: None)
        self.httpd, self.port = None, None

    def recent(self):
        try:
            with open(os.path.join(self.profile, "history.json")) as f:
                return json.load(f)[:12]
        except Exception:
            return []

    def start(self):
        srv = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, body, kind="application/json"):
                data = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", kind + "; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                u = urlparse(self.path)
                q = {k: v[0] for k, v in parse_qs(u.query).items()}
                if q.get("k") != srv.code:
                    return self._send(403, "<h2>Scan the QR code on the TV again</h2>"
                                           "<p>(Search &gt; Search from your phone)</p>", "text/html")
                try:
                    if u.path == "/":
                        return self._send(200, _page(srv.name, srv.code, srv.recent()), "text/html")
                    if u.path == "/s":
                        t, text = q.get("t") or "tv", (q.get("q") or "").strip()[:150]
                        if not text or t not in dict(KINDS):
                            return self._send(400, json.dumps({"ok": False, "error": "Type something to search for"}))
                        srv.on_search(t, text)
                        return self._send(200, json.dumps({"ok": True}))
                    if u.path == "/p":
                        rec = srv.recent()
                        i = int(q.get("i") or -1)
                        if not 0 <= i < len(rec):
                            return self._send(400, json.dumps({"ok": False, "error": "That one's gone - reload the page"}))
                        srv.on_open(rec[i]["params"], rec[i]["label"])
                        return self._send(200, json.dumps({"ok": True}))
                except Exception as e:
                    srv.log("Phone search: %s" % e)
                    return self._send(500, json.dumps({"ok": False, "error": "Something went wrong on the TV"}))
                return self._send(404, json.dumps({"ok": False, "error": "Not found"}))

        for port in PORTS:
            try:
                self.httpd = _Server(("", port), H)
                self.port = port
                break
            except OSError:
                continue
        if not self.httpd:
            self.log("Phone search: no free port in %d-%d" % (PORTS[0], PORTS[-1]))
            return None
        self.httpd.daemon_threads = True
        t = threading.Thread(target=self.httpd.serve_forever)
        t.daemon = True
        t.start()
        return self.port

    def stop(self):
        if self.httpd:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None


def plugin_url(addon_id, params):
    return "plugin://%s/?%s" % (addon_id, urlencode({k: v for k, v in params.items() if v not in (None, "")}))
