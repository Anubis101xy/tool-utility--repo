# -*- coding: utf-8 -*-
"""'Recommended for you': films, TV shows and anime picked from what you've watched lately.

Seeds: the last 60 things you watched (newer counts more) + My list (counts a bit).
Films & TV: TMDB's recommendations for each seed ("people who liked this also liked") when you have a TMDB key,
            otherwise the best-rated titles in the genres you watch most (Cinemeta).
Anime:      AniList's community recommendations (MyAnimeList's when AniList is unreachable).
Scores add up across seeds, so something recommended by several things you watched comes first.
Built in the background (recs.json); 'Not interested' hides a title for good (recs_hide.json)."""
import hashlib
import json
import os
import re
import time

import catalog

IMG = "https://image.tmdb.org/t/p/"
HALF_LIFE = 30 * 86400      # something watched a month ago counts half as much
PER_KIND = 30
MAX_SEEDS = 12


def _load(profile, name, default):
    try:
        with open(os.path.join(profile, name)) as f:
            return json.load(f)
    except Exception:
        return default


def _save(profile, name, data):
    try:
        tmp = os.path.join(profile, name + ".tmp")
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(profile, name))
    except Exception:
        pass


def load(profile):
    return _load(profile, "recs.json", {})


def hidden(profile):
    return set(_load(profile, "recs_hide.json", []))


def hide(profile, key):
    h = _load(profile, "recs_hide.json", [])
    if key not in h:
        h.append(key)
    _save(profile, "recs_hide.json", h[-500:])
    r = load(profile)
    for kind in ("movies", "tv", "anime"):
        r[kind] = [x for x in r.get(kind, []) if x["key"] != key]
    _save(profile, "recs.json", r)


# ---------------- what you've watched ----------------
def seeds(profile, recent, mylist):
    """-> {"movies": [(key, title, weight)], "tv": [...], "anime": [...]} and the set of keys you already know."""
    now = time.time()
    out = {"movies": [], "tv": [], "anime": []}
    seen = set()
    for r in recent:
        k = r.get("show") or ""
        if not k or k in seen:
            continue
        seen.add(k)
        w = 0.5 ** (max(now - r.get("ts", now), 0) / HALF_LIFE)
        kind = "anime" if k.startswith("an:") else "movies" if k.startswith("mv:") else \
            "tv" if k.startswith(("tv:tt", "kdrama:tt")) else None
        if kind:
            out[kind].append((k, r.get("title") or k, w))
    for it in mylist:
        k = it.get("key") or ""
        if k in seen:
            continue
        seen.add(k)
        kind = "anime" if k.startswith("an:") else "movies" if k.startswith("mv:") else \
            "tv" if k.startswith(("tv:tt", "kdrama:tt")) else None
        if kind:
            out[kind].append((k, it.get("title") or k, 0.5))
    for kind in out:
        out[kind] = sorted(out[kind], key=lambda s: -s[2])[:MAX_SEEDS]
    return out, seen


def signature(sd):
    return hashlib.md5(json.dumps(sd, sort_keys=True).encode()).hexdigest()[:12] if sd else ""


# ---------------- films & TV: TMDB ----------------
def _tmdb_item(x, kind):
    title = x.get("title") or x.get("name") or "?"
    date = (x.get("release_date") or x.get("first_air_date") or "")[:10]
    return {"tmdb": x["id"], "title": title, "year": date[:4], "released": date,
            "poster": (IMG + "w342" + x["poster_path"]) if x.get("poster_path") else None,
            "fanart": (IMG + "w1280" + x["backdrop_path"]) if x.get("backdrop_path") else None,
            "plot": x.get("overview") or "", "rating": round(float(x.get("vote_average") or 0), 1),
            "votes": int(x.get("vote_count") or 0), "genres": x.get("genre_ids") or [],
            "country": (x.get("origin_country") or [""])[0] if kind == "tv" else "", "lang": x.get("original_language") or ""}


def tmdb_recs(key, kind, seed_list, known, hide_keys, progress=None):
    typ = "movie" if kind == "movies" else "tv"
    pool, genre_w = {}, {}
    for i, (sk, stitle, w) in enumerate(seed_list):
        if progress and progress("%s: %s" % ("Films" if kind == "movies" else "TV", stitle)):
            break
        imdb = sk.split(":")[1]
        try:
            f = catalog._tmdb(key, "/find/%s" % imdb, external_source="imdb_id")
            hits = f.get("movie_results" if typ == "movie" else "tv_results") or []
            if not hits:
                continue
            sid = hits[0]["id"]
            for g in hits[0].get("genre_ids") or []:
                genre_w[g] = genre_w.get(g, 0) + w
            res = (catalog._tmdb(key, "/%s/%d/recommendations" % (typ, sid)).get("results") or [])[:20]
            if len(res) < 5:
                res += (catalog._tmdb(key, "/%s/%d/similar" % (typ, sid)).get("results") or [])[:10]
        except Exception:
            continue
        for rank, x in enumerate(res):
            if not x.get("id"):
                continue
            it = _tmdb_item(x, kind)
            if typ == "tv" and it["lang"] == "ja" and 16 in it["genres"]:
                continue  # anime: that's the anime list's job
            e = pool.setdefault(x["id"], dict(it, score=0.0, because={}))
            pts = w * (1.0 - rank / 25.0)
            e["score"] += pts
            e["because"][stitle] = e["because"].get(stitle, 0) + pts
    top_g = sorted(genre_w, key=lambda g: -genre_w[g])[:3]
    out = []
    for e in pool.values():
        if e["votes"] < 30 or e["rating"] < 5.5:
            continue
        e["score"] *= 1 + 0.15 * len(set(e["genres"]) & set(top_g))
        e["score"] *= 0.85 + 0.03 * min(e["rating"], 9)
        out.append(e)
    out.sort(key=lambda e: -e["score"])
    picked = []
    for e in out:
        if len(picked) >= PER_KIND:
            break
        try:  # the IMDb id is what the rest of the add-on uses
            if typ == "movie":
                imdb = catalog.tmdb_movie_imdb(key, e["tmdb"])
            else:
                imdb = (catalog._tmdb(key, "/tv/%d/external_ids" % e["tmdb"]) or {}).get("imdb_id")
        except Exception:
            imdb = None
        if not imdb:
            continue
        k = ("mv:" if typ == "movie" else ("kdrama:" if e["country"] == "KR" else "tv:")) + imdb
        if k in known or k in hide_keys or ("tv:" + imdb) in known or ("kdrama:" + imdb) in known:
            continue
        e.update(key=k, imdb=imdb, because=max(e["because"], key=e["because"].get))
        picked.append(e)
    return picked


# ---------------- films & TV without a TMDB key: your favourite genres ----------------
def genre_recs(kind, seed_list, known, hide_keys, progress=None):
    typ = "movie" if kind == "movies" else "series"
    genre_w = {}
    for sk, stitle, w in seed_list[:8]:
        if progress and progress("%s: %s" % ("Films" if kind == "movies" else "TV", stitle)):
            break
        try:
            meta = catalog._get("%s/meta/%s/%s.json" % (catalog.CINEMETA, typ, sk.split(":")[1])).get("meta", {})
        except Exception:
            continue
        for g in meta.get("genres") or meta.get("genre") or []:
            genre_w[g] = genre_w.get(g, 0) + w
    top = sorted(genre_w, key=lambda g: -genre_w[g])[:3]
    pool = {}
    for gi, g in enumerate(top):
        try:
            items = catalog.cinemeta_catalog(typ, g, 0)
        except Exception:
            continue
        for rank, it in enumerate(items[:60]):
            e = pool.setdefault(it["imdb"], dict(it, title=it["name"], score=0.0, genres_hit=[]))
            e["score"] += genre_w[g] * (1.0 - rank / 80.0)
            e["genres_hit"].append(g)
    out = []
    for imdb, e in sorted(pool.items(), key=lambda kv: -kv[1]["score"]):
        k = ("mv:" if typ == "movie" else "tv:") + imdb
        if k in known or k in hide_keys or ("kdrama:" + imdb) in known:
            continue
        hit = e["genres_hit"]
        e.update(key=k, imdb=imdb, because="you like " + " & ".join(hit[:2]), rating=None)
        out.append(e)
        if len(out) >= PER_KIND:
            break
    return out


# ---------------- anime: AniList (MyAnimeList as a backup) ----------------
_AL_REC = """query($m:Int){Media(idMal:$m,type:ANIME){recommendations(sort:RATING_DESC,perPage:12){nodes{rating
mediaRecommendation{id idMal format episodes averageScore popularity startDate{year} title{romaji english}
coverImage{large} bannerImage description(asHtml:false) isAdult}}}}}"""


def anime_recs(seed_list, known, hide_keys, progress=None):
    pool, seed_mal = {}, set()
    for sk, stitle, w in seed_list:
        if progress and progress("Anime: %s" % stitle):
            break
        try:
            mal = catalog.kitsu_show(sk.split(":")[1]).get("mal")
        except Exception:
            mal = None
        if not mal:
            continue
        seed_mal.add(int(mal))
        recs = []
        try:
            m = (catalog._anilist(_AL_REC, {"m": int(mal)}) or {}).get("Media") or {}
            for rank, n in enumerate((m.get("recommendations") or {}).get("nodes") or []):
                x = n.get("mediaRecommendation") or {}
                if not x.get("idMal") or x.get("isAdult") or (n.get("rating") or 0) < 1:
                    continue
                t = x.get("title") or {}
                recs.append({"mal": x["idMal"], "anilist": x["id"], "title": t.get("english") or t.get("romaji") or "?",
                             "year": str((x.get("startDate") or {}).get("year") or ""), "poster": (x.get("coverImage") or {}).get("large"),
                             "fanart": x.get("bannerImage"), "plot": re.sub(r"<[^>]+>", "", x.get("description") or "")[:800],
                             "rating": round((x.get("averageScore") or 0) / 10.0, 1) or None,
                             "movie": x.get("format") == "MOVIE", "eps": x.get("episodes"), "rank": rank})
        except Exception:
            try:  # AniList unreachable: MyAnimeList's recommendations
                d = catalog._jikan("/anime/%s/recommendations" % mal, {}) or {}
                for rank, n in enumerate((d.get("data") or [])[:12]):
                    x = n.get("entry") or {}
                    if not x.get("mal_id"):
                        continue
                    recs.append({"mal": x["mal_id"], "anilist": None, "title": x.get("title") or "?", "year": "",
                                 "poster": ((x.get("images") or {}).get("jpg") or {}).get("large_image_url"), "fanart": None,
                                 "plot": "", "rating": None, "movie": False, "eps": None, "rank": rank})
            except Exception:
                continue
        for x in recs:
            e = pool.setdefault(x["mal"], dict(x, score=0.0, because={}))
            pts = w * (1.0 - x["rank"] / 15.0)
            e["score"] += pts
            e["because"][stitle] = e["because"].get(stitle, 0) + pts
    out = []
    for mal, e in sorted(pool.items(), key=lambda kv: -kv[1]["score"]):
        k = "mal:%s" % mal
        if mal in seed_mal or k in hide_keys or k in known:
            continue
        e.update(key=k, because=max(e["because"], key=e["because"].get))
        out.append(e)
        if len(out) >= PER_KIND:
            break
    return out


def build(profile, recent, mylist, tmdb_key="", progress=None, log=None, also_known=()):
    """Work out all three lists and save them. progress(text) -> True to stop.
    also_known: other keys you've already seen (watched films, shows you're watching)."""
    sd, known = seeds(profile, recent, mylist)
    known |= set(also_known)
    hide_keys = hidden(profile)
    out = {"ts": time.time(), "sig": signature(sd), "source": "tmdb" if tmdb_key else "genres",
           "seeds": {k: len(v) for k, v in sd.items()}}
    for kind in ("movies", "tv"):
        try:
            if not sd[kind]:
                out[kind] = []
            elif tmdb_key:
                out[kind] = tmdb_recs(tmdb_key, kind, sd[kind], known, hide_keys, progress)
            else:
                out[kind] = genre_recs(kind, sd[kind], known, hide_keys, progress)
        except Exception as e:
            out[kind] = load(profile).get(kind, [])
            if log:
                log("Recommendations (%s): %s" % (kind, e))
    try:
        out["anime"] = anime_recs(sd["anime"], known, hide_keys, progress) if sd["anime"] else []
    except Exception as e:
        out["anime"] = load(profile).get("anime", [])
        if log:
            log("Recommendations (anime): %s" % e)
    _save(profile, "recs.json", out)
    if log:
        log("Recommendations built: %d films, %d TV, %d anime (from %s)" % (
            len(out["movies"]), len(out["tv"]), len(out["anime"]), out["source"]))
    return out


def stale(profile, recent, mylist):
    """Time for a rebuild? (once a day, or within the hour when you've watched something new)"""
    r = load(profile)
    age = time.time() - r.get("ts", 0)
    sd, _ = seeds(profile, recent, mylist)
    return age > 20 * 3600 or (r.get("sig") != signature(sd) and age > 3600)
