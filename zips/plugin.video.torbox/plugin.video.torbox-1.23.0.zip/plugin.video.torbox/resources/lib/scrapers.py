# -*- coding: utf-8 -*-
"""Pluggable torrent scrapers. Each returns dicts: name, hash, size, seeds, source[, cached]."""
import re
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, wait

import requests

UA = {"User-Agent": "Mozilla/5.0 (Kodi-TorBox)"}
# Usenet indexers (NZBFinder etc.) reject browser-looking agents - they want the app to say what it is
NZB_UA = {"User-Agent": "TorBoxKodi/1.17.9 (Kodi add-on; Newznab search)"}
BTIH = re.compile(r"btih:([0-9a-fA-F]{40})")
CAM = re.compile(r"\b(cam|camrip|hdcam|ts|hdts|telesync|tc|hdtc)\b", re.I)
UNITS = {"K": 1024, "M": 1024 ** 2, "G": 1024 ** 3, "T": 1024 ** 4}


def to_bytes(txt):
    txt = txt or ""
    if "\U0001F4BE" in txt:  # prefer the size after the disk emoji used by Stremio addons
        txt = txt.split("\U0001F4BE", 1)[1]
    m = re.search(r"(\d+(?:\.\d+)?)\s*([KMGT])i?B\b", txt, re.I)
    return int(float(m.group(1)) * UNITS[m.group(2).upper()]) if m else 0


# ---------------- season packs vs episodes ----------------
EP_RE = re.compile(r"s\d{1,2}[ ._-]?e\d{1,3}|\b\d{1,2}x\d{2,3}\b", re.I)
MULTI_EP = re.compile(r"s\d{1,2}[ ._-]?e\d{1,3}[ ._-]*(?:-|~|to)[ ._-]*e?\d{1,3}", re.I)
RANGE_S = re.compile(r"\bs(?:eason)?s?[ ._]?0*(\d{1,2})[ ._]*(?:-|~|to|&|\+)[ ._]*s?(?:eason)?[ ._]?0*(\d{1,2})\b", re.I)
SEASON_N = re.compile(r"(?:\bs|season[ ._]?)0*(\d{1,2})(?!\d|[ ._-]?e\d)", re.I)
COMPLETE = re.compile(r"complete|batch|collection|all[ ._]seasons|full[ ._]series|integral", re.I)
ANIME_EP = re.compile(r"(?:^|[\s\]\)])-\s*\d{1,3}(?:v\d)?(?=[\s\[\(]|$)")
ANIME_RANGE = re.compile(r"\b0*\d{1,3}\s*[-~]\s*0*\d{2,3}\b")


_NAMED_EP = re.compile(r"\bS\d{1,2}[ ._-]?E(\d{1,4})(?![\d])(?![ ._]?-[ ._]?E?\d)(?![ ._]?E\d)", re.I)


def named_episode(name):
    """The episode a single-episode release names explicitly as S02E08 (None if it doesn't, or if it's a range)."""
    m = _NAMED_EP.search(name or "")
    return int(m.group(1)) if m else None


def pack_kind(name, season=None, anime=False):
    """'ep' = single episode, 'pack' = full season / batch, 'multi' = several seasons or complete series,
    'other' = a pack for a different season."""
    if anime:
        if COMPLETE.search(name) or ANIME_RANGE.search(name):
            return "pack"
        if ANIME_EP.search(name) or EP_RE.search(name) or re.search(r"(?:\be|\bep|episode)[ ._-]*\d{1,4}(?!\d)", name, re.I):
            return "ep"
        return "pack"  # no episode number in the name -> almost always a batch
    if MULTI_EP.search(name):
        return "pack"
    if EP_RE.search(name):
        return "ep"
    rs = RANGE_S.search(name)
    if rs:
        lo, hi = int(rs.group(1)), int(rs.group(2))
        return "multi" if season is None or lo <= int(season) <= hi else "other"
    if re.search(r"complete[ ._]series|full[ ._]series|all[ ._]seasons|complete[ ._]collection", name, re.I):
        return "multi"
    sm = SEASON_N.search(name)
    if sm:
        return "pack" if season is None or int(sm.group(1)) == int(season) else "other"
    if COMPLETE.search(name):
        return "multi"
    return "ep"


# ---------------- audio (anime dub / sub) ----------------
DUB = re.compile(r"\b(dub(?:bed)?|dual[ ._-]?audio|multi[ ._-]?audio|english[ ._-]?dub|eng[ ._-]?dub)\b", re.I)


def audio_kind(name):
    m = DUB.search(name)
    if not m:
        return "sub"
    return "dual" if re.search(r"dual|multi", m.group(0), re.I) else "dub"


# ---------------- quality parsing ----------------
def res_rank(name):
    n = name.lower()
    if re.search(r"2160p|\b4k\b|uhd", n):
        return 4
    if "1080p" in n:
        return 3
    if "720p" in n:
        return 2
    return 1


def tags(name):
    n = name.lower()
    t = [{4: "2160p", 3: "1080p", 2: "720p", 1: "SD"}[res_rank(name)]]
    if re.search(r"remux", n):
        t.append("Remux")
    if re.search(r"\bdv\b|dolby.?vision", n):
        t.append("DV")
    if re.search(r"hdr10\+", n):
        t.append("HDR10+")
    elif re.search(r"hdr", n):
        t.append("HDR")
    if re.search(r"x265|h\.?265|hevc", n):
        t.append("HEVC")
    elif re.search(r"av1", n):
        t.append("AV1")
    if re.search(r"atmos", n):
        t.append("Atmos")
    elif re.search(r"truehd", n):
        t.append("TrueHD")
    elif re.search(r"dts-?hd|dts-?x", n):
        t.append("DTS-HD")
    return " ".join(t)


# ---------------- scrapers ----------------
def stremio(base, ctx):
    """Torrentio / Comet / MediaFusion / any Stremio addon that returns infoHash streams."""
    sid, kind = ctx.get("sid"), ctx.get("kind")
    if not sid:
        if not ctx.get("imdb"):
            return None  # not applicable to free-text searches
        kind = "series" if ctx.get("season") else "movie"
        sid = ctx["imdb"] + (":%s:%s" % (ctx["season"], ctx["episode"]) if kind == "series" else "")
    base = re.sub(r"/manifest\.json$", "", base.strip()).rstrip("/")
    r = requests.get("%s/stream/%s/%s.json" % (base, kind, sid), headers=UA, timeout=ctx["timeout"])
    r.raise_for_status()
    out = []
    for s in r.json().get("streams", []):
        h = (s.get("infoHash") or "").lower()
        if not h:
            continue
        text = s.get("title") or s.get("description") or s.get("name") or ""
        name = (s.get("behaviorHints") or {}).get("filename") or text.split("\n")[0]
        seeds = re.search(r"👤\s*(\d+)", text)
        src = re.search(r"⚙️\s*([^\n]+)", text)
        out.append({"name": name, "hash": h, "file": (s.get("behaviorHints") or {}).get("filename"),
                    "size": to_bytes(text) or (s.get("behaviorHints") or {}).get("videoSize") or 0,
                    "seeds": int(seeds.group(1)) if seeds else 0, "source": (src.group(1) if src else "Stremio").strip()})
    if ctx.get("show"):  # whole-show search asks for episode 1: keep only the season / series packs from it
        out = [r for r in out if pack_kind(r["name"], None, bool(ctx.get("anime"))) != "ep"]
    return out


def torznab(url, key, ctx):
    r = requests.get(url, params={"t": "search", "q": ctx["query"], "apikey": key}, headers=UA, timeout=ctx["timeout"])
    r.raise_for_status()
    root = ET.fromstring(r.content)
    if root.tag == "error":
        raise ValueError(root.get("description") or "Torznab error")
    out = []
    for it in root.iter("item"):
        attrs = {a.get("name"): a.get("value") for a in it if a.tag.endswith("attr")}
        h = (attrs.get("infohash") or "").lower()
        if not h:
            m = BTIH.search(attrs.get("magneturl") or (it.findtext("link") or "") or "")
            h = m.group(1).lower() if m else ""
        if not h:
            continue
        out.append({"name": it.findtext("title") or "?", "hash": h,
                    "size": int(attrs.get("size") or it.findtext("size") or 0),
                    "seeds": int(attrs.get("seeders") or 0), "source": it.findtext("jackettindexer") or "Torznab"})
    return out


def prowlarr(host, key, ctx):
    r = requests.get(host.rstrip("/") + "/api/v1/search", params={"query": ctx["query"], "type": "search"},
                     headers={"X-Api-Key": key}, timeout=ctx["timeout"])
    r.raise_for_status()
    out = []
    for e in r.json():
        h = (e.get("infoHash") or "").lower()
        if not h:
            m = BTIH.search(e.get("magnetUrl") or e.get("guid") or "")
            h = m.group(1).lower() if m else ""
        if h:
            out.append({"name": e.get("title") or "?", "hash": h, "size": e.get("size") or 0,
                        "seeds": e.get("seeders") or 0, "source": e.get("indexer") or "Prowlarr"})
    return out


def coco(ctx):
    """Use the user's installed CocoScrapers module (script.module.cocoscrapers). Providers are chosen in ITS settings."""
    if ctx.get("show") or not ctx.get("imdb") or not ctx.get("title"):
        return None  # needs a title lookup (Movie / TV search) and a specific episode
    try:
        from cocoscrapers import sources as coco_sources
    except ImportError:
        raise RuntimeError("CocoScrapers module is not installed (script.module.cocoscrapers)")
    year = str(ctx.get("year") or "")
    if not year.isdigit():
        raise RuntimeError("no release year for this title - try the Movie / TV search")
    data = {"title": ctx["title"], "year": year, "imdb": ctx["imdb"], "aliases": [ctx["title"]]}
    if ctx.get("season"):
        data.update({"tvshowtitle": ctx["title"], "title": "", "season": str(ctx["season"]),
                     "episode": str(ctx["episode"])})
    providers = coco_sources()
    if not providers:
        raise RuntimeError("no providers enabled - use 'CocoScrapers: choose providers' in the add-on menu")
    ex = ThreadPoolExecutor(max_workers=min(12, len(providers)))
    futs = {ex.submit(lambda m=mod: m().sources(dict(data), []) or []): name for name, mod in providers}
    done, _ = wait(list(futs), timeout=ctx["timeout"])
    ex.shutdown(wait=False)  # don't block on slow providers
    out = []
    for f in done:
        try:
            for r in f.result():
                h = (r.get("hash") or "").lower()
                if h:
                    out.append({"name": r.get("name") or "?", "hash": h,
                                "size": int(float(r.get("size") or 0) * 1024 ** 3),
                                "seeds": int(r.get("seeders") or 0), "source": "Coco:" + futs[f]})
        except Exception:
            continue
    return out


def nyaa(ctx):
    """Nyaa RSS - the main anime source (also live-action for K-dramas). Only runs for Anime / K-drama searches."""
    cat = ctx.get("nyaa_cat")
    if not cat:
        return None
    titles = [t for t in (ctx.get("title"), ctx.get("alt")) if t][:2]
    ep = ctx.get("nyaa_ep") or ""
    queries = [("%s %s" % (t, ep)).strip() for t in titles]
    if ctx.get("pack") and titles:
        queries.append("%s complete" % titles[0])
    if titles and ctx.get("audio") in ("dub", "any", "all") and ctx.get("anime"):
        queries.append(("%s %s dual audio" % (titles[0], ep)).strip())
        if ctx.get("audio") in ("dub", "all"):
            queries.append(("%s %s dub" % (titles[0], ep)).strip())
    ns = "{https://nyaa.si/xmlns/nyaa}"
    out = []
    for q in queries:
        r = requests.get((ctx.get("nyaa_host") or "https://nyaa.si").rstrip("/") + "/", params={"page": "rss", "q": q, "c": cat, "f": "0"},
                         headers=UA, timeout=ctx["timeout"])
        r.raise_for_status()
        for it in ET.fromstring(r.content).iter("item"):
            h = (it.findtext(ns + "infoHash") or "").lower()
            if h:
                out.append({"name": it.findtext("title") or "?", "hash": h, "size": to_bytes(it.findtext(ns + "size")),
                            "seeds": int(it.findtext(ns + "seeders") or 0), "source": "Nyaa"})
    return out


def build(get, api):
    """Return [(label, callable(ctx))] for every enabled scraper."""
    jobs = []
    for n in ("1", "2"):
        if get("stremio%s_enable" % n) == "true" and get("stremio%s_url" % n).strip():
            u = get("stremio%s_url" % n)
            jobs.append(("Stremio%s" % n, lambda c, u=u: stremio(u, c)))
    if get("torznab_enable") == "true" and get("torznab_url").strip():
        jobs.append(("Torznab", lambda c: torznab(get("torznab_url").strip(), get("torznab_key").strip(), c)))
    if get("nyaa_enable") != "false":
        jobs.append(("Nyaa", nyaa))
    for site in SITES:
        job = site_job(get, site)
        if job:
            jobs.append((SITES[site][0], job))
    if get("coco_enable") == "true":
        jobs.append(("CocoScrapers", coco))
    if get("enable_prowlarr") == "true" and get("prowlarr_host").strip():
        jobs.append(("Prowlarr", lambda c: prowlarr(get("prowlarr_host").strip(), get("prowlarr_api_key").strip(), c)))
    return jobs


def run_all(jobs, ctx, progress=None, quick=False, on_batch=None):
    """Run scrapers in parallel. Returns (results, report) where report = [(label, count|None, error, secs)].
    progress(done, total, found, waiting) -> True to stop and show what's in; quick: don't wait long for slow
    sources once plenty is found; on_batch(results) is called as each source finishes (to check TorBox early)."""
    def one(job):
        t0, label, fn = time.time(), job[0], job[1]
        try:
            res = fn(ctx)
            return label, res, None, time.time() - t0
        except Exception as e:  # report, never crash the listing
            return label, None, "%s: %s" % (type(e).__name__, e), time.time() - t0
    results, report = [], []
    ex = ThreadPoolExecutor(max_workers=max(1, len(jobs)))
    futs = [ex.submit(one, j) for j in jobs]
    t0, limit = time.time(), ctx["timeout"] + 5
    seen, found, settled, stopped = set(), 0, None, False
    while True:
        for j, f in zip(jobs, futs):
            if f.done() and j[0] not in seen:
                seen.add(j[0])
                got = f.result()[1]
                found += len(got or [])
                if on_batch and got:
                    try:
                        on_batch(got)
                    except Exception:
                        pass
        if len(seen) == len(jobs):
            break
        el = time.time() - t0
        if el >= limit:
            break
        if progress:
            try:
                if progress(len(seen), len(jobs), found, [j[0] for j in jobs if j[0] not in seen]):
                    stopped = True
                    break
            except Exception:
                pass
        if quick and el >= 3 and len(seen) * 2 >= len(jobs) and found >= 25:
            settled = settled or time.time()  # plenty found: give the slow ones 2.5 s more, then go
            if time.time() - settled >= 2.5:
                stopped = True
                break
        time.sleep(0.15)
    ex.shutdown(wait=False)
    if True:
        rows, el = [], time.time() - t0
        for j, f in zip(jobs, futs):
            if f.done():
                rows.append(f.result())
            elif stopped:
                rows.append((j[0], None, "n/a - still searching, left out to show results sooner", el))
            else:
                rows.append((j[0], None, "timed out", float(ctx["timeout"])))
        for label, res, err, secs in rows:
            if res is None and err is None:
                report.append((label, None, "n/a for this search type", secs))
                continue
            report.append((label, len(res) if res is not None else None, err, secs))
            for r in res or []:
                r.setdefault("source", label)
                results.append(r)
    seen = {}
    for r in results:
        k = r["hash"]
        if k not in seen or (r.get("seeds", 0) > seen[k].get("seeds", 0)):
            if k in seen and "cached" in seen[k]:
                r.setdefault("cached", seen[k]["cached"])
            seen[k] = r
    return list(seen.values()), report


def cinemeta(query, kind):
    r = requests.get("https://v3-cinemeta.strem.io/catalog/%s/top/search=%s.json" % (kind, requests.utils.quote(query, safe="")),
                     headers=UA, timeout=15)
    r.raise_for_status()
    return [{"imdb": m["id"], "name": m.get("name", "?"), "year": str(m.get("releaseInfo") or m.get("year") or "")[:4]}
            for m in r.json().get("metas", []) if str(m.get("id", "")).startswith("tt")][:15]


# ---------------- keyword torrent sites (Pirate Bay, Knaben, BitSearch) ----------------
# Each site can be switched on/off per media type and pointed at a different web address in settings.
import base64 as _b64
from urllib.parse import unquote_plus as _unq

MEDIA_TYPES = ("movie", "tv", "anime", "kdrama")
SITES = {  # id: (label, host setting id, default address)
    "tpb": ("PirateBay", "apibay_host", "https://apibay.org"),
    "knaben": ("Knaben", "knaben_host", "https://api.knaben.org"),
    "bitsearch": ("BitSearch", "bitsearch_host", "https://bitsearch.to"),
}
_STOP = {"the", "a", "an", "and", "of", "to", "in", "on", "at", "for"}
_MAG = re.compile(r"(magnet:\?[^\"'<>\s]+)", re.I)
_HASH = re.compile(r"btih:([0-9a-zA-Z]{32,40})", re.I)


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def site_host(get, site):
    h = (get(SITES[site][1]) or "").strip().rstrip("/") or SITES[site][2]
    return h if h.startswith("http") else "https://" + h


def site_media(get, site):
    return {m for m in MEDIA_TYPES if get("%s_%s" % (site, m)) == "true"}


def site_job(get, site):
    """Settings are read once here (not inside the worker threads)."""
    media, host = site_media(get, site), site_host(get, site)
    if not media:
        return None
    fn = {"tpb": tpb, "knaben": knaben, "bitsearch": bitsearch}[site]

    def run(ctx):
        m = ctx.get("media") or "free"
        if m == "free":
            if not media & {"movie", "tv"}:
                return None
        elif m not in media:
            return None
        out, seen = [], set()
        qs = kw_queries(ctx)
        if len(qs) > 1:  # e.g. English + Japanese anime titles: search both at once
            with ThreadPoolExecutor(max_workers=len(qs)) as ex:
                batches = list(ex.map(lambda q: _safe(fn, host, q, ctx), qs))
            if all(b is None for b in batches):
                fn(host, qs[0], ctx)  # every query failed: raise the real error for the report
        else:
            batches = [fn(host, qs[0], ctx)] if qs else []
        for batch in batches:
            for r in batch or []:
                if r["hash"] in seen or (m != "free" and not relevant(r["name"], ctx)):
                    continue
                seen.add(r["hash"])
                out.append(r)
        return out
    return run


def _safe(fn, host, q, ctx):
    try:
        return fn(host, q, ctx)
    except Exception:
        return None


def kw_queries(ctx):
    qs = [ctx.get("query") or ""]
    if ctx.get("media") == "anime" and ctx.get("alt"):
        qs.append(("%s %s" % (ctx["alt"], ctx.get("nyaa_ep") or "")).strip())
    return [q for i, q in enumerate(qs) if q and q not in qs[:i]]


def relevant(name, ctx):
    """Drop results that are clearly for something else (wrong title, wrong season/episode, wrong year)."""
    n = " %s " % _norm(name)
    media = ctx.get("media")
    titles = [ctx.get("query")] if media == "music" else [t for t in (ctx.get("title"), ctx.get("alt")) if t]
    if titles:
        def has(t):
            words = [w for w in _norm(t).split() if w not in _STOP] or _norm(t).split()
            return all(" %s " % w in n for w in words)
        if not any(has(t) for t in titles):
            return False
    if media in ("tv", "kdrama") and ctx.get("season"):
        m = re.search(r"s(\d{1,2})[ ._-]?e(\d{1,3})(?:[ ._]?(?:-[ ._]?e?|e)(\d{1,3}))?(?!\d)", name, re.I)
        if m:
            if int(m.group(1)) != int(ctx["season"]):
                return False
            if ctx.get("episode") and not ctx.get("pack"):
                lo = int(m.group(2))
                hi = int(m.group(3)) if m.group(3) else lo
                if not min(lo, hi) <= int(ctx["episode"]) <= max(lo, hi):
                    return False
    if media == "movie":
        if re.search(r"s\d{1,2}[ ._-]?e\d{1,3}", name, re.I):
            return False
        y = str(ctx.get("year") or "")
        years = re.findall(r"(?<!\d)(?:19|20)\d\d(?!\d)", name)
        if y.isdigit() and not any(abs(int(v) - int(y)) <= 1 for v in years):
            return False  # no year, or the wrong year -> almost always a different film
    return True


def _hash_of(mag):
    m = _HASH.search(mag)
    if not m:
        return ""
    h = m.group(1)
    if len(h) == 32:  # base32 form
        try:
            return _b64.b32decode(h.upper()).hex()
        except Exception:
            return ""
    return h.lower() if len(h) == 40 else ""


def _from_magnet(mag, source, seeds=0, size=0, name=None):
    mag = _unq(mag.replace("&amp;", "&").replace("&#x3D;", "=").replace("&#61;", "="))
    h = _hash_of(mag)
    if not h:
        return None
    if not name:
        dn = re.search(r"[?&]dn=([^&]+)", mag)
        name = _unq(dn.group(1)) if dn else h
    return {"name": re.sub(r"<[^>]+>", "", name).strip(), "hash": h, "size": int(size or 0), "seeds": int(seeds or 0),
            "source": source}


def _rows(html, tag, cls):
    rx = re.compile(r"<%s\b[^>]*class=[\"'][^\"']*%s[^\"']*[\"'][^>]*>(.*?)</%s>" % (tag, re.escape(cls), tag), re.S | re.I)
    return rx.findall(html)


def _num(txt):
    txt = (txt or "").replace(",", "").strip()
    m = re.match(r"([\d.]+)\s*([kK]?)", txt)
    if not m:
        return 0
    v = float(m.group(1))
    return int(v * 1000) if m.group(2) else int(v)


def _all_magnets(html, source):
    """Fallback when a site's page layout changes: take every magnet link on the page."""
    out, seen = [], set()
    for mag in _MAG.findall(html):
        it = _from_magnet(mag, source)
        if it and it["hash"] not in seen:
            seen.add(it["hash"])
            out.append(it)
    return out


BROWSER = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                         "Chrome/126.0.0.0 Safari/537.36",
           "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
           "Accept-Language": "en-GB,en;q=0.9"}


class SiteError(Exception):
    pass


def _get_html(url, params, ctx):
    """Fetch a site's search page like a normal browser would; explain Cloudflare blocks and server errors."""
    import cfsolve
    try:
        r = cfsolve.get(url, params, BROWSER, ctx["timeout"])
    except cfsolve.CFError as e:
        raise SiteError("blocked by the site's Cloudflare protection - %s" % e)
    if r.status_code >= 400:
        if cfsolve.is_cf_block(r):
            if getattr(r, "via_flaresolverr", False):
                raise SiteError("blocked by the site's Cloudflare protection (HTTP %s) - FlareSolverr couldn't get "
                                "through either; try another web address or turn this site off" % r.status_code)
            raise SiteError("blocked by the site's Cloudflare protection (HTTP %s) - set up FlareSolverr "
                            "(Settings > Torrent sites), try another web address, or turn this site off" % r.status_code)
        if r.status_code >= 500:
            raise SiteError("the site's server failed (HTTP %s) - it may be down or busy, try again later" % r.status_code)
        r.raise_for_status()
    return r.text


def tpb(host, q, ctx):
    """Pirate Bay JSON API (apibay)."""
    cat = {"music": "100", "free": "0"}.get(ctx.get("media"), "200")
    r = requests.get(host + "/q.php", params={"q": q, "cat": cat}, headers=UA, timeout=ctx["timeout"])
    r.raise_for_status()
    out = []
    for d in r.json():
        h = (d.get("info_hash") or "").lower()
        if not h or set(h) == {"0"}:
            continue
        out.append({"name": d.get("name") or "?", "hash": h, "size": int(d.get("size") or 0),
                    "seeds": int(d.get("seeders") or 0), "source": "PirateBay"})
    return out


_NOT_VIDEO = ("audio", "book", "software", "game", "xxx", "porn", "other")


def knaben(host, q, ctx):
    """Knaben meta-search. Uses Knaben's JSON API (fast); if the address is pointed at the website instead,
    reads the search page like CocoScrapers does."""
    if "knaben.eu" in host and "api." not in host:
        host = "https://api.knaben.org"  # old default address -> API
    if "api." not in host:
        return knaben_html(host, q, ctx)
    url = host if host.rstrip("/").endswith("/v1") else host.rstrip("/") + "/v1"
    body = {"search_type": "100%", "search_field": "title", "query": q, "order_by": "seeders",
            "order_direction": "desc", "from": 0, "size": 100, "hide_unsafe": True, "hide_xxx": True}
    r = requests.post(url, json=body, headers=UA, timeout=ctx["timeout"])
    r.raise_for_status()
    music = ctx.get("media") == "music"
    out = []
    for hit in r.json().get("hits") or []:
        cat = (hit.get("category") or "").lower()
        if cat:
            if music and not cat.startswith("audio"):
                continue
            if not music and cat.startswith(_NOT_VIDEO):
                continue
        h = (hit.get("hash") or "").lower()
        if len(h) != 40 and hit.get("magnetUrl"):
            h = _hash_of(_unq(hit["magnetUrl"]))
        if len(h) != 40:
            continue
        src = "Knaben" + (" (%s)" % hit["tracker"] if hit.get("tracker") else "")
        out.append({"name": hit.get("title") or "?", "hash": h, "size": int(hit.get("bytes") or 0),
                    "seeds": int(hit.get("seeders") or 0), "source": src})
    return out


def knaben_html(host, q, ctx):
    """Knaben meta-search (searches many torrent sites at once). Page layout as used by CocoScrapers."""
    params = {"q": q, "search": "fast"}
    cat = {"movie": "003000000", "tv": "002000000", "kdrama": "002000000"}.get(ctx.get("media"))
    if cat:
        params["cat"] = cat
    html = _get_html(host + "/search/index.php", params, ctx)
    out = []
    for row in _rows(html, "tr", "border-start"):
        mag = _MAG.search(row)
        if not mag:
            continue
        cols = re.findall(r"<td.*?>(.+?)</td>", row, re.S)
        seeds = _num(re.sub(r"<[^>]+>", "", cols[4])) if len(cols) > 4 else 0
        size = to_bytes(re.sub(r"<[^>]+>", " ", cols[2])) if len(cols) > 2 else to_bytes(re.sub(r"<[^>]+>", " ", row))
        it = _from_magnet(mag.group(1), "Knaben", seeds, size)
        if it:
            out.append(it)
    return out or _all_magnets(html, "Knaben")


def bitsearch(host, q, ctx):
    """BitSearch (DHT search engine). Page layout as used by CocoScrapers."""
    try:  # sort by size like CocoScrapers does; if the server objects, ask without sorting
        html = _get_html(host + "/search", {"q": q, "sort": "size"}, ctx)
    except SiteError as e:
        if "Cloudflare" in str(e):
            raise
        html = _get_html(host + "/search", {"q": q}, ctx)
    out = []
    for row in _rows(html, "li", "search-result"):
        mag = _MAG.search(row)
        if not mag:
            continue
        cols = re.findall(r"<div.*?>(.*?)</div>", row, re.S)
        seeds = 0
        if len(cols) > 2:
            m = re.search(r">([0-9][0-9,.]*K?)<", cols[2], re.I)
            seeds = _num(m.group(1)) if m else 0
        size = to_bytes(re.sub(r"<[^>]+>", " ", row))
        it = _from_magnet(mag.group(1), "BitSearch", seeds, size)
        if it:
            out.append(it)
    return out or _all_magnets(html, "BitSearch")


# ---------------- Usenet (NZB) search: Newznab indexers + TorBox's own search ----------------
import email.utils as _eu


def _attrs(item):
    return {a.get("name"): a.get("value") for a in item if a.tag.endswith("attr")}


def _age_days(date_txt):
    try:
        dt = _eu.parsedate_to_datetime(date_txt)
        return max(0, int((time.time() - dt.timestamp()) // 86400))
    except Exception:
        return None


def _nzb_fetch(base, params, ctx, source):
    r = requests.get(base, params=params, headers=NZB_UA, timeout=ctx["timeout"])
    try:
        root = ET.fromstring(r.content)
    except ET.ParseError:
        root = None
    if r.status_code >= 400 or root is None or root.tag == "error":
        # explain it in plain words, and never show the API key (requests puts it in its error text)
        code = str(root.get("code")) if root is not None and root.tag == "error" else ""
        desc = root.get("description") if root is not None and root.tag == "error" else ""
        if r.status_code == 401 or code in ("100", "101"):
            hint = "the indexer didn't accept your API key - copy it again from your account / API page on its website"
        elif r.status_code == 403 or code == "102":
            hint = "the indexer refused - the account may need activating, or your plan doesn't allow API searches"
        elif r.status_code == 429 or code in ("500", "501"):
            hint = "you've hit this indexer's daily limit - it resets tomorrow"
        elif r.status_code >= 500:
            hint = "the indexer's server is having problems (HTTP %s) - try later" % r.status_code
        else:
            hint = "unexpected reply (HTTP %s)" % r.status_code
        raise ValueError("%s%s" % (hint, (" [indexer says: %s]" % desc) if desc else ""))
    out = []
    for it in root.iter("item"):
        at = _attrs(it)
        enc = it.find("enclosure")
        nzb = (enc.get("url") if enc is not None else None) or it.findtext("link")
        if not nzb:
            continue
        size = at.get("size") or (enc.get("length") if enc is not None else None) or it.findtext("size") or 0
        out.append({"name": it.findtext("title") or "?", "nzb": nzb, "hash": nzb, "size": int(float(size or 0)),
                    "grabs": int(float(at.get("grabs") or 0)), "age": _age_days(at.get("usenetdate") or it.findtext("pubDate")),
                    "source": source, "mode": "file"})
    return out


def newznab(url, key, ctx, source):
    """Any Newznab indexer (NZBGeek, DrunkenSlug, NZBFinder, AltHub...)."""
    base = url.strip().rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base
    if not base.endswith("/api"):
        base += "/api"
    media = ctx.get("media") or "free"
    imdb = (ctx.get("imdb") or "").replace("tt", "")
    common = {"apikey": key, "o": "xml", "limit": 100}
    params = dict(common, t="search", q=ctx.get("query") or "")
    if media == "movie" and imdb:
        params = dict(common, t="movie", imdbid=imdb)
    elif media in ("tv", "kdrama"):
        params = dict(common, t="tvsearch", q=ctx.get("title") or ctx.get("query") or "")
        if ctx.get("season"):
            params["season"] = int(ctx["season"])
            if ctx.get("episode") and not ctx.get("pack"):
                params["ep"] = int(ctx["episode"])
    elif media == "anime":
        params["cat"] = "5070"
    elif media == "music":
        params["cat"] = "3000"
    items = _nzb_fetch(base, params, ctx, source)
    if not items and params["t"] != "search":  # indexer can't do id / TV searches: plain text search instead
        items = _nzb_fetch(base, dict(common, t="search", q=ctx.get("query") or ""), ctx, source)
    return items


def torbox_usenet(host, api_key, ctx):
    """TorBox's own NZB search (needs a paid plan, and the search address must be reachable)."""
    host = host.strip().rstrip("/") or "https://search-api.torbox.app"
    params = {"check_cache": "true"}
    if ctx.get("imdb") and ctx.get("media") in ("movie", "tv", "kdrama"):
        u = "%s/usenet/imdb:%s" % (host, ctx["imdb"])
        if ctx.get("season"):
            params["season"] = ctx["season"]
            if ctx.get("episode") and not ctx.get("pack"):
                params["episode"] = ctx["episode"]
    else:
        u = "%s/usenet/search/%s" % (host, requests.utils.quote(ctx.get("query") or "", safe=""))
    r = requests.get(u, params=params, headers=dict(UA, Authorization="Bearer " + api_key), timeout=ctx["timeout"])
    r.raise_for_status()
    data = r.json().get("data") or {}
    out = []
    for n in data.get("nzbs") or []:
        if n.get("nzb"):
            out.append({"name": n.get("raw_title") or n.get("title") or "?", "nzb": n["nzb"], "hash": n["nzb"],
                        "size": int(n.get("size") or 0),
                        "grabs": 0, "age": None, "source": "TorBox", "mode": "link", "cached": bool(n.get("cached"))})
    return out


def usenet_search(get, api_key, ctx):
    """-> (results, report). Indexers run in parallel; obvious mismatches are dropped."""
    jobs = []
    for n in ("1", "2"):
        u, k = (get("nzb%s_url" % n) or "").strip(), (get("nzb%s_key" % n) or "").strip()
        if u and k:
            name = re.sub(r"^(https?://)?(api\.|www\.)?", "", u).split("/")[0] or "Indexer %s" % n
            jobs.append((name, lambda c, u=u, k=k, name=name: newznab(u, k, c, name)))
    if get("tb_usenet_search") == "true":
        host = get("tb_search_host") or ""
        jobs.append(("TorBox", lambda c, host=host: torbox_usenet(host, api_key, c)))
    if not jobs:
        return [], [("Usenet", None, "no indexer set up", 0)]
    res, report = run_all(jobs, dict(ctx, music=False))
    out, seen = [], set()
    for r in res:
        key = re.sub(r"\W+", "", r["name"].lower())
        if key in seen or (ctx.get("media") not in (None, "free") and not relevant(r["name"], ctx)):
            continue
        seen.add(key)
        out.append(r)
    return out, report
