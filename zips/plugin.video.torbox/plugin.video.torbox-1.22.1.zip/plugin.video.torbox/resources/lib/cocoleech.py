# -*- coding: utf-8 -*-
"""Cocoleech multi-hoster client. API: https://members.cocoleech.com/auth/api (key from members.cocoleech.com/settings)."""
import requests

API = "https://members.cocoleech.com/auth/api"


class CocoleechError(Exception):
    pass


def _get(path, params):
    import json
    try:
        r = requests.get(API + path, params=params, timeout=30, headers={"User-Agent": "Kodi-TorUtilityBox/1.9.0"})
    except requests.RequestException as e:
        raise CocoleechError("Cocoleech unreachable: %s" % e)
    try:
        body = r.json()
    except ValueError:
        try:
            body = json.loads((r.text or "").strip()[1:])  # Cocoleech sometimes puts a stray character before the JSON
        except ValueError:
            raise CocoleechError("bad response from Cocoleech (HTTP %s)" % r.status_code)
    if isinstance(body, dict):
        failed = str(body.get("status")) == "100" or (
            body.get("message") and not (body.get("download") or body.get("username") or body.get("result")))
        if failed:
            raise CocoleechError(body.get("message") or "Cocoleech refused the request")
    return body


def info(key):
    return _get("/info", {"key": key})


def generate(key, link):
    """Turn a file-host link (Rapidgator etc.) into a direct download URL."""
    d = _get("", {"key": key, "link": link}).get("download")
    if not d:
        raise CocoleechError("Cocoleech returned no download link")
    return d


def hosts():
    """[(host, online?)] for every file host Cocoleech supports (no key needed)."""
    d = _get("/hosts-status", {})
    out = []
    for h in d.get("result") or []:
        if h.get("host"):
            out.append((h["host"], (h.get("status") or "").lower() == "online"))
    return sorted(out)


def name_from_link(link):
    """Best-guess file name from a file-host URL (most put it at the end)."""
    from urllib.parse import unquote, urlparse
    parts = [p for p in urlparse(link).path.split("/") if p]
    for p in reversed(parts):
        p = unquote(p)
        if p.endswith(".html"):
            p = p[:-5]
        if "." in p and len(p) > 6:
            return p
    return parts[-1] if parts else link


def host_of(link):
    from urllib.parse import urlparse
    h = urlparse(link).netloc.lower()
    return h[4:] if h.startswith("www.") else h


# ---------------- log in with a code ----------------
V2 = "https://members.cocoleech.com/api/v2"


def device_start(name):
    r = requests.get(V2 + "/device/code", params={"device_name": name}, timeout=20)
    data = (r.json() or {}).get("data") or {}
    if not (data.get("pin") and data.get("check")):
        raise CocoleechError("Cocoleech didn't give a login code (HTTP %s)" % r.status_code)
    return data


def device_check(pin, check):
    """API key once the code has been approved on the website, else None."""
    r = requests.get(V2 + "/device/check", params={"pin": pin, "check": check}, timeout=20)
    try:
        j = r.json()
    except ValueError:
        return None
    if str(j.get("status")) == "200":
        data = j.get("data") or {}
        if data.get("activated") or data.get("api_key"):
            return data.get("api_key") or None
    return None
