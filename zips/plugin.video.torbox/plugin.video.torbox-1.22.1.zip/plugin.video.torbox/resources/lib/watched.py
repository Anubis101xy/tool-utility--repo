# -*- coding: utf-8 -*-
"""Watched / Just-watched store shared by the plugin and the background service.

Main copy:   <addon_data>/<addon id>/watched.json
Safety copy: <userdata>/tub_backup/<addon id>/watched.json  (outside the add-on's own folder)
If the main copy disappears or is damaged (some cleaners / builds wipe add-on data at start-up) it is put back
from the safety copy automatically, and the event is logged so "Check saved data" can show what happened.
Writes are locked so the background service and the add-on can't trip over each other."""
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

_EMPTY = (("watched", {}), ("recent", []), ("ctx", {}))
_tl = threading.local()


def _paths():
    a = xbmcaddon.Addon()
    aid = a.getAddonInfo("id")
    prof = xbmcvfs.translatePath(a.getAddonInfo("profile"))
    bdir = xbmcvfs.translatePath("special://profile/tub_backup/%s/" % aid)
    return {"id": aid, "prof": prof, "main": os.path.join(prof, "watched.json"), "bdir": bdir,
            "backup": os.path.join(bdir, "watched.json"), "events": os.path.join(bdir, "events.json")}


def _read(path):
    """-> (dict or None, problem)"""
    if not os.path.exists(path):
        return None, "missing"
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return None, "damaged (%s)" % e.__class__.__name__
    if not isinstance(d, dict):
        return None, "damaged"
    return d, None


def _write(path, d):
    folder = os.path.dirname(path)
    xbmcvfs.mkdirs(folder)
    if not os.path.isdir(folder):
        os.makedirs(folder)
    tmp = "%s.%d.%d.tmp" % (path, os.getpid(), threading.get_ident())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, path)


def _size(d):
    return len(d.get("watched") or {}) + len(d.get("recent") or [])


def _log_event(P, reason, restored):
    try:
        ev, _ = _read(P["events"])
        ev = ev if isinstance(ev, dict) else {}
        lst = ev.setdefault("events", [])
        try:
            present = sorted(os.listdir(P["prof"]))
        except Exception:
            present = None
        lst.insert(0, {"ts": int(time.time()), "reason": reason, "restored": restored, "folder": present})
        ev["events"] = lst[:20]
        _write(P["events"], ev)
    except Exception:
        pass
    try:
        import tublog
        tublog.warn("Watched list was %s - put back %d entries from the safety copy. Add-on folder then held: %s" % (
            reason, restored, ", ".join(present) if present else "nothing (whole folder wiped)"))
    except Exception:
        xbmc.log("[%s] watched list was %s - restored %d entries" % (P["id"], reason, restored), xbmc.LOGWARNING)


def load():
    P = _paths()
    d, problem = _read(P["main"])
    if d is None or (_size(d) == 0 and os.path.exists(P["backup"])):
        b, _ = _read(P["backup"])
        if b and _size(b) > 0:
            reason = problem or "emptied"
            d = b
            _log_event(P, reason, _size(b))  # first, so it records what the folder held before the repair
            try:
                _write(P["main"], b)
            except Exception:
                pass
    elif _size(d) > 0 and not os.path.exists(P["backup"]):
        try:
            _write(P["backup"], d)  # first run of this version: start the safety copy now
        except Exception:
            pass
    d = d if isinstance(d, dict) else {}
    for k, v in _EMPTY:
        if not isinstance(d.get(k), type(v)):
            d[k] = type(v)()
    return d


def save(d):
    P = _paths()
    for path in (P["main"], P["backup"]):
        try:
            _write(path, d)
        except Exception as e:
            xbmc.log("[%s] could not save %s: %s" % (P["id"], path, e), xbmc.LOGWARNING)


class _Lock(object):
    """Cross-process lock (plugin + service) using a lock file; re-entrant within a thread."""

    def __enter__(self):
        depth = getattr(_tl, "depth", 0)
        _tl.depth = depth + 1
        if depth:
            return self
        P = _paths()
        xbmcvfs.mkdirs(P["prof"])
        self.path = os.path.join(P["prof"], "watched.lock")
        self.fd = None
        end = time.time() + 3
        while time.time() < end:
            try:
                self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break
            except FileExistsError:
                try:
                    if time.time() - os.path.getmtime(self.path) > 15:  # left behind by a crash
                        os.remove(self.path)
                        continue
                except OSError:
                    pass
                time.sleep(0.05)
            except OSError:
                break  # can't lock on this file system: carry on without
        return self

    def __exit__(self, *a):
        _tl.depth -= 1
        if _tl.depth:
            return False
        if self.fd is not None:
            try:
                os.close(self.fd)
                os.remove(self.path)
            except OSError:
                pass
        return False


def mark_many(keys, on=True):
    with _Lock():
        d = load()
        now = int(time.time())
        for k in keys:
            if on:
                d["watched"][k] = now
            else:
                d["watched"].pop(k, None)
        save(d)


def mark(key, on=True):
    mark_many([key], on)


def count_prefix(d, prefix):
    return sum(1 for k in d["watched"] if k.startswith(prefix))


def remember(key, info):
    """Store how to describe/reopen a title, so a later play can be added to Just watched."""
    with _Lock():
        d = load()
        d["ctx"][key] = dict(info, ts=int(time.time()))
        if len(d["ctx"]) > 400:
            keep = sorted(d["ctx"].items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)[:300]
            d["ctx"] = dict(keep)
        save(d)


def add_recent(key):
    with _Lock():
        d = load()
        info = d["ctx"].get(key)
        if not info:
            return
        e = dict(info, ts=int(time.time()))
        d["recent"] = [r for r in d["recent"] if r.get("show") != e.get("show")]
        d["recent"].insert(0, e)
        d["recent"] = d["recent"][:60]
        save(d)


def recent(section=None):
    return [r for r in load()["recent"] if not section or r.get("section") == section]


def remove_recent(show):
    with _Lock():
        d = load()
        d["recent"] = [r for r in d["recent"] if r.get("show") != show]
        save(d)


def report():
    """Text for Tools > Check saved data."""
    P = _paths()
    d = load()
    lines = ["[B]Watched list[/B]: %d marked watched, %d in Just watched" % (len(d["watched"]), len(d["recent"])), "",
             "[B]Add-on data folder[/B]: %s" % P["prof"]]
    try:
        for n in sorted(os.listdir(P["prof"])):
            st = os.stat(os.path.join(P["prof"], n))
            lines.append("   %s  %s  (saved %s)" % (n, _hsize(st.st_size), time.strftime("%d %b %H:%M", time.localtime(st.st_mtime))))
    except Exception as e:
        lines.append("   can't read it: %s" % e)
    b, prob = _read(P["backup"])
    lines += ["", "[B]Safety copy[/B]: %s" % P["backup"],
              "   %s" % ("%d watched, %d Just watched" % (len(b.get("watched") or {}), len(b.get("recent") or []))
                         if b else prob)]
    ev, _ = _read(P["events"])
    evs = (ev or {}).get("events") or []
    lines += ["", "[B]Times the watched list had to be put back[/B]: %d" % len(evs)]
    for e in evs[:8]:
        folder = e.get("folder")
        lines.append("   %s - file was %s, put back %d entries. Folder then held: %s" % (
            time.strftime("%d %b %H:%M", time.localtime(e.get("ts", 0))), e.get("reason"), e.get("restored", 0),
            ", ".join(folder) if folder else "nothing (whole folder wiped)"))
    if evs:
        lines += ["", "Something outside this add-on is clearing its saved data when Kodi starts - usually a "
                      "'clean up / maintenance' tool in a Kodi build, or a cleaner app on the device. Your watched list "
                      "is protected by the safety copy either way."]
    return "\n".join(lines)


def _hsize(n):
    for u in ("B", "KB", "MB"):
        if n < 1024 or u == "MB":
            return ("%d %s" if u == "B" else "%.1f %s") % (n, u)
        n /= 1024.0
