# -*- coding: utf-8 -*-
"""Getting past Cloudflare's "checking your browser" page.

Kodi can't run the JavaScript test Cloudflare shows, so when a site blocks us we can hand the request to
FlareSolverr (a free helper that runs a real hidden browser on a PC / NAS / Raspberry Pi on your network).
The cookies it earns are remembered so later requests to that site can go direct while they last."""
import json
import os
import re
import threading
import time
from urllib.parse import urlencode, urlparse

import requests

CFG = {"url": "", "cache": None}
_lock = threading.Lock()
_slots = threading.Semaphore(3)  # don't open a dozen browsers at once on the helper box
COOKIE_LIFE = 50 * 60


class CFError(Exception):
    pass


def setup(fs_url, cache_path=None):
    CFG["url"] = (fs_url or "").strip()
    CFG["cache"] = cache_path


def enabled():
    return bool(CFG["url"])


def fs_endpoint():
    u = CFG["url"].rstrip("/")
    if not u.startswith("http"):
        u = "http://" + u
        if not re.search(r":\d+$", urlparse(u).netloc):
            u = u.replace(urlparse(u).netloc, urlparse(u).netloc + ":8191", 1)  # FlareSolverr's standard port
    return u if u.endswith("/v1") else u + "/v1"


def is_cf_block(r):
    if r.status_code not in (403, 429, 503):
        return False
    body = (r.text or "")[:4000].lower()
    server = (r.headers.get("server") or "").lower()
    return ("cloudflare" in server or "just a moment" in body or "cf-chl" in body or "attention required" in body
            or "cf-mitigated" in {k.lower() for k in r.headers})


class Resp(object):
    """Looks enough like a requests.Response for our scrapers."""

    def __init__(self, status, text, headers, url):
        self.status_code, self.text, self.headers, self.url = int(status or 200), text or "", headers or {}, url
        self.via_flaresolverr = True

    def json(self):
        t = self.text.strip()
        if t.startswith("<"):  # the browser shows JSON inside <pre>
            m = re.search(r"<pre[^>]*>(.*?)</pre>", t, re.S | re.I)
            t = m.group(1) if m else re.sub(r"<[^>]+>", "", t)
            import html as _h
            t = _h.unescape(t)
        return json.loads(t)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError("HTTP %s" % self.status_code)


def _load():
    if not CFG["cache"]:
        return {}
    try:
        with open(CFG["cache"]) as f:
            d = json.load(f)
        return {h: v for h, v in d.items() if time.time() - v.get("ts", 0) < COOKIE_LIFE}
    except Exception:
        return {}


def _save(d):
    if not CFG["cache"]:
        return
    try:
        with open(CFG["cache"], "w") as f:
            json.dump(d, f)
    except Exception:
        pass


def get(url, params=None, headers=None, timeout=15):
    """requests.get that falls back to FlareSolverr when Cloudflare blocks the request."""
    full = url + (("&" if "?" in url else "?") + urlencode(params) if params else "")
    host = urlparse(full).netloc.lower()
    h = dict(headers or {})
    with _lock:
        c = _load().get(host)
    if c:
        h["User-Agent"] = c["ua"]
    r = requests.get(url, params=params, headers=h, cookies=(c or {}).get("cookies"), timeout=timeout)
    if not is_cf_block(r) or not enabled():
        return r
    return solve(full, timeout)


def solve(full, timeout=15):
    host = urlparse(full).netloc.lower()
    body = {"cmd": "request.get", "url": full, "maxTimeout": max(60000, int(timeout) * 1000)}
    with _slots:
        try:
            r = requests.post(fs_endpoint(), json=body, timeout=max(75, int(timeout) + 15))
        except requests.RequestException as e:
            raise CFError("FlareSolverr isn't answering at %s (%s)" % (CFG["url"], e.__class__.__name__))
    try:
        d = r.json()
    except ValueError:
        raise CFError("the FlareSolverr address doesn't look like FlareSolverr (HTTP %s)" % r.status_code)
    if d.get("status") != "ok":
        raise CFError("FlareSolverr couldn't get past Cloudflare: %s" % (d.get("message") or "unknown error")[:120])
    sol = d.get("solution") or {}
    cookies = {c["name"]: c["value"] for c in sol.get("cookies") or [] if c.get("name")}
    if cookies and sol.get("userAgent"):
        with _lock:
            cache = _load()
            cache[host] = {"cookies": cookies, "ua": sol["userAgent"], "ts": time.time()}
            _save(cache)
    return Resp(sol.get("status"), sol.get("response"), sol.get("headers"), sol.get("url") or full)


def check():
    """(ok, message) for the settings test."""
    if not enabled():
        return False, "not set up"
    try:
        r = requests.get(fs_endpoint()[:-3], timeout=8)
        d = r.json()
    except Exception as e:
        return False, "not answering at %s (%s)" % (CFG["url"], e.__class__.__name__)
    if "flaresolverr" in json.dumps(d).lower():
        return True, "ready (version %s)" % d.get("version", "?")
    return False, "something answered at %s but it isn't FlareSolverr" % CFG["url"]


def default_cache(profile_dir):
    return os.path.join(profile_dir, "cf_cookies.json")
