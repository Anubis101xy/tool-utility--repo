# -*- coding: utf-8 -*-
"""Browse/discovery sources: Cinemeta (movies/TV, no key), Kitsu (anime, no key), TMDB (K-dramas, free key)."""
import datetime
import re
import time
from urllib.parse import quote

import requests

UA = {"User-Agent": "Mozilla/5.0 (Kodi-TorBox)"}
CINEMETA = "https://v3-cinemeta.strem.io"
KITSU = "https://kitsu.io/api/edge"
TMDB = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/w500"
BACK = "https://image.tmdb.org/t/p/w1280"
GENRES = ["Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Family",
          "Fantasy", "History", "Horror", "Mystery", "Romance", "Sci-Fi", "Sport", "Thriller", "War", "Western"]


def _get(url, params=None, headers=None):
    h = dict(UA)
    h.update(headers or {})
    r = requests.get(url, params=params, headers=h, timeout=15)
    r.raise_for_status()
    return r.json()


# ---------------- Cinemeta (movies / TV) ----------------
# TV-only genres: (shown as, Cinemeta genre or None, TMDB genre id or None)
TV_GENRES = [("Reality", "Reality-TV", 10764), ("Dating shows", None, None), ("Game shows", "Game-Show", None)]
DATING_RX = re.compile(r"(?i)\b(?:love|dating|dates?|bachelor(?:ette)?|married|marry|marriage|singles?|single's|island|"
                       r"perfect match|fianc[e\u00e9]e?|90 day|temptation|ex on the beach|too hot|kiss|flirt|couples?|"
                       r"bride|naked attraction|catfish|paradise|villa|honeymoon|blind date|matchmak\w*)\b")


def tmdb_dating_keywords(key):
    """TMDB keyword ids for dating shows (looked up by name, so nothing to go out of date)."""
    ids = set()
    for w in ("dating show", "dating", "dating competition", "reality dating"):
        for k in _tmdb(key, "/search/keyword", query=w).get("results", [])[:20]:
            if "dating" in (k.get("name") or "").lower():
                ids.add(str(k["id"]))
    return sorted(ids)


def tmdb_tv_discover(key, page=1, genre=None, keywords=None):
    params = {"sort_by": "popularity.desc", "page": page}
    if genre:
        params["with_genres"] = genre
    if keywords:
        params["with_keywords"] = "|".join(keywords)
    return _tmdb_shows(_tmdb(key, "/discover/tv", **params))


def cinemeta_catalog(kind, genre=None, skip=0, search=None):
    if search:
        path = "/catalog/%s/top/search=%s.json" % (kind, quote(search, safe=""))
        return _cinemeta_items(_get(CINEMETA + path).get("metas", []))
    extra = []
    if genre:
        extra.append("genre=" + quote(genre))
    if skip:
        extra.append("skip=%d" % skip)
    path = "/catalog/%s/top%s.json" % (kind, ("/" + "&".join(extra)) if extra else "")
    return _cinemeta_items(_get(CINEMETA + path).get("metas", []))


def _cinemeta_items(metas):
    out = []
    for m in metas:
        imdb = m.get("imdb_id") or m.get("id") or ""
        if not str(imdb).startswith("tt"):
            continue
        out.append({"imdb": imdb, "name": m.get("name", "?"),
                    "year": str(m.get("releaseInfo") or m.get("year") or "")[:4],
                    "released": (m.get("released") or "")[:10],
                    "country": (str(m.get("country") or "").split(",")[0]).strip(),
                    "poster": m.get("poster"), "fanart": m.get("background"), "plot": m.get("description") or ""})
    return out


def cinemeta_episodes(imdb):
    meta = _get("%s/meta/series/%s.json" % (CINEMETA, imdb)).get("meta", {})
    eps = []
    for v in meta.get("videos", []):
        s, e = v.get("season"), v.get("episode") or v.get("number")
        if s is None or e is None:
            continue
        eps.append({"season": int(s), "episode": int(e), "title": v.get("name") or v.get("title") or "",
                    "plot": v.get("overview") or v.get("description") or "", "thumb": v.get("thumbnail"),
                    "aired": (v.get("released") or "")[:10]})
    return eps, meta


# ---------------- Kitsu (anime) ----------------
def _kitsu(data):
    out = []
    for d in data.get("data", []):
        a = d.get("attributes", {})
        t = a.get("titles") or {}
        title = t.get("en") or a.get("canonicalTitle") or t.get("en_jp") or "?"
        alt = t.get("en_jp") or a.get("canonicalTitle") or ""
        keys = set(t)
        origin = "Japan" if keys & {"ja_jp", "en_jp"} else "China" if keys & {"zh_cn", "en_cn"} else \
            "South Korea" if keys & {"ko_kr", "en_kr"} else ""
        out.append({"id": d["id"], "title": title, "alt": alt if alt != title else "",
                    "year": (a.get("startDate") or "")[:4], "released": a.get("startDate") or "", "country": origin, "poster": (a.get("posterImage") or {}).get("large"),
                    "fanart": (a.get("coverImage") or {}).get("large"), "plot": a.get("synopsis") or "",
                    "episodes": a.get("episodeCount"), "subtype": a.get("subtype") or ""})
    return out


_KH = {"Accept": "application/vnd.api+json"}


def kitsu_search(q, offset=0):
    return _kitsu(_get(KITSU + "/anime", {"filter[text]": q, "page[limit]": 20, "page[offset]": offset}, _KH))


def kitsu_trending():
    return _kitsu(_get(KITSU + "/trending/anime", {"limit": 20}, _KH))


def kitsu_popular(offset=0):
    return _kitsu(_get(KITSU + "/anime", {"sort": "-userCount", "page[limit]": 20, "page[offset]": offset}, _KH))


# ---------------- TMDB (K-dramas) ----------------
def _tmdb(key, path, **params):
    params["api_key"] = key
    return _get(TMDB + path, params)


def _tmdb_shows(data):
    return [{"id": s["id"], "title": s.get("name") or s.get("original_name") or "?",
             "year": (s.get("first_air_date") or "")[:4], "plot": s.get("overview") or "",
             "released": s.get("first_air_date") or "", "country": ",".join(s.get("origin_country") or []),
             "poster": (IMG + s["poster_path"]) if s.get("poster_path") else None,
             "fanart": (BACK + s["backdrop_path"]) if s.get("backdrop_path") else None}
            for s in data.get("results", [])]


def kdrama_list(key, mode, page=1, query=None):
    base = dict(with_original_language="ko", without_genres="10767,10764,10763", page=page)
    if mode == "search":
        d = _tmdb(key, "/search/tv", query=query, page=page)
        d["results"] = [s for s in d.get("results", []) if s.get("original_language") == "ko"]
    elif mode == "top":
        d = _tmdb(key, "/discover/tv", sort_by="vote_average.desc", **dict(base, **{"vote_count.gte": 150}))
    elif mode == "airing":
        today = datetime.date.today()
        d = _tmdb(key, "/discover/tv", sort_by="popularity.desc",
                  **dict(base, **{"air_date.gte": (today - datetime.timedelta(days=30)).isoformat(),
                                  "air_date.lte": today.isoformat()}))
    else:
        d = _tmdb(key, "/discover/tv", sort_by="popularity.desc", **base)
    return _tmdb_shows(d)


def tmdb_show(key, tv_id):
    d = _tmdb(key, "/tv/%s" % tv_id, append_to_response="external_ids")
    seasons = [{"season": s["season_number"], "name": s.get("name") or "Season %s" % s["season_number"],
                "count": s.get("episode_count") or 0, "plot": s.get("overview") or "",
                "poster": (IMG + s["poster_path"]) if s.get("poster_path") else None}
               for s in d.get("seasons", []) if s.get("season_number")]
    return {"title": d.get("name") or "?", "year": (d.get("first_air_date") or "")[:4],
            "imdb": (d.get("external_ids") or {}).get("imdb_id") or "", "seasons": seasons}


def tmdb_episodes(key, tv_id, season):
    d = _tmdb(key, "/tv/%s/season/%s" % (tv_id, season))
    return [{"episode": e["episode_number"], "title": e.get("name") or "", "plot": e.get("overview") or "",
             "thumb": (IMG + e["still_path"]) if e.get("still_path") else None, "aired": e.get("air_date") or ""}
            for e in d.get("episodes", [])]


def tmdb_check(key):
    """Raises if the key is rejected."""
    _tmdb(key, "/configuration")


# ---------------- what's been on: TVmaze schedules (no key) ----------------
TVMAZE = "https://api.tvmaze.com"
SKIP_TYPES = {"News", "Talk Show", "Sports", "Game Show", "Variety", "Panel Show", "Award Show"}


def _strip_html(s):
    import re
    return re.sub(r"<[^>]+>", "", s or "").strip()


def tvmaze_aired(country, days=7, korean=False):
    """Episodes aired in the last `days` days. korean=True -> Korean dramas only."""
    from concurrent.futures import ThreadPoolExecutor
    now = datetime.datetime.now(datetime.timezone.utc)
    dates = [(now - datetime.timedelta(days=i)).date().isoformat() for i in range(days)]
    if korean:
        jobs = [("%s/schedule" % TVMAZE, {"country": "KR", "date": d}) for d in dates]
    else:
        jobs = [("%s/schedule" % TVMAZE, {"country": country, "date": d}) for d in dates]
    jobs += [("%s/schedule/web" % TVMAZE, {"date": d}) for d in dates]

    def one(job):
        try:
            return _get(job[0], job[1])
        except Exception:
            return []
    with ThreadPoolExecutor(max_workers=6) as ex:
        batches = list(ex.map(one, jobs))
    out, seen = [], set()
    for ep in (e for b in batches for e in b):
        show = ep.get("show") or (ep.get("_embedded") or {}).get("show") or {}
        if not show or ep.get("season") is None or ep.get("number") is None:
            continue
        stamp = ep.get("airstamp") or ""
        try:
            if datetime.datetime.fromisoformat(stamp.replace("Z", "+00:00")) > now:
                continue  # not shown yet
        except ValueError:
            pass
        lang = show.get("language") or ""
        if korean:
            if lang != "Korean" or show.get("type") not in ("Scripted", None):
                continue
        else:
            if show.get("type") in SKIP_TYPES:
                continue
            if ep.get("_embedded"):  # streaming release: keep English-language ones for your country
                wc = ((show.get("webChannel") or {}).get("country") or {}).get("code")
                if wc != country and (lang != "English" or wc):
                    continue
        imdb = (show.get("externals") or {}).get("imdb")
        if not korean and not imdb:
            continue  # needed for the main scrapers
        key = (show.get("id"), ep["season"], ep["number"])
        if key in seen:
            continue
        seen.add(key)
        img = show.get("image") or {}
        chan = (show.get("network") or {}).get("name") or (show.get("webChannel") or {}).get("name") or ""
        out.append({"show": show.get("name") or "?", "imdb": imdb or "", "tvm": show.get("id"),
                    "year": (show.get("premiered") or "")[:4],
                    "season": int(ep["season"]), "episode": int(ep["number"]), "title": ep.get("name") or "",
                    "plot": _strip_html(ep.get("summary") or show.get("summary")), "airdate": ep.get("airdate") or "",
                    "stamp": stamp, "channel": chan, "poster": img.get("original") or img.get("medium")})
    out.sort(key=lambda e: e["stamp"], reverse=True)
    return out[:200]


# ---------------- anime airing: AniList (no key) ----------------
ANILIST = "https://graphql.anilist.co"
_MEDIA = ("id idMal isAdult episodes format title{romaji english} coverImage{large} bannerImage nextAiringEpisode{episode} "
          "seasonYear startDate{year month day} countryOfOrigin")


def _anilist(query, variables):
    r = requests.post(ANILIST, json={"query": query, "variables": variables},
                      headers=dict(UA, Accept="application/json"), timeout=15)
    r.raise_for_status()
    return r.json().get("data") or {}


def _al_media(m):
    t = m.get("title") or {}
    nxt = (m.get("nextAiringEpisode") or {}).get("episode")
    sd = m.get("startDate") or {}
    rel = "%04d-%02d-%02d" % (sd["year"], sd.get("month") or 1, sd.get("day") or 1) if sd.get("year") and sd.get("month") \
        and sd.get("day") else ""
    return {"anilist": m["id"], "mal": m.get("idMal"), "title": t.get("english") or t.get("romaji") or "?",
            "released": rel, "country": m.get("countryOfOrigin") or "",
            "alt": t.get("romaji") if t.get("english") and t.get("romaji") != t.get("english") else "",
            "poster": (m.get("coverImage") or {}).get("large"), "fanart": m.get("bannerImage"),
            "year": str(m.get("seasonYear") or ""), "movie": m.get("format") == "MOVIE",
            "eps": m.get("episodes") or ((nxt - 1) if nxt else 0)}


def anilist_aired(days=7):
    now = int(time.time())
    q = ("query($from:Int,$to:Int,$page:Int){Page(page:$page,perPage:50){pageInfo{hasNextPage}"
         "airingSchedules(airingAt_greater:$from,airingAt_lesser:$to,sort:TIME_DESC){episode airingAt media{%s}}}}" % _MEDIA)
    out = []
    for page in (1, 2, 3, 4):
        data = _anilist(q, {"from": now - days * 86400, "to": now, "page": page}).get("Page") or {}
        for s in data.get("airingSchedules") or []:
            m = s.get("media") or {}
            if not m or m.get("isAdult"):
                continue
            out.append(dict(_al_media(m), episode=s["episode"], aired=s["airingAt"]))
        if not (data.get("pageInfo") or {}).get("hasNextPage"):
            break
    return out


def anilist_season():
    today = datetime.date.today()
    season = ["WINTER", "WINTER", "WINTER", "SPRING", "SPRING", "SPRING", "SUMMER", "SUMMER", "SUMMER",
              "FALL", "FALL", "FALL"][today.month - 1]
    q = ("query($s:MediaSeason,$y:Int){Page(perPage:50){media(season:$s,seasonYear:$y,type:ANIME,isAdult:false,"
         "sort:POPULARITY_DESC){%s}}}" % _MEDIA)
    return [_al_media(m) for m in (_anilist(q, {"s": season, "y": today.year}).get("Page") or {}).get("media") or []]


def kitsu_from_anilist(anilist_id, mal_id=None):
    """Find the Kitsu id (used by Torrentio for anime) for an AniList/MAL id."""
    for site, ext in (("anilist/anime", anilist_id), ("myanimelist/anime", mal_id)):
        if not ext:
            continue
        try:
            d = _get(KITSU + "/mappings", {"filter[externalSite]": site, "filter[externalId]": ext, "include": "item"}, _KH)
        except Exception:
            continue
        for inc in d.get("included") or []:
            if inc.get("type") == "anime":
                return inc["id"]
    return None


# ---------------- popular on streaming services: TMDB (needs the free key) ----------------
SERVICES = [("Netflix", ["netflix"]), ("Amazon Prime Video", ["amazon prime video"]),
            ("Disney+", ["disney plus", "disney+"]), ("Apple TV+", ["apple tv plus", "apple tv+", "apple tv"]),
            ("NOW", ["now tv", "now"]), ("Paramount+", ["paramount plus", "paramount+"]),
            ("BBC iPlayer", ["bbc iplayer"]), ("ITVX", ["itvx"]), ("Channel 4", ["channel 4", "channel4"]),
            ("Sky Go", ["sky go"]), ("Hulu", ["hulu"]), ("Max", ["max", "hbo max"]), ("Peacock", ["peacock premium", "peacock"])]
LOGO = "https://image.tmdb.org/t/p/w300"


def streaming_services(key, region):
    provs = _tmdb(key, "/watch/providers/movie", watch_region=region).get("results", [])
    by_name = {}
    for pv in provs:
        by_name.setdefault((pv.get("provider_name") or "").strip().lower(), pv)
    out = []
    for label, names in SERVICES:
        for n in names:
            pv = by_name.get(n)
            if pv:
                out.append({"name": label, "id": pv["provider_id"],
                            "logo": (LOGO + pv["logo_path"]) if pv.get("logo_path") else None})
                break
    return out


def streaming_movies(key, region, provider, page=1):
    d = _tmdb(key, "/discover/movie", watch_region=region, with_watch_providers=provider,
              with_watch_monetization_types="flatrate", sort_by="popularity.desc", page=page)
    return [{"tmdb": m["id"], "title": m.get("title") or "?", "year": (m.get("release_date") or "")[:4],
             "released": m.get("release_date") or "", "country": "",
             "plot": m.get("overview") or "", "poster": (IMG + m["poster_path"]) if m.get("poster_path") else None,
             "fanart": (BACK + m["backdrop_path"]) if m.get("backdrop_path") else None}
            for m in d.get("results", [])]


def tmdb_movie_imdb(key, tmdb_id):
    return _tmdb(key, "/movie/%s/external_ids" % tmdb_id).get("imdb_id")


# ---------------- fallbacks when AniList refuses (it has started blocking anonymous apps with HTTP 403) ----------
JIKAN = "https://api.jikan.moe/v4"  # MyAnimeList data, no key
_DAYS = {"mondays": 0, "tuesdays": 1, "wednesdays": 2, "thursdays": 3, "fridays": 4, "saturdays": 5, "sundays": 6}
_JST = datetime.timezone(datetime.timedelta(hours=9))


def _jikan(path, params):
    for attempt in range(3):
        r = requests.get(JIKAN + path, params=params, headers=UA, timeout=15)
        if r.status_code == 429:  # Jikan allows ~3 requests a second
            time.sleep(1.2 * (attempt + 1))
            continue
        r.raise_for_status()
        return r.json()
    r.raise_for_status()


def jikan_aired(days=7):
    """Shows that had a new episode in the last `days` days, newest first, from MyAnimeList's broadcast schedule.
    The episode number is an estimate (weeks since it started), so these open the show's episode list."""
    now = datetime.datetime.now(datetime.timezone.utc).astimezone(_JST)
    out, seen = [], set()
    for page in range(1, 16):
        if page > 1:
            time.sleep(0.4)
        data = _jikan("/schedules", {"sfw": "true", "page": page, "limit": 25})
        for a in data.get("data") or []:
            b = a.get("broadcast") or {}
            day = _DAYS.get((b.get("day") or "").lower())
            if day is None or a.get("mal_id") in seen or (a.get("type") or "TV") not in ("TV", "ONA"):
                continue
            hh, mm = 0, 0
            m = re.match(r"(\d\d?):(\d\d)", b.get("time") or "")
            if m:
                hh, mm = int(m.group(1)), int(m.group(2))
            last = (now - datetime.timedelta(days=(now.weekday() - day) % 7)).replace(hour=hh, minute=mm, second=0,
                                                                                     microsecond=0)
            if last > now:
                last -= datetime.timedelta(days=7)
            start = ((a.get("aired") or {}).get("from") or "")[:10]
            try:
                sd = datetime.date.fromisoformat(start) if start else None
            except ValueError:
                sd = None
            if sd and sd > last.date():
                continue  # hasn't started yet
            if (now - last).total_seconds() > days * 86400:
                continue
            seen.add(a.get("mal_id"))
            est = ((last.date() - sd).days // 7 + 1) if sd else None
            if est and (est > 30 or (a.get("episodes") and est > a["episodes"])):
                est = None  # long-runners take breaks, so a week count would be wrong
            title = a.get("title_english") or a.get("title") or "?"
            img = ((a.get("images") or {}).get("jpg") or {})
            out.append({"mal": a.get("mal_id"), "anilist": None, "title": title,
                        "alt": a.get("title") if a.get("title") and a.get("title") != title else "",
                        "poster": img.get("large_image_url") or img.get("image_url"), "fanart": None,
                        "year": str(a.get("year") or start[:4]), "movie": False, "eps": a.get("episodes") or 0,
                        "aired": int(last.timestamp()), "episode": None, "estimate": est})
        if not (data.get("pagination") or {}).get("has_next_page"):
            break
    out.sort(key=lambda x: -x["aired"])
    return out


def kitsu_season():
    """This season's anime from Kitsu, most popular first."""
    today = datetime.date.today()
    season = ["winter", "winter", "spring", "spring", "spring", "summer", "summer", "summer", "fall", "fall", "fall",
              "winter"][today.month - 1]
    year = today.year + 1 if today.month == 12 else today.year
    out = []
    for off in (0, 20):
        out += _kitsu(_get(KITSU + "/anime", {"filter[season]": season, "filter[seasonYear]": year, "sort": "-userCount",
                                              "page[limit]": 20, "page[offset]": off}, _KH))
    return out


# ---------------- anime episode names + what the show is about (Kitsu, then MyAnimeList for gaps) ----------------
def kitsu_show(kid):
    a = (_get(KITSU + "/anime/%s" % kid, {"include": "mappings"}, _KH) or {})
    data = a.get("data") or {}
    at = data.get("attributes") or {}
    mal = None
    for inc in a.get("included") or []:
        ia = inc.get("attributes") or {}
        if inc.get("type") == "mappings" and ia.get("externalSite") == "myanimelist/anime":
            mal = ia.get("externalId")
    t = at.get("titles") or {}
    return {"title": t.get("en") or at.get("canonicalTitle") or "", "jp": t.get("en_jp") or t.get("ja_jp") or "",
            "plot": at.get("synopsis") or at.get("description") or "", "eps": at.get("episodeCount") or 0,
            "year": (at.get("startDate") or "")[:4], "status": at.get("status") or "",
            "rating": at.get("averageRating") or "", "age": at.get("ageRatingGuide") or "",
            "type": at.get("subtype") or "", "length": at.get("episodeLength") or 0,
            "poster": (at.get("posterImage") or {}).get("large"), "fanart": (at.get("coverImage") or {}).get("large"),
            "mal": mal}


def kitsu_episodes(kid, max_eps=300):
    """{number: {"title", "plot", "aired", "thumb"}} - pages fetched side by side (Kitsu gives 20 a page)."""
    from concurrent.futures import ThreadPoolExecutor

    def page(off):
        try:
            return _get(KITSU + "/anime/%s/episodes" % kid, {"page[limit]": 20, "page[offset]": off, "sort": "number"},
                        _KH)
        except Exception:
            return {}
    first = page(0)
    count = int(((first.get("meta") or {}).get("count")) or 0)
    pages = [first]
    offs = list(range(20, min(count, max_eps), 20))
    if offs:
        with ThreadPoolExecutor(max_workers=8) as ex:
            pages += list(ex.map(page, offs))
    out = {}
    for pg in pages:
        for e in pg.get("data") or []:
            a = e.get("attributes") or {}
            n = a.get("number")
            if not n:
                continue
            t = a.get("titles") or {}
            title = a.get("canonicalTitle") or t.get("en_us") or t.get("en") or t.get("en_jp") or ""
            if re.match(r"^\s*(episode|ep\.?)\s*\d+\s*$", title, re.I):
                title = ""  # "Episode 5" isn't a name
            out[int(n)] = {"title": title, "plot": a.get("description") or a.get("synopsis") or "",
                           "aired": a.get("airdate") or "", "thumb": (a.get("thumbnail") or {}).get("original")}
    return out


def jikan_episodes(mal, max_pages=4):
    """{number: {"title", "aired", "filler", "recap"}} from MyAnimeList (100 a page)."""
    out = {}
    for pg in range(1, max_pages + 1):
        if pg > 1:
            time.sleep(0.4)
        try:
            d = _jikan("/anime/%s/episodes" % mal, {"page": pg})
        except Exception:
            break
        for e in d.get("data") or []:
            n = e.get("mal_id")
            if n:
                out[int(n)] = {"title": e.get("title") or "", "aired": (e.get("aired") or "")[:10],
                               "filler": bool(e.get("filler")), "recap": bool(e.get("recap"))}
        if not (d.get("pagination") or {}).get("has_next_page"):
            break
    return out


def anime_episode_info(kid):
    """Show details + episode names, filling missing names from MyAnimeList."""
    show = kitsu_show(kid)
    eps = kitsu_episodes(kid)
    named = sum(1 for e in eps.values() if e["title"])
    if show.get("mal") and (not eps or named < len(eps) * 0.7):
        try:
            mal = jikan_episodes(show["mal"])
        except Exception:
            mal = {}
        for n, m in mal.items():
            e = eps.setdefault(n, {"title": "", "plot": "", "aired": m["aired"], "thumb": None})
            if not e["title"] and m["title"]:
                e["title"] = m["title"]
            e["filler"], e["recap"] = m.get("filler"), m.get("recap")
    else:
        for e in eps.values():
            e.setdefault("filler", False)
    return {"show": show, "eps": {str(k): v for k, v in eps.items()}}
