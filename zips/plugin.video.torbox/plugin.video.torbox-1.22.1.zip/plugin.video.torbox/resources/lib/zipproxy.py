# -*- coding: utf-8 -*-
"""Tiny local web server (run by the background service) that serves one file from inside a remote zip as a
normal seekable video, so Kodi can stream an episode straight out of a zipped pack."""
import threading
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import requests

TYPES = {".mkv": "video/x-matroska", ".mp4": "video/mp4", ".m4v": "video/mp4", ".avi": "video/x-msvideo",
         ".ts": "video/mp2t", ".webm": "video/webm", ".mov": "video/quicktime", ".mp3": "audio/mpeg",
         ".flac": "audio/flac", ".m4a": "audio/mp4"}


def port_for(addon_id):
    return 47000 + zlib.crc32(addon_id.encode()) % 900


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _params(self):
        q = parse_qs(urlparse(self.path).query)
        return q["u"][0], int(q["o"][0]), int(q["n"][0]), q.get("name", ["file.mkv"])[0]

    def _range(self, size):
        rng = self.headers.get("Range")
        if not rng or not rng.startswith("bytes="):
            return 0, size - 1, False
        a, _, b = rng[6:].split(",")[0].partition("-")
        if a == "":
            start = max(0, size - int(b))
            return start, size - 1, True
        start = int(a)
        end = min(int(b), size - 1) if b else size - 1
        return start, end, True

    def _head(self, code, start, end, size, name):
        ext = name[name.rfind("."):].lower() if "." in name else ""
        self.send_response(code)
        self.send_header("Content-Type", TYPES.get(ext, "application/octet-stream"))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()

    def do_HEAD(self):
        try:
            u, off, size, name = self._params()
        except Exception:
            return self.send_error(400)
        start, end, partial = self._range(size)
        self._head(206 if partial else 200, start, end, size, name)

    def do_GET(self):
        try:
            u, off, size, name = self._params()
        except Exception:
            return self.send_error(400)
        start, end, partial = self._range(size)
        if start >= size:
            return self.send_error(416)
        try:
            up = requests.get(u, headers={"Range": "bytes=%d-%d" % (off + start, off + end),
                                          "User-Agent": "Mozilla/5.0 (Kodi-TorUtilityBox)"}, stream=True, timeout=30)
            up.raise_for_status()
        except Exception:
            return self.send_error(502)
        self._head(206 if partial else 200, start, end, size, name)
        try:
            for chunk in up.iter_content(256 * 1024):
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            up.close()


def start(addon_id):
    srv = ThreadingHTTPServer(("127.0.0.1", port_for(addon_id)), Handler)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever)
    t.daemon = True
    t.start()
    return srv
