# -*- coding: utf-8 -*-
"""Skip intro / recap / credits timings (all free, no key needed).

Anime:        AniSkip (aniskip.com), looked up by MyAnimeList id + episode (Kitsu id -> MAL id via Kitsu's mappings)
TV & movies:  TheIntroDB (theintrodb.org), then IntroDB (introdb.app) to fill any gaps, by IMDb id (+ season/episode)

segments(wk, total, profile) -> [{"type": "intro"|"recap"|"credits", "start": s, "end": s or None}] in seconds."""
import json
import os
import time

import requests

UA = {"User-Agent": "Kodi-TorUtilityBox", "Accept": "application/json"}
ANISKIP = "https://api.aniskip.com/v2/skip-times/%s/%s"
THEINTRODB = "https://api.theintrodb.org/v3/media"
INTRODB = "https://api.introdb.app/segments"
KITSU = "https://kitsu.io/api/edge"
FOUND_TTL, MISS_TTL = 3 * 86400, 12 * 3600
LOG = [None]  # set to a function(msg) to log


def _log(msg):
    if LOG[0]:
        try:
            LOG[0](msg)
        except Exception:
            pass


def _get(url, params=None, timeout=7):
    r = requests.get(url, params=params, headers=UA, timeout=timeout)
    if r.status_code == 404:
        return None
    if r.status_code == 429:
        raise RuntimeError("busy (HTTP 429)")
    if r.status_code >= 400:
        raise RuntimeError("HTTP %d" % r.status_code)
    return r.json()


# ---------------- the cache (one small file) ----------------
def _cache_path(profile):
    return os.path.join(profile, "skip_cache.json")


def _cache_load(profile):
    try:
        with open(_cache_path(profile)) as f:
            return json.load(f)
    except Exception:
        return {}


def _cache_save(profile, data):
    try:
        now = time.time()
        data = {k: v for k, v in data.items() if now - v[0] < (FOUND_TTL if v[1] else MISS_TTL) or k.startswith("kmal:")}
        if len(data) > 800:
            data = dict(sorted(data.items(), key=lambda kv: kv[1][0], reverse=True)[:800])
        os.makedirs(profile, exist_ok=True)
        tmp = _cache_path(profile) + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, _cache_path(profile))
    except Exception:
        pass


# ---------------- sources ----------------
def kitsu_to_mal(kid, cache):
    k = "kmal:%s" % kid
    if k in cache:
        return cache[k][1]
    d = _get("%s/anime/%s/mappings" % (KITSU, kid), {"page[limit]": 20},) or {}
    mal = None
    for m in d.get("data") or []:
        at = m.get("attributes") or {}
        if at.get("externalSite") == "myanimelist/anime" and str(at.get("externalId") or "").isdigit():
            mal = int(at["externalId"])
            break
    cache[k] = [time.time(), mal]
    return mal


_ANI_TYPES = {"op": "intro", "mixed-op": "intro", "ed": "credits", "mixed-ed": "credits", "recap": "recap"}


def aniskip(mal, ep, total=0):
    params = [("types", t) for t in ("op", "ed", "recap", "mixed-op", "mixed-ed")] + [("episodeLength", 0)]
    d = _get(ANISKIP % (mal, ep), params) or {}
    if not d.get("found"):
        return []
    best = {}
    for r in d.get("results") or []:
        typ = _ANI_TYPES.get(r.get("skipType"))
        iv = r.get("interval") or {}
        if not typ or iv.get("startTime") is None or iv.get("endTime") is None:
            continue
        length = float(r.get("episodeLength") or 0)
        # prefer timings from a release the same length as yours, then the dedicated (not 'mixed') kind
        score = (-(abs(length - total)) if (total and length) else -9999, not str(r.get("skipType")).startswith("mixed"))
        if typ not in best or score > best[typ][0]:
            best[typ] = (score, {"type": typ, "start": float(iv["startTime"]), "end": float(iv["endTime"])})
    return [v[1] for v in best.values()]


def theintrodb(imdb, season=None, ep=None, total=0):
    params = {"imdb_id": imdb}
    if season is not None:
        params.update(season=int(season), episode=int(ep))
    if total:
        params["duration_ms"] = int(total * 1000)
    d = _get(THEINTRODB, params) or {}
    if not isinstance(d, dict) or d.get("error"):
        return []
    out = []
    for typ in ("intro", "recap", "credits"):
        best, score = None, -1.0
        for s in d.get(typ) or []:
            if not isinstance(s, dict):
                continue
            a, b = s.get("start_ms"), s.get("end_ms")
            if typ in ("intro", "recap"):
                if b is None:
                    continue
                a = a or 0
            elif a is None:
                continue
            if b is not None and b <= a:
                continue
            sc = float(s.get("confidence") if s.get("confidence") is not None else 0.5) + (s.get("submission_count") or 1) * 0.001
            if sc > score:
                score, best = sc, {"type": typ, "start": a / 1000.0, "end": (b / 1000.0) if b is not None else None}
        if best:
            out.append(best)
    return out


def introdb(imdb, season=None, ep=None):
    params = {"imdb_id": imdb}
    if season is not None:
        params.update(season=int(season), episode=int(ep))
    else:
        params["is_movie"] = "true"
    d = _get(INTRODB, params) or {}
    out = []
    for key, typ in (("intro", "intro"), ("recap", "recap"), ("outro", "credits")):
        s = d.get(key) if isinstance(d, dict) else None
        if not isinstance(s, dict):
            continue
        a = s.get("start_ms") if s.get("start_ms") is not None else (s.get("start_sec") * 1000 if s.get("start_sec") is not None else None)
        b = s.get("end_ms") if s.get("end_ms") is not None else (s.get("end_sec") * 1000 if s.get("end_sec") is not None else None)
        if typ != "credits" and b is None:
            continue
        if typ == "credits" and a is None:
            continue
        a = a or 0
        if b is not None and b <= a:
            continue
        out.append({"type": typ, "start": a / 1000.0, "end": (b / 1000.0) if b is not None else None})
    return out


# ---------------- what's playing -> timings ----------------
def parse_wk(wk):
    """'an:48671:10' / 'tv:tt0903747:2:5' / 'kdrama:tt123:1:3' / 'mv:tt0111161' -> dict, or None."""
    p = (wk or "").split(":")
    try:
        if p[0] == "an" and len(p) == 3:
            return {"kind": "anime", "kitsu": p[1], "ep": int(p[2])}
        if p[0] in ("tv", "kdrama") and len(p) == 4 and p[1].startswith("tt"):
            return {"kind": "tv", "imdb": p[1], "season": int(p[2]), "ep": int(p[3])}
        if p[0] == "mv" and len(p) == 2 and p[1].startswith("tt"):
            return {"kind": "movie", "imdb": p[1]}
    except (ValueError, IndexError):
        pass
    return None


def clean(segs, total):
    """Throw away timings that can't be right for this file."""
    out = []
    for s in segs:
        a, b = s["start"], s.get("end")
        if total:
            if a >= total - 2 or (b is not None and b > total + 5):
                continue
            if s["type"] == "credits" and a < total * 0.6:
                continue  # 'credits' starting before 60% in is a mix-up
            if b is not None:
                b = min(b, total)
        if b is not None and b - a < 3:
            continue
        out.append(dict(s, end=b))
    return sorted(out, key=lambda s: s["start"])


def segments(wk, total, profile):
    info = parse_wk(wk)
    if not info:
        return []
    cache = _cache_load(profile)
    hit = cache.get("seg:" + wk)
    if hit and time.time() - hit[0] < (FOUND_TTL if hit[1] else MISS_TTL):
        return clean(hit[1], total)
    found, errors = {}, []

    def add(lst):
        for s in lst:
            found.setdefault(s["type"], s)
    try:
        if info["kind"] == "anime":
            mal = kitsu_to_mal(info["kitsu"], cache)
            if mal:
                add(aniskip(mal, info["ep"], total))
            else:
                errors.append("no MyAnimeList id for Kitsu %s" % info["kitsu"])
        else:
            season = info.get("season")
            for name, fn in (("TheIntroDB", lambda: theintrodb(info["imdb"], season, info.get("ep"), total)),
                             ("IntroDB", lambda: introdb(info["imdb"], season, info.get("ep")))):
                if len(found) >= 3:
                    break
                try:
                    add(fn())
                except Exception as e:
                    errors.append("%s: %s" % (name, e))
    except Exception as e:
        errors.append(str(e))
    segs = list(found.values())
    if segs or not errors:  # don't remember a miss caused by a site being down
        cache["seg:" + wk] = [time.time(), segs]
    _cache_save(profile, cache)
    _log("Skip timings for %s: %s%s" % (wk, ", ".join("%s %d-%s" % (s["type"], s["start"], int(s["end"]) if s.get("end") else "end")
                                                     for s in segs) or "none",
                                      (" (" + "; ".join(errors) + ")") if errors else ""))
    return clean(segs, total)
