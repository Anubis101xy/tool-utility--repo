# -*- coding: utf-8 -*-
"""Minimal TorBox API client (https://api-docs.torbox.app)."""
import re

import requests

API_BASE = "https://api.torbox.app/v1/api"

# kind -> (path segment, id field name, control path, control id field)
KINDS = {
    "torrents": ("torrents", "torrent_id", "controltorrent", "torrent_id"),
    "usenet": ("usenet", "usenet_id", "controlusenetdownload", "usenet_id"),
    "webdl": ("webdl", "web_id", "controlwebdownload", "webdl_id"),
}


class TorBoxError(Exception):
    pass


class TorBoxAPI(object):
    def __init__(self, api_key, search_host=None):
        self.api_key = (api_key or "").strip()
        self.search_host = (search_host or "https://search-api.torbox.app").strip().rstrip("/")
        self.s = requests.Session()
        self.s.headers.update({
            "Authorization": "Bearer " + self.api_key,
            "User-Agent": "Kodi-TorBox/1.3.0",
        })

    def _req(self, method, path, **kw):
        kw.setdefault("timeout", 20)
        down = "TorBox is down for maintenance right now - see status.torbox.app"
        try:
            r = self.s.request(method, API_BASE + path, **kw)
        except requests.RequestException as e:
            if "status.torbox.app" in str(e):
                raise TorBoxError(down)  # during maintenance the API redirects to the status page
            raise TorBoxError("Network error: %s" % e)
        if "status.torbox.app" in (getattr(r, "url", "") or ""):
            raise TorBoxError(down)
        try:
            body = r.json()
        except ValueError:
            if r.status_code in (404, 502, 503, 504):
                raise TorBoxError("TorBox isn't answering properly (HTTP %s) - it may be down for maintenance, "
                                  "see status.torbox.app" % r.status_code)
            if r.status_code >= 500:
                raise TorBoxError("TorBox isn't working right now (HTTP %s) - it may be down for maintenance, "
                                  "see status.torbox.app" % r.status_code)
            raise TorBoxError("HTTP %s from TorBox" % r.status_code)
        if r.status_code >= 400 or body.get("success") is False:
            raise TorBoxError(body.get("detail") or body.get("error") or "HTTP %s" % r.status_code)
        return body

    def user(self):
        return self._req("GET", "/user/me").get("data") or {}

    def mylist(self, kind, item_id=None):
        params = {"bypass_cache": "true"}
        if item_id is not None:
            params["id"] = item_id
        data = self._req("GET", "/%s/mylist" % KINDS[kind][0], params=params).get("data")
        if item_id is not None:
            if isinstance(data, list):
                return data[0] if data else None
            return data
        return data or []

    def request_dl(self, kind, item_id, file_id):
        seg, id_field = KINDS[kind][0], KINDS[kind][1]
        params = {"token": self.api_key, id_field: item_id, "file_id": file_id}
        return self._req("GET", "/%s/requestdl" % seg, params=params).get("data")

    def redirect_url(self, kind, item_id, file_id):
        """Permanent URL that 302s to the CDN; used if requestdl itself fails."""
        seg, id_field = KINDS[kind][0], KINDS[kind][1]
        return "%s/%s/requestdl?token=%s&%s=%s&file_id=%s&redirect=true" % (
            API_BASE, seg, self.api_key, id_field, item_id, file_id)

    def delete(self, kind, item_id):
        seg, _, ctl, ctl_id = KINDS[kind]
        self._req("POST", "/%s/%s" % (seg, ctl), json={ctl_id: int(item_id), "operation": "delete"})

    def add_magnet(self, magnet):
        # createtorrent expects multipart/form-data
        body = self._req("POST", "/torrents/createtorrent", files={"magnet": (None, magnet)}, timeout=30)
        return (body.get("data") or {}).get("torrent_id")

    def add_webdl(self, link):
        """Have TorBox fetch a file-host link (Rapidgator etc.) into the cloud. Needs a paid TorBox plan."""
        body = self._req("POST", "/webdl/createwebdownload", data={"link": link}, timeout=60)
        dd = body.get("data") or {}
        return dd.get("webdownload_id") or dd.get("webdl_id") or dd.get("id")

    def webdl_hosters(self):
        return self._req("GET", "/webdl/hosters").get("data") or []

    def add_nzb(self, nzb_bytes=None, link=None, name=None):
        """Usenet download (TorBox Pro). Upload the NZB file itself when we have it, otherwise pass the link."""
        files = {}
        if nzb_bytes:
            files["file"] = (re.sub(r"[^\w.\- ]+", "_", name or "download")[:120] + ".nzb", nzb_bytes, "application/x-nzb")
        else:
            files["link"] = (None, link)
        if name:
            files["name"] = (None, name[:200])
        body = self._req("POST", "/usenet/createusenetdownload", files=files, timeout=60)
        dd = body.get("data") or {}
        return dd.get("usenetdownload_id") or dd.get("usenet_id") or dd.get("id")

    def check_cached(self, hashes):
        out = {}
        self.cache_failed = None
        hashes = [h for h in hashes if h]
        for i in range(0, len(hashes), 40):
            chunk = hashes[i:i + 40]
            try:
                data = self._req("GET", "/torrents/checkcached",
                                 params={"hash": ",".join(chunk), "format": "object"}, timeout=10).get("data") or {}
            except TorBoxError as e:
                self.cache_failed = str(e)  # TorBox down / refusing: don't keep trying (each try can take seconds)
                break
            for h in chunk:
                out[h.lower()] = bool(data.get(h) or data.get(h.lower()))
        return out

    def search(self, query):
        """TorBox Search API (needs a paid plan). Returns normalised results, cache status included."""
        try:
            r = self.s.get(self.search_host + "/torrents/search/" + requests.utils.quote(query, safe=""),
                           params={"check_cache": "true", "metadata": "false"}, timeout=30)
            body = r.json()
        except (requests.RequestException, ValueError) as e:
            raise TorBoxError("TorBox search unreachable at %s (the address may have changed; "
                              "turn this scraper off in Settings > Scrapers): %s" % (self.search_host, e))
        if r.status_code >= 400 or body.get("success") is False:
            raise TorBoxError(body.get("detail") or "Search HTTP %s" % r.status_code)
        data = body.get("data") or {}
        items = data.get("torrents") if isinstance(data, dict) else data
        out = []
        for t in items or []:
            h = (t.get("hash") or "").lower()
            if not h:
                continue
            out.append({"name": t.get("raw_title") or t.get("title") or "Unknown", "hash": h,
                        "size": t.get("size") or 0, "seeds": t.get("last_known_seeders") or 0,
                        "source": t.get("tracker") or "TorBox", "cached": bool(t.get("cached"))})
        return out


# ---------------- log in with a code (no typing the key on a TV remote) ----------------
def device_start(app):
    r = requests.get(API_BASE + "/user/auth/device/start", params={"app": app}, timeout=20)
    data = r.json().get("data") or {}
    if not data.get("device_code"):
        raise TorBoxError("TorBox didn't give a login code (HTTP %s)" % r.status_code)
    return data


def device_token(device_code):
    """API key once the code has been entered on the website, else None."""
    r = requests.post(API_BASE + "/user/auth/device/token", json={"device_code": device_code}, timeout=20)
    try:
        j = r.json()
    except ValueError:
        return None
    if j.get("success"):
        return (j.get("data") or {}).get("access_token")
    return None
