# -*- coding: utf-8 -*-
"""Look inside a zip on the internet without downloading it (HTTP range requests), and find where a stored
(uncompressed) file's bytes start so it can be streamed directly."""
import io
import struct
import zipfile
import zlib

import requests

UA = {"User-Agent": "Mozilla/5.0 (Kodi-TorUtilityBox)"}
BLOCK = 256 * 1024


class RangeFile(io.RawIOBase):
    def __init__(self, url, timeout=20):
        self.url, self.timeout, self.pos, self.cache = url, timeout, 0, {}
        r = requests.get(url, headers=dict(UA, Range="bytes=0-0"), timeout=timeout, stream=True)
        cr = r.headers.get("Content-Range") or ""
        r.close()
        if r.status_code != 206 or "/" not in cr:
            raise IOError("this server doesn't allow reading part of a file (no range support)")
        self.size = int(cr.rsplit("/", 1)[1])

    def seekable(self):
        return True

    def readable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, off, whence=0):
        self.pos = off if whence == 0 else self.pos + off if whence == 1 else self.size + off
        return self.pos

    def _block(self, n):
        if n not in self.cache:
            start = n * BLOCK
            end = min(self.size, start + BLOCK) - 1
            r = requests.get(self.url, headers=dict(UA, Range="bytes=%d-%d" % (start, end)), timeout=self.timeout)
            r.raise_for_status()
            if len(self.cache) > 64:
                self.cache.clear()
            self.cache[n] = r.content
        return self.cache[n]

    def readinto(self, b):
        if self.pos >= self.size:
            return 0
        want = min(len(b), self.size - self.pos)
        out = bytearray()
        while len(out) < want:
            blk = self._block((self.pos + len(out)) // BLOCK)
            off = (self.pos + len(out)) % BLOCK
            out += blk[off:off + want - len(out)]
        b[:len(out)] = out
        self.pos += len(out)
        return len(out)


def list_zip(url):
    """-> [(name, size, stored?, header_offset)] for every file in the zip."""
    zf = zipfile.ZipFile(RangeFile(url))
    return [(zi.filename, zi.file_size, zi.compress_type == zipfile.ZIP_STORED, zi.header_offset)
            for zi in zf.infolist() if not zi.is_dir()]


def data_offset(url, header_offset):
    """Where a member's raw bytes start (after its local header)."""
    r = requests.get(url, headers=dict(UA, Range="bytes=%d-%d" % (header_offset, header_offset + 29)), timeout=20)
    r.raise_for_status()
    hdr = r.content[:30]
    if len(hdr) < 30 or hdr[:4] != b"PK\x03\x04":
        raise IOError("unexpected zip layout")
    name_len, extra_len = struct.unpack("<HH", hdr[26:30])
    return header_offset + 30 + name_len + extra_len
