# -*- coding: utf-8 -*-
"""File-host link search on release blogs (for Cocoleech).
1) WordPress search API (/wp-json/wp/v2/posts?search=) - survives theme changes
2) the blog's normal search page (/?s=), reading links from the results
3) opening the top posts found by 1 or 2 and reading the links from each post
Links hidden as url-encoded or base64 text are decoded. Cloudflare-blocked blogs go through FlareSolverr when set.
Pass diag=[] to get a step-by-step account of what happened (used by the blog test)."""
import base64
import html as _html
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote, urljoin, urlparse

import requests

import cfsolve

BROWSER = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                         "Chrome/126.0.0.0 Safari/537.36",
           "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
           "Accept-Language": "en-GB,en;q=0.9"}
# file hosts commonly used on release blogs (Cocoleech's live list is added on top of this)
KNOWN_HOSTS = {"rapidgator.net", "rg.to", "nitroflare.com", "nitro.download", "1fichier.com", "ddownload.com", "ddl.to",
               "turbobit.net", "turb.cc", "katfile.com", "uploadgig.com", "mega.nz", "mediafire.com", "fikper.com",
               "filestore.me", "hitfile.net", "uploaded.net", "ul.to", "clicknupload.click", "clicknupload.org",
               "drop.download", "filefactory.com", "alfafile.net", "wupfile.com", "usersdrive.com", "dailyuploads.net",
               "k2s.cc", "keep2share.cc", "fboom.me", "tezfiles.com", "filespace.com", "file.al", "hexload.com",
               "mexa.sh", "uptobox.com", "send.cm", "gofile.io", "pixeldrain.com", "dropapk.to", "filerio.in",
               "rosefile.net", "upload.ee", "workupload.com", "filer.net", "uploadrar.com", "isra.cloud"}
# link "protectors" / shorteners that hide the real file-host link behind a captcha page
PROTECTORS = {"filecrypt.cc", "filecrypt.co", "ouo.io", "ouo.press", "shrinkme.io", "linkvertise.com", "adf.ly",
              "safelinking.net", "keeplinks.org", "keeplinks.co", "protect-links.com", "dl-protect.link", "zeroupload.com",
              "rlslinks.com", "shorte.st", "exe.io", "uii.io", "linksafe.cc", "relink.to", "share-links.biz"}
# links that are never downloads (left out of the "links go to" summary)
_BORING = ("wp.com", "wordpress.org", "w.org", "gravatar.com", "google", "gstatic", "facebook", "twitter", "x.com",
           "imdb.com", "youtube", "youtu.be", "schema.org", "cloudflare", "jquery", "bootstrapcdn", "fonts.", "disqus",
           "addtoany", "pinterest", "reddit", "telegram", "t.me", "instagram", "tvmaze", "themoviedb", "imgur",
           "imgbox", "pixhost", "postimg", "fastpic", "jsdelivr", "unpkg", "gmpg.org", "ogp.me", "creativecommons",
           "whatsapp", "linkedin", "tumblr", "vk.com", "amazon", "apple.com", "github")
LINK = re.compile(r"""https?://[^\s"'<>\]\[\\]+""", re.I)
B64 = re.compile(r"aHR0c[A-Za-z0-9+/_=-]{12,}")
PARTS = re.compile(r"(?:\.part0*(\d+)\.rar|\.r(\d\d)|\.(\d{3}))(?:\.html?)?$", re.I)
_SKIP_PATH = re.compile(r"/(?:category|tag|tags|page|author|feed|comments|wp-content|wp-json|wp-admin|wp-login|search|"
                        r"privacy|contact|about|dmca|login|register|xmlrpc)\b|\.(?:jpe?g|png|gif|webp|css|js|xml|ico)$", re.I)
_STOP = {"the", "a", "an", "and", "of", "to", "in", "on", "at", "for"}


class DDLError(Exception):
    pass


def host_of(u):
    h = urlparse(u).netloc.lower().split(":")[0]
    return h[4:] if h.startswith("www.") else h


def _in(h, hosts):
    return any(h == x or h.endswith("." + x) for x in hosts)


def is_hoster(u, hosts):
    return _in(host_of(u), hosts)


def file_name(u):
    parts = [unquote(p) for p in urlparse(u).path.split("/") if p]
    for p in reversed(parts):
        if p.endswith(".html"):
            p = p[:-5]
        elif p.endswith(".htm"):
            p = p[:-4]
        if "." in p and len(p) > 6:
            return p
    return parts[-1] if parts else u


def part_no(name):
    m = PARTS.search(name)
    if not m:
        return None
    return int(next(g for g in m.groups() if g))


def _candidates_text(html):
    """The page text plus any links hidden url-encoded or base64-encoded inside it."""
    t = _html.unescape(html or "")
    out = [t]
    if "%3A%2F%2F" in t or "%3a%2f%2f" in t:
        out.append(unquote(t))
    for b in set(B64.findall(t)):
        b = b.replace("-", "+").replace("_", "/")
        try:
            out.append(base64.b64decode(b + "=" * (-len(b) % 4)).decode("utf-8", "ignore"))
        except Exception:
            pass
    return "\n".join(out)


def _links(html, hosts, others=None, own=None):
    out = []
    for u in LINK.findall(_candidates_text(html)):
        u = u.rstrip(".,);:")
        pu = urlparse(u)
        h = host_of(u)
        if _in(h, hosts):
            if u not in out and (len(pu.path) > 1 or pu.query):
                out.append(u)
        elif others is not None and h and h != own and not any(b in h for b in _BORING):
            others[h] += 1
    return out


def _clean(t):
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", " ", t or ""))).strip()


def _err(r):
    if cfsolve.is_cf_block(r):
        return DDLError("blocked by Cloudflare protection (HTTP %s)%s" % (
            r.status_code, " - FlareSolverr couldn't get through either" if getattr(r, "via_flaresolverr", False) else
            " - set up FlareSolverr (Settings > Torrent sites) or swap this blog for another"))
    return DDLError("HTTP %s" % r.status_code)


def _get(url, params, timeout):
    try:
        r = cfsolve.get(url, params, BROWSER, timeout)
    except cfsolve.CFError as e:
        raise DDLError("blocked by Cloudflare protection - %s" % e)
    except requests.RequestException as e:
        raise DDLError("can't reach the site (%s)" % e.__class__.__name__)
    if r.status_code >= 400:
        raise _err(r)
    return r


def _words(q):
    w = [x for x in re.sub(r"[^a-z0-9]+", " ", q.lower()).split() if x not in _STOP]
    return w or re.sub(r"[^a-z0-9]+", " ", q.lower()).split()


def _wp_api(base, q, timeout, hosts, note, others):
    """(posts with links, [(url, title)] of every post found) or None when the blog has no usable API."""
    try:
        r = _get(base + "/wp-json/wp/v2/posts", {"search": q, "per_page": 20, "_fields": "title,link,content"}, timeout)
        data = r.json()
    except DDLError as e:
        if "Cloudflare" in str(e):
            raise
        note("WordPress search API: %s" % e)
        return None
    except ValueError:
        note("WordPress search API: not available (not JSON)")
        return None
    if not isinstance(data, list):
        note("WordPress search API: not available")
        return None
    posts, found = [], []
    for p in data:
        title = _clean((p.get("title") or {}).get("rendered"))
        link = p.get("link") or ""
        if not title:
            continue
        if link:
            found.append((link, title))
        links = _links((p.get("content") or {}).get("rendered"), hosts, others, host_of(base))
        if links:
            posts.append({"title": title, "url": link or base, "links": links})
    note("WordPress search API: %d posts found, %d with file-host links in the text" % (len(found), len(posts)))
    return posts, found


HEAD = re.compile(r"<h[1-4][^>]*>\s*(?:<[^a/][^>]*>\s*)*<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", re.I | re.S)
BOOKMARK = re.compile(r"<a[^>]+href=[\"']([^\"']+)[\"'][^>]*rel=[\"'][^\"']*bookmark[^>]*>(.*?)</a>|"
                      r"<a[^>]+rel=[\"'][^\"']*bookmark[^\"']*[\"'][^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", re.I | re.S)
ANCHOR = re.compile(r"<a[^>]+href=[\"']([^\"'#]+)[\"'][^>]*>(.*?)</a>", re.I | re.S)


def _site(h):
    """rlsbb.to and search.rlsbb.to are the same blog."""
    h = host_of(h) if "/" in h else h
    return h[7:] if h.startswith("search.") else h


def _post_like(u, base):
    return _site(host_of(u)) == _site(host_of(base)) and len(urlparse(u).path.strip("/")) > 3 and not _SKIP_PATH.search(
        urlparse(u).path) and "?" not in u


def _html_search(base, q, timeout, hosts, note, others, label="Search page"):
    r = _get(base + "/", {"s": q}, timeout)
    page = r.text
    heads = [(urljoin(base + "/", u), _clean(t), m.end()) for m, (u, t) in
             ((m, m.groups()) for m in HEAD.finditer(page))]
    heads = [h for h in heads if _post_like(h[0], base) and h[1]]
    posts = []
    for i, (u, title, end) in enumerate(heads):  # links shown right in the search results
        nxt = heads[i + 1][2] if i + 1 < len(heads) else len(page)
        links = _links(page[end:nxt], hosts, others, _site(host_of(base)))
        if links:
            posts.append({"title": title, "url": u, "links": links})
    found = [(u, t) for u, t, _ in heads]
    # other layouts: WordPress "bookmark" links, then any link to this blog whose address contains the search words
    for m in BOOKMARK.finditer(page):
        u, t = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        u = urljoin(base + "/", u)
        if _post_like(u, base) and _clean(t):
            found.append((u, _clean(t)))
    words = _words(q)
    for u, t in ANCHOR.findall(page):
        u = urljoin(base + "/", u)
        slug = re.sub(r"[^a-z0-9]+", " ", unquote(urlparse(u).path).lower())
        if _post_like(u, base) and all(w in slug.split() or w in slug for w in words):
            found.append((u, _clean(t) or slug.strip()))
    seen, uniq = set(), []
    for u, t in found:
        k = u.rstrip("/")
        if k not in seen:
            seen.add(k)
            uniq.append((u, t))
    extra = ""
    if not uniq:  # say what the page actually was, to help work out a new layout
        m = re.search(r"<title[^>]*>(.*?)</title>", page, re.S | re.I)
        moved = getattr(r, "url", "") or ""
        moved = moved if isinstance(moved, str) and moved and "s=" not in moved else ""
        extra = "  (page title: '%s'%s)" % (_clean(m.group(1))[:60] if m else "none",
                                            (", sent on to " + moved[:80]) if moved else "")
    note("%s: %d posts found, %d with file-host links shown in the results%s" % (label, len(uniq), len(posts), extra))
    return posts, uniq


def _open_posts(todo, timeout, hosts, note, others, base):
    def one(item):
        try:
            page = _get(item[0], None, timeout).text
        except Exception as e:
            return None, str(e)
        t = item[1]
        m = re.search(r"<h1[^>]*>(.*?)</h1>", page, re.S | re.I)
        if m and _clean(m.group(1)):
            t = _clean(m.group(1))
        elif not t or t == item[0]:
            m = re.search(r"<title[^>]*>(.*?)</title>", page, re.S | re.I)
            t = _clean(m.group(1)) if m else item[0]
        return {"title": t, "url": item[0], "links": _links(page, hosts, others, _site(host_of(base)))}, None
    with ThreadPoolExecutor(max_workers=max(1, len(todo))) as ex:
        got = list(ex.map(one, todo))
    ok = [g for g, e in got if g and g["links"]]
    errs = [e for g, e in got if e]
    note("Opened %d posts: %d had file-host links%s" % (
        len(todo), len(ok), ("  (%d failed: %s)" % (len(errs), errs[0])) if errs else ""))
    return ok


def _slugs(q):
    """Post addresses some blogs use, e.g. rlsbb.to/dune-part-two-2024-1080p or /the-bear-s03e01."""
    s = re.sub(r"[^a-z0-9]+", "-", q.lower().replace("&", "and")).strip("-")
    if s.count("-") < 1:
        return []
    out = [s]
    if re.search(r"-(?:19|20)\d\d$", s):
        out.append(s + "-1080p")
    m = re.match(r"(.+-s\d\d)e\d\d+$", s)
    if m:
        out.append(m.group(1))  # whole-season post
    return out


def _try_slugs(base, q, timeout, hosts, note, others):
    slugs = _slugs(q)
    if not slugs:
        return []

    def one(s):
        u = "%s/%s/" % (base, s)
        try:
            page = _get(u, None, timeout).text
        except DDLError:
            return None
        m = re.search(r"<h1[^>]*>(.*?)</h1>", page, re.S | re.I) or re.search(r"<title[^>]*>(.*?)</title>", page, re.S | re.I)
        links = _links(page, hosts, others, _site(host_of(base)))
        return {"title": _clean(m.group(1)) if m else s, "url": u, "links": links} if links else None
    with ThreadPoolExecutor(max_workers=len(slugs)) as ex:
        got = [g for g in ex.map(one, slugs) if g]
    note("Guessed post addresses (%s): %d had file-host links" % (", ".join("/" + s for s in slugs), len(got)))
    return got


def search_site(base, q, timeout=15, hosts=None, open_posts=6, diag=None):
    note = diag.append if diag is not None else (lambda s: None)
    base = base.strip().rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base
    hosts = set(hosts or ()) | KNOWN_HOSTS
    others = Counter()
    found = []
    api = _wp_api(base, q, timeout, hosts, note, others)
    posts = []
    if api is not None:
        posts, found = api
    if not posts:
        try:
            hp, hfound = _html_search(base, q, timeout, hosts, note, others)
        except DDLError as e:
            if not found:
                raise
            note("Search page: %s" % e)
            hp, hfound = [], []
        posts = hp
        known = {u.rstrip("/") for u, _ in found}
        found += [x for x in hfound if x[0].rstrip("/") not in known]
    if not posts and not found and not host_of(base).startswith("search."):
        # some blogs (rlsbb) run their search on a separate search.<blog> site
        u = urlparse(base)
        sbase = "%s://search.%s" % (u.scheme, host_of(base))
        try:
            hp, hfound = _html_search(sbase, q, timeout, hosts, note, others, "search.%s" % host_of(base))
            posts, found = hp, hfound
        except DDLError as e:
            if "can't reach" not in str(e):
                note("search.%s: %s" % (host_of(base), e))
    if not posts and found:
        posts = _open_posts(found[:open_posts], timeout, hosts, note, others, base)
    if not posts:
        posts = _try_slugs(base, q, timeout, hosts, note, others)
    if not posts and others:
        prot = [h for h, n in others.most_common() if _in(h, PROTECTORS)]
        note("Links in those pages go to: %s" % ", ".join("%s (%d)" % (h, n) for h, n in others.most_common(6)))
        if prot:
            note("%s hides its links behind a link-protector page (%s) that needs a person to solve a captcha - "
                 "Kodi can't open those" % (host_of(base), ", ".join(prot[:3])))
    src = host_of(base)
    for p in posts:
        p["source"] = src
    return posts


def group_links(links):
    """{host: [(name, part, url)]} with parts in order."""
    out = {}
    for u in links:
        n = file_name(u)
        out.setdefault(host_of(u), []).append((n, part_no(n), u))
    for h in out:
        out[h].sort(key=lambda x: (x[1] or 0, x[0]))
    return out
