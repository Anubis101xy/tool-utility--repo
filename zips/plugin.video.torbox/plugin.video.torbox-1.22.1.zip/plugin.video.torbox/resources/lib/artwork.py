# -*- coding: utf-8 -*-
"""Live menu backgrounds: backdrops of what's trending right now. The background service refreshes the list
every few hours, so menus only read a small local file (no waiting)."""
import json
import os
import random
import time

import xbmcaddon
import xbmcvfs

REFRESH = 6 * 3600
LIVE_SECTIONS = ("movies", "tv", "anime", "kdrama")
_cache = {}


def _file():
    prof = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    return prof, os.path.join(prof, "artwork.json")


def load():
    if "d" not in _cache:
        try:
            with open(_file()[1], "r") as f:
                _cache["d"] = json.load(f)
        except Exception:
            _cache["d"] = {}
    return _cache["d"]


def save(d):
    prof, p = _file()
    try:
        xbmcvfs.mkdirs(prof)
        tmp = p + ".tmp"
        with open(tmp, "w") as f:
            json.dump(d, f)
        os.replace(tmp, p)
        _cache["d"] = d
    except Exception:
        pass


def stale():
    _cache.pop("d", None)
    return time.time() - load().get("ts", 0) > REFRESH


def refresh(get_setting):
    import catalog
    pools = {}

    def add(section, items):
        out = [{"fanart": i.get("fanart"), "poster": i.get("poster"), "title": i.get("title") or i.get("name")}
               for i in items or [] if i.get("fanart")]
        if out:
            pools[section] = out[:25]
    for section, fn in (("movies", lambda: catalog.cinemeta_catalog("movie")),
                        ("tv", lambda: catalog.cinemeta_catalog("series")),
                        ("anime", catalog.kitsu_trending)):
        try:
            add(section, fn())
        except Exception:
            pass
    key = (get_setting("tmdb_key") or "").strip()
    if key:
        try:
            add("kdrama", catalog.kdrama_list(key, "popular"))
        except Exception:
            pass
    merged = dict(load().get("pools") or {})
    merged.update(pools)
    save({"ts": time.time(), "pools": merged})
    return len(pools)


def pick(section):
    pools = load().get("pools") or {}
    if section == "home":
        choices = [s for s in LIVE_SECTIONS if pools.get(s)]
        if not choices:
            return None
        section = random.choice(choices)
    pool = pools.get(section) or []
    return random.choice(pool) if pool else None
