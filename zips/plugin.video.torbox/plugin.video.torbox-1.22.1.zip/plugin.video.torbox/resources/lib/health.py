# -*- coding: utf-8 -*-
"""Service status: quick checks of everything the add-on talks to (only the ones you use).

run(get, profile, rd_file, music=True) -> {"ts", "items": [{"group", "name", "state", "detail", "ms"}]}
state: "ok", "warn" (working with a problem / blocked), "down", "off" (not set up - not shown)."""
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor

import requests

UA = {"User-Agent": "TorUtilityBox (Kodi add-on; status check)"}
TIMEOUT = 8
FILE = "status.json"


class Result(Exception):
    def __init__(self, state, detail):
        Exception.__init__(self, detail)
        self.state, self.detail = state, detail


def _cf(r):
    body = (r.text or "")[:3000].lower()
    return r.status_code in (403, 429, 503) and ("cloudflare" in (r.headers.get("server") or "").lower()
                                                 or "just a moment" in body or "cf-chl" in body)


def _web(url, **kw):
    """Plain reachability check for a website / API."""
    r = requests.get(url, headers=UA, timeout=TIMEOUT, **kw)
    if _cf(r):
        raise Result("warn", "blocked by Cloudflare (needs FlareSolverr)")
    if r.status_code == 520 or r.status_code >= 500:
        raise Result("down", "server error (HTTP %s)" % r.status_code)
    if r.status_code >= 400:
        raise Result("down", "HTTP %s" % r.status_code)
    return r


def _host(u):
    u = (u or "").strip().rstrip("/")
    return u if u.startswith("http") else "https://" + u


# ---------------- accounts ----------------
def c_torbox(key):
    def run():
        r = requests.get("https://api.torbox.app/v1/api/user/me", headers=dict(UA, Authorization="Bearer " + key),
                         timeout=TIMEOUT)
        if "status.torbox.app" in (r.url or ""):
            raise Result("down", "down for maintenance (see status.torbox.app)")
        try:
            j = r.json()
        except ValueError:
            raise Result("down", "not answering properly (HTTP %s) - maintenance?" % r.status_code)
        if r.status_code in (401, 403) or j.get("success") is False:
            raise Result("down", "API key not accepted - log in again")
        d = j.get("data") or {}
        exp = (d.get("premium_expires_at") or "")[:10]
        return "logged in%s" % ((" - paid until %s" % exp) if exp else "")
    return run


def c_realdebrid(token):
    def run():
        r = requests.get("https://api.real-debrid.com/rest/1.0/user", headers=dict(UA, Authorization="Bearer " + token),
                         timeout=TIMEOUT)
        if r.status_code == 401:
            raise Result("warn", "login needs refreshing - it renews itself when you next play something")
        if r.status_code >= 500:
            raise Result("down", "server error (HTTP %s)" % r.status_code)
        d = r.json()
        exp = (d.get("expiration") or "")[:10]
        if d.get("type") != "premium":
            raise Result("warn", "account isn't premium")
        return "premium until %s" % exp if exp else "premium"
    return run


def c_cocoleech(key):
    def run():
        r = requests.get("https://members.cocoleech.com/auth/api/info", params={"key": key}, headers=UA, timeout=TIMEOUT)
        try:
            j = r.json()
        except ValueError:
            try:
                j = json.loads((r.text or "").strip()[1:])
            except ValueError:
                raise Result("down", "bad reply (HTTP %s)" % r.status_code)
        if str(j.get("status")) == "100" or (j.get("message") and not j.get("username")):
            raise Result("down", j.get("message") or "key not accepted")
        exp = j.get("expire_date") or ""
        return "%s%s" % (j.get("package") or j.get("type") or "logged in", (" until %s" % exp) if exp else "")
    return run


# ---------------- torrent search ----------------
def c_stremio(url):
    def run():
        u = url.strip()
        if not u.endswith("manifest.json"):
            u = u.rstrip("/") + "/manifest.json"
        if u.startswith("stremio://"):
            u = "https://" + u[len("stremio://"):]
        j = _web(u).json()
        return "%s v%s" % (j.get("name") or "add-on", j.get("version") or "?")
    return run


def c_piratebay(host):
    return lambda: (_web(_host(host) + "/q.php", params={"q": "ubuntu", "cat": "0"}).json() and "searching")


def c_knaben(host):
    def run():
        h = _host(host)
        if "api." not in h:
            _web(h)
            return "website reachable"
        u = h if h.endswith("/v1") else h + "/v1"
        r = requests.post(u, json={"query": "ubuntu", "size": 1, "search_type": "100%", "search_field": "title"},
                          headers=UA, timeout=TIMEOUT)
        if r.status_code >= 400:
            raise Result("down", "HTTP %s" % r.status_code)
        return "searching"
    return run


def c_web(url, ok="reachable"):
    def run():
        _web(_host(url))
        return ok
    return run


def c_nyaa(host):
    return lambda: (_web(_host(host) + "/", params={"page": "rss", "q": "test"}) and "searching")


def c_newznab(url, key, profile=None):
    def run():
        b = _host(url)
        b = b if b.endswith("/api") else b + "/api"
        r = requests.get(b, params={"t": "caps", "apikey": key}, headers=UA, timeout=TIMEOUT)
        if r.status_code in (401, 403):
            raise Result("down", "API key not accepted (free plans often have no API access)")
        if r.status_code >= 400:
            raise Result("down", "HTTP %s" % r.status_code)
        if "<error" in (r.text or "")[:400]:
            import re
            m = re.search(r'description="([^"]+)"', r.text)
            raise Result("down", m.group(1) if m else "indexer error")
        try:  # caps doesn't test the key - so say if the last real search was refused
            with open(os.path.join(profile or "", "indexer_errors.json")) as f:
                bad = json.load(f).get(b.split("//")[-1].split("/")[0])
            if bad and time.time() - bad.get("ts", 0) < 86400:
                raise Result("down", "last search failed: %s" % bad.get("err", "")[:90])
        except (IOError, OSError, ValueError):
            pass
        return "reachable"
    return run


def c_flaresolverr(url):
    def run():
        u = url.strip().rstrip("/")
        if not u.startswith("http"):
            hostpart, _, rest = u.partition("/")
            u = "http://" + hostpart + ("" if ":" in hostpart else ":8191") + (("/" + rest) if rest else "")
        j = requests.get(u, headers=UA, timeout=TIMEOUT).json()
        if "flaresolverr" not in json.dumps(j).lower():
            raise Result("down", "something answered, but it isn't FlareSolverr")
        return "ready (v%s)" % j.get("version", "?")
    return run


# ---------------- catalogues ----------------
def c_anilist():
    def run():
        r = requests.post("https://graphql.anilist.co", json={"query": "{Page(perPage:1){media{id}}}"},
                          headers=dict(UA, Accept="application/json"), timeout=TIMEOUT)
        if r.status_code == 403:
            return "refusing apps - Kitsu / MyAnimeList used instead (nothing to fix)"
        if r.status_code >= 400:
            raise Result("warn", "HTTP %s - Kitsu / MyAnimeList used instead" % r.status_code)
        return "working"
    return run


def build(get, rd_token="", music=True, profile=None):
    on = lambda k: get(k) == "true"  # noqa: E731
    checks = []
    if get("api_key").strip():
        checks.append(("Accounts", "TorBox", c_torbox(get("api_key").strip())))
    if rd_token:
        checks.append(("Accounts", "Real-Debrid", c_realdebrid(rd_token)))
    if get("cocoleech_key").strip():
        checks.append(("Accounts", "Cocoleech", c_cocoleech(get("cocoleech_key").strip())))
    if on("stremio1_enable") and get("stremio1_url").strip():
        checks.append(("Torrent search", "Torrentio / Stremio 1", c_stremio(get("stremio1_url"))))
    if on("stremio2_enable") and get("stremio2_url").strip():
        checks.append(("Torrent search", "Stremio add-on 2", c_stremio(get("stremio2_url"))))
    if on("nyaa_enable"):
        checks.append(("Torrent search", "Nyaa (anime)", c_nyaa(get("nyaa_host") or "https://nyaa.si")))
    media = ("movie", "tv", "anime", "kdrama", "music")
    if any(on("tpb_%s" % m) for m in media):
        checks.append(("Torrent search", "Pirate Bay", c_piratebay(get("apibay_host") or "https://apibay.org")))
    if any(on("knaben_%s" % m) for m in media):
        checks.append(("Torrent search", "Knaben", c_knaben(get("knaben_host") or "https://api.knaben.org")))
    if any(on("bitsearch_%s" % m) for m in media):
        checks.append(("Torrent search", "BitSearch", c_web(get("bitsearch_host") or "https://bitsearch.to")))
    if on("torznab_enable") and get("torznab_url").strip():
        checks.append(("Torrent search", "Torznab", c_web(get("torznab_url"))))
    if on("enable_prowlarr") and get("prowlarr_host").strip():
        checks.append(("Torrent search", "Prowlarr", c_web(get("prowlarr_host"))))
    if get("usenet_enable") != "false":
        for n in ("1", "2"):
            u, k = get("nzb%s_url" % n).strip(), get("nzb%s_key" % n).strip()
            if u and k:
                checks.append(("Usenet", u.split("//")[-1].split("/")[0], c_newznab(u, k, profile)))
    for n in ("1", "2", "3"):
        u = get("ddl%s_url" % n).strip()
        if u:
            checks.append(("File-host search", u.split("//")[-1].split("/")[0], c_web(u)))
    if get("flaresolverr_url").strip():
        checks.append(("File-host search", "FlareSolverr", c_flaresolverr(get("flaresolverr_url"))))
    checks += [("Catalogues", "Cinemeta (movies & TV)", c_web("https://v3-cinemeta.strem.io/manifest.json", "working")),
               ("Catalogues", "Kitsu (anime)", c_web("https://kitsu.io/api/edge/anime?page%5Blimit%5D=1", "working")),
               ("Catalogues", "MyAnimeList via Jikan (anime)", c_web("https://api.jikan.moe/v4/anime/1", "working")),
               ("Catalogues", "AniList (anime schedule)", c_anilist()),
               ("Catalogues", "TVmaze (what's been on)", c_web("https://api.tvmaze.com/shows/1", "working"))]
    if get("tmdb_key").strip():
        checks.append(("Catalogues", "TMDB (K-dramas, top 10s)",
                       c_web("https://api.themoviedb.org/3/configuration?api_key=%s" % get("tmdb_key").strip(), "working")))
    if music:
        checks.append(("Catalogues", "Deezer (music)", c_web("https://api.deezer.com/chart/0/albums?limit=1", "working")))
    return checks


def _one(check):
    group, name, fn = check
    t0 = time.time()
    try:
        state, detail = "ok", fn() or "working"
    except Result as r:
        state, detail = r.state, r.detail
    except requests.Timeout:
        state, detail = "down", "not answering (timed out)"
    except requests.RequestException as e:
        state, detail = "down", "can't connect (%s)" % e.__class__.__name__
    except Exception as e:
        state, detail = "down", ("%s" % e)[:120] or e.__class__.__name__
    return {"group": group, "name": name, "state": state, "detail": detail, "ms": int((time.time() - t0) * 1000)}


def run(get, profile, rd_token="", music=True):
    checks = build(get, rd_token, music, profile)
    with ThreadPoolExecutor(max_workers=10) as ex:
        items = list(ex.map(_one, checks))
    out = {"ts": time.time(), "items": items}
    try:
        os.makedirs(profile, exist_ok=True)
        tmp = os.path.join(profile, FILE + ".tmp")
        with open(tmp, "w") as f:
            json.dump(out, f)
        os.replace(tmp, os.path.join(profile, FILE))
    except Exception:
        pass
    return out


def load(profile):
    try:
        with open(os.path.join(profile, FILE)) as f:
            return json.load(f)
    except Exception:
        return None


def summary(st):
    """(colour, text) for the main menu line."""
    if not st or not st.get("items"):
        return "grey", "Service status - check now"
    down = [i["name"] for i in st["items"] if i["state"] == "down"]
    warn = [i["name"] for i in st["items"] if i["state"] == "warn"]
    if down:
        return "red", "Down: %s%s" % (", ".join(down[:4]), (" +%d more" % (len(down) - 4)) if len(down) > 4 else "")
    if warn:
        return "orange", "All working - %d with a problem (%s)" % (len(warn), ", ".join(warn[:3]))
    return "lightgreen", "All %d services working" % len(st["items"])
