# -*- coding: utf-8 -*-
"""The add-on's own error log (Tools > Error log, or Settings > Error log).

Kept in <userdata>/tub_backup/<addon id>/log.txt - outside the add-on's data folder, so it survives anything that
clears that folder. Errors and warnings are always written; "detailed logging" in settings adds what each screen
was asked to do and how each search went. Everything also goes to Kodi's own kodi.log."""
import os
import re
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcvfs

MAX = 300 * 1024
_lock = threading.Lock()
_SECRET = re.compile(r"((?:api_?key|apikey|key|token|password|pass)=)[^&\s]+", re.I)


def _path():
    a = xbmcaddon.Addon()
    aid = a.getAddonInfo("id")
    d = xbmcvfs.translatePath("special://profile/tub_backup/%s/" % aid)
    return aid, d, os.path.join(d, "log.txt")


def debug_on():
    try:
        return xbmcaddon.Addon().getSetting("debug_log") == "true"
    except Exception:
        return False


def clean(msg):
    return _SECRET.sub(r"\1***", "%s" % msg)


def write(level, msg):
    aid, d, p = _path()
    msg = clean(msg)
    line = "%s  %-5s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), level, msg.replace("\n", "\n" + " " * 26))
    with _lock:
        try:
            os.makedirs(d, exist_ok=True)
            if os.path.exists(p) and os.path.getsize(p) > MAX:  # keep the newest half
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    data = f.read()
                with open(p, "w", encoding="utf-8") as f:
                    f.write(data[-MAX // 2:].split("\n", 1)[-1])
            with open(p, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass
    try:
        xbmc.log("[%s] %s: %s" % (aid, level, msg), xbmc.LOGWARNING if level in ("ERROR", "WARN") else xbmc.LOGINFO)
    except Exception:
        pass


def error(msg):
    write("ERROR", msg)


def warn(msg):
    write("WARN", msg)


def info(msg):
    write("INFO", msg)


def debug(msg):
    if debug_on():
        write("DEBUG", msg)


def exc(context):
    error("%s\n%s" % (context, traceback.format_exc().strip()))


def entries():
    """Log entries, newest first: [(time, level, text)]"""
    try:
        with open(_path()[2], "r", encoding="utf-8", errors="replace") as f:
            raw = f.read()
    except Exception:
        return []
    out = []
    for block in re.split(r"\n(?=\d{4}-\d\d-\d\d \d\d:\d\d:\d\d  )", raw.strip()):
        m = re.match(r"(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)  (\w+)\s+(.*)", block, re.S)
        if m:
            out.append((m.group(1), m.group(2), re.sub(r"\n {26}", "\n", m.group(3))))
    out.reverse()
    return out


def clear():
    try:
        os.remove(_path()[2])
    except OSError:
        pass


def path():
    return _path()[2]
