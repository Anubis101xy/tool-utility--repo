# -*- coding: utf-8 -*-
"""Real-Debrid and Cocoleech as torrent services (alongside TorBox), plus Real-Debrid's file-host unlocker.

Every service works the same way for the add-on:
    h = svc.start(info_hash, name)        -> handle (string) once the torrent has been added
    st = svc.status(h)                    -> {"ready", "progress", "state", "name", "files", "error"}
    url = svc.link(h, file_id)            -> direct link to play / download
Files are [{"id", "name", "size"}]. API details as used by ResolveURL (script.module.resolveurl)."""
import re
import time

import requests

UA = {"User-Agent": "TorUtilityBox (Kodi add-on)"}
MEDIA_EXT = (".mkv", ".mp4", ".avi", ".mov", ".ts", ".m4v", ".webm", ".wmv", ".mpg", ".mpeg", ".m2ts", ".flac", ".mp3",
             ".m4a", ".ogg", ".opus", ".wav", ".aac", ".ape", ".wv", ".alac", ".aiff", ".wma", ".srt", ".ass", ".sub")


PLAY_EXT = tuple(x for x in MEDIA_EXT if x not in (".srt", ".ass", ".sub"))


class DebridError(Exception):
    pass


def _clean(name):
    return re.sub(r"^/+", "", name or "")


# ---------------------------------------------------------------- Real-Debrid
class RealDebrid(object):
    label = "Real-Debrid"
    REST = "https://api.real-debrid.com/rest/1.0"
    OAUTH = "https://api.real-debrid.com/oauth/v2"
    CLIENT_ID = "X245A4XAIBGVM"  # Real-Debrid's public client id for open-source apps (same as ResolveURL)
    STALLED = ("magnet_error", "error", "virus", "dead")

    def __init__(self, auth, save_auth):
        """auth: {"token", "refresh", "client_id", "client_secret"}; save_auth(dict) stores refreshed tokens."""
        self.auth = dict(auth or {})
        self.save_auth = save_auth

    # -- login with a code
    @classmethod
    def device_start(cls):
        r = requests.get(cls.OAUTH + "/device/code", params={"client_id": cls.CLIENT_ID, "new_credentials": "yes"},
                         headers=UA, timeout=20)
        d = r.json()
        if not d.get("device_code"):
            raise DebridError("Real-Debrid didn't give a login code")
        return d  # verification_url, user_code, device_code, interval, expires_in

    @classmethod
    def device_poll(cls, device_code):
        """-> auth dict once the code has been entered, else None."""
        r = requests.get(cls.OAUTH + "/device/credentials", params={"client_id": cls.CLIENT_ID, "code": device_code},
                         headers=UA, timeout=20)
        try:
            c = r.json()
        except ValueError:
            return None
        if not c.get("client_id") or not c.get("client_secret"):
            return None
        t = requests.post(cls.OAUTH + "/token", data={"client_id": c["client_id"], "client_secret": c["client_secret"],
                                                       "code": device_code,
                                                       "grant_type": "http://oauth.net/grant_type/device/1.0"},
                          headers=UA, timeout=20).json()
        if not t.get("access_token"):
            return None
        return {"token": t["access_token"], "refresh": t.get("refresh_token", ""), "client_id": c["client_id"],
                "client_secret": c["client_secret"], "expires": time.time() + int(t.get("expires_in") or 3600)}

    def _refresh(self):
        a = self.auth
        if not (a.get("refresh") and a.get("client_id")):
            raise DebridError("Real-Debrid login has expired - log in again (Tools > Real-Debrid)")
        t = requests.post(self.OAUTH + "/token", data={"client_id": a["client_id"], "client_secret": a["client_secret"],
                                                        "code": a["refresh"],
                                                        "grant_type": "http://oauth.net/grant_type/device/1.0"},
                          headers=UA, timeout=20).json()
        if not t.get("access_token"):
            raise DebridError("Real-Debrid login has expired - log in again (Tools > Real-Debrid)")
        a.update(token=t["access_token"], refresh=t.get("refresh_token") or a["refresh"],
                 expires=time.time() + int(t.get("expires_in") or 3600))
        self.save_auth(a)

    def _req(self, method, path, retry=True, **kw):
        if not self.auth.get("token"):
            raise DebridError("not logged in to Real-Debrid")
        if self.auth.get("expires") and time.time() > self.auth["expires"] - 60:
            self._refresh()
        h = dict(UA, Authorization="Bearer " + self.auth["token"])
        try:
            r = requests.request(method, self.REST + path, headers=h, timeout=kw.pop("timeout", 25), **kw)
        except requests.RequestException as e:
            raise DebridError("can't reach Real-Debrid (%s)" % e.__class__.__name__)
        if r.status_code == 401 and retry:
            self._refresh()
            return self._req(method, path, retry=False, **kw)
        if r.status_code >= 400:
            try:
                j = r.json()
                msg = j.get("error") or ("error %s" % j.get("error_code"))
            except ValueError:
                msg = "HTTP %s" % r.status_code
            if r.status_code >= 500:
                msg = "Real-Debrid's server isn't working right now (HTTP %s)" % r.status_code
            raise DebridError(msg.replace("_", " "))
        if r.status_code == 204 or not r.content:
            return {}
        try:
            return r.json()
        except ValueError:
            return {}

    def user(self):
        return self._req("GET", "/user")

    def start(self, info_hash, name=""):
        d = self._req("POST", "/torrents/addMagnet", data={"magnet": "magnet:?xt=urn:btih:%s" % info_hash})
        tid = d.get("id")
        if not tid:
            raise DebridError("Real-Debrid didn't accept the torrent")
        return str(tid)

    def _info(self, h):
        return self._req("GET", "/torrents/info/%s" % h)

    def status(self, h):
        info = self._info(h)
        st = info.get("status") or "?"
        if st == "waiting_files_selection":
            files = info.get("files") or []
            want = [str(f["id"]) for f in files if (f.get("path") or "").lower().endswith(MEDIA_EXT)]
            self._req("POST", "/torrents/selectFiles/%s" % h, data={"files": ",".join(want) if want else "all"})
            info = self._info(h)
            st = info.get("status") or "?"
        out = {"ready": st == "downloaded", "progress": int(float(info.get("progress") or 0)),
               "state": st.replace("_", " "), "name": info.get("filename") or info.get("original_filename") or "",
               "files": [], "error": None}
        if any(x in st for x in self.STALLED):
            out["error"] = "Real-Debrid says the torrent is %s" % st.replace("_", " ")
        if out["ready"]:
            sel = [f for f in info.get("files") or [] if f.get("selected")]
            links = info.get("links") or []
            out["files"] = [{"id": i, "name": _clean(f.get("path")), "size": f.get("bytes") or 0}
                            for i, f in enumerate(sel) if i < len(links)]
        if st == "downloading" and info.get("speed"):
            out["state"] = "downloading %.1f MB/s from %s peers" % (float(info["speed"]) / 1e6, info.get("seeders") or "?")
        return out

    def link(self, h, file_id):
        links = self._info(h).get("links") or []
        try:
            return self.unrestrict(links[int(file_id)])
        except IndexError:
            raise DebridError("Real-Debrid lost that file - pick the torrent again")

    def unrestrict(self, link):
        d = self._req("POST", "/unrestrict/link", data={"link": link})
        if not d.get("download"):
            raise DebridError("Real-Debrid gave no download link")
        return d["download"]

    def delete(self, h):
        try:
            self._req("DELETE", "/torrents/delete/%s" % h)
        except DebridError:
            pass

    def hosts(self):
        return [x.lower() for x in self._req("GET", "/hosts/domains") or [] if isinstance(x, str)]

    def list(self):
        out = []
        for t in self._req("GET", "/torrents", params={"limit": 100}) or []:
            st = t.get("status") or "?"
            out.append({"id": str(t.get("id")), "name": t.get("filename") or "?", "ready": st == "downloaded",
                        "progress": int(float(t.get("progress") or 0)), "state": st.replace("_", " "),
                        "size": t.get("bytes") or 0})
        return out


# ---------------------------------------------------------------- Cocoleech torrents
class CocoleechTorrents(object):
    label = "Cocoleech"
    V2 = "https://members.cocoleech.com/api/v2"

    def __init__(self, key):
        self.key = key

    def _get(self, path, **params):
        if not self.key:
            raise DebridError("not logged in to Cocoleech")
        params["key"] = self.key
        try:
            r = requests.get(self.V2 + path, params=params, headers=UA, timeout=25)
        except requests.RequestException as e:
            raise DebridError("can't reach Cocoleech (%s)" % e.__class__.__name__)
        try:
            j = r.json()
        except ValueError:
            import json
            try:
                j = json.loads((r.text or "").strip()[1:])
            except ValueError:
                raise DebridError("bad reply from Cocoleech (HTTP %s)" % r.status_code)
        if isinstance(j, dict) and str(j.get("status")) not in ("200", "None") and j.get("message") and \
                "cached" not in str(j.get("message")).lower():
            raise DebridError("Cocoleech: %s" % j["message"])
        return j

    def cached(self, info_hash):
        try:
            j = self._get("/checkInstant", hash=info_hash)
        except DebridError:
            return False
        return isinstance(j, dict) and str(j.get("status")) == "200" and "torrent cached" in str(j.get("message")).lower()

    def start(self, info_hash, name=""):
        self._get("/add", hash=info_hash)
        return info_hash.lower()

    def _entry(self, h):
        j = self._get("/list", hash=h)
        items = j if isinstance(j, list) else (j.get("data") or j.get("result") or []) if isinstance(j, dict) else []
        for it in items:
            if (it.get("hash") or "").lower() == h.lower():
                return it
        return None

    def _files(self, h):
        j = self._get("/browse", hash=h)
        tors = ((j.get("arguments") or {}).get("torrents") or []) if isinstance(j, dict) else []
        if not tors:
            return []
        return [{"id": i, "name": _clean(f.get("name")), "size": int(f.get("size") or 0), "url": f.get("downloadUrl")}
                for i, f in enumerate(tors[0].get("files") or [])]

    def status(self, h):
        it = self._entry(h) or {}
        done = bool(it.get("isComplete"))
        out = {"ready": done, "progress": int(float(it.get("progress") or (100 if done else 0))),
               "state": it.get("status") or ("ready" if done else "queued"), "name": it.get("name") or "",
               "files": [], "error": None}
        if not it:
            # not in the list yet - it may still be cached and browsable
            files = self._files(h)
            if files:
                out.update(ready=True, progress=100, state="ready", files=files)
            return out
        if done:
            out["files"] = self._files(h)
            if not out["files"]:
                out["ready"] = False
                out["state"] = "preparing the files"
        elif it.get("rateDownload"):
            out["state"] = "downloading %.1f MB/s" % (float(it["rateDownload"]) / 1e6)
        if "error" in str(it.get("status") or "").lower():
            out["error"] = "Cocoleech: %s" % it.get("status")
        return out

    def list(self):
        j = self._get("/list")
        items = j if isinstance(j, list) else (j.get("data") or j.get("result") or []) if isinstance(j, dict) else []
        return [{"id": (it.get("hash") or "").lower(), "name": it.get("name") or "?", "ready": bool(it.get("isComplete")),
                 "progress": int(float(it.get("progress") or 0)), "state": it.get("status") or "",
                 "size": int(it.get("size") or 0)} for it in items if it.get("hash")]

    def link(self, h, file_id):
        for f in self._files(h):
            if f["id"] == int(file_id):
                if not f.get("url"):
                    raise DebridError("Cocoleech gave no download link for that file")
                return f["url"]
        raise DebridError("Cocoleech lost that file - pick the torrent again")

    def delete(self, h):
        try:
            self._get("/delete", hash=h)
        except DebridError:
            pass
