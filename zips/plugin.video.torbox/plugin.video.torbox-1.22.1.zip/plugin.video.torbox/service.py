# -*- coding: utf-8 -*-
"""Background service: marks an episode/movie watched once ~85% has been played (or it played to the end)."""
import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
sys.path.insert(0, os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
import watched  # noqa: E402

THRESHOLD = 0.85
SKIP_NAMES = {"intro": "intro", "recap": "recap", "credits": "credits"}


def quiet_popup(msg, ms=2500):
    """A short pop-up, unless Settings > Messages says stealth / off."""
    a = xbmcaddon.Addon()
    if (a.getSetting("notify_mode") or "0") == "0":
        xbmcgui.Dialog().notification(a.getAddonInfo("name"), msg, xbmcgui.NOTIFICATION_INFO, ms, False)


class SkipButton(xbmcgui.WindowXMLDialog):
    """The 'Skip intro' / 'Next episode' button in the bottom corner of the video."""

    def __init__(self, *args, **kwargs):
        self.text = kwargs.get("text", "Skip")
        self.pressed = False

    def onInit(self):
        try:
            self.getControl(3001).setLabel(self.text)
            self.setFocusId(3001)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == 3001:
            self.pressed = True
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 13, 92, 216, 247, 257, 275, 61467, 61448):  # back / stop / close
            self.close()


def profile_dir():
    import xbmcvfs
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))


def play_next_countdown(ended_wk):
    """The episode finished: count down and play the next one (if it was got ready in time)."""
    import binge
    import tublog
    a = xbmcaddon.Addon()
    if a.getSetting("autonext") == "false":
        return
    nx = binge.next_up(profile_dir())
    if nx.get("for") != ended_wk:
        return
    if not nx.get("url"):
        if nx.get("label"):
            xbmcgui.Dialog().notification(a.getAddonInfo("name"), "Nothing cached for %s yet - it's in Continue watching"
                                          % nx["label"], xbmcgui.NOTIFICATION_INFO, 6000)
        return
    win = xbmcgui.Window(10000)
    try:
        chain = int(win.getProperty("tub.autochain") or 0)  # episodes played on their own in a row
        ask_after = int(a.getSetting("still_watching") or 0)
    except ValueError:
        chain, ask_after = 0, 0
    if ask_after and chain >= ask_after:
        still = xbmcgui.Dialog().yesno(a.getAddonInfo("name"), "[B]Are you still watching?[/B]\n\nUp next: %s" % nx["label"],
                                       nolabel="Stop", yeslabel="Keep watching", autoclose=60000)
        win.setProperty("tub.autochain", "0")
        if not still:
            tublog.info("Still watching? - no answer, stopped before %s" % nx["label"])
            quiet_popup("Stopped - %s is in Continue watching" % nx["label"], 6000)
            return
        chain = 0
    else:
        wait = int(a.getSetting("autonext_wait") or 10)
        prog = xbmcgui.DialogProgress()
        prog.create(a.getAddonInfo("name"), "Up next: %s" % nx["label"])
        for i in range(wait * 2, 0, -1):
            prog.update(int(100 * i / (wait * 2.0)), "Up next: [B]%s[/B]\nStarting in %d s - press Cancel to stop" % (
                nx["label"], (i + 1) // 2))
            xbmc.sleep(500)
            if prog.iscanceled():
                prog.close()
                tublog.info("Up next cancelled: %s" % nx["label"])
                return
        prog.close()
    win.setProperty("tub.autochain", str(chain + 1))
    np = {k: nx.get(k) for k in ("wk", "show", "season", "ep", "anime", "svc", "hd", "hash", "name", "files", "file",
                                 "group", "res", "audio", "source")}
    binge.started(profile_dir(), np)
    try:
        watched.add_recent(nx["wk"])
    except Exception:
        pass
    win.setProperty("tub.playing", json.dumps({"wk": nx["wk"], "addon": ADDON_ID, "auto": 1}))
    li = xbmcgui.ListItem(nx["label"], path=nx["url"])
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(nx["label"])
        tag.setMediaType("episode")
    except AttributeError:
        li.setInfo("video", {"title": nx["label"], "mediatype": "episode"})
    tublog.info("Up next playing: %s" % nx["label"])
    xbmc.Player().play(nx["url"], li)


class Tracker(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.key, self.pos, self.total = None, 0.0, 0.0
        self.prepped = False
        self.segs, self.done, self.dlg, self.gen = [], set(), None, 0

    def onAVStarted(self):
        win = xbmcgui.Window(10000)
        try:
            info = json.loads(win.getProperty("tub.playing") or "{}")
        except ValueError:
            info = {}
        if info.get("addon") != ADDON_ID:
            return  # started by the other add-on (or something else)
        win.clearProperty("tub.playing")
        self.key, self.pos, self.total = info.get("wk") or None, 0.0, 0.0
        self.prepped = False
        self.close_button()
        self.segs, self.done = [], set()
        self.gen += 1
        if not info.get("auto"):
            win.setProperty("tub.autochain", "0")  # you started this one yourself
        if self.key:
            import threading
            t = threading.Thread(target=self.load_skips, args=(self.key, self.gen))
            t.daemon = True
            t.start()

    # ---------------- skip intro / recap / credits ----------------
    def load_skips(self, key, gen):
        a = xbmcaddon.Addon()
        if all((a.getSetting("skip_" + k) or "1") == "0" for k in SKIP_NAMES):
            return
        total = 0.0
        for _ in range(40):  # wait for the length of the video (needed to check the timings fit this file)
            try:
                total = self.getTotalTime() if self.isPlayingVideo() else 0.0
            except Exception:
                total = 0.0
            if total > 0 or gen != self.gen:
                break
            xbmc.sleep(500)
        if gen != self.gen or total <= 0:
            return
        try:
            import skipper
            import tublog
            skipper.LOG[0] = tublog.debug
            segs = skipper.segments(key, total, profile_dir())
        except Exception as e:
            xbmc.log("[%s] skip timings: %s" % (ADDON_ID, e), xbmc.LOGWARNING)
            segs = []
        if gen == self.gen:
            self.segs = segs

    def close_button(self):
        d, self.dlg = self.dlg, None
        if d:
            try:
                d[0].close()
            except Exception:
                pass

    def next_ready(self):
        try:
            import binge
            nx = binge.next_up(profile_dir())
            return nx.get("for") == self.key and bool(nx.get("url")) and xbmcaddon.Addon().getSetting("autonext") != "false"
        except Exception:
            return False

    def do_skip(self, seg, end, auto):
        if seg["type"] == "credits" and end >= self.total - 25:
            target = max(self.total - 1.5, 0)  # to the very end: marks it watched and starts 'Up next'
        else:
            target = end
        try:
            self.seekTime(target)
        except Exception:
            return
        if auto:
            quiet_popup("Skipped the %s" % SKIP_NAMES[seg["type"]])
        else:
            xbmcgui.Window(10000).setProperty("tub.autochain", "0")  # someone is watching

    def show_button(self, seg, end):
        if seg["type"] == "credits":
            text = "Next episode  >" if (end >= self.total - 25 and self.next_ready()) else "Skip credits  >"
        else:
            text = "Skip %s  >" % SKIP_NAMES[seg["type"]]
        path = xbmcaddon.Addon().getAddonInfo("path")
        try:
            dlg = SkipButton("tub_skip.xml", path, "Default", "1080i", text=text)
        except Exception as e:
            xbmc.log("[%s] skip button: %s" % (ADDON_ID, e), xbmc.LOGWARNING)
            return
        import threading
        import time

        def run(gen):
            dlg.doModal()
            if dlg.pressed and gen == self.gen and self.isPlayingVideo():
                self.do_skip(seg, end, False)
            if self.dlg and self.dlg[0] is dlg:
                self.dlg = None
        self.dlg = (dlg, end, time.time())
        t = threading.Thread(target=run, args=(self.gen,))
        t.daemon = True
        t.start()

    def handle_skips(self):
        import time
        if self.dlg:  # hide the button once the part is over (or after 12 s)
            dlg, end, shown = self.dlg
            if self.pos >= end - 1 or time.time() - shown > 12:
                self.close_button()
            return
        a = None
        for s in self.segs:
            k = (s["type"], s["start"])
            if k in self.done:
                continue
            end = s["end"] if s.get("end") is not None else self.total
            if self.pos < s["start"] - 0.5:
                continue
            self.done.add(k)
            if self.pos >= end - 3:
                continue  # already past it (you jumped ahead)
            a = a or xbmcaddon.Addon()
            mode = a.getSetting("skip_" + s["type"]) or "1"
            if mode == "2":
                self.do_skip(s, end, True)
            elif mode == "1":
                self.show_button(s, end)
            break

    def finish(self, ended):
        self.close_button()
        self.segs = []
        if self.key and (ended or (self.total > 0 and self.pos / self.total >= THRESHOLD)):
            watched.mark(self.key, True)
            import tublog
            tublog.debug("Marked watched: %s" % self.key)
        self.key = None

    def onPlayBackStopped(self):
        self.finish(False)

    def onPlayBackEnded(self):
        key = self.key
        self.finish(True)
        if key:
            import threading
            t = threading.Thread(target=play_next_countdown, args=(key,))
            t.daemon = True
            t.start()

    def onPlayBackError(self):
        self.close_button()
        self.key = None

    def poll(self):
        if self.key and self.isPlayingVideo():
            try:
                self.pos, self.total = self.getTime(), self.getTotalTime()
            except Exception:
                pass
            if self.segs:
                self.handle_skips()
            # ~3 minutes before the end of an episode: get the next one ready in the background
            if (not self.prepped and self.total > 600 and self.total - self.pos < 180 and self.key.count(":") >= 2
                    and xbmcaddon.Addon().getSetting("autonext") != "false"):
                self.prepped = True
                xbmc.executebuiltin("RunPlugin(plugin://%s/?action=prep_next&wk=%s)" % (ADDON_ID, self.key))


if __name__ == "__main__":
    import threading
    import artwork

    def art_refresh():
        try:
            if ADDON.getSetting("dyn_art") != "false" and artwork.stale():
                artwork.refresh(xbmcaddon.Addon().getSetting)
        except Exception as e:
            import tublog
            tublog.warn("Background: menu artwork refresh failed: %s" % e)

    try:
        import zipproxy
        zipproxy.start(ADDON_ID)
    except Exception as e:
        import tublog
        tublog.error("Background: zip streaming relay didn't start: %s" % e)

    try:
        watched.load()  # puts the watched list back straight away if something wiped it while Kodi was starting
    except Exception as e:
        import tublog
        tublog.exc("Background: watched list check failed")
    def status_refresh():
        try:
            import health
            import tublog
            import xbmcvfs
            a = xbmcaddon.Addon()
            if a.getSetting("status_bg") == "false":
                return
            prof = xbmcvfs.translatePath(a.getAddonInfo("profile"))
            rdf = os.path.join(xbmcvfs.translatePath("special://profile/tub_backup/%s/" % ADDON_ID), "rd_auth.json")
            try:
                with open(rdf) as f:
                    rd = json.load(f)
            except Exception:
                rd = {}
            if rd.get("token") and rd.get("expires") and __import__("time").time() > rd["expires"] - 120:
                try:  # renew the hourly Real-Debrid login first
                    import debrid

                    def save(a):
                        with open(rdf, "w") as f:
                            json.dump(a, f)
                    debrid.RealDebrid(rd, save)._refresh()
                except Exception as e:
                    tublog.warn("Real-Debrid login renewal: %s" % e)
            rd_token = rd.get("token", "")
            before = {i["name"]: i["state"] for i in (health.load(prof) or {}).get("items", [])}
            st = health.run(a.getSetting, prof, rd_token, ADDON_ID == "plugin.video.torutilitybox")
            for i in st["items"]:  # note changes in the error log
                was = before.get(i["name"])
                if i["state"] == "down" and was != "down":
                    tublog.warn("Status: %s is down - %s" % (i["name"], i["detail"]))
                elif was == "down" and i["state"] == "ok":
                    tublog.info("Status: %s is working again" % i["name"])
        except Exception as e:
            xbmc.log("[%s] status check failed: %s" % (ADDON_ID, e), xbmc.LOGWARNING)

    monitor = xbmc.Monitor()
    tracker = Tracker()
    ticks = 0
    while not monitor.abortRequested():
        tracker.poll()
        if ticks % 900 == 30:  # ~30 s after start-up, then every 15 minutes
            t = threading.Thread(target=status_refresh)
            t.daemon = True
            t.start()
        if ticks % 3600 == 0:  # at start-up, then about every hour (only refreshes when 6h old)
            t = threading.Thread(target=art_refresh)
            t.daemon = True
            t.start()
        ticks += 1
        if monitor.waitForAbort(1):
            break
