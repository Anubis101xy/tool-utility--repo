# -*- coding: utf-8 -*-
"""StashBox background service: download queue, library scans, playback tracking."""
import json
import os
import sys
import threading
import time

import xbmc
import xbmcaddon

sys.path.insert(0, os.path.join(xbmcaddon.Addon("plugin.video.stashbox").getAddonInfo("path"), "resources", "lib"))

import db  # noqa: E402
import downloads  # noqa: E402
import player  # noqa: E402
import scanner  # noqa: E402
from common import (ADDON_ID, HOME, NAME, SECTION_LABEL, hide_creds, log, log_exc, notify, sections_set_up,  # noqa: E402
                    setting_bool, setting_int, take_request)


class Monitor(xbmc.Monitor):
    pass


def _req(raw):
    """Scan requests from the add-on: '' / 'ui' / JSON {"by": ..., "only": [folders], "sections": [...]}."""
    if not raw:
        return None
    try:
        r = json.loads(raw)
        if isinstance(r, dict):
            return r
    except ValueError:
        pass
    return {"by": "you" if raw == "ui" else raw}


def scan_loop(mon):
    if mon.waitForAbort(40):
        return
    last = 0.0
    try:
        last = float(db.meta_get("last_scan") or 0)
    except Exception:
        pass
    pending = {"by": "Kodi starting"} if setting_bool("scan_on_start", True) else None
    while not mon.abortRequested():
        req = _req(take_request("scan")) or pending
        pending = None
        hours = setting_int("scan_interval", 6)
        if not req and hours and time.time() - last > hours * 3600:
            req = {"by": "timer"}
        if req and sections_set_up():
            run_scan(req)
            if not req.get("only"):
                last = time.time()
        if mon.waitForAbort(5):
            return


PROGRESS_EVERY = 0.3  # seconds between progress bar updates


def run_scan(req):
    by = req.get("by") or "you"
    mine = by == "you"
    show = setting_int("scan_show", 0)  # 0 always, 1 only scans I start, 2 never
    bg = None
    if show == 0 or (show == 1 and mine):
        try:
            import xbmcgui
            bg = xbmcgui.DialogProgressBG()
            bg.create("%s: scanning your NAS" % NAME, "Starting...")
        except Exception:
            bg = None
    state = {"t": 0.0, "head": None}

    def prog(pct, head, where):
        now = time.time()
        if head == state["head"] and now - state["t"] < PROGRESS_EVERY:
            return
        state["t"], state["head"] = now, head
        HOME.setProperty("stashbox.scan.now", json.dumps({"pct": pct, "head": head, "where": hide_creds(where)}))
        if bg:
            try:
                bg.update(pct, "%s: %s" % (NAME, head), hide_creds(where)[:90])
            except Exception:
                pass
    HOME.setProperty("stashbox.scan.now", json.dumps({"pct": 0, "head": "Starting", "where": ""}))
    t0 = time.time()
    try:
        res = scanner.scan(sections=req.get("sections"), progress=prog, only=req.get("only"), by=by)
    except Exception:
        log_exc("Library scan")
        res = []
    finally:
        HOME.clearProperty("stashbox.scan.now")
        if bg:
            try:
                bg.close()
            except Exception:
                pass
    new, gone, bad = scanner.summary(res)
    secs = time.time() - t0
    took = ("%dm %02ds" % divmod(int(secs), 60)) if secs >= 60 else "%ds" % max(1, int(secs))
    log("Scan (%s) done in %s: %d new, %d removed%s" % (by, took, new, gone,
                                                        "; couldn't reach " + ", ".join(bad) if bad else ""))
    mode = setting_int("scan_notify", 0)  # 0 if something changed / a folder was missing, 1 always, 2 never
    if mode != 2:
        if bad:
            notify("Couldn't reach %s - skipped, nothing removed" % ", ".join(bad[:3]) +
                   (" and %d more" % (len(bad) - 3) if len(bad) > 3 else ""), "warn", 8000)
        if new or gone or mode == 1 or mine:
            parts = []
            for r in res:
                if r.get("new"):
                    parts.append("%s +%d" % (SECTION_LABEL[r["section"]], r["new"]))
            msg = ("%d new (%s)" % (new, ", ".join(parts)) if new else "nothing new") + \
                  (", %d removed" % gone if gone else "")
            notify("Scan done in %s: %s" % (took, msg), "info", 6000)
    if (new or gone) and xbmc.getInfoLabel("Container.PluginName") == ADDON_ID:
        xbmc.executebuiltin("Container.Refresh")


def download_loop(mon):
    w = downloads.Worker(mon)
    try:
        w.recover()
    except Exception:
        log_exc("Download queue recovery")
    while not mon.abortRequested():
        busy = False
        try:
            busy = w.tick()
        except Exception:
            log_exc("Download queue")
        if busy:
            continue
        # idle: wake on a new job or every few seconds
        for _ in range(6):
            if take_request("downloads") or mon.waitForAbort(0.5):
                break


def main():
    mon = Monitor()
    log("Service started (%s)" % xbmcaddon.Addon(ADDON_ID).getAddonInfo("version"))
    tracker = player.Tracker()
    threads = [threading.Thread(target=scan_loop, args=(mon,), name="stashbox-scan"),
               threading.Thread(target=download_loop, args=(mon,), name="stashbox-downloads")]
    for t in threads:
        t.daemon = True
        t.start()
    while not mon.abortRequested():
        try:
            tracker.tick()
        except Exception:
            pass
        if take_request("refresh"):
            fp = xbmc.getInfoLabel("Container.FolderPath")
            if fp.startswith("plugin://%s/" % ADDON_ID) and ("downloads" in fp or fp.rstrip("/").endswith(ADDON_ID)
                                                             or "action=" not in fp):
                xbmc.executebuiltin("Container.Refresh")
        if mon.waitForAbort(1):
            break
    HOME.clearProperty(player.PROP)
    log("Service stopped")


main()
