# -*- coding: utf-8 -*-
import os
import sys

import xbmcaddon

sys.path.insert(0, os.path.join(xbmcaddon.Addon("plugin.video.stashbox").getAddonInfo("path"), "resources", "lib"))

import router  # noqa: E402

router.main(sys.argv)
