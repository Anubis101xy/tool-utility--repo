# -*- coding: utf-8 -*-
"""Library queries: continue watching, next up, recently added, seasons and episodes."""
import time

import db


def _in_progress_sql():
    return ("p.watched=0 AND p.pos>60 AND (p.total IS NULL OR p.total=0 OR p.pos < p.total*0.95)")


def continue_watching(limit=40, section=None):
    sql = ("SELECT f.*, p.pos, p.total, p.last FROM progress p JOIN files f ON f.path=p.path "
           "WHERE " + _in_progress_sql())
    args = []
    if section:
        sql += " AND f.section=?"
        args.append(section)
    sql += " ORDER BY p.last DESC LIMIT ?"
    args.append(limit)
    return db.q(sql, args)


def next_episode(item_id, season, episode):
    return db.one("SELECT * FROM files WHERE item_id=? AND season>0 AND episode IS NOT NULL AND "
                  "(season>? OR (season=? AND episode>?)) ORDER BY season, episode, path LIMIT 1",
                  (item_id, season, season, episode))


def next_up(limit=40, section=None):
    """For each show you've been watching: the episode after the last one you watched."""
    sql = ("SELECT f.item_id, f.season, f.episode, p.last FROM progress p JOIN files f ON f.path=p.path "
           "JOIN items i ON i.id=f.item_id WHERE i.kind='show' AND p.watched=1 AND f.season>0")
    args = []
    if section:
        sql += " AND f.section=?"
        args.append(section)
    sql += " ORDER BY p.last DESC"
    seen, out = set(), []
    in_prog = set(r["item_id"] for r in continue_watching(200, section))
    for r in db.q(sql, args):
        if r["item_id"] in seen:
            continue
        seen.add(r["item_id"])
        if r["item_id"] in in_prog:
            continue
        # furthest watched episode of this show
        far = db.one("SELECT f.season, f.episode FROM progress p JOIN files f ON f.path=p.path WHERE f.item_id=? "
                     "AND p.watched=1 AND f.season>0 ORDER BY f.season DESC, f.episode DESC LIMIT 1", (r["item_id"],))
        nx = next_episode(r["item_id"], far["season"], far["episode"] or 0)
        while nx is not None:
            pr = db.progress(nx["path"])
            if not (pr and pr["watched"]):
                break
            nx = next_episode(r["item_id"], nx["season"], nx["episode"])
        if nx is not None:
            out.append((nx, r["last"]))
        if len(out) >= limit:
            break
    return out


def recently_added(limit=40, section=None, days=60):
    """-> list of ("movie", item_row, added) / ("show", item_row, added, new_episode_count, first_new_file)."""
    since = time.time() - days * 86400
    out = []
    args = [since]
    extra = ""
    if section:
        extra = " AND i.section=?"
        args.append(section)
    for r in db.q("SELECT i.*, MAX(f.added) fa FROM items i JOIN files f ON f.item_id=i.id WHERE i.kind='movie' "
                  "AND f.added>?" + extra + " GROUP BY i.id ORDER BY fa DESC LIMIT ?", args + [limit]):
        out.append(("movie", r, r["fa"]))
    for r in db.q("SELECT i.*, MAX(f.added) fa, COUNT(f.path) n FROM items i JOIN files f ON f.item_id=i.id "
                  "WHERE i.kind='show' AND f.added>?" + extra + " GROUP BY i.id ORDER BY fa DESC LIMIT ?",
                  args + [limit]):
        out.append(("show", r, r["fa"], r["n"]))
    out.sort(key=lambda x: -(x[2] or 0))
    return out[:limit]


def items(section, order="title", where="", args=()):
    orders = {"title": "COALESCE(i.sorttitle, i.title) COLLATE NOCASE", "added": "i.added DESC",
              "year": "i.year DESC, i.title", "rating": "i.rating DESC"}
    sql = "SELECT i.* FROM items i WHERE i.section=?" + (" AND " + where if where else "") + \
          " ORDER BY " + orders.get(order, orders["title"])
    return db.q(sql, (section,) + tuple(args))


def unwatched_movies(section):
    return db.q("SELECT i.* FROM items i WHERE i.section=? AND i.kind='movie' AND NOT EXISTS ("
                "SELECT 1 FROM files f JOIN progress p ON p.path=f.path WHERE f.item_id=i.id AND p.watched=1) "
                "ORDER BY COALESCE(i.sorttitle, i.title) COLLATE NOCASE", (section,))


def show_stats(item_ids):
    """item_id -> (episodes on NAS, watched)."""
    out = {}
    if not item_ids:
        return out
    ids = list(item_ids)
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        for r in db.q("SELECT f.item_id, COUNT(DISTINCT f.season || 'x' || f.episode) n, "
                      "COUNT(DISTINCT CASE WHEN p.watched=1 THEN f.season || 'x' || f.episode END) w "
                      "FROM files f LEFT JOIN progress p ON p.path=f.path WHERE f.season>0 AND f.item_id IN (%s) "
                      "GROUP BY f.item_id" % ",".join("?" * len(chunk)), chunk):
            out[r["item_id"]] = (r["n"], r["w"])
    return out


def season_files(item_id):
    """season -> list of file rows."""
    out = {}
    for r in db.item_files(item_id):
        out.setdefault(r["season"] if r["season"] is not None else 0, []).append(r)
    return out


def genres(section):
    seen = {}
    for r in db.q("SELECT genres FROM items WHERE section=? AND genres<>''", (section,)):
        for g in (r["genres"] or "").split(", "):
            if g:
                seen[g] = seen.get(g, 0) + 1
    return sorted(seen.items())


def collections(section):
    """Your collection folders ("Harry Potter Collection", "Pixar Pack") and TMDB's film series, merged.
    -> [{"kind": "tmdb"/"folder", "name", "n", "poster", "fanart", "id" | "root"+"coll", "folder_name"}]"""
    tm = {}
    for r in db.q("SELECT id, collection_id, collection, poster, fanart FROM items WHERE section=? AND "
                  "collection_id IS NOT NULL", (section,)):
        c = tm.setdefault(r["collection_id"], {"kind": "tmdb", "id": r["collection_id"], "name": r["collection"],
                                               "items": set(), "poster": r["poster"], "fanart": r["fanart"],
                                               "folder_name": None})
        c["items"].add(r["id"])
    folders = {}
    for r in db.q("SELECT root, coll, item_id FROM files WHERE section=? AND COALESCE(coll, '')<>''", (section,)):
        folders.setdefault((r["root"], r["coll"]), set()).add(r["item_id"])
    out = []
    for (root, coll), items in sorted(folders.items(), key=lambda x: x[0][1].lower()):
        name = coll.rsplit("/", 1)[-1]
        # a folder that's just one TMDB series (your "Harry Potter Collection") shows as that series - it knows
        # which films are missing - under your folder's name
        best = None
        for c in tm.values():
            if items <= c["items"] and (best is None or len(c["items"]) < len(best["items"])):
                best = c
        if best is not None:
            best["folder_name"] = best["folder_name"] or name
            continue
        first = db.one("SELECT poster, fanart FROM items WHERE id IN (%s) AND poster<>'' ORDER BY year LIMIT 1" %
                       ",".join(str(int(i)) for i in items))
        out.append({"kind": "folder", "root": root, "coll": coll, "name": name, "n": len(items),
                    "poster": first["poster"] if first else "", "fanart": first["fanart"] if first else ""})
    for c in tm.values():
        if len(c["items"]) > 1 or c["folder_name"]:
            out.append(dict(c, n=len(c["items"]), name=c["folder_name"] or c["name"]))
    for c in out:
        c.pop("items", None)
    return sorted(out, key=lambda c: c["name"].lower())


def collection_order(item_ids):
    """item_id -> your order number ("01 ...") where there is one."""
    ids = [int(i) for i in item_ids]
    if not ids:
        return {}
    return dict((r["item_id"], r["o"]) for r in db.q(
        "SELECT item_id, MIN(ord) o FROM files WHERE ord IS NOT NULL AND item_id IN (%s) GROUP BY item_id" %
        ",".join(str(i) for i in ids)))


def search(text):
    t = "%" + text.strip() + "%"
    return db.q("SELECT * FROM items WHERE title LIKE ? OR original LIKE ? ORDER BY section, title", (t, t))


def on_nas(kind, tmdb_id):
    if not tmdb_id:
        return []
    return db.q("SELECT * FROM items WHERE kind=? AND tmdb=?", (kind, tmdb_id))
