# -*- coding: utf-8 -*-
"""Runs in the service: remembers where you stopped, marks things watched, plays the next episode."""
import json
import time

import xbmc

import db
import library
from common import ADDON_ID, HOME, log, notify, setting_bool, setting_int

PROP = "stashbox.now"


def _same_file(a, b):
    a = (a or "").replace("\\", "/").rstrip("/")
    b = (b or "").replace("\\", "/").rstrip("/")
    return a == b or (a.rsplit("/", 1)[-1] == b.rsplit("/", 1)[-1] and a.rsplit("/", 1)[-1] != "")


class Tracker(xbmc.Player):
    def __init__(self):
        super(Tracker, self).__init__()
        self.cur = None
        self.pos = 0.0
        self.total = 0.0
        self.last_save = 0.0

    def onAVStarted(self):
        raw = HOME.getProperty(PROP)
        if not raw:
            self.cur = None
            return
        try:
            d = json.loads(raw)
        except ValueError:
            return
        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            playing = ""
        if not _same_file(playing, d.get("path")):
            self.cur = None
            return
        HOME.clearProperty(PROP)
        self.cur = d
        self.pos = float(d.get("start") or 0)
        self.total = 0.0
        self.last_save = time.time()

    def tick(self):
        if not self.cur:
            return
        try:
            if not self.isPlayingVideo():
                return
            self.pos = self.getTime()
            self.total = self.getTotalTime() or self.total
        except RuntimeError:
            return
        if time.time() - self.last_save > 30 and self.pos > 60:
            self.last_save = time.time()
            try:
                db.save_progress(self.cur["path"], self.pos, self.total, None)
            except Exception as e:
                log("Saving position: %s" % e, "warn")

    def onPlayBackStopped(self):
        self._finish(False)

    def onPlayBackEnded(self):
        self._finish(True)

    def onPlayBackError(self):
        self.cur = None

    def _finish(self, ended):
        d, self.cur = self.cur, None
        if not d:
            return
        path = d["path"]
        pct = (self.pos / self.total) if self.total else 0
        watched = ended or pct >= setting_int("watched_pct", 90) / 100.0
        try:
            if watched:
                db.mark_watched([path], True)
            elif self.pos > 60:
                db.save_progress(path, self.pos, self.total, False)
        except Exception as e:
            log("Saving watched state: %s" % e, "warn")
        if xbmc.getInfoLabel("Container.PluginName") == ADDON_ID:
            xbmc.executebuiltin("Container.Refresh")
        if ended and d.get("item") and d.get("season") is not None and setting_bool("autoplay_next", True):
            try:
                nx = library.next_episode(d["item"], d["season"], d.get("episode") or 0)
            except Exception:
                nx = None
            if nx is not None:
                from urllib.parse import urlencode
                notify("Up next: S%02dE%02d" % (nx["season"], nx["episode"] or 0), "info", 4000)
                xbmc.sleep(1500)
                url = "plugin://%s/?%s" % (ADDON_ID, urlencode({"action": "play", "f": nx["path"], "auto": "1"}))
                xbmc.executebuiltin("PlayMedia(%s)" % url)
