# -*- coding: utf-8 -*-
"""Download queue: torrents / TorBox cloud items / file-host links -> files on the NAS with Plex-style names.

The plugin only writes job files (and marker files to cancel / retry / remove). The background service owns the
queue and runs one job at a time, so downloads carry on after you leave the add-on."""
import glob
import io
import json
import os
import re
import time
import uuid
import zipfile

import requests

import debrid
import names
import tmdb
import vfs
from common import (NAME, PROFILE, UA, ensure_profile, fmt_size, fmt_speed, hide_creds, log, notify, npath,
                    replace_file, request, setting_bool, setting_int, under)

JOBS = os.path.join(PROFILE, "jobs")
ACTIVE = ("queued", "waiting", "downloading", "extracting")


class Cancelled(Exception):
    pass


# ---------------------------------------------------------------- job files (shared with the plugin)
def _p(jid, extn="json"):
    return os.path.join(JOBS, "%s.%s" % (jid, extn))


def load(jid):
    try:
        with open(_p(jid), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save(job):
    ensure_profile()
    if not os.path.isdir(JOBS):
        os.makedirs(JOBS, exist_ok=True)
    tmp = _p(job["id"]) + ".tmp%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(job, f)
    replace_file(tmp, _p(job["id"]))


def all_jobs():
    out = []
    for p in glob.glob(os.path.join(JOBS, "*.json")):
        try:
            with open(p, "r", encoding="utf-8") as f:
                out.append(json.load(f))
        except Exception:
            continue
    return sorted(out, key=lambda j: j.get("created", 0))


def add(job):
    job.setdefault("id", uuid.uuid4().hex[:12])
    job.setdefault("created", time.time())
    job.update(status="queued", msg="Waiting its turn", progress=0, done_bytes=0, total_bytes=0, speed=0)
    save(job)
    request("downloads")
    log("Queued: %s (%s)" % (job.get("title"), job.get("source", {}).get("type")))
    return job["id"]


def mark(jid, what):
    """cancel / retry / remove from the plugin side."""
    ensure_profile()
    os.makedirs(JOBS, exist_ok=True)
    open(_p(jid, what), "w").close()
    request("downloads")


def _take_marker(jid, what):
    p = _p(jid, what)
    if os.path.exists(p):
        try:
            os.remove(p)
        except OSError:
            pass
        return True
    return False


def counts():
    n = {"active": 0, "failed": 0, "done": 0}
    for j in all_jobs():
        st = j.get("status")
        if st in ACTIVE:
            n["active"] += 1
        elif st == "failed":
            n["failed"] += 1
        elif st == "done":
            n["done"] += 1
    return n


# ---------------------------------------------------------------- reading remote zips without downloading them twice
class HTTPReader(io.RawIOBase):
    """Seekable reader over an https link using Range requests (so zipfile can pull single members)."""

    def __init__(self, url):
        self.url = url
        self.pos = 0
        self.resp = None
        self.rpos = None
        r = requests.get(url, headers=dict(UA, Range="bytes=0-0"), stream=True, timeout=30, allow_redirects=True)
        cr = r.headers.get("Content-Range", "")
        r.close()
        m = re.search(r"/(\d+)$", cr)
        if r.status_code != 206 or not m:
            raise IOError("the server can't send parts of the file")
        self.size = int(m.group(1))

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, off, whence=0):
        if whence == 1:
            off += self.pos
        elif whence == 2:
            off += self.size
        self.pos = max(0, min(off, self.size))
        return self.pos

    def _open(self):
        if self.resp is not None:
            self.resp.close()
        self.resp = requests.get(self.url, headers=dict(UA, Range="bytes=%d-" % self.pos), stream=True, timeout=60)
        if self.resp.status_code != 206:
            raise IOError("HTTP %s when reading part of the archive" % self.resp.status_code)
        self.rpos = self.pos

    def read(self, n=-1):
        if n is None or n < 0:
            n = self.size - self.pos
        n = min(n, self.size - self.pos)
        if n <= 0:
            return b""
        if self.resp is None or self.rpos != self.pos:
            self._open()
        chunks = []
        got = 0
        while got < n:
            b = self.resp.raw.read(n - got)
            if not b:
                break
            chunks.append(b)
            got += len(b)
        data = b"".join(chunks)
        self.pos += len(data)
        self.rpos = self.pos
        return data

    def readinto(self, buf):
        b = self.read(len(buf))
        buf[:len(b)] = b
        return len(b)

    def close(self):
        if self.resp is not None:
            self.resp.close()
        super(HTTPReader, self).close()


# ---------------------------------------------------------------- deciding where each file goes
def _season_count(media, s):
    for x in media.get("seasons") or []:
        if x.get("n") == s:
            return x.get("count") or 0
    return 0


def _episode_of(entry_name, job, single_video):
    """-> list of (season, episode, ep_end) a video file holds, [] if it's not wanted / can't tell."""
    want = job["want"]
    media = job["media"]
    base = entry_name.replace("\\", "/").rsplit("/", 1)[-1]
    p = names.parse_episode(base)
    se = None
    if p and not p["absolute"]:
        se = (p["season"], p["episode"], p["ep_end"])
    elif p and p["absolute"]:
        # a season-folder inside the torrent ("Season 2/05.mkv") wins
        parts = entry_name.replace("\\", "/").split("/")[:-1]
        sdir = None
        for d in reversed(parts):
            sdir = names.season_from_dir(d)
            if sdir is not None:
                break
        ws = want.get("season")
        cnt = _season_count(media, sdir) if sdir is not None else 0
        if sdir is not None and (not cnt or p["episode"] <= cnt):
            se = (sdir, p["episode"], p["ep_end"])
        elif ws and ws > 1 and job.get("season_pack") and p["episode"] <= _season_count(media, ws):
            se = (ws, p["episode"], p["ep_end"])  # season 2 batch numbered from 1
        elif media.get("seasons"):
            s, e = tmdb.absolute_to_se(media["seasons"], p["episode"])
            end = e + (p["ep_end"] - p["episode"]) if p["ep_end"] else None
            se = (s, e, end)
        else:
            se = (ws or 1, p["episode"], p["ep_end"])
    elif single_video and want.get("mode") == "episode":
        s, e = want["episodes"][0]
        se = (s, e, None)
    if not se:
        return None
    s, e, end = se
    mode = want.get("mode")
    if mode == "episode":
        wanted = set(tuple(x) for x in want["episodes"])
        if not any((s, x) in wanted for x in range(e, (end or e) + 1)):
            if single_video:  # trust the user's pick if the name is odd
                s, e = want["episodes"][0]
                end = None
            else:
                return None
    elif mode == "season":
        if s != want["season"]:
            return None
        if want.get("episodes"):
            eps = set(want["episodes"])
            if not any(x in eps for x in range(e, (end or e) + 1)):
                return None
    if want.get("skip_have"):
        have = set(tuple(x) for x in media.get("have") or [])
        if all((s, x) in have for x in range(e, (end or e) + 1)):
            return None
    return s, e, end


def _show_dir(job):
    m = job["media"]
    return m.get("folder") or vfs.join(job["root"], names.title_year(m["title"], m.get("year")))


def _season_dir(job, s):
    m = job["media"]
    known = (m.get("season_dirs") or {}).get(str(s))
    return known or vfs.join(_show_dir(job), names.season_dirname(s))


def plan(job, entries):
    """entries: [{"name", "size", ...}] -> list of (entry, dest path, what) where what is video / sub / archive."""
    vids = [e for e in entries if names.is_video(e["name"]) and not names.is_sample(e["name"])
            and not any(names.skip_dir(d) for d in e["name"].replace("\\", "/").split("/")[:-1])]
    subs = [e for e in entries if names.is_sub(e["name"])] if setting_bool("include_subs", True) else []
    arcs = [e for e in entries if names.is_archive(e["name"])]
    m = job["media"]
    out = []
    if job["kind"] == "raw":  # "save it as it is": keep the torrent's own folders and names
        for e in entries:
            parts = [names.safe(x) for x in e["name"].replace("\\", "/").split("/") if x]
            out.append((e, vfs.join(job["root"], *parts), "file"))
        return out
    if job["kind"] == "movie":
        if vids:
            v = max(vids, key=lambda e: e.get("size") or 0)
            if m.get("loose_name"):  # joining a numbered collection folder: "04 Harry Potter and ... (2005).mkv"
                folder, base = job["root"], m["loose_name"]
            else:
                folder = m.get("folder") or vfs.join(job["root"], names.title_year(m["title"], m.get("year")))
                base = names.title_year(m["title"], m.get("year"))
            dest = vfs.join(folder, base + names.ext(v["name"]))
            if m.get("folder") and vfs.exists(dest) and vfs.stat(dest)[0] != (v.get("size") or 0):
                # another version of a film you already have: keep both, Plex-style "Title (Year) - 2160p"
                base += " - %s" % names.resolution(v["name"]).replace("SD?", "other")
                dest = vfs.join(folder, base + names.ext(v["name"]))
            out.append((v, dest, "video"))
            used = set()
            for s in subs[:4]:
                suf = names.sub_suffix(s["name"])
                nm = base + suf + names.ext(s["name"])
                n = 2
                while nm in used:
                    nm = "%s%s.%d%s" % (base, suf, n, names.ext(s["name"]))
                    n += 1
                used.add(nm)
                out.append((s, vfs.join(folder, nm), "sub"))
        elif arcs:
            for a in arcs:
                out.append((a, vfs.join(m.get("folder") or vfs.join(job["root"], names.title_year(
                    m["title"], m.get("year"))), vfs.basename(a["name"])), "archive"))
        return out
    single = len(vids) == 1
    taken = {}
    for v in vids:
        se = _episode_of(v["name"], job, single)
        if not se:
            continue
        s, e, end = se
        if (s, e) in taken and (taken[(s, e)][0].get("size") or 0) >= (v.get("size") or 0):
            continue  # two copies of one episode: keep the bigger
        dest = vfs.join(_season_dir(job, s), names.episode_filename(m["title"], m.get("year"), s, e,
                                                                   names.ext(v["name"]), end))
        taken[(s, e)] = (v, dest)
    for (s, e), (v, dest) in sorted(taken.items()):
        out.append((v, dest, "video"))
        vstem = names.stem(v["name"]).lower()
        for sb in subs:
            if names.stem(sb["name"]).lower().startswith(vstem) or names.episode_for(sb["name"], s, e) is True:
                out.append((sb, dest[:-len(names.ext(dest))] + names.sub_suffix(sb["name"]) + names.ext(sb["name"]),
                            "sub"))
                break
    if not taken and arcs:
        for a in arcs:
            out.append((a, vfs.join(_show_dir(job), vfs.basename(a["name"])), "archive"))
    return out


# ---------------------------------------------------------------- the worker (runs in the service)
class Worker(object):
    def __init__(self, monitor):
        self.monitor = monitor
        self.bg = None
        self.last_save = 0
        self.last_marker_check = 0

    # -- housekeeping
    def recover(self):
        """After a Kodi restart, anything that was mid-way starts again (finished files are skipped)."""
        for j in all_jobs():
            if j.get("status") in ("waiting", "downloading", "extracting"):
                j["status"] = "queued"
                j["msg"] = "Restarting after Kodi restarted"
                save(j)

    def markers(self):
        for p in glob.glob(os.path.join(JOBS, "*.remove")) + glob.glob(os.path.join(JOBS, "*.retry")) + \
                glob.glob(os.path.join(JOBS, "*.cancel")):
            jid, what = os.path.basename(p).rsplit(".", 1)
            j = load(jid)
            if j is None:
                _take_marker(jid, what)
                continue
            if what == "remove" and j.get("status") not in ("downloading", "extracting", "waiting"):
                _take_marker(jid, what)
                try:
                    os.remove(_p(jid))
                except OSError:
                    pass
            elif what == "retry" and j.get("status") in ("failed", "cancelled"):
                _take_marker(jid, what)
                j.update(status="queued", msg="Trying again", error=None)
                save(j)
            elif what == "cancel" and j.get("status") == "queued":
                _take_marker(jid, what)
                j.update(status="cancelled", msg="Cancelled")
                save(j)
            elif what in ("retry", "remove") and j.get("status") not in ACTIVE + ("failed", "cancelled"):
                _take_marker(jid, what)
                if what == "remove":
                    try:
                        os.remove(_p(jid))
                    except OSError:
                        pass

    def next_job(self):
        for j in all_jobs():
            if j.get("status") == "queued":
                return j
        return None

    def tick(self):
        self.markers()
        j = self.next_job()
        if not j:
            return False
        try:
            self.process(j)
        except Cancelled:
            j = load(j["id"]) or j
            j.update(status="cancelled", msg="Cancelled", speed=0)
            save(j)
            log("Cancelled: %s" % j.get("title"))
        except Exception as e:
            import traceback
            j = load(j["id"]) or j
            j.update(status="failed", msg=str(e)[:300], error=str(e)[:300], speed=0)
            save(j)
            log("Download failed: %s - %s\n%s" % (j.get("title"), e, traceback.format_exc()), "error")
            notify("Download failed: %s - %s" % (j.get("title"), e), "error", 8000)
        finally:
            self._bg_close()
        return True

    # -- progress
    def update(self, job, force=False, **kw):
        job.update(kw)
        now = time.time()
        if now - self.last_marker_check > 2:
            self.last_marker_check = now
            if _take_marker(job["id"], "cancel"):
                raise Cancelled()
            if self.monitor.abortRequested():
                raise Cancelled()
        if force or now - self.last_save > 2:
            self.last_save = now
            try:
                save(job)
            except OSError as e:  # only a progress update - never let it stop a download or a move
                log("Saving progress of '%s': %s" % (job.get("title"), e), "warn")
            if self.bg is not None:
                try:
                    self.bg.update(int(job.get("progress") or 0), "%s: %s" % (NAME, job.get("title", "")[:40]),
                                   job.get("msg", "")[:80])
                except Exception:
                    pass

    def _bg_open(self, job):
        if setting_bool("bg_progress", True) and self.bg is None:
            try:
                import xbmcgui
                self.bg = xbmcgui.DialogProgressBG()
                self.bg.create("%s: %s" % (NAME, job.get("title", "")[:40]), "Starting")
            except Exception:
                self.bg = None

    def _bg_close(self):
        if self.bg is not None:
            try:
                self.bg.close()
            except Exception:
                pass
            self.bg = None

    def sleep(self, job, secs):
        end = time.time() + secs
        while time.time() < end:
            if self.monitor.waitForAbort(1):
                raise Cancelled()
            self.update(job)

    # -- getting the file list from wherever the job comes from
    def files_from_service(self, job):
        src = job["source"]
        order = src.get("order") or [src.get("svc") or "tb"]
        if setting_bool("svc_fallback", True):
            order = order + [s for s in debrid.available() if s not in order]
        errors = []
        deadline_h = max(1, setting_int("max_wait_hours", 12))
        for s in order:
            if not debrid.ready(s):
                continue
            label = debrid.NAMES[s]
            try:
                obj = debrid.get(s)
                if src.get("svc_used") == s and src.get("handle"):
                    h = src["handle"]
                else:
                    self.update(job, force=True, status="waiting", msg="Adding to %s..." % label)
                    h = obj.start(src["hash"], src.get("name", ""))
                    src.update(svc_used=s, handle=h)
                    save(job)
                start_t = time.time()
                end = start_t + deadline_h * 3600
                while True:
                    st = obj.status(h)
                    if st.get("error"):
                        raise debrid.DebridError(st["error"])
                    if st.get("ready") and st.get("files"):
                        return s, obj, h, st["files"]
                    if time.time() > end:
                        raise debrid.DebridError("%s didn't finish it within %d hours" % (label, deadline_h))
                    self.update(job, status="waiting", progress=0,
                                msg="%s: %s %d%%" % (label, st.get("state") or "", st.get("progress") or 0))
                    waited = time.time() - start_t
                    self.sleep(job, 10 if waited < 120 else 30 if waited < 1800 else 60)
            except debrid.DebridError as e:
                errors.append("%s: %s" % (label, e))
                log("%s couldn't get '%s': %s" % (label, job.get("title"), e), "warn")
                src.pop("handle", None)
                src.pop("svc_used", None)
                continue
        raise debrid.DebridError(" | ".join(errors) or "no torrent service is set up (Tools > Accounts)")

    def process(self, job):
        job.update(status="waiting", msg="Starting", error=None, progress=0, speed=0)
        save(job)
        self._bg_open(job)
        src = job["source"]
        if src["type"] == "organise":
            return self.organise(job)
        obj, h, s = None, None, None
        if src["type"] == "torrent":
            s, obj, h, files = self.files_from_service(job)
        elif src["type"] == "tbcloud":
            s, obj, h = "tb", debrid.TorBox(debrid.tb_key()), src["id"]
            st = obj.status(h, src.get("kind", "torrents"))
            if not st.get("ready"):
                raise debrid.DebridError("it isn't finished on TorBox yet (%s %d%%)" % (st["state"], st["progress"]))
            files = st["files"]
        elif src["type"] == "link":
            self.update(job, force=True, msg="Unlocking the link...")
            url, via = debrid.unlock(src["url"])
            files = [{"id": 0, "name": src.get("name") or _name_from_url(url), "size": 0, "url": url}]
            s = via
        else:  # direct
            files = [{"id": 0, "name": src.get("name") or _name_from_url(src["url"]), "size": 0, "url": src["url"]}]
        todo = plan(job, files)
        if not todo:
            vids = [f["name"] for f in files if names.is_video(f["name"])]
            raise RuntimeError("nothing to save - %s" % (
                "none of the files are the episodes you wanted" if vids else "no video files in it"))
        job["files"] = [{"name": e["name"], "dest": hide_creds(d), "what": w, "done": False} for e, d, w in todo]
        job["total_bytes"] = sum(int(e.get("size") or 0) for e, _d, _w in todo)
        job["done_bytes"] = 0
        notes = []
        tops = set()
        for i, (entry, dest, what) in enumerate(todo):
            self.update(job, force=True, status="downloading",
                        msg="File %d of %d: %s" % (i + 1, len(todo), vfs.basename(dest)))
            if vfs.exists(dest):
                size, _ = vfs.stat(dest)
                if not entry.get("size") or not size or size == entry["size"]:
                    job["done_bytes"] += int(entry.get("size") or 0)
                    job["files"][i]["done"] = True
                    tops.add(_item_folder(job, dest))
                    continue
            url = entry.get("url") or self._link(obj, s, h, src, entry)
            if what == "archive":
                got = self.extract(job, url, entry, dest)
                if got is None:
                    notes.append("%s couldn't be unpacked here - saved as-is, unpack it on the NAS" %
                                 vfs.basename(dest))
                    self.fetch(job, url, dest, entry)
                    tops.add(_item_folder(job, dest))
                else:
                    tops.update(got)
            else:
                self.fetch(job, url, dest, entry)
                tops.add(_item_folder(job, dest))
            job["files"][i]["done"] = True
        # into the library
        self.update(job, force=True, msg="Adding to the library...", progress=100)
        try:
            import scanner
            for t in tops if job.get("section") else []:
                scanner.scan_folder(job["section"], t)
        except Exception as e:
            log("Library update after download: %s" % e, "warn")
        request("refresh")
        if setting_bool("cleanup_debrid", False) and obj is not None and h and src["type"] == "torrent":
            try:
                obj.delete(h)
            except Exception:
                pass
        msg = "Saved %d file%s to the NAS" % (len(todo), "" if len(todo) == 1 else "s")
        if notes:
            msg += " - " + "; ".join(notes)
        job.update(status="done", msg=msg, progress=100, speed=0, finished=time.time())
        save(job)
        log("Done: %s -> %s" % (job.get("title"), ", ".join(hide_creds(t) for t in tops)))
        if setting_bool("notify_done", True):
            notify("On your NAS now: %s" % job.get("title"), "info", 6000)

    # -- moving files around the NAS ("put it all in one place")
    def organise(self, job):
        import db
        is_music = job.get("kind") == "music"
        if is_music:
            import music
            move_record = music.move_track
        else:
            move_record = db.move_path
        moves = job["moves"]
        todo = [m for m in moves if not m.get("done")]
        total = float(sum(m["size"] or 0 for m in todo)) or 1.0
        done_b, moved, problems = 0.0, 0, []
        self.update(job, force=True, status="downloading", msg="Moving %d files..." % len(todo))
        for i, mv in enumerate(moves):
            if mv.get("done"):
                continue
            src, dst = mv["src"], mv["dst"]
            name = vfs.basename(dst)
            if not vfs.exists(src):
                if vfs.exists(dst):  # moved before Kodi was restarted
                    move_record(src, dst)
                    mv["done"] = True
                    continue
                mv["error"] = "not there any more"
                problems.append("%s: %s" % (vfs.basename(src), mv["error"]))
                continue
            if vfs.exists(dst):
                mv["error"] = "a file with that name is already there"
                problems.append("%s: %s" % (name, mv["error"]))
                continue
            vfs.mkdirs(vfs.parent(dst))
            self.update(job, force=True, progress=min(99, int(100 * done_b / total)),
                        msg="%d of %d: %s" % (i + 1, len(moves), name))
            if not vfs.move_fast(src, dst):  # different drive: copy it across, check it, then remove the original
                self._copy(job, src, dst, mv, done_b, total)
                if not vfs.delete(src):
                    mv["note"] = "copied, but the original couldn't be removed"
                    problems.append("%s: %s" % (name, mv["note"]))
                mv["copied"] = True
            move_record(src, dst)
            mv["done"] = True
            moved += 1
            done_b += mv["size"] or 0
            save(job)
        # tidy up: empty season / show folders left behind (never anything above the show's own folder,
        # and never one of your StashBox folders themselves)
        from common import all_locations, music_locations
        roots = set(npath(loc["path"]) for _s, loc in all_locations()) | set(npath(x["path"]) for x in
                                                                             music_locations())
        for h in job.get("tidy") or []:
            if npath(h) in roots or any(under(r, h) for r in roots) or npath(h) == npath(vfs.share_root(h)):
                continue  # never one of your StashBox folders, or a whole share
            for d in sorted(set(vfs.parent(m["src"]) for m in moves if m.get("done") and under(m["src"], h)),
                            key=len, reverse=True):
                if under(d, h) and npath(d) != npath(h):
                    vfs.rmdir_if_empty(d)
            vfs.rmdir_if_empty(h)
        self.update(job, force=True, msg="Updating the library...", progress=100)
        try:
            if is_music:
                pass  # the tracks' rows were moved with the files
            elif job.get("section"):
                import scanner
                scanner.scan_section(job["section"], None, sorted(set([job["root"]] + (job.get("tidy") or []))))
        except Exception as e:
            log("Library update after moving: %s" % e, "warn")
        request("refresh")
        msg = "Moved %d file%s" % (moved, "" if moved == 1 else "s")
        if problems:
            msg += " - %d problem%s (see the error)" % (len(problems), "" if len(problems) == 1 else "s")
        job.update(status="done" if moved or not problems else "failed", msg=msg, progress=100, speed=0,
                   finished=time.time(), error="\n".join(problems) or None)
        save(job)
        log("Organise '%s': %s%s" % (job.get("title"), msg, (": " + "; ".join(problems[:10])) if problems else ""))
        notify("%s: %s" % (job.get("title"), msg), "warn" if problems else "info", 6000)

    def _copy(self, job, src, dst, mv, base_done, total):
        part = dst + ".part"
        size = vfs.stat(src)[0]
        f = xbmcvfs_file(src)
        w = vfs.Writer(part)
        got, last_t, last_got = 0, time.time(), 0
        try:
            while True:
                b = bytes(f.readBytes(4 * 1024 * 1024))
                if not b:
                    break
                w.write(b)
                got += len(b)
                now = time.time()
                if now - last_t >= 2:
                    speed = (got - last_got) / (now - last_t)
                    last_t, last_got = now, got
                    self.update(job, speed=speed, progress=min(99, int(100 * (base_done + got) / total)),
                                msg="Copying to the other drive: %s - %s of %s  %s" % (
                                    vfs.basename(dst)[:40], fmt_size(got), fmt_size(size), fmt_speed(speed)))
        except Cancelled:
            w.close()
            f.close()
            vfs.delete(part)
            raise
        f.close()
        w.close()
        if size and vfs.stat(part)[0] != size:
            vfs.delete(part)
            raise IOError("the copy of %s came out the wrong size - original left where it was" % vfs.basename(src))
        if not vfs.rename(part, dst):
            vfs.delete(part)
            raise IOError("couldn't finish the copy of %s" % vfs.basename(src))

    def _link(self, obj, s, h, src, entry):
        if obj is None:
            raise RuntimeError("no service to get the file from")
        if s == "tb" and src["type"] == "tbcloud":
            return obj.link(h, entry["id"], src.get("kind", "torrents"))
        return obj.link(h, entry["id"])

    # -- moving bytes
    def fetch(self, job, url, dest, entry):
        vfs.mkdirs(vfs.parent(dest))
        part = dest + ".part"
        last_err = None
        for attempt in range(3):
            try:
                self._stream(job, url, part, entry)
                if not vfs.rename(part, dest):
                    raise IOError("couldn't rename the finished file on the NAS")
                return
            except Cancelled:
                vfs.delete(part)
                raise
            except (requests.RequestException, IOError, OSError) as e:
                last_err = e
                log("Download attempt %d failed for %s: %s" % (attempt + 1, vfs.basename(dest), e), "warn")
                vfs.delete(part)
                if "refused the write" in str(e):
                    break
                self.sleep(job, 5 * (attempt + 1))
        raise IOError("couldn't download %s (%s)" % (vfs.basename(dest), last_err))

    def _stream(self, job, url, part, entry):
        base_done = job["done_bytes"]
        r = requests.get(url, headers=UA, stream=True, timeout=(20, 90), allow_redirects=True)
        if r.status_code >= 400:
            r.close()
            raise IOError("HTTP %s from the download server" % r.status_code)
        total = int(r.headers.get("Content-Length") or 0) or int(entry.get("size") or 0)
        if total and not entry.get("size"):
            entry["size"] = total
            job["total_bytes"] = max(job["total_bytes"], base_done + total)
        w = vfs.Writer(part)
        got, t0, last_t, last_got = 0, time.time(), time.time(), 0
        try:
            for chunk in r.iter_content(1024 * 1024):
                if not chunk:
                    continue
                w.write(chunk)
                got += len(chunk)
                now = time.time()
                if now - last_t >= 2:
                    speed = (got - last_got) / (now - last_t)
                    last_t, last_got = now, got
                    tb = job["total_bytes"] or (base_done + total)
                    pct = int(100.0 * (base_done + got) / tb) if tb else 0
                    self.update(job, speed=speed, progress=min(99, pct),
                                msg="%s - %s of %s  %s" % (vfs.basename(part[:-5])[:50], fmt_size(got),
                                                          fmt_size(total) if total else "?", fmt_speed(speed)))
        finally:
            r.close()
            w.close()
        if total and got < total:
            raise IOError("the download stopped early (%s of %s)" % (fmt_size(got), fmt_size(total)))
        job["done_bytes"] = base_done + got

    def extract(self, job, url, entry, dest):
        """Unpack a zip straight from the link into the right places. -> set of top folders, or None if we can't."""
        if not entry["name"].lower().endswith(".zip"):
            return None
        try:
            reader = HTTPReader(url)
            zf = zipfile.ZipFile(reader)
        except (IOError, OSError, zipfile.BadZipFile, requests.RequestException) as e:
            log("Can't open %s remotely (%s) - will save the zip instead" % (entry["name"], e), "warn")
            return None
        members = [{"name": i.filename, "size": i.file_size, "zi": i} for i in zf.infolist() if not i.is_dir()]
        todo = plan(job, members)
        if not todo:
            raise RuntimeError("the zip has none of the files you wanted")
        job["total_bytes"] += sum(m["size"] for m, _d, _w in todo) - int(entry.get("size") or 0)
        tops = set()
        for m, d, _w in todo:
            if vfs.exists(d):
                job["done_bytes"] += m["size"]
                tops.add(_item_folder(job, d))
                continue
            self.update(job, force=True, status="extracting", msg="Unpacking %s" % vfs.basename(d))
            vfs.mkdirs(vfs.parent(d))
            part = d + ".part"
            w = vfs.Writer(part)
            got, last_t = 0, time.time()
            try:
                with zf.open(m["zi"]) as src:
                    while True:
                        b = src.read(1024 * 1024)
                        if not b:
                            break
                        w.write(b)
                        got += len(b)
                        if time.time() - last_t > 2:
                            last_t = time.time()
                            tb = job["total_bytes"] or 1
                            self.update(job, progress=min(99, int(100.0 * (job["done_bytes"] + got) / tb)),
                                        msg="Unpacking %s - %s" % (vfs.basename(d)[:50], fmt_size(got)))
            except Cancelled:
                w.close()
                vfs.delete(part)
                raise
            w.close()
            vfs.rename(part, d)
            job["done_bytes"] += got
            tops.add(_item_folder(job, d))
        reader.close()
        return tops


def xbmcvfs_file(path):
    import xbmcvfs
    return xbmcvfs.File(path)


def undo_moves(job):
    """A new job that moves everything from an organise job back where it was."""
    back = [{"src": m["dst"], "dst": m["src"], "size": m.get("size") or 0, "video": m.get("video")}
            for m in job.get("moves") or [] if m.get("done")]
    if not back:
        return None
    tidy = sorted(set(npath(vfs.parent(m["src"])) for m in back))  # folders the first job filled (or made)
    return add({"title": "Undo: " + job.get("title", ""), "section": job.get("section"),
                "root": vfs.parent(back[0]["dst"]), "kind": job.get("kind") or "organise",
                "source": {"type": "organise"},
                "moves": back, "tidy": tidy, "undo_of": job["id"], "media": {}, "want": {}})


def _name_from_url(url):
    n = requests.utils.unquote(url.split("?")[0].rstrip("/").rsplit("/", 1)[-1])
    return n or "download"


def _item_folder(job, dest):
    """The movie / show folder a new file went into (what the library rescans straight away)."""
    if job["kind"] == "show":
        return _show_dir(job)
    return vfs.parent(dest)
