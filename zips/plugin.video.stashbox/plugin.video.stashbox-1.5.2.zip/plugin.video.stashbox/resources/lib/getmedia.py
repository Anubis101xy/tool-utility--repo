# -*- coding: utf-8 -*-
"""Get new media onto the NAS: browse/search TMDB, list torrents, pick a service, queue background downloads."""
import datetime
import re

import xbmc
import xbmcgui
import xbmcplugin

import db
import debrid
import downloads
import library
import names
import scrapers
import tmdb
import vfs
from common import (NAME, SECTION_KIND, SECTION_LABEL, SECTIONS, fmt_size, loc_label, locations, log, notify, npath,
                    section_path, setting, setting_int)
from kodiui import add, color, end, fail_dir, handle, item, refresh, run, set_info, url

RES_RANK = scrapers.RES_RANK


def _today(offset=0):
    return (datetime.date.today() + datetime.timedelta(days=offset)).isoformat()


def lists(sec):
    if sec == "movies":
        return [("trending", "Trending this week", "/trending/movie/week", {}),
                ("popular", "Popular", "/movie/popular", {}),
                ("now", "In cinemas now", "/movie/now_playing", {"region": "GB"}),
                ("top", "Top rated", "/movie/top_rated", {})]
    if sec == "anime":
        base = {"with_genres": "16", "with_original_language": "ja"}
        return [("popular", "Popular anime", "/discover/tv", dict(base, sort_by="popularity.desc")),
                ("airing", "Airing now", "/discover/tv", dict(base, sort_by="popularity.desc",
                                                               **{"air_date.gte": _today(-10),
                                                                  "air_date.lte": _today(3)})),
                ("top", "Top rated anime", "/discover/tv", dict(base, sort_by="vote_average.desc",
                                                                 **{"vote_count.gte": "300"})),
                ("films", "Anime films", "/discover/movie", dict(base, sort_by="popularity.desc"))]
    if sec == "kdrama":
        base = {"with_genres": "18", "with_original_language": "ko"}
        return [("popular", "Popular K-dramas", "/discover/tv", dict(base, sort_by="popularity.desc")),
                ("airing", "Airing now", "/discover/tv", dict(base, sort_by="popularity.desc",
                                                               **{"air_date.gte": _today(-10),
                                                                  "air_date.lte": _today(3)})),
                ("top", "Top rated K-dramas", "/discover/tv", dict(base, sort_by="vote_average.desc",
                                                                    **{"vote_count.gte": "100"}))]
    return [("trending", "Trending this week", "/trending/tv/week", {}),
            ("popular", "Popular", "/tv/popular", {}),
            ("airing", "On the air this week", "/tv/on_the_air", {}),
            ("top", "Top rated", "/tv/top_rated", {})]


# ---------------------------------------------------------------- menus
def menu():
    if not tmdb.have_key():
        add(color("Add a TMDB key first (Tools > Accounts)", "orange"), {"action": "accounts"}, False, icon="key")
    add("Search everything", {"action": "get_search", "k": "any"}, icon="search")
    for sid, label, _key, _kind in SECTIONS:
        add(label, {"action": "get_menu", "k": sid}, icon={"movies": "movies", "tv": "tv", "anime": "anime",
                                                            "kdrama": "kdrama"}[sid])
    add("Paste a magnet or file-host link", {"action": "paste"}, False, icon="magnet",
        plot="A magnet link, an info hash, or a Rapidgator/Nitroflare/etc link (unlocked with Cocoleech or "
             "Real-Debrid). You'll be asked what it is so it gets the right name on the NAS.")
    if debrid.tb_key():
        add("Send something from my TorBox cloud", {"action": "cloud"}, icon="cloud")
    add("Downloads", {"action": "downloads"}, icon="downloads")
    end(cache=False)


def section_menu(sec):
    add("Search %s" % SECTION_LABEL[sec].lower(), {"action": "get_search", "k": sec}, icon="search")
    for lid, label, _p, _a in lists(sec):
        add(label, {"action": "get_list", "k": sec, "l": lid}, icon={"trending": "trending", "popular": "star",
                                                                    "top": "star", "airing": "calendar",
                                                                    "now": "movies", "films": "movies"}.get(lid))
    if SECTION_KIND[sec] == "show" and db.one("SELECT 1 FROM items WHERE section=? AND kind='show' AND tmdb>0",
                                               (sec,)):
        add("Shows on my NAS with missing episodes", {"action": "missing_shows", "k": sec}, icon="nextup")
    end()


# ---------------------------------------------------------------- TMDB results
def _show_section(r):
    gids = r.get("genre_ids") or [g.get("id") for g in r.get("genres") or []]
    lang = r.get("original_language") or ""
    if 16 in gids and lang == "ja" and section_path("anime"):
        return "anime"
    if lang == "ko" and section_path("kdrama"):
        return "kdrama"
    return "tv"


def _results(res, sec):
    for r in res:
        mt = r.get("media_type") or ("movie" if "title" in r else "tv")
        if mt not in ("movie", "tv"):
            continue
        kind = "movie" if mt == "movie" else "show"
        k = "movies" if kind == "movie" else (sec if sec in ("tv", "anime", "kdrama") else _show_section(r))
        title = r.get("title") or r.get("name") or "?"
        year = (r.get("release_date") or r.get("first_air_date") or "")[:4]
        label = "%s (%s)" % (title, year) if year else title
        on = library.on_nas(kind, r.get("id"))
        if on:
            if kind == "show":
                st = library.show_stats([on[0]["id"]]).get(on[0]["id"], (0, 0))
                label += "  " + color("[%d eps on NAS]" % st[0], "lightgreen")
            else:
                label += "  " + color("[On NAS]", "lightgreen")
        if sec == "any":
            label += "  " + color(SECTION_LABEL[k], "grey")
        li = xbmcgui.ListItem(label)
        li.setArt(dict((a, b) for a, b in {"poster": tmdb.img(r.get("poster_path")),
                                            "thumb": tmdb.img(r.get("poster_path")),
                                            "fanart": tmdb.img(r.get("backdrop_path"), "w1280")}.items() if b))
        set_info(li, {"mediatype": "movie" if kind == "movie" else "tvshow", "title": title,
                      "plot": r.get("overview"), "year": int(year) if year.isdigit() else None,
                      "rating": r.get("vote_average"), "votes": r.get("vote_count")})
        xbmcplugin.addDirectoryItem(handle(), url(action="get_title", k=k, tmdb=r["id"]), li, isFolder=True)


def search(sec, q=None):
    if q is None:
        q = xbmcgui.Dialog().input("Search %s" % ("films and shows" if sec == "any" else SECTION_LABEL[sec].lower()))
        if not q:
            return fail_dir()
    return results(sec, q)


def results(sec, q, page=1):
    page = int(page)
    try:
        if sec == "any":
            d = tmdb.get("/search/multi", 86400, query=q, page=page)
        else:
            d = tmdb.search("movie" if sec == "movies" else "tv", q, page)
    except tmdb.TMDBError as e:
        notify(str(e), "error")
        return fail_dir()
    res = d.get("results") or []
    if sec == "anime":
        res = [r for r in res if 16 in (r.get("genre_ids") or [])] or res
    if not res:
        add(color("TMDB found nothing for '%s'" % q, "grey"), {}, False)
    _results(res, sec)
    if page < (d.get("total_pages") or 1):
        add(color("Next page >>", "deepskyblue"), {"action": "get_results", "k": sec, "q": q, "page": page + 1},
            icon="next")
    end("videos")


def tmdb_list(sec, lid, page=1):
    page = int(page)
    for l_id, _label, path, args in lists(sec):
        if l_id == lid:
            try:
                d = tmdb.listing(path, page, **args)
            except tmdb.TMDBError as e:
                notify(str(e), "error")
                return fail_dir()
            k = "movies" if "/movie" in path else sec
            for r in d.get("results") or []:
                r.setdefault("media_type", "movie" if "/movie" in path else "tv")
            _results(d.get("results") or [], k)
            if page < min(20, d.get("total_pages") or 1):
                add(color("Next page >>", "deepskyblue"), {"action": "get_list", "k": sec, "l": lid, "page": page + 1},
                    icon="next")
            return end("videos")
    fail_dir()


# ---------------------------------------------------------------- where things go
def target(sec, kind, tmdb_id, details=None):
    """-> (section, library item or None). Already on the NAS wins; else the section you came from."""
    rows = library.on_nas(kind, tmdb_id)
    if rows:
        return rows[0]["section"], rows[0]
    if kind == "movie":
        return ("movies" if section_path("movies") else None), None
    if sec not in ("tv", "anime", "kdrama") and details:
        sec = _show_section(details)
    for s in (sec, "tv", "anime", "kdrama"):
        if s and section_path(s):
            return s, None
    return None, None


def main_folder(lib):
    """The title's own folder on the NAS (for a show split over several, the one with the latest season), or None
    if it's loose files in a NAS / category folder."""
    if lib is None:
        return None
    pre = "movie:" if lib["kind"] == "movie" else "show:"
    best = None
    for r in db.q("SELECT mkey, MAX(COALESCE(season, 0)) s, COUNT(*) n FROM files WHERE item_id=? GROUP BY mkey",
                  (lib["id"],)):
        mk = r["mkey"] or ""
        if not mk.startswith(pre) or "|" in mk:
            continue
        key = (r["s"], r["n"])
        if best is None or key > best[0]:
            best = (key, mk[len(pre):])
    return best[1] if best else None


def own_folder(lib):
    return main_folder(lib) is not None


def _series_folders(sec, cid):
    """Your collection folders that already hold films from this film series -> [(path, root, coll, count)]."""
    if not cid:
        return []
    return [(vfs.join(r["root"], *r["coll"].split("/")), r["root"], r["coll"], r["n"]) for r in db.q(
        "SELECT f.root, f.coll, COUNT(DISTINCT f.item_id) n FROM files f JOIN items i ON i.id=f.item_id "
        "WHERE f.section=? AND i.collection_id=? AND COALESCE(f.coll, '')<>'' GROUP BY f.root, f.coll ORDER BY n DESC",
        (sec, cid))]


def collection_name(sec, path, m):
    """Saving into your collection folder: name it like the rest, e.g. '04 Harry Potter and the Goblet of Fire
    (2005)' beside '01 ...', '02 ...'. -> file name without extension, or None (use a 'Title (Year)' folder)."""
    cid = m.get("collection_id")
    for p, root, coll, _n in _series_folders(sec, cid):
        if npath(p) != npath(path):
            continue
        rows = db.q("SELECT label FROM files WHERE section=? AND root=? AND coll=? AND ord IS NOT NULL AND "
                    "mkey LIKE '%|%' ORDER BY ord", (sec, root, coll))
        styles = [names.order_prefix(r["label"]) for r in rows]
        styles = [s for s in styles if s]
        if not styles:
            return None  # their films are in folders of their own - do the same
        try:
            parts = sorted(tmdb.collection(cid).get("parts") or [], key=lambda x: x.get("release_date") or "9999")
            n = [x.get("id") for x in parts].index(m["tmdb"]) + 1
        except (tmdb.TMDBError, ValueError):
            return None
        pre = styles[0][2]
        digits = re.search(r"\d+", pre).group(0)
        num = str(n).zfill(len(digits)) if digits.startswith("0") else str(n)
        return pre.replace(digits, num, 1) + names.title_year(m["title"], m.get("year"))
    return None


def dest_root(sec, lib=None, what="", m=None):
    """The folder a new title goes into: one of the section's NAS folders, a category folder inside one, or - for a
    film from a series you collect - that collection folder. Things already on the NAS stay where they are.
    -> path, or None if cancelled."""
    if lib is not None and lib["section"] == sec and lib["folder"]:
        mf = main_folder(lib)
        return vfs.parent(mf) if mf else lib["folder"]
    locs = locations(sec)
    if not locs:
        return None
    choices = []
    series = _series_folders(sec, (m or {}).get("collection_id"))
    for p, root, coll, n in series:
        lab = "%s > %s" % (loc_label(next((x for x in locs if npath(x["path"]) == root), {"path": root})),
                           coll.replace("/", " > "))
        choices.append((p, lab + color("  (with your other %d %s film%s)" % (
            n, (m or {}).get("collection", "").replace(" Collection", "") or "series", "" if n == 1 else "s"),
            "lightgreen")))
    if series and setting("save_where", "0") == "1":
        return series[0][0]
    for loc in locs:
        root = npath(loc["path"])
        choices.append((root, loc_label(loc) + (color("  (default)", "gold") if loc.get("default") else "")))
        cats = sorted(set(r["cat"] for r in db.q("SELECT DISTINCT cat FROM files WHERE section=? AND root=? AND "
                                                  "cat<>''", (sec, root))), key=lambda c: c.lower())
        for c in cats[:40]:
            p = vfs.join(root, *c.split("/"))
            if not any(npath(p) == npath(x[0]) for x in choices):
                choices.append((p, "%s > %s" % (loc_label(loc), c.replace("/", " > "))))
    if len(choices) == 1 or setting("save_where", "0") == "1":
        return (series[0][0] if series else next(x[0] for x in choices if any(
            npath(x[0]) == npath(l["path"]) for l in locs)))
    i = xbmcgui.Dialog().select("Save %s where?" % (what or "it"), [c[1] for c in choices])
    if i < 0:
        return None
    return choices[i][0]


def show_media(d, sec, lib):
    seasons = [{"n": s.get("season_number"), "count": s.get("episode_count") or 0}
               for s in d.get("seasons") or [] if s.get("season_number") is not None]
    m = {"tmdb": d.get("id"), "title": d.get("name") or "", "year": tmdb._year(d.get("first_air_date")),
         "imdb": (d.get("external_ids") or {}).get("imdb_id") or "", "seasons": seasons, "have": [],
         "season_dirs": {}, "folder": None}
    if lib is not None and lib["section"] == sec:
        m["folder"] = main_folder(lib)
        for f in db.item_files(lib["id"]):
            if f["season"] is not None and f["episode"] is not None:
                m["have"].append([f["season"], f["episode"]])
                for e in range(f["episode"] + 1, (f["ep_end"] or f["episode"]) + 1):
                    m["have"].append([f["season"], e])
            par = vfs.parent(f["path"])
            if m["folder"] and par.rstrip("/\\") != m["folder"].rstrip("/\\") and f["season"] is not None:
                m["season_dirs"].setdefault(str(f["season"]), par)
        if lib["title"] and lib["matched"]:
            m["title"], m["year"] = lib["title"], lib["year"] or m["year"]
    return m


def movie_media(d, lib=None):
    return {"tmdb": d.get("id"), "title": d.get("title") or "", "year": tmdb._year(d.get("release_date")),
            "imdb": d.get("imdb_id") or (d.get("external_ids") or {}).get("imdb_id") or "",
            "folder": main_folder(lib),
            "collection_id": (d.get("belongs_to_collection") or {}).get("id"),
            "collection": (d.get("belongs_to_collection") or {}).get("name") or ""}


def _need_folder(sec_label):
    xbmcgui.Dialog().ok(NAME, "Set up a NAS folder for %s first (Tools > Set up NAS folders)." % sec_label)


# ---------------------------------------------------------------- a title
def title(sec, tmdb_id, lib_id=None):
    if not tmdb_id:
        notify("This one isn't matched on TMDB - use Fix match first", "warn")
        return fail_dir()
    if sec == "movies":
        return sources(sec, tmdb_id)
    try:
        d = tmdb.tv(tmdb_id)
    except tmdb.TMDBError as e:
        notify(str(e), "error")
        return fail_dir()
    s, lib = target(sec, "show", tmdb_id, d)
    have = {}
    if lib is not None:
        for f in db.item_files(lib["id"]):
            if f["episode"] is not None:
                have.setdefault(f["season"], set()).update(range(f["episode"], (f["ep_end"] or f["episode"]) + 1))
    fan = tmdb.img(d.get("backdrop_path"), "w1280")
    if s is None:
        add(color("No NAS folder set up for shows yet - Tools > Set up NAS folders", "orange"), {"action": "setup"},
            False, icon="folder")
    else:
        where = color("Saves to: %s" % SECTION_LABEL[s], "grey")
        add(color("Get every missing episode", "deepskyblue") + "  " + where,
            {"action": "autoget", "k": s, "tmdb": tmdb_id}, False, icon="get", fanart=fan,
            plot="Searches each season for the best release (TorBox-cached first, your preferred quality), "
                 "queues them, and only saves episodes you don't already have.")
    if lib is not None:
        add("Open in my library", {"action": "show", "id": lib["id"]}, icon="tv", fanart=fan)
    for se in d.get("seasons") or []:
        n = se.get("season_number")
        if n is None or (n == 0 and not have.get(0)):
            continue
        cnt = se.get("episode_count") or 0
        got = len(have.get(n, set()))
        aired_ok = tmdb.aired(se.get("air_date") or "")
        if not aired_ok and not got:
            tag = color("not aired yet", "grey")
        elif cnt and got >= cnt:
            tag = color("all %d on NAS" % cnt, "lightgreen")
        elif got:
            tag = color("%d of %d on NAS" % (got, cnt), "orange")
        else:
            tag = color("%d episodes" % cnt, "grey")
        li = xbmcgui.ListItem("%s  %s" % (se.get("name") or "Season %d" % n, tag))
        li.setArt(dict((a, b) for a, b in {"poster": tmdb.img(se.get("poster_path")) or tmdb.img(d.get("poster_path")),
                                            "fanart": fan}.items() if b))
        set_info(li, {"mediatype": "season", "season": n, "tvshowtitle": d.get("name"),
                      "plot": se.get("overview") or d.get("overview")})
        xbmcplugin.addDirectoryItem(handle(), url(action="get_season", k=s or sec, tmdb=tmdb_id, n=n), li, True)
    end("seasons", cache=False)


def get_season(sec, tmdb_id, n):
    n = int(n)
    try:
        d = tmdb.tv(tmdb_id)
        sd = tmdb.season(tmdb_id, n)
    except tmdb.TMDBError as e:
        notify(str(e), "error")
        return fail_dir()
    s, lib = target(sec, "show", tmdb_id, d)
    files = {}
    if lib is not None:
        for f in db.item_files(lib["id"]):
            if f["season"] == n and f["episode"] is not None:
                for e in range(f["episode"], (f["ep_end"] or f["episode"]) + 1):
                    files[e] = f
    fan = tmdb.img(d.get("backdrop_path"), "w1280")
    eps = sd.get("episodes") or []
    missing = [e.get("episode_number") for e in eps if e.get("episode_number") not in files and
               tmdb.aired(e.get("air_date") or "")]
    if s:
        add(color("Season packs for season %d" % n, "deepskyblue"), {"action": "sources", "k": s, "tmdb": tmdb_id,
                                                                      "n": n, "pack": "1"}, icon="get", fanart=fan)
        if missing:
            add(color("Get the %d missing episode%s automatically" % (len(missing), "" if len(missing) == 1 else "s"),
                      "deepskyblue"), {"action": "autoget", "k": s, "tmdb": tmdb_id, "n": n}, False, icon="get",
                fanart=fan)
    for e in eps:
        ep = e.get("episode_number")
        name = e.get("name") or "Episode %d" % ep
        f = files.get(ep)
        if f is not None:
            label = "%d. %s  %s" % (ep, name, color("[On NAS]", "lightgreen"))
            u, folder = url(action="play", f=f["path"]), False
        elif not tmdb.aired(e.get("air_date") or ""):
            label = color("%d. %s  (airs %s)" % (ep, name, e.get("air_date") or "TBA"), "grey")
            u, folder = url(action="noop"), False
        else:
            label = "%d. %s" % (ep, name)
            u, folder = url(action="sources", k=s or sec, tmdb=tmdb_id, n=n, e=ep), True
        li = xbmcgui.ListItem(label)
        li.setArt(dict((a, b) for a, b in {"thumb": tmdb.img(e.get("still_path"), "w300"), "fanart": fan}.items() if b))
        set_info(li, {"mediatype": "episode", "title": name, "season": n, "episode": ep,
                      "tvshowtitle": d.get("name"), "plot": e.get("overview"), "premiered": e.get("air_date"),
                      "rating": e.get("vote_average")})
        if f is not None:
            li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle(), u, li, folder)
    end("episodes", cache=False)


def missing_shows(sec):
    rows = db.q("SELECT * FROM items WHERE section=? AND kind='show' AND tmdb>0 ORDER BY sorttitle", (sec,))
    stats = library.show_stats([r["id"] for r in rows])
    for r in rows:
        total = 0
        for s in db.seasons_of(r):
            if s.get("n") and tmdb.aired(s.get("air") or ""):
                total += s.get("count") or 0
        n = stats.get(r["id"], (0, 0))[0]
        if total and n < total:
            add("%s  %s" % (r["title"], color("%d of %d on NAS" % (n, total), "orange")),
                {"action": "get_title", "k": sec, "tmdb": r["tmdb"]}, poster=r["poster"], fanart=r["fanart"],
                icon=r["poster"] or "tv")
    end("tvshows", cache=False)


# ---------------------------------------------------------------- sources
def _ctx(sec, tmdb_id, n=None, e=None, pack=False):
    """-> (scrape ctx, media dict, section, lib item, title text) for a movie / episode / season pack."""
    if sec == "movies":
        d = tmdb.movie(tmdb_id)
        s, lib = target(sec, "movie", tmdb_id, d)
        m = movie_media(d, lib)
        ctx = {"kind": "movie", "title": m["title"], "year": m["year"], "imdb": m["imdb"]}
        return ctx, m, s, lib, "%s (%s)" % (m["title"], m["year"] or "?")
    d = tmdb.tv(tmdb_id)
    s, lib = target(sec, "show", tmdb_id, d)
    m = show_media(d, s, lib)
    anime = s == "anime" or _show_section(d) == "anime"
    n = int(n)
    ctx = {"kind": "show", "title": m["title"], "year": m["year"], "imdb": m["imdb"], "season": n,
           "episode": int(e) if e else None, "pack": pack, "anime": anime,
           "alt_titles": tmdb.alt_titles(d) if anime else []}
    if anime and e:
        ctx["abs"] = tmdb.se_to_absolute(m["seasons"], n, int(e))
    what = "%s S%02d" % (m["title"], n) + ("E%02d" % int(e) if e else " (season pack)")
    return ctx, m, s, lib, what


def _scrape(ctx):
    key = "scrape:" + "|".join(str(ctx.get(k)) for k in ("kind", "imdb", "title", "season", "episode", "pack"))
    hit = db.cache_get(key, 900)
    if hit is not None:
        return hit["res"], hit["rep"], hit.get("cached_ok", False)
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Searching the torrent sites...")
    try:
        res, rep = scrapers.run(ctx)
    finally:
        prog.close()
    cached_ok = False
    if res and debrid.tb_key():
        try:
            cached = debrid.TorBox(debrid.tb_key()).check_cached([r["hash"] for r in res])
            for r in res:
                r["cached"] = r["hash"] in cached
            cached_ok = True
        except debrid.DebridError as e:
            log("TorBox cache check: %s" % e, "warn")
    res.sort(key=lambda r: (not r.get("cached"), -RES_RANK.get(r["res"], 0), -r["seeds"]))
    db.cache_put(key, {"res": res, "rep": rep, "cached_ok": cached_ok})
    return res, rep, cached_ok


def sources(sec, tmdb_id, n=None, e=None, pack=False):
    try:
        ctx, m, s, lib, what = _ctx(sec, tmdb_id, n, e, pack)
    except tmdb.TMDBError as err:
        notify(str(err), "error")
        return fail_dir()
    if s is None:
        _need_folder(SECTION_LABEL.get(sec, "this"))
        return fail_dir()
    if sec == "movies" and lib is not None:
        add(color("Already on your NAS - play it", "lightgreen"), {"action": "play_item", "id": lib["id"]}, False,
            icon="continue", playable=True)
    res, rep, cached_ok = _scrape(ctx)
    if not res:
        msg = "No torrents found for %s" % what
        errs = [r for r in rep if r[2]]
        if errs:
            msg += " (%s)" % "; ".join("%s: %s" % (r[0], r[2][:40]) for r in errs)
        add(color(msg, "grey"), {}, False)
        if ctx["kind"] == "show" and not pack:
            add(color("Try season packs instead", "deepskyblue"), {"action": "sources", "k": s, "tmdb": tmdb_id,
                                                                    "n": n, "pack": "1"}, icon="get")
    for r in res:
        tags = []
        if r.get("cached"):
            tags.append(color("CACHED", "lightgreen"))
        elif cached_ok:
            tags.append(color("not cached", "gold"))
        if r.get("pack") and not pack:
            tags.append(color("PACK", "deepskyblue"))
        label = "%s %s  %s  %s  %s  %s" % (" ".join(tags), color(r["res"], "white"), fmt_size(r["size"]),
                                            color("%d seeds" % r["seeds"], "grey"), color(r["source"], "grey"),
                                            r["name"])
        li = item(label, "magnet", plot="%s\n\n%s\n%s | %s seeds | %s\n\nSelect to save it to your NAS (%s)." % (
            r["name"], r["res"], fmt_size(r["size"]), r["seeds"], r["source"], SECTION_LABEL[s]))
        p = {"action": "pick", "k": s, "tmdb": tmdb_id, "n": n, "e": e, "pack": "1" if pack else None,
             "h": r["hash"], "nm": r["name"][:150], "c": "1" if r.get("cached") else ("0" if cached_ok else ""),
             "rp": "1" if r.get("pack") else None}
        ctx_menu = [("Play now instead (don't save)", run(**dict(p, action="stream")))]
        li.addContextMenuItems(ctx_menu)
        xbmcplugin.addDirectoryItem(handle(), url(**p), li, isFolder=False)
    if rep:
        add(color("Sources: " + ", ".join("%s %s" % (r[0], r[1] if not r[2] else "error") for r in rep), "grey"),
            {"action": "noop"}, False, icon="search")
    end("files", cache=True)


def choose_service(cached, quiet=False):
    avail = debrid.available()
    if not avail:
        xbmcgui.Dialog().ok(NAME, "Log in to TorBox, Real-Debrid or Cocoleech first (Tools > Accounts).")
        return None
    auto = sorted(avail, key=lambda s: (not (s == "tb" and cached == "1"), ("tb", "rd", "cl").index(s)))
    mode = setting("download_service", "0")
    fixed = {"2": "tb", "3": "rd", "4": "cl"}.get(mode)
    if fixed in avail:
        return [fixed] + [s for s in auto if s != fixed]
    if mode == "1" or len(avail) == 1 or quiet:
        return auto
    labels = []
    for s in auto:
        if s == "tb" and cached == "1":
            tag = color("cached - fast", "lightgreen")
        elif s == "tb" and cached == "0":
            tag = color("not cached - TorBox downloads it first", "grey")
        else:
            tag = color("fast if they have it cached", "grey")
        labels.append("%s  %s" % (debrid.NAMES[s], tag))
    i = xbmcgui.Dialog().select("Download it through...", labels)
    if i < 0:
        return None
    return [auto[i]] + [s for s in auto if s != auto[i]]


def _want(ctx, m, pick_pack, single_pack_name=""):
    if ctx["kind"] == "movie":
        return {"mode": "movie"}
    n = ctx["season"]
    if ctx.get("episode") and not ctx.get("pack"):
        return {"mode": "episode", "episodes": [[n, ctx["episode"]]], "skip_have": False}
    w = {"mode": "season", "season": n, "episodes": None, "skip_have": True}
    seasons = names.pack_seasons(single_pack_name)
    if len([x for x in seasons if x != "all"]) > 1 or "all" in seasons:
        i = xbmcgui.Dialog().select("This pack has more than season %d" % n,
                                    ["Just season %d" % n, "Every episode in it that's not on the NAS"])
        if i < 0:
            return None
        if i == 1:
            w = {"mode": "all", "skip_have": True}
    return w


def _job(ctx, m, s, want, source, what, root):
    return {"title": what, "section": s, "root": root, "kind": "movie" if ctx["kind"] == "movie" else "show",
            "media": m, "want": want, "source": source, "season_pack": bool(ctx.get("pack"))}


def pick(p):
    try:
        ctx, m, s, lib, what = _ctx(p["k"], p["tmdb"], p.get("n"), p.get("e"), bool(p.get("pack")))
    except tmdb.TMDBError as err:
        return notify(str(err), "error")
    if not s:
        return _need_folder(SECTION_LABEL.get(p["k"], "this"))
    want = _want(ctx, m, bool(p.get("pack")), p.get("nm", "") if p.get("rp") or p.get("pack") else "")
    if want is None:
        return
    root = dest_root(s, lib, what, m)
    if not root:
        return
    if ctx["kind"] == "movie" and lib is None:
        m["loose_name"] = collection_name(s, root, m)
    order = choose_service(p.get("c", ""))
    if not order:
        return
    src = {"type": "torrent", "hash": p["h"], "name": p.get("nm", ""), "svc": order[0], "order": order}
    downloads.add(_job(ctx, m, s, want, src, what, root))
    notify("Saving to your NAS via %s: %s" % (debrid.NAMES[order[0]], what), "info", 5000)


def stream(p):
    """Play a torrent straight away through a debrid service, without saving it."""
    try:
        ctx, m, s, lib, what = _ctx(p["k"], p["tmdb"], p.get("n"), p.get("e"), bool(p.get("pack")))
    except tmdb.TMDBError as err:
        return notify(str(err), "error")
    order = choose_service(p.get("c", ""))
    if not order:
        return
    want = {"mode": "movie"} if ctx["kind"] == "movie" else (
        {"mode": "episode", "episodes": [[ctx["season"], ctx["episode"]]]} if ctx.get("episode") else
        {"mode": "season", "season": ctx["season"]})
    job = _job(ctx, m, s or p["k"], want, {}, what, section_path(s or p["k"]) or "/")
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Opening it on %s..." % debrid.NAMES[order[0]])
    errs = []
    try:
        for svc in order:
            try:
                obj = debrid.get(svc)
                h = obj.start(p["h"], p.get("nm", ""))
                deadline = setting_int("stream_wait", 60)
                waited = 0
                while True:
                    st = obj.status(h)
                    if st.get("error"):
                        raise debrid.DebridError(st["error"])
                    if st.get("ready") and st.get("files"):
                        break
                    if prog.iscanceled():
                        return
                    if waited >= deadline:
                        prog.close()
                        if xbmcgui.Dialog().yesno(NAME, "%s isn't ready yet (%d%%).\nSave it to the NAS instead "
                                                        "when it's done?" % (debrid.NAMES[svc], st.get("progress", 0))):
                            src = {"type": "torrent", "hash": p["h"], "name": p.get("nm", ""), "svc": svc,
                                   "order": [svc], "svc_used": svc, "handle": h}
                            root = dest_root(s, lib, what, m)
                            if root:
                                downloads.add(_job(ctx, m, s, want if want["mode"] != "season" else
                                                   dict(want, skip_have=True), src, what, root))
                            notify("Queued for the NAS: %s" % what)
                        return
                    prog.update(min(99, st.get("progress") or 0), "%s: %s %d%%\n%s" % (
                        debrid.NAMES[svc], st.get("state", ""), st.get("progress") or 0, what))
                    xbmc.sleep(2000)
                    waited += 2
                todo = [t for t in downloads.plan(job, st["files"]) if t[2] == "video"]
                if not todo:
                    vids = [f for f in st["files"] if names.is_video(f["name"])]
                    if not vids:
                        raise debrid.DebridError("no video in that torrent")
                    prog.close()
                    i = xbmcgui.Dialog().select("Which file?", [vfs.basename(f["name"]) for f in vids])
                    if i < 0:
                        return
                    f = vids[i]
                else:
                    f = todo[0][0]
                link = obj.link(h, f["id"])
                prog.close()
                li = xbmcgui.ListItem(what, path=link)
                set_info(li, {"title": what, "mediatype": "movie" if ctx["kind"] == "movie" else "episode"})
                xbmc.Player().play(link, li)
                return
            except debrid.DebridError as e:
                errs.append("%s: %s" % (debrid.NAMES[svc], e))
                continue
    finally:
        try:
            prog.close()
        except Exception:
            pass
    if errs:
        notify(" | ".join(errs)[:220], "error", 8000)


# ---------------------------------------------------------------- automatic picking (missing episodes)
def best(res, want_pack=None):
    pref = {"0": 3, "1": 4, "2": 2}.get(setting("pref_res", "0"), 3)
    cands = [r for r in res if want_pack is None or bool(r.get("pack")) == want_pack]
    if not cands:
        return None
    cands.sort(key=lambda r: (not r.get("cached"), abs(RES_RANK.get(r["res"], 0) - pref),
                              -RES_RANK.get(r["res"], 0), -r["seeds"]))
    top = cands[0]
    if not top.get("cached") and top["seeds"] < 2:
        return None
    return top


def autoget(sec, tmdb_id, n=None):
    try:
        d = tmdb.tv(tmdb_id)
    except tmdb.TMDBError as e:
        return notify(str(e), "error")
    s, lib = target(sec, "show", tmdb_id, d)
    if not s:
        return _need_folder(SECTION_LABEL.get(sec, "TV"))
    m = show_media(d, s, lib)
    have = set(tuple(x) for x in m["have"])
    seasons = [int(n)] if n is not None else [x["n"] for x in m["seasons"] if x["n"]]
    root = dest_root(s, lib, m["title"])
    if not root:
        return
    order = choose_service("", quiet=True)
    if not order:
        return
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Looking for missing episodes of %s..." % m["title"])
    queued, not_found = [], []
    try:
        for i, sn in enumerate(seasons):
            if prog.iscanceled():
                break
            try:
                sd = tmdb.season(tmdb_id, sn)
            except tmdb.TMDBError:
                continue
            missing = [e["episode_number"] for e in sd.get("episodes") or []
                       if (sn, e["episode_number"]) not in have and tmdb.aired(e.get("air_date") or "")]
            if not missing:
                continue
            prog.update(int(100.0 * i / len(seasons)), "Season %d: %d missing - looking for a season pack..." % (
                sn, len(missing)))
            got_pack = False
            if len(missing) >= 3:
                ctx, _m, _s, _l, _w = _ctx(s, tmdb_id, sn, None, True)
                res, _rep, _c = _scrape(ctx)
                b = best(res, True)
                if b:
                    want = {"mode": "season", "season": sn, "episodes": missing, "skip_have": True}
                    src = {"type": "torrent", "hash": b["hash"], "name": b["name"],
                           "svc": order[0], "order": order}
                    downloads.add(_job(ctx, m, s, want, src, "%s S%02d (%d episodes)" % (m["title"], sn,
                                                                                         len(missing)), root))
                    queued.append("Season %d pack%s" % (sn, " (cached)" if b.get("cached") else ""))
                    got_pack = True
            if got_pack:
                continue
            for ep in missing[:40]:
                if prog.iscanceled():
                    break
                prog.update(int(100.0 * i / len(seasons)), "Season %d episode %d..." % (sn, ep))
                ctx, _m, _s, _l, what = _ctx(s, tmdb_id, sn, ep, False)
                res, _rep, _c = _scrape(ctx)
                b = best(res, False) or best(res)
                if not b:
                    not_found.append("S%02dE%02d" % (sn, ep))
                    continue
                want = {"mode": "episode", "episodes": [[sn, ep]], "skip_have": False}
                if b.get("pack"):
                    want = {"mode": "season", "season": sn, "episodes": [e for e in missing], "skip_have": True}
                src = {"type": "torrent", "hash": b["hash"], "name": b["name"], "svc": order[0], "order": order}
                downloads.add(_job(ctx, m, s, want, src, what, root))
                queued.append("S%02dE%02d" % (sn, ep))
                if b.get("pack"):
                    break
    finally:
        prog.close()
    msg = []
    if queued:
        msg.append("Queued for the NAS: " + ", ".join(queued[:15]) + (" and %d more" % (len(queued) - 15)
                                                                        if len(queued) > 15 else ""))
    if not_found:
        msg.append("Couldn't find: " + ", ".join(not_found[:20]))
    if not queued and not not_found:
        msg.append("Nothing missing - you've got every episode that's aired.")
    xbmcgui.Dialog().ok(NAME, "\n".join(msg))


# ---------------------------------------------------------------- magnet / link / TorBox cloud
def identify(name):
    """Ask what a torrent / file is so it gets the right name. -> (kind, section, media, want) or None."""
    d = xbmcgui.Dialog()
    opts = [("movies", "A film"), ("tv", "A TV show"), ("anime", "Anime"), ("kdrama", "A K-drama"),
            (None, "Something else - save it as it is into a folder")]
    opts = [o for o in opts if o[0] is None or section_path(o[0])]
    i = d.select("What is '%s'?" % name[:60], [o[1] for o in opts])
    if i < 0:
        return None
    sec = opts[i][0]
    if sec is None:
        folder = d.browse(3, "Save it into which folder?", "files", "", False, False, "")
        if not folder:
            return None
        return "raw", None, {"title": name}, {"mode": "all"}, folder
    if sec == "movies":
        t, y = names.parse_movie(name)
    else:
        t, y = names.parse_show_name(name)
    q = d.input("Search TMDB for...", t)
    if not q:
        return None
    try:
        res = tmdb.search("movie" if sec == "movies" else "tv", q).get("results") or []
    except tmdb.TMDBError as e:
        notify(str(e), "error")
        return None
    if not res:
        notify("TMDB found nothing for '%s'" % q, "warn")
        return None
    labels = ["%s (%s)" % (r.get("title") or r.get("name"),
                           (r.get("release_date") or r.get("first_air_date") or "?")[:4]) for r in res[:20]]
    j = d.select("Which one is it?", labels)
    if j < 0:
        return None
    tid = res[j]["id"]
    if sec == "movies":
        dd = tmdb.movie(tid)
        s, lib = target(sec, "movie", tid, dd)
        m = movie_media(dd, lib)
        root = dest_root(s, lib, m["title"], m)
        if root and lib is None:
            m["loose_name"] = collection_name(s, root, m)
        return ("movie", s, m, {"mode": "movie"}, root) if root else None
    dd = tmdb.tv(tid)
    s, lib = target(sec, "show", tid, dd)
    m = show_media(dd, s, lib)
    root = dest_root(s, lib, m["title"])
    return ("show", s, m, {"mode": "all", "skip_have": True}, root) if root else None


def _queue_identified(info, source, name):
    kind, s, media, want, folder = info
    if kind == "raw":
        job = {"title": name, "section": None, "root": folder, "kind": "raw", "media": media, "want": want,
               "source": source}
    else:
        job = {"title": media["title"] + (" (%s)" % media["year"] if media.get("year") else ""), "section": s,
               "root": folder, "kind": kind, "media": media, "want": want, "source": source}
    downloads.add(job)
    notify("Queued for the NAS: %s" % job["title"])


def paste():
    text = xbmcgui.Dialog().input("Paste a magnet link, info hash or file-host link")
    if not text:
        return
    text = text.strip()
    h = scrapers._hash_from_magnet(text) if text.startswith("magnet:") else (
        text.lower() if re.match(r"^[a-fA-F0-9]{40}$", text) else "")
    if h:
        m = re.search(r"[?&]dn=([^&]+)", text)
        name = requests_unquote(m.group(1)) if m else h
        info = identify(name)
        if not info:
            return
        order = choose_service("")
        if not order:
            return
        _queue_identified(info, {"type": "torrent", "hash": h, "name": name, "svc": order[0], "order": order}, name)
    elif text.startswith("http"):
        name = requests_unquote(text.split("?")[0].rstrip("/").rsplit("/", 1)[-1]).replace(".html", "")
        if not (debrid.coco_key() or debrid.ready("rd")):
            return xbmcgui.Dialog().ok(NAME, "Log in to Cocoleech or Real-Debrid to unlock file-host links.")
        info = identify(name)
        if info:
            _queue_identified(info, {"type": "link", "url": text}, name)
    else:
        xbmcgui.Dialog().ok(NAME, "That doesn't look like a magnet link, info hash or web link.")


def requests_unquote(s):
    from urllib.parse import unquote_plus
    return unquote_plus(s)


def cloud(kind="torrents"):
    tb = debrid.TorBox(debrid.tb_key())
    for k, label in (("torrents", "Torrents"), ("usenet", "Usenet"), ("webdl", "Web downloads")):
        if k != kind:
            add(color("Show my TorBox %s" % label.lower(), "deepskyblue"), {"action": "cloud", "kind": k}, icon="cloud")
    try:
        rows = tb.mylist(kind)
    except debrid.DebridError as e:
        add(color(str(e), "red"), {}, False)
        return end()
    for r in sorted(rows, key=lambda x: x.get("created_at") or "", reverse=True):
        ready = r.get("download_finished") or r.get("download_present")
        tag = color("ready", "lightgreen") if ready else color("%s %d%%" % (r.get("download_state") or "",
                                                                            float(r.get("progress") or 0) * 100), "grey")
        add("%s  %s  %s" % (r.get("name") or "?", color(fmt_size(r.get("size")), "grey"), tag),
            {"action": "cloud_item", "kind": kind, "id": r.get("id"), "nm": (r.get("name") or "")[:150]}, False,
            icon="cloud")
    end(cache=False)


def cloud_item(kind, item_id, name):
    info = identify(name)
    if info:
        _queue_identified(info, {"type": "tbcloud", "kind": kind, "id": item_id}, name)


# ---------------------------------------------------------------- downloads screen
STATUS = {"queued": ("waiting", "grey"), "waiting": ("preparing", "deepskyblue"),
          "downloading": ("downloading", "lightgreen"), "extracting": ("unpacking", "lightgreen"),
          "done": ("done", "lightgreen"), "failed": ("failed", "red"), "cancelled": ("cancelled", "grey")}


def downloads_screen():
    jobs = downloads.all_jobs()
    if not jobs:
        add(color("Nothing downloading. Use Get new media to find something.", "grey"), {"action": "get"}, icon="get")
    if any(j.get("status") in ("done", "cancelled") for j in jobs):
        add(color("Clear finished from this list", "deepskyblue"), {"action": "dl_clear"}, False, icon="tools")
    active = [j for j in jobs if j.get("status") in downloads.ACTIVE]
    other = [j for j in reversed(jobs) if j.get("status") not in downloads.ACTIVE]
    for j in active + other:
        st, col = STATUS.get(j.get("status"), (j.get("status"), "grey"))
        pct = j.get("progress") or 0
        label = "%s  %s  %s" % (color(("%d%% " % pct if j.get("status") == "downloading" else "") + st, col),
                                j.get("title", "?"), color(j.get("msg", ""), "grey"))
        if j["source"].get("type") == "organise":
            mv = [m for m in j.get("moves") or [] if m.get("video", True)]
            files = "\n".join(("[x] " if m.get("done") else "[ ] ") + "%s  ->  %s" % (
                vfs.basename(m["src"]), places_label(vfs.parent(m["dst"]))) for m in mv[:40])
            plot = "%s\n\n%s%s" % (j.get("msg", ""), files, "\n..." if len(mv) > 40 else "")
        else:
            files = "\n".join(("[x] " if f.get("done") else "[ ] ") + vfs.basename(f["dest"])
                              for f in j.get("files") or [])
            plot = "%s\n\n%s\n\n%s" % (j.get("msg", ""), files, color(
                "From %s via %s" % (j["source"].get("type"), debrid.NAMES.get(j["source"].get("svc_used") or
                                                                             j["source"].get("svc"), "-")), "grey"))
        add(label, {"action": "dl_job", "id": j["id"]}, False, icon="downloads", plot=plot)
    add(color("Refresh", "grey"), {"action": "refresh"}, False, icon="scan")
    end(cache=False)


def job_menu(jid):
    j = downloads.load(jid)
    if not j:
        return refresh()
    st = j.get("status")
    opts = []
    if st in downloads.ACTIVE:
        opts.append(("Cancel", "cancel"))
    if st in ("failed", "cancelled"):
        opts.append(("Try again", "retry"))
    if st not in ("waiting", "downloading", "extracting"):
        opts.append(("Remove from the list", "remove"))
    if j.get("error"):
        opts.append(("Show the error", "err"))
    if j["source"].get("type") == "organise" and st in ("done", "failed", "cancelled") and \
            any(m.get("done") for m in j.get("moves") or []):
        opts.append(("Undo - move them all back", "undo"))
    if not opts:
        return
    i = xbmcgui.Dialog().select(j.get("title", ""), [o[0] for o in opts])
    if i < 0:
        return
    what = opts[i][1]
    if what == "err":
        return xbmcgui.Dialog().textviewer(NAME, j.get("error") or "")
    if what == "undo":
        n = sum(1 for m in j.get("moves") or [] if m.get("done"))
        if xbmcgui.Dialog().yesno(NAME, "Move the %d file%s back where they were?" % (n, "" if n == 1 else "s")):
            downloads.undo_moves(j)
            notify("Moving them back in the background")
        return refresh()
    downloads.mark(jid, what)
    xbmc.sleep(800)
    refresh()


def places_label(path):
    import places
    return places.place_label(path)


def clear_finished():
    for j in downloads.all_jobs():
        if j.get("status") in ("done", "cancelled"):
            downloads.mark(j["id"], "remove")
    xbmc.sleep(800)
    refresh()


# ---------------------------------------------------------------- testing the sources
def test_sources():
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Testing the torrent sites...")
    lines = []
    tests = [("Film: The Matrix (1999)", {"kind": "movie", "title": "The Matrix", "year": 1999, "imdb": "tt0133093"}),
             ("Episode: Breaking Bad S01E01", {"kind": "show", "title": "Breaking Bad", "year": 2008,
                                               "imdb": "tt0903747", "season": 1, "episode": 1}),
             ("Anime: Frieren episode 5", {"kind": "show", "title": "Frieren: Beyond Journey's End", "year": 2023,
                                           "imdb": "tt22248376", "season": 1, "episode": 5, "anime": True, "abs": 5,
                                           "alt_titles": ["Sousou no Frieren"]})]
    try:
        for i, (label, ctx) in enumerate(tests):
            prog.update(int(100 * i / len(tests)), label)
            res, rep = scrapers.run(ctx)
            lines.append("[B]%s[/B]: %d usable results" % (label, len(res)))
            for name, n, err, secs in rep:
                lines.append("   %-12s %s  (%.1fs)" % (name, color("error: " + err, "red") if err else
                                                         "%d results" % n, secs))
    finally:
        prog.close()
    xbmcgui.Dialog().textviewer(NAME + " - source test", "\n".join(lines))
