# -*- coding: utf-8 -*-
"""NAS file helpers on top of Kodi's VFS, so smb://, nfs://, local and Windows paths all work the same."""
import io
import re
import time

import xbmcvfs

from common import log


def sep(path):
    return "\\" if ("\\" in path and "://" not in path) else "/"


def join(base, *parts):
    s = sep(base)
    out = base.rstrip("/\\")
    for p in parts:
        p = str(p).strip("/\\")
        if p:
            out += s + p
    return out


def as_dir(path):
    s = sep(path)
    return path if path.endswith(s) else path + s


def parent(path):
    s = sep(path)
    p = path.rstrip("/\\")
    i = p.rfind(s)
    if i <= 0 or p[:i].endswith(":/") or p[:i].endswith(":"):
        return p
    return p[:i]


def basename(path):
    return path.rstrip("/\\").replace("\\", "/").rsplit("/", 1)[-1]


def exists(path):
    try:
        return bool(xbmcvfs.exists(path))
    except Exception:
        return False


def dir_exists(path):
    return exists(as_dir(path))


def listdir(path):
    """-> (dirs, files) or None if the folder can't be read (NAS offline, wrong password...)."""
    d = as_dir(path)
    try:
        if not xbmcvfs.exists(d):
            return None
        dirs, files = xbmcvfs.listdir(d)
    except Exception as e:
        log("Can't list %s: %s" % (path, e), "warn")
        return None
    return [x for x in dirs if x not in (".", "..")], list(files)


def walk(path, skip=None, depth=6):
    """Yield (folder, [subfolders], [files]) top-down. skip(name) -> True to not go into a folder."""
    res = listdir(path)
    if res is None:
        return
    dirs, files = res
    yield path, dirs, files
    if depth <= 0:
        return
    for d in sorted(dirs):
        if skip and skip(d):
            continue
        for x in walk(join(path, d), skip, depth - 1):
            yield x


def stat(path):
    """-> (size, mtime); (0, 0) if unknown."""
    try:
        st = xbmcvfs.Stat(path)
        return int(st.st_size() or 0), float(st.st_mtime() or 0)
    except Exception:
        return 0, 0.0


def mkdirs(path):
    if dir_exists(path):
        return True
    try:
        return bool(xbmcvfs.mkdirs(as_dir(path)))
    except Exception as e:
        log("mkdirs %s: %s" % (path, e), "warn")
        return False


def delete(path):
    try:
        return bool(xbmcvfs.delete(path))
    except Exception:
        return False


def rmdir_if_empty(path):
    res = listdir(path)
    if res is not None and not res[0] and not res[1]:
        try:
            xbmcvfs.rmdir(as_dir(path))
        except Exception:
            pass


def rename(src, dst):
    if exists(dst):
        delete(dst)
    try:
        if xbmcvfs.rename(src, dst):
            return True
    except Exception:
        pass
    # some shares refuse renames: copy then delete
    try:
        if xbmcvfs.copy(src, dst):
            delete(src)
            return True
    except Exception as e:
        log("rename %s -> %s: %s" % (src, dst, e), "warn")
    return False


def move_fast(src, dst):
    """Move without copying - works within one share / drive. False if the NAS can't (different drives)."""
    if exists(dst):
        return False
    try:
        return bool(xbmcvfs.rename(src, dst))
    except Exception:
        return False


def share_root(p):
    """smb://host/share for network paths; the folder above for anything else."""
    m = re.match(r"^([a-z0-9]+://[^/]+/[^/]+)", (p or "").replace("\\", "/"), re.I)
    return m.group(1) if m else parent(p)


def host_root(p):
    m = re.match(r"^([a-z0-9]+://[^/]+)", (p or "").replace("\\", "/"), re.I)
    return (m.group(1) + "/") if m else None


def same_share(a, b):
    return share_root(a).lower() == share_root(b).lower()


class Writer(object):
    """Write bytes to a NAS file in big chunks."""

    def __init__(self, path):
        self.path = path
        self.f = xbmcvfs.File(path, "w")
        self.buf = bytearray()
        self.written = 0

    def write(self, b):
        self.buf += b
        if len(self.buf) >= 4 * 1024 * 1024:
            self._flush()

    def _flush(self):
        if self.buf:
            ok = self.f.write(self.buf)
            if ok is False:
                raise IOError("the NAS refused the write (disk full or no permission?)")
            self.written += len(self.buf)
            self.buf = bytearray()

    def close(self):
        try:
            self._flush()
        finally:
            self.f.close()


class Reader(io.RawIOBase):
    """Seekable read-only file over Kodi's VFS (for reading a zip that's already on the NAS)."""

    def __init__(self, path):
        self.f = xbmcvfs.File(path)
        self._size = self.f.size()
        self.pos = 0

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, off, whence=0):
        if whence == 1:
            off += self.pos
        elif whence == 2:
            off += self._size
        self.pos = max(0, off)
        self.f.seek(self.pos, 0)
        return self.pos

    def read(self, n=-1):
        if n is None or n < 0:
            n = self._size - self.pos
        b = bytes(self.f.readBytes(n)) if n else b""
        self.pos += len(b)
        return b

    def readinto(self, buf):
        b = self.read(len(buf))
        buf[:len(b)] = b
        return len(b)

    def close(self):
        try:
            self.f.close()
        finally:
            super(Reader, self).close()


def free_name(path):
    """path, or 'name (2).ext' if it's taken."""
    if not exists(path):
        return path
    i = path.rfind(".")
    base, e = (path[:i], path[i:]) if i > path.rfind(sep(path)) else (path, "")
    for n in range(2, 99):
        p = "%s (%d)%s" % (base, n, e)
        if not exists(p):
            return p
    return "%s (%d)%s" % (base, int(time.time()), e)
