# -*- coding: utf-8 -*-
"""TMDB (themoviedb.org) lookups with a local cache."""
import datetime
import re

import requests

import db
import names
from common import UA, log, setting

BASE = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/"
DAY = 86400


class TMDBError(Exception):
    pass


def key():
    return setting("tmdb_key").strip()


def have_key():
    return bool(key())


def img(p, size="w500"):
    return (IMG + size + p) if p else ""


def get(path, ttl=7 * DAY, **params):
    k = key()
    if not k:
        raise TMDBError("no TMDB key - add one in Tools > Accounts (free at themoviedb.org)")
    params = dict((a, b) for a, b in params.items() if b not in (None, ""))
    ck = path + "?" + "&".join("%s=%s" % (a, params[a]) for a in sorted(params))
    if ttl:
        hit = db.cache_get(ck, ttl)
        if hit is not None:
            return hit
    headers = dict(UA)
    if k.startswith("eyJ") and len(k) > 60:
        headers["Authorization"] = "Bearer " + k  # v4 read access token
    else:
        params["api_key"] = k
    params.setdefault("language", "en-GB")
    for attempt in range(3):
        try:
            r = requests.get(BASE + path, params=params, headers=headers, timeout=15)
        except requests.RequestException as e:
            if attempt == 2:
                raise TMDBError("can't reach TMDB (%s)" % e.__class__.__name__)
            continue
        if r.status_code == 429:
            import time
            time.sleep(1 + attempt)
            continue
        if r.status_code == 401:
            raise TMDBError("TMDB didn't accept the key - check it in Tools > Accounts")
        if r.status_code == 404:
            return {}
        if r.status_code >= 400:
            raise TMDBError("TMDB error HTTP %s" % r.status_code)
        try:
            body = r.json()
        except ValueError:
            raise TMDBError("bad reply from TMDB")
        if ttl:
            db.cache_put(ck, body)
        return body
    raise TMDBError("TMDB is busy - try again in a minute")


def _year(d):
    m = re.match(r"(\d{4})", d or "")
    return int(m.group(1)) if m else None


def same_name(a, b):
    """'Lazy Town' = 'LazyTown', 'Bug Juice-My Adventures At Camp' = 'Bug Juice: My Adventures at Camp'."""
    na, nb = names.norm(a or ""), names.norm(b or "")
    return bool(na) and (na == nb or na.replace(" ", "") == nb.replace(" ", ""))


def _named(r, title):
    return same_name(r.get("title") or r.get("name"), title) or \
        same_name(r.get("original_title") or r.get("original_name"), title)


def _pick(results, title, year, date_key):
    """Best search result: exact title + year, then title, then year, then TMDB's own order."""
    if not results:
        return None
    nt = names.norm(title)

    def score(i_r):
        i, r = i_r
        t = names.norm(r.get("title") or r.get("name") or "")
        y = _year(r.get(date_key))
        s = 0
        if nt and _named(r, title):
            s += 10
        elif nt and (t.startswith(nt) or nt.startswith(t)):
            s += 3
        if year and y:
            if y == year:
                s += 6
            elif abs(y - year) == 1:
                s += 3
            else:
                s -= 2
        return (s, -i)
    best = max(enumerate(results[:8]), key=score)
    return best[1]


def _sure(r, title, year, date_key):
    """For a guess made from part of a name: the title has to match - or the year does and one name holds the
    other ('Bean' (1997) for 'Mr Bean The Ultimate Disaster Movie' (1997))."""
    if _named(r, title):
        return True
    if not year or _year(r.get(date_key)) != year:
        return False
    a = " %s " % names.norm(title)
    b = " %s " % names.norm(r.get("title") or r.get("name") or "")
    return len(b.strip()) > 2 and (b in a or a in b)


def search_movie(title, year=None, exact=False):
    res = get("/search/movie", 3 * DAY, query=title, year=year).get("results") or []
    if not res and year:
        res = get("/search/movie", 3 * DAY, query=title).get("results") or []
    r = _pick(res, title, year, "release_date")
    if r and exact and not _sure(r, title, year, "release_date"):
        return None
    return r["id"] if r else None


def _seasons_of(tv_id):
    try:
        d = tv(tv_id)
    except TMDBError:
        return None
    return d.get("number_of_seasons") or len([s for s in d.get("seasons") or [] if s.get("season_number")])


def search_tv(title, year=None, exact=False, max_season=None):
    """max_season: the highest season number on the NAS - picks between shows with the same name (Doctor Who
    from 1963 has 26 seasons, the 2005 one far fewer)."""
    res = get("/search/tv", 3 * DAY, query=title, first_air_date_year=year).get("results") or []
    if not res and year:
        res = get("/search/tv", 3 * DAY, query=title).get("results") or []
    if not res:
        t2 = re.sub(r"\s*\((?:us|uk)\)$|\s+(?:us|uk)$", "", title, flags=re.I)
        if t2 != title:
            res = get("/search/tv", 3 * DAY, query=t2).get("results") or []
    r = _pick(res, title, year, "first_air_date")
    if r and max_season and max_season > 1 and not year:
        same = [x for x in res[:6] if _named(x, title)]
        if len(same) > 1:
            best = None
            for c in same[:4]:
                n = _seasons_of(c["id"])
                if n and n >= max_season and (best is None or n < best[0]):
                    best = (n, c)
            if best:
                r = best[1]
    if r and exact and not _sure(r, title, year, "first_air_date"):
        return None
    return r["id"] if r else None


def search(kind, query, page=1):
    path = "/search/movie" if kind == "movie" else "/search/tv"
    return get(path, DAY, query=query, page=page)


def movie(tmdb_id):
    return get("/movie/%s" % tmdb_id, 7 * DAY, append_to_response="external_ids,release_dates")


def tv(tmdb_id):
    return get("/tv/%s" % tmdb_id, 2 * DAY, append_to_response="external_ids,content_ratings,alternative_titles")


def season(tmdb_id, n):
    return get("/tv/%s/season/%s" % (tmdb_id, n), DAY)


def collection(cid):
    return get("/collection/%s" % cid, 7 * DAY)


def find_imdb(imdb):
    return get("/find/%s" % imdb, 7 * DAY, external_source="imdb_id")


def listing(path, page=1, **params):
    return get(path, 6 * 3600, page=page, **params)


# ---------------------------------------------------------------- normalised details for the library
def _cert_movie(d):
    for c in (d.get("release_dates") or {}).get("results") or []:
        if c.get("iso_3166_1") in ("GB", "US"):
            for rd in c.get("release_dates") or []:
                if rd.get("certification"):
                    return rd["certification"]
    return ""


def _cert_tv(d):
    for c in (d.get("content_ratings") or {}).get("results") or []:
        if c.get("iso_3166_1") in ("GB", "US") and c.get("rating"):
            return c["rating"]
    return ""


def details(kind, tmdb_id):
    """-> dict ready for the items table."""
    if kind == "movie":
        d = movie(tmdb_id)
        if not d:
            return None
        col = d.get("belongs_to_collection") or {}
        return {
            "tmdb": d.get("id"), "imdb": d.get("imdb_id") or (d.get("external_ids") or {}).get("imdb_id") or "",
            "title": d.get("title") or "", "original": d.get("original_title") or "",
            "year": _year(d.get("release_date")), "plot": d.get("overview") or "", "tagline": d.get("tagline") or "",
            "poster": img(d.get("poster_path")), "fanart": img(d.get("backdrop_path"), "w1280"),
            "rating": d.get("vote_average") or 0, "votes": d.get("vote_count") or 0,
            "genres": ", ".join(g["name"] for g in d.get("genres") or []), "runtime": (d.get("runtime") or 0) * 60,
            "mpaa": _cert_movie(d), "studio": ", ".join(c["name"] for c in (d.get("production_companies") or [])[:2]),
            "status": d.get("status") or "", "collection_id": col.get("id"), "collection": col.get("name") or "",
            "seasons": "[]",
        }
    d = tv(tmdb_id)
    if not d:
        return None
    import json
    seasons = [{"n": s.get("season_number"), "count": s.get("episode_count") or 0, "name": s.get("name") or "",
                "poster": img(s.get("poster_path")), "air": s.get("air_date") or ""}
               for s in d.get("seasons") or [] if s.get("season_number") is not None]
    rt = d.get("episode_run_time") or []
    return {
        "tmdb": d.get("id"), "imdb": (d.get("external_ids") or {}).get("imdb_id") or "",
        "title": d.get("name") or "", "original": d.get("original_name") or "",
        "year": _year(d.get("first_air_date")), "plot": d.get("overview") or "", "tagline": d.get("tagline") or "",
        "poster": img(d.get("poster_path")), "fanart": img(d.get("backdrop_path"), "w1280"),
        "rating": d.get("vote_average") or 0, "votes": d.get("vote_count") or 0,
        "genres": ", ".join(g["name"] for g in d.get("genres") or []), "runtime": (rt[0] if rt else 0) * 60,
        "mpaa": _cert_tv(d), "studio": ", ".join(n["name"] for n in (d.get("networks") or [])[:2]),
        "status": d.get("status") or "", "collection_id": None, "collection": "",
        "seasons": json.dumps(seasons),
    }


def alt_titles(tv_details):
    """Latin-script alternative titles (romaji names help anime searches)."""
    out = []
    for t in ((tv_details or {}).get("alternative_titles") or {}).get("results") or []:
        s = t.get("title") or ""
        if s and re.match(r"^[\x20-\x7eÀ-ɏ]+$", s) and s not in out:
            out.append(s)
    return out


def absolute_to_se(seasons, absolute):
    """Anime absolute episode number -> (season, episode) using TMDB season sizes."""
    n = absolute
    regular = sorted([s for s in seasons if s.get("n")], key=lambda s: s["n"])
    for s in regular:
        c = s.get("count") or 0
        if c and n <= c:
            return s["n"], n
        n -= c
    if regular:
        return 1, absolute
    return 1, absolute


def se_to_absolute(seasons, season_n, ep):
    total = 0
    for s in sorted([s for s in seasons if s.get("n")], key=lambda s: s["n"]):
        if s["n"] < season_n:
            total += s.get("count") or 0
    return total + ep


def aired(date_str):
    try:
        return datetime.date(*[int(x) for x in date_str[:10].split("-")]) <= datetime.date.today()
    except (ValueError, TypeError, AttributeError):
        return False


def log_err(e):
    log("TMDB: %s" % e, "warn")
