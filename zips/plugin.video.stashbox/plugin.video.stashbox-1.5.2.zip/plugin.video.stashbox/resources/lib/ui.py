# -*- coding: utf-8 -*-
"""The library side: home, sections, shows, seasons, episodes, playback, right-click actions, tools."""
import datetime
import json
import os
import re
import time

import xbmc
import xbmcgui
import xbmcplugin

import db
import downloads
import library
import names
import places
import scanner
import tmdb
import vfs
from common import (HOME, NAME, RULE_TEXT, SECTION_KIND, SECTION_LABEL, SECTIONS, all_locations, auto_label, fmt_size,
                    fmt_time, hide_creds, load_json, load_locations, load_rules, loc_label, location_for, locations,
                    log, log_exc, notify, npath, rel, remap_rules, request, save_locations, sections_set_up,
                    set_rule, setting, setting_bool, set_setting, under)
from kodiui import add, color, end, fail_dir, fail_play, handle, item, refresh, run, set_info, url
from player import PROP

SEC_ICON = {"movies": "movies", "tv": "tv", "anime": "anime", "kdrama": "kdrama", "music": "music"}


# ---------------------------------------------------------------- list items
def _genres(row):
    return [g for g in (row["genres"] or "").split(", ") if g]


def item_li(row, label=None, extra_plot=""):
    li = xbmcgui.ListItem(label or row["title"])
    art = {"poster": row["poster"], "thumb": row["poster"], "icon": row["poster"], "fanart": row["fanart"],
           "landscape": row["fanart"]}
    li.setArt(dict((k, v) for k, v in art.items() if v) or {"icon": "DefaultVideo.png"})
    plot = row["plot"] or ""
    if not row["matched"]:
        plot = color("Not matched on TMDB - right-click > Fix match", "orange") + "\n" + plot
    if extra_plot:
        plot = extra_plot + "\n\n" + plot
    set_info(li, {"mediatype": "movie" if row["kind"] == "movie" else "tvshow", "title": row["title"],
                  "plot": plot, "year": row["year"], "genres": _genres(row), "rating": row["rating"],
                  "votes": row["votes"], "duration": row["runtime"], "mpaa": row["mpaa"],
                  "studio": [row["studio"]] if row["studio"] else [], "tagline": row["tagline"],
                  "originaltitle": row["original"], "tmdb": row["tmdb"], "imdb": row["imdb"],
                  "sorttitle": row["sorttitle"], "tvshowtitle": row["title"] if row["kind"] == "show" else None})
    return li


def item_ctx(row, watched=None):
    c = []
    if watched is not None:
        c.append(("Mark as unwatched" if watched else "Mark as watched",
                  run(action="mark", id=row["id"], w="0" if watched else "1")))
    c.append(("Where is it on the NAS?", "Container.Update(%s)" % url(action="where", id=row["id"])))
    if row["kind"] == "show":
        c.append(("Not one show? Split it up...", run(action="split", id=row["id"])))
        c.append(("Look for missing episodes on the NAS", run(action="hunt", id=row["id"])))
        c.append(("Get missing episodes (download)", "Container.Update(%s)" % url(
            action="get_title", k=row["section"], tmdb=row["tmdb"] or "", lib=row["id"])))
    c += [("Fix match (search TMDB)..." if row["matched"] else "Find it on TMDB (match by hand)...",
           run(action="fixmatch", id=row["id"])),
          ("Refresh info", run(action="refresh_item", id=row["id"])),
          ("Delete from NAS", run(action="delete", id=row["id"]))]
    return c


def file_ctx(f, watched):
    return [("Mark as unwatched" if watched else "Mark as watched",
             run(action="markf", f=f["path"], w="0" if watched else "1")),
            ("Play from the start", "PlayMedia(%s)" % url(action="play", f=f["path"], resume="0")),
            ("File info", run(action="fileinfo", f=f["path"])),
            ("Delete from NAS", run(action="deletef", f=f["path"]))]


# ---------------------------------------------------------------- home
def home():
    secs = sections_set_up()
    if not secs:
        add(color("Set up your NAS folders", "lightgreen"), {"action": "folders"}, True, icon="folder",
            plot="Add the folders on your NAS (and any USB drives plugged into it) for Movies, TV, Anime and "
                 "K-Dramas. Each section can have as many folders as you like.")
    now = scanning_now()
    if now:
        add(color("Scanning now %d%%: %s" % (now["pct"], now["head"]), "deepskyblue") + "  " + color(now["where"], "grey"),
            {"action": "folders"}, True, icon="scan", plot="StashBox is reading %s\n\n%s" % (now["head"], now["where"]))
    if not tmdb.have_key():
        add(color("Add a TMDB key (for posters and matching)", "orange"), {"action": "accounts"}, False, icon="key",
            plot="Free from themoviedb.org > Settings > API. If TorUtilityBox has one, use Tools > Import keys.")
    cw = library.continue_watching(1)
    if cw:
        add("Continue Watching", {"action": "continue"}, icon="continue")
    if library.next_up(1):
        add("Next Up", {"action": "nextup"}, icon="nextup")
    add("Recently Added", {"action": "recent"}, icon="recent")
    counts = db.counts()
    for sid, label, _key, _kind in secs:
        n = counts.get(sid, 0)
        add("%s  %s" % (label, color("(%d)" % n, "grey")), {"action": "section", "s": sid}, icon=SEC_ICON[sid])
    import music
    if music.enabled():
        n, albums, _ar = music.counts()
        add("Music  %s" % color("(%d albums)" % albums if n else "(look for it)", "grey"), {"action": "music"},
            icon="music")
    add("Search my library", {"action": "lib_search"}, icon="search")
    add(color("Get new media", "deepskyblue"), {"action": "get"}, icon="get",
        plot="Find films and shows, pick a torrent, and StashBox saves it to your NAS through TorBox, Real-Debrid or "
             "Cocoleech.")
    n = downloads.counts()
    dl = "Downloads"
    if n["active"]:
        dl += "  " + color("(%d on the go)" % n["active"], "lightgreen")
    elif n["failed"]:
        dl += "  " + color("(%d failed)" % n["failed"], "red")
    add(dl, {"action": "downloads"}, icon="downloads")
    add("Tools & settings", {"action": "tools"}, icon="tools")
    end(cache=False)


def section(sec):
    kind = SECTION_KIND[sec]
    label = SECTION_LABEL[sec]
    fan = _section_fanart(sec)
    if kind == "movie":
        rows = [("All movies", {"action": "list", "s": sec}, "movies"),
                ("Unwatched", {"action": "list", "s": sec, "f": "unwatched"}, "eye"),
                ("Recently added", {"action": "recent", "s": sec}, "recent"),
                ("Continue watching", {"action": "continue", "s": sec}, "continue"),
                ("Collections", {"action": "collections", "s": sec}, "collection"),
                ("Genres", {"action": "genres", "s": sec}, "genre"),
                ("By year", {"action": "years", "s": sec}, "calendar"),
                ("Top rated", {"action": "list", "s": sec, "o": "rating"}, "star")]
    else:
        rows = [("All shows", {"action": "list", "s": sec}, SEC_ICON[sec]),
                ("Next up", {"action": "nextup", "s": sec}, "nextup"),
                ("Continue watching", {"action": "continue", "s": sec}, "continue"),
                ("Recently added", {"action": "recent", "s": sec}, "recent"),
                ("Unwatched shows", {"action": "list", "s": sec, "f": "unwatched"}, "eye"),
                ("Genres", {"action": "genres", "s": sec}, "genre"),
                ("Top rated", {"action": "list", "s": sec, "o": "rating"}, "star")]
    if len(locations(sec)) > 1 or db.one("SELECT 1 FROM files WHERE section=? AND cat<>'' LIMIT 1", (sec,)):
        rows.insert(1, ("Your folders", {"action": "browse", "s": sec}, "folder"))
    for lab, p, ic in rows:
        add(lab, p, icon=ic, fanart=fan)
    n_un = unmatched_count(sec)
    if n_un:
        add(color("Not matched (%d) - match them by hand" % n_un, "orange"), {"action": "unmatched", "s": sec},
            icon="search", fanart=fan,
            plot="Titles TMDB couldn't place from their folder and file names. Pick one to see suggestions, search "
                 "with your own words, or type its TMDB / IMDb ID.")
    add(color("Get new %s" % label.lower(), "deepskyblue"), {"action": "get_menu", "k": sec}, icon="get", fanart=fan)
    end(cache=False)


def _section_fanart(sec):
    r = db.one("SELECT fanart FROM items WHERE section=? AND fanart<>'' ORDER BY added DESC LIMIT 1", (sec,))
    return r["fanart"] if r else None


def list_items(sec, f=None, order="title", genre=None, year=None, coll=None, froot=None, fcoll=None):
    kind = SECTION_KIND[sec]
    if f == "unwatched" and kind == "movie":
        rows = library.unwatched_movies(sec)
    elif genre:
        rows = library.items(sec, order, "(', ' || i.genres || ',') LIKE ?", ("%%, %s,%%" % genre,))
    elif year:
        rows = library.items(sec, "title", "i.year BETWEEN ? AND ?", (int(year), int(year) + 9))
    elif coll or fcoll:
        if coll:
            rows = library.items(sec, "year", "i.collection_id=?", (int(coll),))
        else:
            rows = db.q("SELECT DISTINCT i.* FROM items i JOIN files f ON f.item_id=i.id WHERE f.section=? AND "
                        "f.root=? AND f.coll=?", (sec, froot, fcoll))
        nums = library.collection_order([r["id"] for r in rows])
        rows = sorted(rows, key=lambda r: (nums.get(r["id"]) is None, nums.get(r["id"]) or 0, r["year"] or 0))
        _movie_rows(rows, nums)
        if coll:
            _missing_parts(int(coll), set(r["tmdb"] for r in rows))
        return end("movies", cache=False)
    else:
        rows = library.items(sec, order)
    if kind == "movie":
        _movie_rows(rows)
        sorts = [xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, xbmcplugin.SORT_METHOD_VIDEO_YEAR,
                 xbmcplugin.SORT_METHOD_VIDEO_RATING, xbmcplugin.SORT_METHOD_DATEADDED]
        end("movies", sorts if order == "title" and not coll else None, cache=False)
    else:
        _show_rows(rows, unwatched_only=(f == "unwatched"))
        end("tvshows", [xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, xbmcplugin.SORT_METHOD_VIDEO_YEAR,
                        xbmcplugin.SORT_METHOD_VIDEO_RATING] if order == "title" else None, cache=False)


def _missing_parts(cid, have):
    """Films in this series that aren't on your NAS, greyed out - select one to get it."""
    if not tmdb.have_key():
        return
    try:
        parts = tmdb.collection(cid).get("parts") or []
    except tmdb.TMDBError as e:
        return tmdb.log_err(e)
    parts = sorted(parts, key=lambda p: p.get("release_date") or "9999")
    for n, p in enumerate(parts, 1):
        if p.get("id") in have or not tmdb.aired(p.get("release_date") or ""):
            continue
        y = (p.get("release_date") or "")[:4]
        li = xbmcgui.ListItem(color("%d. %s (%s)  [not on your NAS]" % (n, p.get("title"), y or "?"), "grey"))
        li.setArt(dict((k, v) for k, v in {"poster": tmdb.img(p.get("poster_path")),
                                            "fanart": tmdb.img(p.get("backdrop_path"), "w1280")}.items() if v))
        set_info(li, {"mediatype": "movie", "title": p.get("title"), "year": int(y) if y.isdigit() else None,
                      "plot": color("Not on your NAS - select to find it", "deepskyblue") + "\n\n" +
                      (p.get("overview") or "")})
        xbmcplugin.addDirectoryItem(handle(), url(action="get_title", k="movies", tmdb=p["id"]), li, isFolder=True)


def _movie_rows(rows, nums=None):
    files = {}
    for r in rows:
        files[r["id"]] = []
    if not rows:
        return
    ids = list(files)
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        for f in db.q("SELECT * FROM files WHERE item_id IN (%s)" % ",".join("?" * len(chunk)), chunk):
            files[f["item_id"]].append(f)
    prog = db.progress_map([f["path"] for fs in files.values() for f in fs])
    where_txt = places.summaries([r["id"] for r in rows])
    for r in rows:
        fs = files.get(r["id"]) or []
        if not fs:
            continue
        watched = any(prog.get(f["path"]) and prog[f["path"]]["watched"] for f in fs)
        p = next((prog[f["path"]] for f in fs if prog.get(f["path"]) and not prog[f["path"]]["watched"]
                  and prog[f["path"]]["pos"] > 60), None)
        label = r["title"]
        if r["year"]:
            label += " (%s)" % r["year"]
        if nums and nums.get(r["id"]) is not None:
            label = "%d. %s" % (nums[r["id"]], label)
        extra = ""
        if p and p["total"]:
            pct = int(100 * p["pos"] / p["total"])
            label += "  " + color("%d%%" % pct, "orange")
            extra = color("Stopped at %s of %s" % (fmt_time(p["pos"]), fmt_time(p["total"])), "orange")
        if len(fs) > 1:
            nd = sum(1 for f in fs if names.is_disc_path(f["path"]))
            label += "  " + color("(%d %s)" % (len(fs), "discs" if nd == len(fs) else "versions"), "grey")
        on = (where_txt or {}).get(r["id"])
        li = item_li(r, label, (extra + "\n" if extra else "") + (color("On: " + on, "grey") if on else ""))
        if watched:
            set_info(li, {"playcount": 1})
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(item_ctx(r, watched))
        if len(fs) == 1:
            u = url(action="play", f=fs[0]["path"])
        else:
            u = url(action="play_item", id=r["id"])
        xbmcplugin.addDirectoryItem(handle(), u, li, isFolder=False)


def _show_rows(rows, unwatched_only=False):
    stats = library.show_stats([r["id"] for r in rows])
    where_txt = places.summaries([r["id"] for r in rows])
    for r in rows:
        n, w = stats.get(r["id"], (0, 0))
        if unwatched_only and n and w >= n:
            continue
        left = n - w
        label = r["title"]
        if left and w:
            label += "  " + color("%d left" % left, "orange")
        elif n and not w:
            label += "  " + color("%d eps" % n, "grey")
        li = item_li(r, label, "%d episode%s on the NAS, %d watched\n%s" % (
            n, "" if n == 1 else "s", w, color("On: " + where_txt.get(r["id"], "?"), "grey")))
        if n and w >= n:
            set_info(li, {"playcount": 1})
        li.addContextMenuItems(item_ctx(r, bool(n and w >= n)))
        xbmcplugin.addDirectoryItem(handle(), url(action="show", id=r["id"]), li, isFolder=True)


def genres(sec):
    for g, n in library.genres(sec):
        add("%s  %s" % (g, color("(%d)" % n, "grey")), {"action": "list", "s": sec, "g": g}, icon="genre")
    end()


def years(sec):
    decades = {}
    for r in db.q("SELECT year FROM items WHERE section=? AND year IS NOT NULL", (sec,)):
        d = (r["year"] // 10) * 10
        decades[d] = decades.get(d, 0) + 1
    for d in sorted(decades, reverse=True):
        add("%ds  %s" % (d, color("(%d)" % decades[d], "grey")), {"action": "list", "s": sec, "y": d},
            icon="calendar")
    end()


def collections(sec):
    rows = library.collections(sec)
    if not rows:
        add(color("No collections yet - your 'Collection' / 'Pack' folders and film series show up here", "grey"),
            {}, False)
    for r in rows:
        if r["kind"] == "tmdb":
            p = {"action": "list", "s": sec, "c": r["id"]}
            plot = "Your folder: %s" % r["folder_name"] if r.get("folder_name") else "Film series (from TMDB)"
        else:
            p = {"action": "list", "s": sec, "fr": r["root"], "fc": r["coll"]}
            plot = "Your folder: %s" % r["coll"].replace("/", " > ")
        add("%s  %s" % (r["name"], color("(%d)" % r["n"], "grey")), p, icon="collection", poster=r["poster"],
            fanart=r["fanart"], plot=plot)
    end("sets", cache=False)


# ---------------------------------------------------------------- shows
def show(item_id):
    it = db.item(item_id)
    if not it:
        return fail_dir()
    by_season = library.season_files(item_id)
    tm_seasons = dict((s["n"], s) for s in db.seasons_of(it))
    prog = db.progress_map([f["path"] for fs in by_season.values() for f in fs])
    all_s = sorted(set(by_season) | (set(n for n in tm_seasons if n) if setting_bool("show_missing", True) else set()))
    if len(all_s) == 1 and not setting_bool("show_missing", True):
        return season(item_id, all_s[0])
    hs = places.homes(item_id)
    if len(hs) == 1:
        lab = "On your NAS: %s" % hs[0]["label"]
    else:
        lab = "On your NAS in %d places: %s" % (len(hs), ", ".join(h["label"] for h in hs[:2]) +
                                                 (" ..." if len(hs) > 2 else ""))
    add(color(lab, "grey"), {"action": "where", "id": item_id}, True, icon="folder", fanart=it["fanart"],
        plot="\n".join("%s\n   %s, %d episodes, %s" % (h["label"], h["season_text"] or "no numbered episodes",
                                                        h["count"], fmt_size(h["size"])) for h in hs))
    odd = places.suspicious(it)
    if odd:
        add(color("Looks like more than one show? Split it up...", "orange"), {"action": "split", "id": item_id}, False,
            icon="folder", fanart=it["fanart"],
            plot="%s.\n\nIf a folder of different shows has been read as one show, this sorts it into separate "
                 "shows (and you can undo it from Tools > Folder rules)." % "; ".join(odd).capitalize())
    missing = 0
    on_disc = set(f["season"] for fs in by_season.values() for f in fs if names.is_disc_path(f["path"]))
    for n, ts in tm_seasons.items():
        if n and tmdb.aired(ts.get("air") or "") and n not in on_disc:
            have = set(f["episode"] for f in by_season.get(n, []) if f["episode"] is not None)
            missing += max(0, (ts.get("count") or 0) - len(have))
    if missing:
        add(color("Missing episodes? Look for them elsewhere on the NAS", "deepskyblue"),
            {"action": "hunt", "id": item_id}, False, icon="search", fanart=it["fanart"],
            plot="Looks through your StashBox folders and the rest of the drives they're on for episodes of %s "
                 "that aren't counted - stray downloads, files filed under another name, ones that were too small."
                 % it["title"])
    for n in all_s:
        fs = by_season.get(n, [])
        eps = set(f["episode"] for f in fs if f["episode"] is not None)
        w = len(set(f["episode"] for f in fs if prog.get(f["path"]) and prog[f["path"]]["watched"]))
        ts = tm_seasons.get(n) or {}
        name = ts.get("name") or ("Specials" if n == 0 else "Season %d" % n)
        if n == 0 and not fs:
            continue
        have = len(eps)
        cnt = ts.get("count") or 0
        discs = [f for f in fs if names.is_disc_path(f["path"])]
        if discs and not eps:
            tag = color("on %s (%d disc%s)" % (names.disc_kind(discs[0]["path"]), len(discs),
                                              "" if len(discs) == 1 else "s"), "lightgreen")
        elif fs and cnt and have < cnt:
            tag = color("%d of %d on NAS" % (have, cnt), "orange") + (
                color(" + %d disc%s" % (len(discs), "" if len(discs) == 1 else "s"), "lightgreen") if discs else "")
        elif fs:
            tag = color("%d eps" % (have or len(fs)), "grey")
        else:
            if not tmdb.aired(ts.get("air") or ""):
                continue
            tag = color("none on NAS", "grey")
        label = "%s  %s" % (name, tag)
        li = xbmcgui.ListItem(label)
        li.setArt(dict((k, v) for k, v in {"poster": ts.get("poster") or it["poster"], "fanart": it["fanart"],
                                            "thumb": ts.get("poster") or it["poster"]}.items() if v))
        set_info(li, {"mediatype": "season", "title": name, "season": n, "tvshowtitle": it["title"],
                      "plot": it["plot"], "playcount": 1 if fs and w >= len(eps) and eps else None})
        ctx = []
        if fs:
            ctx.append(("Mark season watched", run(action="mark", id=item_id, n=n, w="1")))
            ctx.append(("Mark season unwatched", run(action="mark", id=item_id, n=n, w="0")))
        if it["tmdb"]:
            ctx.append(("Get missing episodes of this season", run(action="autoget", k=it["section"], tmdb=it["tmdb"],
                                                                     n=n, lib=item_id)))
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle(), url(action="season", id=item_id, n=n), li, isFolder=True)
    end("seasons", cache=False)


def season(item_id, n):
    it = db.item(item_id)
    if not it:
        return fail_dir()
    n = int(n)
    fs = [f for f in db.item_files(item_id) if (f["season"] if f["season"] is not None else 0) == n]
    prog = db.progress_map([f["path"] for f in fs])
    meta = {}
    if it["tmdb"] and tmdb.have_key():
        try:
            for e in tmdb.season(it["tmdb"], n).get("episodes") or []:
                meta[e.get("episode_number")] = e
        except tmdb.TMDBError as e:
            tmdb.log_err(e)
    have = {}
    discs = [f for f in fs if names.is_disc_path(f["path"])]
    for f in fs:
        if f not in discs:
            have.setdefault(f["episode"], []).append(f)
    for f in sorted(discs, key=lambda f: (f["ord"] or 0, f["label"])):  # DVD / Blu-ray discs of this season first
        _episode_item(it, f, {"overview": "%s - plays with the disc's own menus." % f["label"]},
                      prog.get(f["path"]), f["label"])
    # a season you have on DVD: its episodes are on the discs, so don't list them as missing
    show_missing = setting_bool("show_missing", True) and not (discs and not any(k is not None for k in have))
    eps = sorted(set(k for k in have if k is not None) | (set(meta) if show_missing else set()))
    for ep in eps:
        m = meta.get(ep) or {}
        files = have.get(ep)
        name = m.get("name") or (names.stem(files[0]["label"]) if files else "Episode %d" % ep)
        if not files:
            if not tmdb.aired(m.get("air_date") or ""):
                continue
            label = color("%d. %s  [missing]" % (ep, name), "grey")
            li = xbmcgui.ListItem(label)
            li.setArt(dict((k, v) for k, v in {"thumb": tmdb.img(m.get("still_path"), "w300") or it["poster"],
                                                "fanart": it["fanart"]}.items() if v))
            set_info(li, {"mediatype": "episode", "title": name, "season": n, "episode": ep,
                          "tvshowtitle": it["title"], "premiered": m.get("air_date"),
                          "plot": color("Not on your NAS - select to find it", "deepskyblue") + "\n\n" +
                          (m.get("overview") or "")})
            xbmcplugin.addDirectoryItem(handle(), url(action="sources", k=it["section"], tmdb=it["tmdb"], n=n, e=ep,
                                                      lib=item_id), li, isFolder=True)
            continue
        f = max(files, key=lambda x: x["size"] or 0)
        _episode_item(it, f, m, prog.get(f["path"]), name)
    for f in have.get(None, []):  # files we couldn't number
        _episode_item(it, f, {}, prog.get(f["path"]), names.stem(f["label"]))
    end("episodes", cache=False)


def _episode_item(it, f, m, p, name):
    ep = f["episode"]
    label = ("%d. %s" % (ep, name)) if ep is not None else name
    extra = ""
    watched = bool(p and p["watched"])
    if p and not watched and p["pos"] > 60 and p["total"]:
        label += "  " + color("%d%%" % int(100 * p["pos"] / p["total"]), "orange")
        extra = color("Stopped at %s" % fmt_time(p["pos"]), "orange") + "\n\n"
    li = xbmcgui.ListItem(label)
    thumb = tmdb.img(m.get("still_path"), "w300") if m.get("still_path") else it["fanart"] or it["poster"]
    li.setArt(dict((k, v) for k, v in {"thumb": thumb, "fanart": it["fanart"], "poster": it["poster"],
                                        "icon": thumb}.items() if v))
    set_info(li, {"mediatype": "episode", "title": name, "season": f["season"], "episode": ep,
                  "tvshowtitle": it["title"], "plot": extra + (m.get("overview") or "") +
                  "\n\n" + color("%s\nOn: %s" % (f["label"], places.place_label(vfs.parent(f["path"]))), "grey"),
                  "premiered": m.get("air_date"),
                  "duration": (m.get("runtime") or 0) * 60, "playcount": 1 if watched else None,
                  "rating": m.get("vote_average")})
    li.setProperty("IsPlayable", "true")
    li.addContextMenuItems(file_ctx(f, watched))
    xbmcplugin.addDirectoryItem(handle(), url(action="play", f=f["path"]), li, isFolder=False)


# ---------------------------------------------------------------- home rows
def continue_watching(sec=None):
    for f in library.continue_watching(60, sec):
        it = db.item(f["item_id"])
        if not it:
            continue
        pct = int(100 * f["pos"] / f["total"]) if f["total"] else 0
        if it["kind"] == "show":
            label = "%s  S%02dE%02d  %s" % (it["title"], f["season"] or 0, f["episode"] or 0, color("%d%%" % pct,
                                                                                                   "orange"))
        else:
            label = "%s  %s" % (it["title"], color("%d%%" % pct, "orange"))
        li = item_li(it, label, color("Resume from %s" % fmt_time(f["pos"]), "orange"))
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(file_ctx(f, False))
        xbmcplugin.addDirectoryItem(handle(), url(action="play", f=f["path"], resume="1"), li, isFolder=False)
    end("videos", cache=False)


def next_up(sec=None):
    for f, _last in library.next_up(60, sec):
        it = db.item(f["item_id"])
        if not it:
            continue
        label = "%s  %s" % (it["title"], color("S%02dE%02d" % (f["season"], f["episode"] or 0), "lightgreen"))
        li = item_li(it, label, "Next: Season %d, episode %d" % (f["season"], f["episode"] or 0))
        set_info(li, {"mediatype": "episode", "season": f["season"], "episode": f["episode"],
                      "tvshowtitle": it["title"]})
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(file_ctx(f, False))
        xbmcplugin.addDirectoryItem(handle(), url(action="play", f=f["path"]), li, isFolder=False)
    end("episodes", cache=False)


def recent(sec=None):
    rows = library.recently_added(60, sec)
    if not rows:
        add(color("Nothing new in the last 60 days", "grey"), {}, False)
    for r in rows:
        it = r[1]
        when = _ago(r[2])
        if r[0] == "movie":
            fs = db.item_files(it["id"])
            if not fs:
                continue
            li = item_li(it, "%s  %s" % (it["title"], color(when, "grey")))
            li.setProperty("IsPlayable", "true")
            li.addContextMenuItems(item_ctx(it))
            u = url(action="play", f=fs[0]["path"]) if len(fs) == 1 else url(action="play_item", id=it["id"])
            xbmcplugin.addDirectoryItem(handle(), u, li, isFolder=False)
        else:
            n = r[3]
            li = item_li(it, "%s  %s" % (it["title"], color("%d new %s" % (n, when), "lightgreen")))
            li.addContextMenuItems(item_ctx(it))
            xbmcplugin.addDirectoryItem(handle(), url(action="show", id=it["id"]), li, isFolder=True)
    end("videos", cache=False)


def _ago(ts):
    if not ts:
        return ""
    d = (time.time() - ts) / 86400
    if d < 1:
        return "today"
    if d < 2:
        return "yesterday"
    if d < 14:
        return "%d days ago" % d
    return datetime.datetime.fromtimestamp(ts).strftime("%d %b")


def lib_search(text=None):
    if text is None:
        text = xbmcgui.Dialog().input("Search my library")
        if not text:
            return fail_dir()
    rows = library.search(text)
    if not rows:
        add(color("Nothing on the NAS matches '%s'" % text, "grey"), {}, False)
        add(color("Look for '%s' to download" % text, "deepskyblue"), {"action": "get_results", "k": "any", "q": text},
            icon="get")
    movies = [r for r in rows if r["kind"] == "movie"]
    shows = [r for r in rows if r["kind"] == "show"]
    _movie_rows(movies)
    _show_rows(shows)
    end("videos", cache=False)


# ---------------------------------------------------------------- playback
def play(path, resume=None, auto=False):
    f = db.one("SELECT * FROM files WHERE path=?", (path,))
    it = db.item(f["item_id"]) if f else None
    pr = db.progress(path)
    start = 0
    if pr and not pr["watched"] and (pr["pos"] or 0) > 60 and resume != "0":
        if resume == "1" or auto:
            start = pr["pos"]
        else:
            i = xbmcgui.Dialog().contextmenu(["Resume from %s" % fmt_time(pr["pos"]), "Play from the start"])
            if i < 0:
                return fail_play()
            start = pr["pos"] if i == 0 else 0
    if not vfs.exists(path):
        notify("Can't reach that file - is the NAS on?", "error")
        log("Play: can't reach %s" % path, "warn")
        return fail_play()
    li = xbmcgui.ListItem(path=path)
    if it:
        li.setArt(dict((k, v) for k, v in {"poster": it["poster"], "fanart": it["fanart"],
                                            "thumb": it["poster"]}.items() if v))
        if it["kind"] == "movie":
            set_info(li, {"mediatype": "movie", "title": it["title"], "year": it["year"], "plot": it["plot"],
                          "tmdb": it["tmdb"], "imdb": it["imdb"]})
        else:
            title = names.stem(f["label"])
            if it["tmdb"] and f["episode"] is not None:
                try:
                    for e in tmdb.season(it["tmdb"], f["season"]).get("episodes") or []:
                        if e.get("episode_number") == f["episode"]:
                            title = e.get("name") or title
                except Exception:
                    pass
            set_info(li, {"mediatype": "episode", "title": title, "tvshowtitle": it["title"], "season": f["season"],
                          "episode": f["episode"], "plot": it["plot"]})
    if start:
        li.setProperty("StartOffset", "%.1f" % start)
    HOME.setProperty(PROP, json.dumps({"path": path, "item": f["item_id"] if f else None,
                                       "season": f["season"] if f and it and it["kind"] == "show" else None,
                                       "episode": f["episode"] if f else None, "start": start}))
    xbmcplugin.setResolvedUrl(handle(), True, li)


def play_item(item_id):
    fs = db.item_files(item_id)
    if not fs:
        return fail_play()
    if len(fs) == 1:
        return play(fs[0]["path"])
    rank = {"2160p": 4, "1080p": 3, "720p": 2, "480p": 1}
    fs = sorted(fs, key=lambda f: (-rank.get(names.resolution(f["label"]), 0), -(f["size"] or 0)))
    labels = ["%s  %s  %s" % (names.disc_kind(f["path"]) if names.is_disc_path(f["path"]) else
                              names.resolution(f["label"]), fmt_size(f["size"]), f["label"]) for f in fs]
    i = xbmcgui.Dialog().select("Which version?", labels)
    if i < 0:
        return fail_play()
    play(fs[i]["path"])


# ---------------------------------------------------------------- right-click actions
def mark(item_id=None, path=None, watched=True, season_n=None):
    if path:
        paths = [path]
    else:
        fs = db.item_files(item_id)
        if season_n is not None:
            fs = [f for f in fs if (f["season"] or 0) == int(season_n)]
        paths = [f["path"] for f in fs]
    db.mark_watched(paths, watched)
    refresh()


def _match_queries(it):
    """Names worth searching TMDB with for an unmatched title: its own, its folders', its files', and the
    fallbacks (without '02 ', '1979 ', 'Jerry Lewis - ' ...). -> [(query, year)]"""
    show = it["kind"] == "show"
    parse = names.parse_show_name if show else names.parse_movie
    out = [(it["title"], it["year"])]
    files = db.item_files(it["id"])
    for h in places.homes(it["id"])[:2]:
        base = vfs.basename(h["folder"])
        if h["own"] and base:
            t, y = parse(base)
            out.append((names.clean_show_title(names.clean_part_title(t)) if show else t, y))
            par = vfs.basename(vfs.parent(h["folder"]))
            if show and par and not scanner.category_like(par):
                out.append((names.parse_show_name(par)[0], None))
    for f in files[:2]:
        t, y = (names.file_show_name(vfs.basename(f["path"])), None) if show else names.parse_movie(f["path"])
        if names.norm(t):
            out.append((t, y))
    out += names.fallback_titles(it["title"], it["year"])
    seen, res = set(), []
    for q, y in out:
        k = names.norm(q)
        if k and len(k) > 1 and k not in seen:
            seen.add(k)
            res.append((q, y))
    return res[:5]


def _result_li(r, kind):
    name = r.get("title") or r.get("name") or "?"
    y = (r.get("release_date") or r.get("first_air_date") or "")[:4]
    li = xbmcgui.ListItem("%s (%s)" % (name, y or "?"), (r.get("overview") or "")[:200])
    if r.get("poster_path"):
        li.setArt({"thumb": tmdb.img(r["poster_path"], "w185"), "icon": tmdb.img(r["poster_path"], "w185")})
    return li


def _tmdb_lookup(kind, queries):
    """Search each name, merge the results (best first). -> [results]"""
    seen, out = set(), []
    for q, y in queries:
        params = {"query": q}
        if y:
            params["year" if kind == "movie" else "first_air_date_year"] = y
        try:
            res = tmdb.get("/search/movie" if kind == "movie" else "/search/tv", 3 * 86400, **params).get("results") or []
            if not res and y:
                res = tmdb.search(kind, q).get("results") or []
        except tmdb.TMDBError as e:
            notify(str(e), "error")
            break
        for r in res[:8]:
            if r.get("id") not in seen:
                seen.add(r.get("id"))
                out.append(r)
    return out[:20]


def _by_id(kind, text):
    """'tt0436992' (IMDb) or '57243' (TMDB) -> a result dict, or None."""
    text = (text or "").strip()
    try:
        m = re.search(r"tt\d{5,}", text)
        if m:
            d = tmdb.find_imdb(m.group(0))
            hits = (d.get("movie_results") if kind == "movie" else d.get("tv_results")) or []
            return hits[0] if hits else None
        m = re.search(r"\d+", text)
        if m:
            d = tmdb.movie(int(m.group(0))) if kind == "movie" else tmdb.tv(int(m.group(0)))
            return d if d and d.get("id") else None
    except tmdb.TMDBError:
        return None
    return None


def fix_match(item_id, refresh_after=True):
    """Match a title by hand: suggestions from its folder / file names, your own search words (add a year), or a
    TMDB / IMDb ID."""
    it = db.item(item_id)
    if not it:
        return
    kind = "movie" if it["kind"] == "movie" else "tv"
    d = xbmcgui.Dialog()
    if not tmdb.have_key():
        return d.ok(NAME, "Add a TMDB key first (Tools > Accounts).")
    hs = places.homes(item_id)
    where = vfs.basename(hs[0]["folder"]) if hs and hs[0]["own"] else (
        vfs.basename(db.item_files(item_id)[0]["path"]) if db.item_files(item_id) else it["title"])
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Looking up '%s'..." % it["title"])
    try:
        sugg = _tmdb_lookup(kind, _match_queries(it))
    finally:
        prog.close()
    pick = None
    while pick is None:
        rows = [xbmcgui.ListItem("[B]Search with my own words...[/B]", "Add the year to narrow it down, "
                                                                        "e.g. 'Doctor Who 1963'"),
                xbmcgui.ListItem("[B]Type a TMDB or IMDb ID...[/B]", "From themoviedb.org or imdb.com "
                                                                     "- e.g. tt0436992 or 57243"),
                xbmcgui.ListItem("[B]Leave it unmatched[/B]" if it["matched"] else
                                 "[B]Leave it unmatched - stop listing it[/B]", "")]
        rows += [_result_li(r, kind) for r in sugg]
        i = d.select("%s - %s" % (where[:60], "%d suggestion%s" % (len(sugg), "" if len(sugg) == 1 else "s")
                                  if sugg else "no suggestions"), rows, useDetails=True)
        if i < 0:
            return
        if i == 0:
            q = d.input("Search TMDB for (add a year if you like)", it["title"])
            if not q:
                continue
            t, y = names.parse_movie(q)
            res = _tmdb_lookup(kind, [(t, y)] + ([(q, None)] if names.norm(q) != names.norm(t) else []))
            if not res:
                d.ok(NAME, "TMDB found nothing for '%s'." % q)
                continue
            j = d.select("Which is '%s'?" % where[:60], [_result_li(r, kind) for r in res], useDetails=True)
            if j >= 0:
                pick = res[j]
        elif i == 1:
            q = d.input("TMDB or IMDb ID", "")
            if not q:
                continue
            r = _by_id(kind, q)
            if not r:
                d.ok(NAME, "Couldn't find %s '%s' on TMDB." % ("a film" if kind == "movie" else "a show", q))
                continue
            name = r.get("title") or r.get("name")
            y = (r.get("release_date") or r.get("first_air_date") or "")[:4]
            if d.yesno(NAME, "Match '%s' to %s (%s)?" % (where, name, y or "?")):
                pick = r
        elif i == 2:
            for mk in scanner.item_mkeys(item_id):
                db.match_set(mk, 0, it["kind"], manual=1)
            if it["matched"]:
                scanner.relink(item_id, 0)
            notify("'%s' left unmatched" % it["title"])
            if refresh_after:
                refresh()
            return
        elif i - 3 < len(sugg):
            pick = sugg[i - 3]
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Matching...")
    try:
        scanner.relink(item_id, pick["id"])
    finally:
        prog.close()
    notify("Matched to %s" % (pick.get("title") or pick.get("name")))
    if refresh_after:
        refresh()


def _unmatched_rows(sec=None):
    rows = db.q("SELECT * FROM items WHERE matched=0%s ORDER BY section, COALESCE(sorttitle, title) COLLATE NOCASE" % (
        " AND section=?" if sec else ""), (sec,) if sec else ())
    kept = set(r["mkey"] for r in db.q("SELECT mkey FROM matches WHERE manual=1 AND tmdb=0"))
    out = []
    for r in rows:
        mks = scanner.item_mkeys(r["id"])
        if mks and all(m in kept for m in mks):
            continue  # you said to leave it unmatched
        out.append(r)
    return out


def unmatched_count(sec=None):
    try:
        return len(_unmatched_rows(sec))
    except Exception:
        return 0


def unmatched(sec=None):
    """Everything TMDB couldn't place, to go through one by one."""
    rows = _unmatched_rows(sec)
    if not rows:
        add(color("Everything's matched", "grey"), {"action": "noop"}, False, icon="star")
        return end(cache=False)
    places_ = places.summaries([r["id"] for r in rows])
    for r in rows:
        n = db.one("SELECT COUNT(*) n FROM files WHERE item_id=?", (r["id"],))["n"]
        lab = "%s  %s" % (names.title_year(r["title"], r["year"]), color(
            "%s%s" % ("" if sec else SECTION_LABEL.get(r["section"], "") + " - ", places_.get(r["id"], "")), "grey"))
        fs = db.item_files(r["id"])[:6]
        plot = "%s\n\n%s%s\n\nSelect to find it on TMDB." % (
            places_.get(r["id"], ""), "\n".join(vfs.basename(f["path"]) for f in fs),
            "\n... %d files" % n if n > len(fs) else "")
        add(lab, {"action": "fixmatch", "id": r["id"], "next": "1"}, False, icon="search", plot=plot,
            ctx=[("Play / open it", "Container.Update(%s)" % url(action="show" if r["kind"] == "show" else "where",
                                                                 id=r["id"])),
                 ("Where is it on the NAS?", "Container.Update(%s)" % url(action="where", id=r["id"])),
                 ("Not one %s? Sort out its folder..." % ("show" if r["kind"] == "show" else "film"),
                  run(action="split", id=r["id"], menu="1"))])
    end(cache=False)


def refresh_item(item_id):
    try:
        ok = scanner.refresh(item_id)
    except tmdb.TMDBError as e:
        return notify(str(e), "error")
    notify("Info refreshed" if ok else "Can't refresh - not matched on TMDB (try Fix match)")
    refresh()


def _delete_files(paths):
    gone, failed = 0, 0
    folders = set()
    for p in paths:
        if names.is_disc_path(p):
            failed += 1  # a DVD / Blu-ray folder: never deleted from here (it's a whole folder of files)
            log("Not deleting disc folder %s - delete it on the NAS if you're sure" % hide_creds(names.disc_folder(p)))
            continue
        ok = vfs.delete(p) or not vfs.exists(p)
        if ok:
            gone += 1
            db.run("DELETE FROM files WHERE path=?", (p,), commit=False)
            folders.add(vfs.parent(p))
            st = names.stem(vfs.basename(p))
            res = vfs.listdir(vfs.parent(p))
            if res:
                for side in res[1]:  # matching subtitles / nfo
                    if side.startswith(st) and not names.is_video(side):
                        vfs.delete(vfs.join(vfs.parent(p), side))
        else:
            failed += 1
    db.commit()
    db.drop_empty_items()
    roots = set(npath(loc["path"]) for _s, loc in all_locations())
    for fd in sorted(folders, key=len, reverse=True):
        for x in (fd, vfs.parent(fd)):
            x = x.rstrip("/\\")
            if x in roots or any(r.startswith(x) for r in roots):
                continue  # never remove a section's own folder
            vfs.rmdir_if_empty(x)
    return gone, failed


def delete_item(item_id):
    it = db.item(item_id)
    fs = db.item_files(item_id) if it else []
    if not fs:
        return
    total = sum(f["size"] or 0 for f in fs)
    if not xbmcgui.Dialog().yesno(NAME, "Delete %s from the NAS?\n%d file%s, %s. This can't be undone." % (
            it["title"], len(fs), "" if len(fs) == 1 else "s", fmt_size(total))):
        return
    discs = sum(1 for f in fs if names.is_disc_path(f["path"]))
    gone, failed = _delete_files([f["path"] for f in fs])
    failed -= discs
    msg = "Deleted %d file%s" % (gone, "" if gone == 1 else "s") if gone else ""
    if failed:
        msg += (" - " if msg else "") + "%d couldn't be deleted" % failed
    if discs:
        msg += (" - " if msg else "") + "DVD / Blu-ray folders aren't deleted from here - delete the folder on the NAS"
    notify(msg, "warn" if failed or discs else "info", 7000)
    refresh()


def delete_file(path):
    if not xbmcgui.Dialog().yesno(NAME, "Delete this file from the NAS?\n%s" % vfs.basename(path)):
        return
    if names.is_disc_path(path):
        return xbmcgui.Dialog().ok(NAME, "That's a DVD / Blu-ray folder rip (%s).\nDelete the folder on the NAS if "
                                         "you're sure - StashBox doesn't remove whole folders." % hide_creds(
                                             names.disc_folder(path)))
    gone, failed = _delete_files([path])
    notify("Deleted" if gone else "Couldn't delete it (read-only share?)", "info" if gone else "error")
    refresh()


def file_info(path):
    f = db.one("SELECT * FROM files WHERE path=?", (path,))
    if not f:
        return
    it = db.item(f["item_id"])
    xbmcgui.Dialog().textviewer(NAME, "File: %s\nFolder: %s\nSize: %s\nMatched as: %s (%s) - TMDB %s\n"
                                      "Season/episode: %s/%s" % (
                                          f["label"], hide_creds(vfs.parent(path)), fmt_size(f["size"]),
                                          it["title"] if it else "?", it["year"] if it else "?",
                                          it["tmdb"] if it else "-", f["season"], f["episode"]))


# ---------------------------------------------------------------- tools
def tools():
    rows = [("Your NAS folders (add drives, see what's being scanned)", {"action": "folders"}, "folder"),
            ("Scan the NAS for new files", {"action": "scan"}, "scan"),
            ("Last scan report", {"action": "scan_report"}, "log"),
            ("Find missing episodes everywhere on the NAS", {"action": "hunt"}, "search"),
            ("Last missing-episode search", {"action": "hunt_results"}, "search"),
            ("Shows and films in more than one place", {"action": "many_places"}, "folder"),
            ("Folder rules - folders you've sorted out (%d)" % len(load_rules()), {"action": "folder_rules"}, "folder"),
            ("Titles that need matching (%d)" % unmatched_count(), {"action": "unmatched"}, "search"),
            ("Rescan and re-match everything", {"action": "scan", "full": "1"}, "scan"),
            ("Accounts (TMDB, TorBox, Real-Debrid, Cocoleech)", {"action": "accounts"}, "key"),
            ("Import keys from TorUtilityBox", {"action": "import_keys"}, "key"),
            ("Test the torrent sources", {"action": "test_sources"}, "search"),
            ("Error log", {"action": "log"}, "log"),
            ("How each folder was read (detailed scan log)", {"action": "scan_detail"}, "log"),
            ("Export a problem report (zip to send for help)", {"action": "export"}, "log"),
            ("Settings", {"action": "settings"}, "tools")]
    last = db.meta_get("last_scan")
    for lab, p, ic in rows:
        plot = None
        if p.get("action") == "scan" and last and not p.get("full"):
            plot = "Last scan: %s" % _ago(float(last))
        if p.get("action") == "export":
            plot = ("Saves one zip file on your NAS with the scan log, what each folder was read as and why, and your "
                    "library list - send it over when something's filed wrong. Folder and file names are in it; "
                    "passwords and API keys aren't.")
        add(lab, p, p.get("action") in ("folders", "hunt_results", "many_places", "folder_rules", "unmatched"), icon=ic,
            plot=plot)
    end(cache=False)


# ---------------------------------------------------------------- your NAS folders
def scanning_now():
    raw = HOME.getProperty("stashbox.scan.now")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError:
        return None


def _last_report():
    return load_json(scanner.REPORT, {})


def _loc_status(rep, path, sec=None):
    """This folder's line in the last scan report."""
    for r in rep.get("sections") or []:
        if sec and r.get("section") != sec:
            continue
        for l in r.get("locations") or []:
            if l.get("path") == hide_creds(npath(path)):
                return l
    return None


def folders():
    rep = _last_report()
    now = scanning_now()
    if now:
        add(color("Scanning now %d%%: %s" % (now["pct"], now["head"]), "deepskyblue"), {"action": "folders"}, True,
            icon="scan", plot=now["where"])
    add("Scan every folder now", {"action": "scan"}, False, icon="scan")
    if rep.get("finished"):
        new = sum(r.get("new", 0) for r in rep.get("sections") or [])
        bad = sum(1 for r in rep.get("sections") or [] for l in r.get("locations") or [] if l.get("status") != "ok")
        add("Last scan %s: %d new%s - see the report" % (_ago(rep["finished"]), new,
                                                        color(", %d folder%s unreachable" % (bad, "" if bad == 1 else "s"),
                                                              "red") if bad else ""),
            {"action": "scan_report"}, False, icon="log")
    allloc = load_locations()
    for sid, label, _key, _kind in SECTIONS:
        locs = allloc.get(sid, [])
        head = "[B]%s[/B]  %s" % (label, color("%d folder%s" % (len(locs), "" if len(locs) == 1 else "s")
                                               if locs else "not set up", "grey"))
        add(head, {"action": "noop"}, False, icon=SEC_ICON[sid])
        for loc in locs:
            n, titles = db.folder_stats(loc["path"], sid)
            st = _loc_status(rep, loc["path"], sid)
            if st and st.get("status") == "unreachable":
                state = color("couldn't reach it last scan", "red")
            elif st:
                state = color("OK %s" % _ago(rep.get("finished")), "lightgreen")
            else:
                state = color("not scanned yet", "orange")
            star = color("* ", "gold") if loc.get("default") else "   "
            count = "%d title%s, %d file%s" % (titles, "" if titles == 1 else "s", n, "" if n == 1 else "s")
            lab = "    %s%s  %s  %s" % (star, loc_label(loc), color(count, "grey"), state)
            plot = "%s\n%s\n\n%s.%s" % (
                loc_label(loc), hide_creds(loc["path"]), count,
                "\n[COLOR gold]*[/COLOR] New %s downloads go here unless you pick another folder." % label.lower()
                if loc.get("default") else "")
            if st and st.get("status") == "ok" and not st.get("partial"):
                plot += "\n\nLast scan: %d videos in %d folders (%.0fs), %d new, %d removed." % (
                    st["found"], st["folders"], st["secs"], st["new"], st["gone"])
            add(lab, {"action": "loc_menu", "s": sid, "p": loc["path"]}, False, icon="folder", plot=plot,
                ctx=[("Scan just this folder", run(action="scan_loc", p=loc["path"])),
                     ("Rename", run(action="loc_menu", s=sid, p=loc["path"], do="rename")),
                     ("Remove from StashBox", run(action="loc_menu", s=sid, p=loc["path"], do="remove"))])
        add("    " + color("+ Add a folder for %s" % label, "deepskyblue"), {"action": "loc_add", "s": sid}, False,
            icon="folder", plot="A folder on your NAS, a USB drive plugged into it, or a category folder you keep "
                                "%s in. Add as many as you like." % label.lower())
    _music_folders(rep)
    end(cache=False)


def _music_folders(rep):
    import music
    ml = load_locations().get("music", [])
    whole = setting("music_scope", "0") == "0"
    n, albums, _a = music.counts()
    add("[B]Music[/B]  %s" % color("%d album%s - looks through %s" % (
        albums, "" if albums == 1 else "s", "the whole NAS" if whole else "your music folders"), "grey"),
        {"action": "noop"}, False, icon="music",
        plot="Music is found %s. Change that in Settings > Music. Your music folders below are where 'Tidy my music' "
             "can gather it." % ("on every share of the NAS (film / TV folders skipped)" if whole else
                                "only in the folders below"))
    st = next((r for r in rep.get("sections") or [] if r.get("section") == "music"), None)
    for loc in ml:
        star = color("* ", "gold") if loc.get("default") else "   "
        cnt = db.one("SELECT COUNT(*) n FROM tracks WHERE root=?", (npath(loc["path"]),))["n"]
        add("    %s%s  %s" % (star, loc_label(loc), color("%d tracks" % cnt, "grey")),
            {"action": "loc_menu", "s": "music", "p": loc["path"]}, False, icon="folder",
            plot="%s\n%s" % (loc_label(loc), hide_creds(loc["path"])))
    if st and st.get("locations"):
        bad = [l["label"] for l in st["locations"] if l.get("status") == "unreachable"]
        if bad:
            add("    " + color("Couldn't reach last time: %s" % ", ".join(bad[:3]), "red"), {"action": "scan_report"},
                False, icon="log")
    add("    " + color("+ Add a music folder", "deepskyblue"), {"action": "loc_add", "s": "music"}, False,
        icon="folder")
    add("    " + color("Look for music now", "deepskyblue"), {"action": "music_scan"}, False, icon="scan")


def _pick_folder(title, cur=""):
    d = xbmcgui.Dialog()
    how = d.select(title, ["Browse for it (shares you've added to Kodi)",
                           "Type its address (e.g. smb://192.168.1.20/usbshare1/Films)"])
    if how < 0:
        return None
    if how == 0:
        p = d.browse(3, title, "files", "", False, False, cur or "")
    else:
        p = d.input("Folder address (smb://, nfs:// or a local path)", cur or "smb://")
    p = npath(p or "")
    if not p or p in ("smb:", "nfs:"):
        return None
    if not vfs.dir_exists(p):
        d.ok(NAME, "Can't open that folder.\n%s\n\nIf it's a network share, add it in Kodi's file manager first "
                   "(that saves the username and password)." % hide_creds(p))
        return None
    return p


def _clash(p, ignore=None):
    """Another StashBox folder that this one is inside / contains."""
    for sec, loc in all_locations():
        if ignore and npath(loc["path"]) == npath(ignore):
            continue
        if under(p, loc["path"]) or under(loc["path"], p):
            return sec, loc
    return None


def loc_add(sec):
    d = xbmcgui.Dialog()
    p = _pick_folder("Add a folder for %s" % SECTION_LABEL[sec])
    if not p:
        return
    if sec == "music":
        ml = load_locations().get("music", [])
        if any(under(p, x["path"]) or under(x["path"], p) for x in ml):
            return d.ok(NAME, "That's inside (or contains) one of your music folders already.")
        label = d.input("A name for it (e.g. 'USB 2 - Music')", auto_label(p)) or auto_label(p)
        allloc = load_locations()
        locs = allloc.setdefault("music", [])
        locs.append({"path": p, "label": label.strip(), "default": not locs})
        save_locations(allloc)
        request("scan", json.dumps({"by": "you", "only": [p]}))
        notify("Added '%s' - looking for music in it now" % label)
        return refresh()
    c = _clash(p)
    label = None
    if c and npath(c[1]["path"]) == npath(p) and c[0] != sec and \
            (SECTION_KIND[c[0]] == "movie") != (SECTION_KIND[sec] == "movie") and \
            not any(npath(x["path"]) == npath(p) for x in locations(sec)):
        # the same drive in Movies AND a TV section: films go to Movies, episodes / TV discs to TV
        if not d.yesno(NAME, "'%s' is already in %s.\nAdd it to %s too? Films stay in Movies; episodes, season "
                             "folders and TV box-set discs go to %s." % (loc_label(c[1]), SECTION_LABEL[c[0]],
                                                                        SECTION_LABEL[sec], SECTION_LABEL[sec])):
            return
        label, c = loc_label(c[1]), None
    if c:
        inside = under(p, c[1]["path"])
        return d.ok(NAME, "That folder %s '%s' (%s), which StashBox already scans.\n\nCategory folders inside a "
                          "folder are found automatically - no need to add them separately." % (
                              "is inside" if inside else ("is" if npath(p) == npath(c[1]["path"]) else "contains"),
                              loc_label(c[1]), SECTION_LABEL[c[0]]))
    label = label or d.input("A name for it (e.g. 'USB 2 - Kids films')", auto_label(p)) or auto_label(p)
    allloc = load_locations()
    locs = allloc.setdefault(sec, [])
    locs.append({"path": p, "label": label.strip(), "default": not locs})
    save_locations(allloc)
    log("Added %s folder %s (%s)" % (sec, label, hide_creds(p)))
    request("scan", json.dumps({"by": "you", "only": [p]}))
    notify("Added '%s' - scanning it now" % label)
    refresh()


def loc_menu(sec, path, do=None):
    d = xbmcgui.Dialog()
    allloc = load_locations()
    locs = allloc.get(sec, [])
    loc = next((x for x in locs if npath(x["path"]) == npath(path)), None)
    if loc is None:
        return refresh()
    opts = [("scan", "Scan just this folder now"), ("rename", "Rename it (now '%s')" % loc_label(loc))]
    if not loc.get("default"):
        opts.append(("default", "Tidy music into here by default" if sec == "music" else
                     "Save new %s downloads here by default" % SECTION_LABEL[sec].lower()))
    opts += [("move", "Change its address - drive moved / renamed (keeps watched history)"),
             ("remove", "Remove it from StashBox (nothing on the NAS is deleted)")]
    if do is None:
        i = d.select("%s - %s" % (loc_label(loc), hide_creds(loc["path"])), [o[1] for o in opts])
        if i < 0:
            return
        do = opts[i][0]
    if do == "scan":
        return scan_loc(loc["path"])
    if do == "rename":
        v = d.input("Name", loc_label(loc))
        if v:
            loc["label"] = v.strip()
    elif do == "default":
        for x in locs:
            x["default"] = x is loc
    elif do == "move":
        p = _pick_folder("New address for '%s'" % loc_label(loc), loc["path"])
        if not p or npath(p) == npath(loc["path"]):
            return
        c = _clash(p, ignore=loc["path"])
        if c:
            return d.ok(NAME, "That's inside / contains '%s' (%s) already." % (loc_label(c[1]), SECTION_LABEL[c[0]]))
        if sec == "music":
            import music
            music.remap(loc["path"], p)
        else:
            db.remap_prefix(loc["path"], p)
        remap_rules(loc["path"], p)
        log("Moved folder %s: %s -> %s" % (loc_label(loc), hide_creds(loc["path"]), hide_creds(p)))
        old = npath(loc["path"])
        for _s, ls in allloc.items():  # the same folder may be in Movies and TV
            for x in ls:
                if npath(x["path"]) == old:
                    x["path"] = p
        save_locations(allloc)
        request("scan", json.dumps({"by": "you", "only": [p]}))
        notify("Address changed - checking the folder now")
        return refresh()
    elif do == "remove":
        if sec == "music":
            n = titles = db.one("SELECT COUNT(*) n FROM tracks WHERE root=?", (npath(loc["path"]),))["n"]
        else:
            n, titles = db.folder_stats(loc["path"], sec)
        if not d.yesno(NAME, "Remove '%s' from StashBox?\n%d title%s (%d file%s) leave the library. Nothing on the "
                             "NAS is deleted - add the folder again any time." % (
                                 loc_label(loc), titles, "" if titles == 1 else "s", n, "" if n == 1 else "s")):
            return
        locs.remove(loc)
        if locs and not any(x.get("default") for x in locs):
            locs[0]["default"] = True
        save_locations(allloc)
        if sec == "music":
            import music
            if music.setting("music_scope", "0") != "0":
                music.forget(loc["path"])  # searching the whole NAS still finds what's in there
        else:
            db.forget_folder(loc["path"], sec)
        notify("Removed '%s'" % loc_label(loc))
        return refresh()
    save_locations(allloc)
    refresh()


def scan_loc(path):
    request("scan", json.dumps({"by": "you", "only": [npath(path)]}))
    notify("Scanning that folder in the background...")


def setup():
    """Old menu entry - the folders screen does this now."""
    folders()


def scan(full=False):
    if not sections_set_up():
        return xbmcgui.Dialog().ok(NAME, "Add your NAS folders first (Tools > Your NAS folders).")
    if full:
        if not xbmcgui.Dialog().yesno(NAME, "Re-read every folder and match everything on TMDB again?\n"
                                            "Your watched history and any Fix match choices are kept."):
            return
        db.run("DELETE FROM matches WHERE manual=0")
        db.run("DELETE FROM files")
        db.run("DELETE FROM items")
    if scanning_now():
        return notify("A scan is already running - it's in the top corner")
    request("scan", json.dumps({"by": "you"}))
    n = len(all_locations())
    notify("Scanning %d NAS folder%s in the background..." % (n, "" if n == 1 else "s"))


def scan_report():
    rep = _last_report()
    if not rep.get("finished"):
        return xbmcgui.Dialog().ok(NAME, "No scan has finished yet.")
    secs = rep["finished"] - rep["started"]
    took = ("%dm %02ds" % divmod(int(secs), 60)) if secs >= 60 else "%ds" % max(1, int(secs))
    who = {"you": "you", "timer": "the regular check", "Kodi starting": "Kodi starting"}.get(rep.get("by"),
                                                                                         rep.get("by") or "?")
    sections = rep.get("sections") or []
    new = sum(r.get("new", 0) for r in sections)
    gone = sum(r.get("gone", 0) for r in sections)
    lines = ["Finished %s (%s), took %s - started by %s%s" % (
        _ago(rep["finished"]), time.strftime("%a %d %b %H:%M", time.localtime(rep["finished"])), took, who,
        " (just some folders)" if rep.get("partial") else ""),
        "[B]%d new, %d removed[/B]" % (new, gone), ""]
    for r in sections:
        if r.get("skipped"):
            continue
        lines.append("[B]%s[/B]%s" % (SECTION_LABEL.get(r["section"], r["section"]).upper(),
                                      color("  - " + r["error"], "red") if r.get("error") else ""))
        for l in r.get("locations") or []:
            lines.append("  %s  [COLOR grey]%s[/COLOR]" % (l["label"], l["path"]))
            if l.get("status") == "unreachable":
                lines.append("      " + color("COULDN'T REACH IT - skipped. Nothing was removed from the library. "
                                              "Is the drive asleep, unplugged, or the share renamed?", "red"))
                continue
            lines.append("      %d videos in %d folders, %.1fs - %d new, %d removed%s" % (
                l["found"], l["folders"], l["secs"], l["new"], l["gone"],
                ", %d looked up again with tidier names" % l["rematched"] if l.get("rematched") else ""))
            if l.get("new_titles"):
                lines.append("      New: " + ", ".join(l["new_titles"]))
            if l.get("tv_skipped"):
                lines.append("      " + color("%d TV disc%s / episode%s left out of Movies - add this folder to TV "
                                              "Shows as well and they'll go there" % ((l["tv_skipped"],) + (
                                                  ("", "") if l["tv_skipped"] == 1 else ("s", "s"))), "orange"))
            if l.get("unreadable"):
                lines.append("      " + color("Couldn't read %d sub-folder%s (kept as they were): %s" % (
                    len(l["unreadable"]), "" if len(l["unreadable"]) == 1 else "s", ", ".join(l["unreadable"][:3])),
                    "orange"))
        lines.append("")
    xbmcgui.Dialog().textviewer(NAME + " - last scan", "\n".join(lines))


# ---------------------------------------------------------------- browse by your own folders
def browse(sec, root=None, cat=""):
    locs = locations(sec)
    if root is None:
        if len(locs) == 1:
            return browse(sec, npath(locs[0]["path"]), "")
        for loc in locs:
            n, titles = db.folder_stats(loc["path"], sec)
            add("%s  %s" % (loc_label(loc), color("(%d)" % titles, "grey")), {"action": "browse", "s": sec,
                                                                              "r": npath(loc["path"])},
                icon="folder", plot=hide_creds(loc["path"]))
        return end(cache=False)
    rows = db.q("SELECT cat, item_id FROM files WHERE section=? AND root=?", (sec, root))
    kids = {}
    pre = cat + "/" if cat else ""
    for r in rows:
        c = r["cat"] or ""
        if cat and not (c == cat or c.startswith(pre)):
            continue
        rest = c[len(pre):] if pre else c
        if rest and (c != cat):
            kids.setdefault(rest.split("/", 1)[0], set()).add(r["item_id"])
    rules = load_rules()
    for k in sorted(kids, key=lambda s: s.lower()):
        fp = vfs.join(root, pre + k)
        r = rules.get(npath(fp))
        add("%s  %s%s" % (k, color("(%d)" % len(kids[k]), "grey"), color("  [%s]" % RULE_TEXT[r], "orange") if r else ""),
            {"action": "browse", "s": sec, "r": root, "c": pre + k}, icon="folder",
            ctx=[("Sort out this folder (one %s / separate / skip)..." % ("film" if SECTION_KIND[sec] == "movie" else
                                                                         "show"),
                  run(action="folder_rule", p=fp))])
    items = db.q("SELECT DISTINCT i.* FROM items i JOIN files f ON f.item_id=i.id WHERE f.section=? AND f.root=? "
                 "AND COALESCE(f.cat, '')=? ORDER BY COALESCE(i.sorttitle, i.title) COLLATE NOCASE", (sec, root, cat))
    if SECTION_KIND[sec] == "movie":
        nums = library.collection_order([r["id"] for r in items])
        items = sorted(items, key=lambda r: (nums.get(r["id"]) is None, nums.get(r["id"]) or 0,
                                             (r["sorttitle"] or r["title"] or "").lower()))
        _movie_rows(items, nums)
        end("movies", cache=False)
    else:
        _show_rows(items)
        end("tvshows", cache=False)


def accounts():
    import debrid
    d = xbmcgui.Dialog()
    while True:
        rd = debrid.rd_auth().get("token")
        rows = ["TMDB key:  %s" % (_mask(setting("tmdb_key")) or color("not set", "orange")),
                "TorBox API key:  %s" % (_mask(setting("api_key")) or color("not set", "grey")),
                "Real-Debrid:  %s" % ("logged in" if rd else color("log in with a code", "grey")),
                "Cocoleech API key:  %s" % (_mask(setting("cocoleech_key")) or color("not set", "grey")),
                "Import keys from TorUtilityBox"]
        i = d.select("Accounts", rows)
        if i < 0:
            return
        if i in (0, 1, 3):
            key = ("tmdb_key", "api_key", None, "cocoleech_key")[i]
            v = d.input(rows[i].split(":")[0], setting(key))
            if v is not None and v != "":
                set_setting(key, v.strip())
        elif i == 2:
            rd_login()
        else:
            import_keys()


def _mask(k):
    k = (k or "").strip()
    return (k[:4] + "..." + k[-3:]) if len(k) > 10 else ("set" if k else "")


def rd_login():
    import debrid
    d = xbmcgui.Dialog()
    if debrid.rd_auth().get("token"):
        try:
            u = debrid.RealDebrid().user()
            info = "Logged in as %s (%s, until %s)" % (u.get("username", "?"), u.get("type", "?"),
                                                       (u.get("expiration") or "?")[:10])
        except debrid.DebridError as e:
            info = "Logged in, but: %s" % e
        if d.select("Real-Debrid", [info, "Log out"]) == 1:
            debrid.rd_save({})
            notify("Logged out of Real-Debrid")
        return
    try:
        dd = debrid.RealDebrid.device_start()
    except Exception as e:
        return d.ok(NAME, "Couldn't start the Real-Debrid log in: %s" % e)
    prog = xbmcgui.DialogProgress()
    prog.create(NAME + " - Real-Debrid", "On your phone, go to %s\nand enter the code:  [B]%s[/B]" % (
        (dd.get("verification_url") or "real-debrid.com/device").replace("https://", ""), dd.get("user_code")))
    end_t = time.time() + int(dd.get("expires_in") or 600)
    step = max(3, int(dd.get("interval") or 5))
    auth = None
    while time.time() < end_t and not prog.iscanceled():
        for _ in range(step * 2):
            xbmc.sleep(500)
            if prog.iscanceled():
                break
        try:
            auth = debrid.RealDebrid.device_poll(dd["device_code"])
        except Exception:
            auth = None
        if auth:
            break
        prog.update(int(100 * (1 - (end_t - time.time()) / float(dd.get("expires_in") or 600))))
    prog.close()
    if auth:
        debrid.rd_save(auth)
        d.ok(NAME, "Real-Debrid is logged in.")


def import_keys():
    """Copy keys from TorUtilityBox (or the older TorBox add-on)."""
    import glob
    import xbmcaddon
    import debrid
    got = []
    for aid in ("plugin.video.torutilitybox", "plugin.video.torbox"):
        try:
            other = xbmcaddon.Addon(aid)
        except Exception:
            continue
        for src, dst in (("api_key", "api_key"), ("cocoleech_key", "cocoleech_key"), ("tmdb_key", "tmdb_key"),
                         ("stremio1_url", "torrentio_url"), ("nyaa_host", "nyaa_host")):
            try:
                v = (other.getSetting(src) or "").strip()
            except Exception:
                v = ""
            if v and not setting(dst):
                set_setting(dst, v)
                got.append(dst)
        if not debrid.rd_auth().get("token"):
            import xbmcvfs
            cands = [xbmcvfs.translatePath("special://profile/tub_backup/%s/rd_auth.json" % aid)]
            cands += glob.glob(os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s/" % aid), "*.json"))
            for c in cands:
                try:
                    with open(c, "r") as fh:
                        a = json.load(fh)
                except Exception:
                    continue
                if isinstance(a, dict) and a.get("token") and a.get("client_id"):
                    debrid.rd_save(a)
                    got.append("real-debrid")
                    break
    names_ = {"api_key": "TorBox", "cocoleech_key": "Cocoleech", "tmdb_key": "TMDB", "torrentio_url": "Torrentio address",
              "nyaa_host": "Nyaa address", "real-debrid": "Real-Debrid login"}
    if got:
        xbmcgui.Dialog().ok(NAME, "Imported: %s" % ", ".join(names_[g] for g in dict.fromkeys(got)))
    else:
        xbmcgui.Dialog().ok(NAME, "Nothing new to import (TorUtilityBox not installed, or the keys are already here).")


def view_log():
    from common import LOG_FILE
    try:
        with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()[-400:]
    except IOError:
        lines = ["(nothing logged yet)"]
    xbmcgui.Dialog().textviewer(NAME + " - log (newest at the bottom)", "\n".join(lines))


def view_scan_detail():
    p = os.path.join(scanner.PROFILE_DIR(), scanner.DETAIL_FILE)
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except IOError:
        text = ""
    if not text.strip():
        return xbmcgui.Dialog().ok(NAME, "Nothing yet - it's written on the next scan (unless it's switched off in "
                                         "Settings > Advanced).")
    runs = [r.strip("\n") for r in re.split(r"\n(?=\d{4}-\d\d-\d\d \d\d:\d\d:\d\d  )", text) if r.strip()]
    lines = "\n\n".join(reversed(runs)).splitlines()  # newest scan first
    xbmcgui.Dialog().textviewer(NAME + " - how each folder was read (newest scan first)", "\n".join(lines[:3000]))


# ---------------------------------------------------------------- where is it on the NAS?
def where(item_id):
    it = db.item(item_id)
    if not it:
        return fail_dir()
    hs = places.homes(item_id)
    total = sum(h["size"] for h in hs)
    show = it["kind"] == "show"
    n_eps = len(set(e for h in hs for e in h["eps"])) if show else sum(len(h["files"]) for h in hs)
    add("[B]%s[/B]  %s" % (names.title_year(it["title"], it["year"]), color(
        "%d %s in %d place%s, %s" % (n_eps, "episodes" if show else "files", len(hs), "" if len(hs) == 1 else "s",
                                     fmt_size(total)), "grey")),
        {"action": "noop"}, False, poster=it["poster"], fanart=it["fanart"], icon=it["poster"] or "folder")
    for h in hs:
        what = ("%s, %d episode%s" % (h["season_text"] or "no episode numbers", h["count"],
                                      "" if h["count"] == 1 else "s") if show else
                "%d file%s" % (len(h["files"]), "" if len(h["files"]) == 1 else "s"))
        add("    %s  %s" % (h["label"], color("%s, %s" % (what, fmt_size(h["size"])), "grey")),
            {"action": "where_folder", "id": item_id, "h": h["folder"]}, True, icon="folder", fanart=it["fanart"],
            plot="%s\n%s\n\n%s, %s%s" % (h["label"], hide_creds(h["folder"]), what, fmt_size(h["size"]),
                                          "" if h["own"] else "\n(loose files in this folder, not a folder of its own)"))
    dups = places.duplicates(item_id)
    if dups:
        nd = len(dups) if show else len(dups[0][1])
        add(color(("%d episode%s in more than one place" % (nd, " is" if nd == 1 else "s are")) if show else
                  "%d copies of this film" % nd, "orange"),
            {"action": "where_dups", "id": item_id}, True, icon="collection", fanart=it["fanart"],
            plot="\n".join(("S%02dE%02d: " % k if k else "") + ", ".join(places.place_label(vfs.parent(f["path"]))
                                                                       for f in fs) for k, fs in dups[:30]))
    for o in places.other_sections(it):
        add(color("Also in %s: %d file%s" % (SECTION_LABEL.get(o["section"], o["section"]), o["n"],
                                             "" if o["n"] == 1 else "s"), "orange"),
            {"action": "where", "id": o["id"]}, True, icon="folder", fanart=it["fanart"],
            plot="The same %s is filed in your %s folders too. 'Put it all in one place' can bring those files here."
                 % ("show" if show else "film", SECTION_LABEL.get(o["section"], o["section"])))
    for o in places.lookalikes(it):
        add(color("Maybe the same %s: '%s' (%d file%s%s)" % ("show" if show else "film", o["title"], o["n"],
                                                             "" if o["n"] == 1 else "s",
                                                             ", not matched" if not o["matched"] else ""), "orange"),
            {"action": "merge", "id": item_id, "o": o["id"]}, False, icon="search", fanart=it["fanart"],
            plot="Select to count all of its files as %s." % it["title"])
    own = [h for h in hs if h["own"]]
    if own:
        add(color("Not one %s? Sort out its folder..." % ("show" if show else "film"), "deepskyblue"),
            {"action": "split", "id": item_id, "menu": "1"}, False, icon="folder", fanart=it["fanart"],
            plot="If several %s have been counted as this one - a folder of different shows read as one show with "
                 "lots of seasons, say - split the folder up. Or tell StashBox to treat a folder as one %s, or "
                 "leave it out of the library." % (("shows", "show") if show else ("films", "film")))
    if show:
        add(color("Look for missing episodes everywhere on the NAS", "deepskyblue"), {"action": "hunt", "id": item_id},
            False, icon="search", fanart=it["fanart"])
        if len(hs) > 1 or dups or places.other_sections(it):
            add(color("Put it all in one place...", "deepskyblue"), {"action": "organise", "id": item_id}, False,
                icon="folder", fanart=it["fanart"],
                plot="Moves every episode into one show folder, in Season folders, keeping your watched history. "
                     "Moves on the same drive are instant; between drives the files are copied through this Kodi "
                     "box, checked, then the originals removed. You can undo it from Downloads.")
    end(cache=False)


def where_folder(item_id, folder):
    it = db.item(item_id)
    fs = [f for f in db.item_files(item_id) if npath(places.home_of(f)[0]) == npath(folder)]
    prog = db.progress_map([f["path"] for f in fs])
    add(color(places.place_label(folder), "grey"), {"action": "folder_rule", "p": folder}, False, icon="folder",
        plot=hide_creds(folder) + "\n\nSelect to sort out how this folder is read (one %s / separate / skip)." % (
            "film" if it and it["kind"] == "movie" else "show"))
    for f in fs:
        p = prog.get(f["path"])
        lab = ("S%02dE%02d  " % (f["season"] or 0, f["episode"]) if f["episode"] is not None else "") + f["label"]
        lab += "  " + color(fmt_size(f["size"]), "grey")
        li = item(lab, it["poster"] if it else "folder", fanart=it["fanart"] if it else None,
                  plot="%s\n%s" % (f["label"], hide_creds(vfs.parent(f["path"]))))
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(file_ctx(f, bool(p and p["watched"])))
        xbmcplugin.addDirectoryItem(handle(), url(action="play", f=f["path"]), li, isFolder=False)
    end(cache=False)


def where_dups(item_id):
    it = db.item(item_id)
    for k, fs in places.duplicates(item_id):
        for f in sorted(fs, key=lambda f: -(f["size"] or 0)):
            lab = ("S%02dE%02d  " % k if k else "") + "%s  %s" % (fmt_size(f["size"]), color(
                places.place_label(vfs.parent(f["path"])), "grey"))
            li = item(lab, it["poster"] if it else "folder", plot="%s\n%s\n\nRight-click to delete this copy." % (
                f["label"], hide_creds(vfs.parent(f["path"]))))
            li.setProperty("IsPlayable", "true")
            li.addContextMenuItems(file_ctx(f, False))
            xbmcplugin.addDirectoryItem(handle(), url(action="play", f=f["path"]), li, isFolder=False)
    end(cache=False)


def merge(item_id, other_id):
    it, o = db.item(item_id), db.item(other_id)
    if not it or not o or not it["tmdb"]:
        return notify("Can't merge - match '%s' on TMDB first (Fix match)" % (it["title"] if it else "?"), "warn")
    n = len(db.item_files(other_id))
    if not xbmcgui.Dialog().yesno(NAME, "Count all %d file%s of '%s' as %s?\n(Nothing is moved on the NAS.)" % (
            n, "" if n == 1 else "s", o["title"], names.title_year(it["title"], it["year"]))):
        return
    scanner.relink(other_id, it["tmdb"])
    notify("'%s' is now part of %s" % (o["title"], it["title"]))
    refresh()


def shows_in_many_places():
    rows = []
    for r in db.q("SELECT item_id, COUNT(DISTINCT CASE WHEN instr(mkey, '|')>0 THEN substr(mkey, 1, instr(mkey, '|')) "
                  "ELSE mkey END) h FROM files GROUP BY item_id HAVING h>1"):
        it = db.item(r["item_id"])
        if it:
            rows.append((it, r["h"]))
    if not rows:
        add(color("Everything is in one place.", "grey"), {"action": "noop"}, False)
    for it, h in sorted(rows, key=lambda x: (x[0]["section"], (x[0]["sorttitle"] or x[0]["title"]).lower())):
        add("%s  %s" % (names.title_year(it["title"], it["year"]), color("%d places - %s" % (
            h, SECTION_LABEL.get(it["section"], "")), "orange")), {"action": "where", "id": it["id"]}, True,
            poster=it["poster"], fanart=it["fanart"], icon=it["poster"] or "folder",
            plot="On: " + places.summary(it["id"]))
    end(cache=False)


# ---------------------------------------------------------------- put it all in one place
def organise(item_id, only_paths=None, extra=None, title=None, tidy_extra=None):
    d = xbmcgui.Dialog()
    it = db.item(item_id)
    if not it:
        return
    choices = places.target_choices(item_id)
    newf = places.new_show_folder(it)
    targets = [(h["folder"], "%s  (%d episode%s)%s" % (h["label"], h["count"], "" if h["count"] == 1 else "s",
                                                       "  - inside a pack of other things" if h.get("in_pack") else ""))
               for h in choices]
    if not any(npath(h["folder"]) == npath(newf) for h in choices):
        new = (newf, "A new folder: %s" % places.place_label(newf))
        # a show that only has a folder inside someone's pack (a Christmas special in a mega pack) gets its own
        n_ok = sum(1 for h in choices if not h.get("in_pack"))
        targets.insert(n_ok, new)
    i = d.select("Put %s where?" % it["title"], [t[1] for t in targets]) if len(targets) > 1 else 0
    if i < 0:
        return
    target = targets[i][0]
    j = d.select("File names", ["Keep the file names as they are",
                                "Rename to '%s'" % names.episode_filename(it["title"], it["year"], 1, 1, ".mkv")])
    if j < 0:
        return
    p = places.plan(item_id, target, j == 1, only_paths, extra)
    others = [o for o in places.other_sections(it)]
    if not p["moves"]:
        msg = "Nothing to move - it's all in %s already." % places.place_label(target)
        if p["dups"]:
            msg += "\n%d duplicate cop%s left where %s (see 'Where is it')." % (
                len(p["dups"]), "y is" if len(p["dups"]) == 1 else "ies are", "it is" if len(p["dups"]) == 1 else "they are")
        return d.ok(NAME, msg)
    vids = [m for m in p["moves"] if m["video"]]
    lines = ["Move %d file%s (%s) into\n%s" % (len(vids), "" if len(vids) == 1 else "s",
                                              fmt_size(p["cross_bytes"] + p["same_bytes"]), places.place_label(target))]
    if p["cross_bytes"]:
        lines.append("%s is on another drive, so it's copied through this Kodi box, checked, then the original "
                     "removed - over Wi-Fi that's roughly %s." % (fmt_size(p["cross_bytes"]),
                                                                 _eta(p["cross_bytes"])))
    if p["same_bytes"]:
        lines.append("%s is on the same drive - that moves instantly." % fmt_size(p["same_bytes"]))
    if p["dups"]:
        lines.append("%d duplicate%s stay where they are." % (len(p["dups"]), "" if len(p["dups"]) == 1 else "s"))
    if others and extra is None and only_paths is None:
        lines.append("(Copies filed in your %s folders aren't included.)" % ", ".join(
            SECTION_LABEL.get(o["section"], "") for o in others))
    if not d.yesno(NAME, "\n".join(lines)):
        return
    if it["tmdb"]:
        db.match_set("show:" + npath(target), it["tmdb"], "show", manual=1)
    if extra is None:
        tidy = sorted(set(h["folder"] for h in places.homes(item_id) if h["own"] and
                          npath(h["folder"]) != npath(target)))
    else:
        tidy = sorted(set(t for t in tidy_extra or [] if npath(t) != npath(target) and not under(target, t)))
    jid = downloads.add({"title": title or "Put %s in one place" % it["title"], "section": it["section"],
                         "root": npath(target), "kind": "organise", "source": {"type": "organise"},
                         "moves": p["moves"], "tidy": tidy, "media": {}, "want": {}})
    log("Organise %s: %d moves into %s (job %s)" % (it["title"], len(p["moves"]), hide_creds(target), jid))
    notify("Moving in the background - see Downloads (you can undo it there)", "info", 6000)


def _eta(nbytes):
    secs = nbytes / (8 * 1024 * 1024.0)  # ~8 MB/s through a Kodi box on Wi-Fi
    if secs < 90:
        return "a minute"
    if secs < 3600:
        return "%d minutes" % (secs / 60)
    return "%.1f hours" % (secs / 3600)


# ---------------------------------------------------------------- look for missing episodes elsewhere
HUNT = "hunt.json"


def hunt_start(item_id=None):
    d = xbmcgui.Dialog()
    i = d.select("Where should I look?", [
        "Your StashBox folders + the rest of the drives/shares they're on (recommended)",
        "Everywhere on the NAS - every share (slower)",
        "Just your StashBox folders"])
    if i < 0:
        return
    scope = ("shares", "nas", "folders")[i]
    prog = xbmcgui.DialogProgress()
    it = db.item(int(item_id)) if item_id else None
    prog.create(NAME, "Looking for %s..." % ("missing episodes of %s" % it["title"] if it else
                                            "missing episodes of all your shows"))

    def cb(pct, line):
        prog.update(pct, "Looking for %s...\n%s" % (it["title"] if it else "missing episodes", line))
        return prog.iscanceled()
    try:
        res = places.hunt([int(item_id)] if item_id else None, scope, cb)
    finally:
        prog.close()
    res["for"] = int(item_id) if item_id else None
    from common import save_json
    save_json(HUNT, res)
    xbmc.executebuiltin("Container.Update(%s)" % url(action="hunt_results"))


def hunt_results():
    res = load_json(HUNT, {})
    if not res.get("when"):
        add(color("No search yet - right-click a show > Look for missing episodes on the NAS", "grey"),
            {"action": "noop"}, False)
        return end(cache=False)
    found = sum(len(s["found"]) for s in res["shows"])
    spare = sum(s.get("spare", 0) for s in res["shows"])
    head = "Looked through %d folders (%s) %s" % (res["folders"], {"shares": "your folders + their drives",
                                                                   "nas": "the whole NAS",
                                                                   "folders": "your StashBox folders"}[res["scope"]],
                                                  _ago(res["when"]))
    if res.get("cancelled"):
        head += color("  - stopped early%s" % (" (folder limit)" if res.get("limit_hit") else ""), "orange")
    add(color(head, "grey"), {"action": "noop"}, False, icon="search",
        plot="Looked in:\n" + "\n".join(res.get("roots") or []))
    if not found:
        add(color("Nothing found - the missing episodes aren't anywhere I looked%s." % (
            " (%d spare copies of episodes you already have)" % spare if spare else ""), "grey"), {"action": "noop"},
            False)
    for s in res["shows"]:
        if not s["found"]:
            continue
        it = db.item(s["id"])
        if not it:
            continue
        add("[B]%s[/B]  %s" % (it["title"], color("%d missing episode%s found" % (
            len(s["found"]), "" if len(s["found"]) == 1 else "s"), "lightgreen")),
            {"action": "show", "id": it["id"]}, True, poster=it["poster"], fanart=it["fanart"],
            icon=it["poster"] or "tv")
        movable = [r for r in s["found"] if r["kind"] in ("outside", "uncounted", "section", "misfiled")]
        if movable:
            add("    " + color("Move %d into %s's folder" % (len(movable), it["title"]), "deepskyblue"),
                {"action": "hunt_move", "id": it["id"]}, False, icon="folder", fanart=it["fanart"],
                plot="Brings these episodes into the show's folder (in Season folders), keeping watched history. "
                     "Runs in the background - you can undo it from Downloads.")
        mis = {}
        for r in s["found"]:
            if r["kind"] == "misfiled":
                mis.setdefault(r["other"], r["other_title"])
        for oid, ot in mis.items():
            add("    " + color("Count '%s' as %s (no moving)" % (ot, it["title"]), "deepskyblue"),
                {"action": "merge", "id": it["id"], "o": oid}, False, icon="search", fanart=it["fanart"])
        small = [r for r in s["found"] if r["kind"] == "small"]
        if small:
            add("    " + color("%d %s smaller than your size limit - lower it and rescan" % (
                len(small), "is" if len(small) == 1 else "are"), "deepskyblue"), {"action": "hunt_small"}, False,
                icon="tools", fanart=it["fanart"])
        for r in s["found"]:
            li = item("    " + places.fmt_found(r), it["poster"] or "tv", fanart=it["fanart"],
                      plot="%s\n%s\n\n%s" % (vfs.basename(r["path"]), r["place"], places.KIND_TEXT.get(r["kind"], "")))
            li.setProperty("IsPlayable", "true")
            li.addContextMenuItems([("Move just this one into %s's folder" % it["title"],
                                     run(action="hunt_move", id=it["id"], p=r["path"]))])
            xbmcplugin.addDirectoryItem(handle(), url(action="play_any", f=r["path"]), li, isFolder=False)
    if spare and found:
        add(color("Also found %d spare cop%s of episodes you already have (not listed)" % (
            spare, "y" if spare == 1 else "ies"), "grey"), {"action": "noop"}, False)
    end(cache=False)


def hunt_move(item_id, path=None):
    res = load_json(HUNT, {})
    s = next((x for x in res.get("shows") or [] if x["id"] == int(item_id)), None)
    if not s:
        return
    rows = [r for r in s["found"] if r["kind"] in ("outside", "uncounted", "section", "misfiled")]
    if path:
        rows = [r for r in rows if r["path"] == path] or [r for r in s["found"] if r["path"] == path]
    extra = [{"path": r["path"], "season": r["season"], "episode": r["episode"], "size": r["size"]} for r in rows]
    if not extra:
        return
    # folders these came from that are a show's own folder in the library: removed if they end up empty
    tidy = set()
    for r in rows:
        f = db.one("SELECT * FROM files WHERE path=?", (r["path"],))
        if f is not None:
            h, own = places.home_of(f)
            if own:
                tidy.add(h)
    organise(int(item_id), only_paths=set(), extra=extra, title="Bring missing episodes into %s" % s["title"],
             tidy_extra=sorted(tidy))


def hunt_small():
    res = load_json(HUNT, {})
    sizes = [r["size"] for s in res.get("shows") or [] for r in s["found"] if r["kind"] == "small" and r.get("size")]
    if not sizes:
        return
    mb = max(0, int(min(sizes) * 5 / (1024 * 1024)) - 1)
    if not xbmcgui.Dialog().yesno(NAME, "Lower 'Ignore films smaller than' to %d MB (episodes: %d MB) so these "
                                        "count, and scan again?" % (mb, mb // 5)):
        return
    set_setting("min_movie_mb", str(mb))
    request("scan", json.dumps({"by": "you"}))
    notify("Size limit lowered - scanning again")


def play_any(path):
    """Play a file that isn't (yet) in the library."""
    if not vfs.exists(path):
        notify("Can't reach that file", "error")
        return fail_play()
    xbmcplugin.setResolvedUrl(handle(), True, xbmcgui.ListItem(path=path))


# ---------------------------------------------------------------- sorting out a folder StashBox read wrongly
def _in_folder(path):
    """What the library has from inside this folder: rows of (item_id, title, year, n files)."""
    p = npath(path)
    return db.q("SELECT f.item_id, i.title, i.year, i.matched, COUNT(*) n FROM files f JOIN items i ON i.id=f.item_id "
                "WHERE f.path=? OR substr(f.path, 1, ?) IN (?, ?) GROUP BY f.item_id ORDER BY n DESC, i.title",
                (p, len(p) + 1, p + "/", p + "\\"))


def _titles_text(rows, what, most=4):
    if not rows:
        return "nothing in the library"
    n = len(rows)
    names_ = ", ".join(names.title_year(r["title"], r["year"]) for r in rows[:most]) + (" ..." if n > most else "")
    return "%d %s%s: %s" % (n, what, "" if n == 1 else "s", names_)


def split(item_id, menu=False):
    """'Not one show?': pick the folder it lives in (if more than one) and split it up (or, with menu, choose)."""
    it = db.item(item_id)
    if not it:
        return
    own = [h for h in places.homes(item_id) if h["own"]]
    if not own:
        return xbmcgui.Dialog().ok(NAME, "'%s' isn't in a folder of its own - its files sit loose in a folder and are "
                                         "named after the files, so there's nothing to split. Rename the files, or "
                                         "use Fix match." % it["title"])
    i = 0
    if len(own) > 1:
        i = xbmcgui.Dialog().select("Which folder of '%s'?" % it["title"], [
            "%s  (%s)" % (h["label"], h["season_text"] or "%d files" % len(h["files"])) for h in own])
        if i < 0:
            return
    if it["kind"] == "show" and not menu:
        return shows_in(own[i]["folder"])
    return folder_rule(own[i]["folder"], None)


def _split_preview(sec, folder):
    """Roughly what each sub-folder / loose file becomes once this folder is split up. -> [(what, becomes)]"""
    show = SECTION_KIND.get(sec) != "movie"
    w = scanner.Walker()
    w.rules = {}
    res = w.listdir(folder)
    if res is None:
        return None
    dirs, files = res
    rows = []
    for x in sorted(dirs, key=lambda s: s.lower()):
        if names.system_dir(x) or x.lower() in names.DISC_DIRS:
            continue
        if show:
            t, y = w.show_title(vfs.join(folder, x))
        else:
            t, y = names.parse_movie(x)
        rows.append((x + "/", names.title_year(t, y) if names.norm(t) else "(named from its files)"))
    groups = {}
    for f in files:
        if not names.is_video(f) or names.is_sample(f):
            continue
        if show:
            t, y = names.file_show_name(f), None
        else:
            t, y = names.parse_movie(f)
        g = groups.setdefault("%s|%s" % (names.norm(t), y or ""), [names.title_year(t, y), 0])
        g[1] += 1
    for _k, (ty, n) in sorted(groups.items()):
        rows.append(("%d loose file%s" % (n, "" if n == 1 else "s"), ty))
    return rows


def _rescan(path, title):
    """Read one folder again now (in this window, so the result shows straight away)."""
    if scanning_now():
        request("scan", json.dumps({"by": "you", "only": [npath(path)]}))
        notify("Saved - '%s' gets sorted out when the scan that's running now finishes" % title)
        return False
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Sorting out '%s'..." % title)

    def p(pct, head, where):
        try:
            prog.update(int(pct), "%s\n%s" % (head, hide_creds(where)[:80]))
        except Exception:
            pass
    HOME.setProperty("stashbox.scan.now", json.dumps({"pct": 0, "head": "Sorting out " + title, "where": ""}))
    try:
        scanner.scan(only=[npath(path)], progress=p, by="you")
    except Exception:
        log_exc("Sorting out a folder")
    finally:
        HOME.clearProperty("stashbox.scan.now")
        try:
            prog.close()
        except Exception:
            pass
    return True


def folder_rule(path, do=None):
    """How StashBox reads one folder: let it decide, separate shows / films, one show / film, or leave it out.
    The choice is saved as a folder rule (Tools > Folder rules) and the folder is read again straight away."""
    d = xbmcgui.Dialog()
    path = npath(path)
    rules = load_rules()
    cur = rules.get(path)
    sec, loc = location_for(path)
    if loc is None:
        if cur and d.yesno(NAME, "%s isn't in your StashBox folders any more.\nForget its folder rule (%s)?" % (
                hide_creds(path), RULE_TEXT[cur])):
            set_rule(path, None)
            refresh()
        elif not cur:
            notify("That folder isn't in your StashBox folders", "warn")
        return
    root = npath(loc["path"])
    if path == root:
        return d.ok(NAME, "That's one of your main NAS folders ('%s'). Pick a folder inside it - or to leave all of "
                          "it out, remove it in Tools > Your NAS folders." % loc_label(loc))
    show = SECTION_KIND.get(sec) != "movie"
    what = "show" if show else "film"
    name = vfs.basename(path)
    now = _in_folder(path)
    if do is None and show:
        i = d.select("'%s' is now %s" % (name, _titles_text(now, what, 2)), [
            "[B]Pick which folders in here are different shows...[/B]", "More choices (split it all up / one show / "
                                                                        "leave it out)..."])
        if i < 0:
            return
        if i == 0:
            return shows_in(path)
    if do is None:
        opts = [("auto", "Let StashBox decide (how it's read without a rule)"),
                ("many", "Separate %ss - each sub-folder / file is its own %s" % (what, what)),
                ("one", "One %s - everything in this folder is one %s" % (what, what)),
                ("skip", "Leave this folder out of the library")]
        labs = [("[B]%s[/B]  - now" if (k == cur or (k == "auto" and not cur)) else "%s") % t for k, t in opts]
        i = d.select("'%s' is now %s" % (name, _titles_text(now, what, 2)), labs)
        if i < 0:
            return
        do = opts[i][0]
    if do == "auto" and not cur:
        return notify("'%s' has no folder rule - StashBox already decides it" % name)
    if do == cur:
        return notify("'%s' is already set to %s" % (name, RULE_TEXT[cur]))
    if do == "many":
        prev = _split_preview(sec, path)
        if prev is None:
            return d.ok(NAME, "Can't open %s right now - is the drive awake?" % hide_creds(path))
        if not prev:
            return d.ok(NAME, "There's nothing in '%s' to split up." % name)
        while True:
            rows = ["[B]Yes - split it up like this[/B]", "No, leave it as it is"] + [
                "%s  ->  %s" % (a, b) for a, b in prev]
            i = d.select("Split '%s' into %d %ss?" % (name, len(prev), what), rows)
            if i == 0:
                break
            if i == 1 or i < 0:
                return
    elif do == "one":
        t, y = (scanner.Walker().show_title(path) if show else names.parse_movie(name))
        if not d.yesno(NAME, "Count everything in '%s' as one %s - %s?\n(It's %s now.)" % (
                name, what, names.title_year(t, y), _titles_text(now, what, 3))):
            return
    elif do == "skip":
        n = sum(r["n"] for r in now)
        if not d.yesno(NAME, "Leave '%s' out of the library?\n%s (%d file%s) leave the library. Nothing on the NAS "
                             "is deleted, and you can bring it back from Tools > Folder rules." % (
                                 name, _titles_text(now, what, 3), n, "" if n == 1 else "s")):
            return
    set_rule(path, None if do == "auto" else do)
    log("Folder rule: %s -> %s" % (hide_creds(path), RULE_TEXT.get(do, "automatic")))
    scanner.forget_lookups(path)
    if _rescan(path, name):
        after = _in_folder(path)
        notify("'%s' is now %s" % (name, _titles_text(after, what, 3) if do != "skip" else "left out of the library"),
               ms=7000)
    cat = rel(path if do == "many" else vfs.parent(path), root)
    xbmc.executebuiltin("Container.Update(%s,replace)" % url(action="browse", s=sec, r=root, c=cat))


def folder_rules():
    rules = load_rules()
    if not rules:
        add(color("No folder rules yet", "grey"), {"action": "noop"}, False, icon="folder",
            plot="When StashBox reads a folder wrongly - several shows counted as one show with lots of seasons, say "
                 "- open the show and choose 'Not one show? Split it up', or right-click the folder when you browse "
                 "'Your folders'. The choices you make show up here.")
    for k, v in sorted(rules.items(), key=lambda kv: kv[0].lower()):
        sec, loc = location_for(k)
        lab = places.place_label(k) if loc else hide_creds(k)
        add("%s  %s" % (lab, color("[%s]" % RULE_TEXT.get(v, v), "orange" if loc else "grey")),
            {"action": "folder_rule", "p": k}, False, icon="folder",
            plot="%s\n\n%s\n\nSelect to change it or go back to letting StashBox decide." % (
                hide_creds(k), "Read as: %s" % RULE_TEXT.get(v, v) if loc else "Not in your StashBox folders any more"))
    end(cache=False)


def export_report():
    import export
    d = xbmcgui.Dialog()
    last = setting("export_folder")
    first = npath(all_locations()[0][1]["path"]) if all_locations() else ""
    folder = None
    if last and vfs.dir_exists(last):
        i = d.select("Save the report where?", ["In %s (like last time)" % hide_creds(last), "Somewhere else..."])
        if i < 0:
            return
        folder = last if i == 0 else None
    if folder is None:
        folder = npath(d.browse(3, "Save the report in which folder? (Somewhere you can get at from a computer or "
                                   "phone - a NAS folder is easiest)", "files", "", False, False, first) or "")
        if not folder:
            return
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Putting the report together...")
    try:
        path, size = export.save(folder)
    except Exception as e:
        log_exc("Export report")
        return d.ok(NAME, "Couldn't save the report: %s" % hide_creds(e))
    finally:
        try:
            prog.close()
        except Exception:
            pass
    set_setting("export_folder", folder)
    log("Exported a report: %s (%s)" % (hide_creds(path), fmt_size(size)))
    d.ok(NAME, "Saved [B]%s[/B] (%s) in %s\n\nSend that zip file over. It has your folder and file names, what each "
               "folder was read as and why, and the logs - no passwords or API keys." % (
                   vfs.basename(path), fmt_size(size), hide_creds(folder)))


# ---------------------------------------------------------------- "these folders are different shows"
def _show_candidates(w, path):
    """Folders inside 'path' that could be shows of their own: not 'Season 2', 'Disc 1', 'Specials', 'Extras'.
    A folder that only holds other folders ('Star Trek/Spin-offs') isn't listed itself - what's in it is.
    -> [(path, label, the folder it's in when that's one of those, or None)]"""
    res = w.listdir(path)
    out = []
    for x in sorted(res[0] if res else [], key=lambda s: s.lower()):
        if not scanner._could_be_show(x):
            continue
        p = vfs.join(path, x)
        r2 = w.listdir(p)
        inner = []
        if r2 and not [f for f in r2[1] if names.is_video(f)] and \
                not any(names.season_from_dir(y) is not None for y in r2[0]):
            inner = [y for y in sorted(r2[0], key=lambda s: s.lower()) if scanner._could_be_show(y)]
        if inner:
            out += [(vfs.join(p, y), "%s / %s" % (x, y), p) for y in inner]
        else:
            out.append((p, x, None))
    return out[:80]


def shows_in(path):
    """Tick the folders that are different shows ('Star Trek' holding 'The Next Generation', 'Deep Space Nine',
    'Voyager'...): each ticked one is read and matched on TMDB as its own show; the rest stay part of this one."""
    d = xbmcgui.Dialog()
    path = npath(path)
    sec, loc = location_for(path)
    if loc is None or SECTION_KIND.get(sec) == "movie":
        return notify("That folder isn't in your TV folders", "warn")
    root = npath(loc["path"])
    if path == root:
        return d.ok(NAME, "That's one of your main NAS folders - pick the show's folder inside it.")
    w = scanner.Walker()
    name = vfs.basename(path)
    t = w.show_title(path)[0] or name
    if w.listdir(path) is None:
        return d.ok(NAME, "Can't open %s right now - is the drive awake?" % hide_creds(path))
    cands = _show_candidates(w, path)
    if not cands:
        return d.ok(NAME, "Everything in '%s' is seasons, discs or extras - there are no folders in it that could be "
                          "other shows." % name)
    rules = load_rules()
    auto = set(npath(p) for p, _why in w.split_outs(path, t))

    def is_auto(p, box):
        if box is None:
            return npath(p) in auto
        return npath(box) in auto and bool(w.other_show(p, t, 1) or w.classify(p) == "show")
    pre = [i for i, (p, _l, box) in enumerate(cands)
           if rules.get(npath(p)) == "one" or (is_auto(p, box) and rules.get(npath(p)) != "part")]
    labs = []
    for p, lab, _box in cands:
        st, sy = w.show_title(p)
        labs.append("%s   [COLOR grey]->  %s[/COLOR]" % (lab, names.title_year(st, sy)) if names.norm(st) and
                    names.norm(st) != names.norm(lab) else lab)
    sel = d.multiselect("Tick each folder that's a DIFFERENT show from '%s' (the rest stay part of it)" % t, labs,
                        preselect=pre)
    if sel is None:
        return
    sel = set(sel)
    ticked = [p for i, (p, _l, _b) in enumerate(cands) if i in sel]
    boxes_left = set()
    for i, (p, _l, box) in enumerate(cands):
        r = rules.get(npath(p))
        if i in sel:
            if r != "one":
                set_rule(p, "one")
            continue
        if box is not None:
            boxes_left.add(npath(box))
        if box is None and npath(p) in auto:
            set_rule(p, "part")  # StashBox would have read it as another show - you say it belongs here
        elif r in ("one", "part"):
            set_rule(p, None)
    for box in boxes_left:  # "Spin-offs" holding a show you say is part of this one: read it with this show
        if box in auto:
            set_rule(box, "part")
    for box in set(npath(b) for _p, _l, b in cands if b is not None) - boxes_left:
        if rules.get(box) == "part":
            set_rule(box, None)
    # what's left belongs to this folder's show
    res = w.listdir(path)
    own_left = [f for f in res[1] if names.is_video(f)] or [x for x in res[0] if names.season_from_dir(x) is not None]
    left = [p for i, (p, _l, _b) in enumerate(cands) if i not in sel]
    cur = rules.get(path)
    w2 = scanner.Walker()
    w2.rules.pop(path, None)
    if (left or own_left) and (cur != "one" and w2.classify(path) != "show"):
        set_rule(path, "one")  # e.g. "Star Trek/Star Trek (TOS)" stays Star Trek, the ticked ones go
    elif not (left or own_left) and cur == "one":
        set_rule(path, None)
    log("Shows in %s: %d marked as different shows (%s)" % (hide_creds(path), len(ticked), ", ".join(
        vfs.basename(p) for p in ticked)[:300]))
    scanner.forget_lookups(path)
    if _rescan(path, name):
        _shows_found(path, name)
    cat = rel(vfs.parent(path), root)
    xbmc.executebuiltin("Container.Update(%s,replace)" % url(action="browse", s=sec, r=root, c=cat))


def _shows_found(path, name):
    """After sorting a folder out: every show now in it, and whether TMDB found it - pick one to match it by hand."""
    d = xbmcgui.Dialog()
    while True:
        rows = _in_folder(path)
        if not rows:
            return
        labs = []
        for r in rows:
            if r["matched"]:
                labs.append("%s  [COLOR grey]%d file%s[/COLOR]" % (names.title_year(r["title"], r["year"]), r["n"],
                                                                   "" if r["n"] == 1 else "s"))
            else:
                labs.append("[COLOR orange]%s - not found on TMDB, pick to find it[/COLOR]  [COLOR grey]%d file%s"
                            "[/COLOR]" % (r["title"], r["n"], "" if r["n"] == 1 else "s"))
        n_un = sum(1 for r in rows if not r["matched"])
        i = d.select("'%s' is now %d show%s%s" % (name, len(rows), "" if len(rows) == 1 else "s",
                                                  " - %d not found yet" % n_un if n_un else ""), labs)
        if i < 0:
            return
        fix_match(rows[i]["item_id"], refresh_after=False)
