# -*- coding: utf-8 -*-
"""Music screens: artists, albums, songs, playing, and tidying it all into one folder."""
import json
import time

import xbmc
import xbmcgui
import xbmcplugin

import db
import downloads
import music
import vfs
from common import (NAME, fmt_size, hide_creds, load_locations, log, music_locations, notify, npath, request,
                    save_locations, setting)
from kodiui import add, color, end, handle, refresh, run, set_music, url


def _li(label, art="", fanart="", info=None):
    li = xbmcgui.ListItem(label)
    a = {"thumb": art, "icon": art, "poster": art, "fanart": fanart}
    li.setArt(dict((k, v) for k, v in a.items() if v) or {"icon": "DefaultMusicAlbums.png"})
    if info:
        set_music(li, info)
    return li


def home():
    n, albums, artists = music.counts()
    if not music.enabled():
        add(color("Music is switched off in Settings > Music", "grey"), {"action": "settings"}, False, icon="tools")
        return end(cache=False)
    if not n:
        where = "the whole NAS" if setting("music_scope", "0") == "0" else "your music folders"
        add(color("No music found yet - look through %s now" % where, "deepskyblue"),
            {"action": "music_scan"}, False, icon="scan",
            plot="Looks for MP3, FLAC, M4A, OGG... and reads their tags. Set where it looks in Settings > Music, "
                 "or add a music folder in Tools > Your NAS folders.")
    else:
        add("Artists  %s" % color("(%d)" % artists, "grey"), {"action": "m_artists"}, icon="star")
        add("Albums  %s" % color("(%d)" % albums, "grey"), {"action": "m_albums"}, icon="collection")
        add("Recently added", {"action": "m_albums", "o": "recent"}, icon="recent")
        add("Genres", {"action": "m_genres"}, icon="genre")
        add("Search music", {"action": "m_search"}, icon="search")
        add("Shuffle everything", {"action": "m_shuffle"}, False, icon="continue")
        add(color("Tidy my music into one folder...", "deepskyblue"), {"action": "m_tidy"}, False, icon="folder",
            plot="Moves every track into Artist / Album (Year) / 01 - Title in a music folder you pick - covers and "
                 ".cue files go with them, duplicates are left where they are. Runs in the background; you can "
                 "undo it from Downloads.")
    last = float(db.meta_get("last_music_scan") or 0)
    add(color("Look for new music now%s" % (" (last looked %s)" % time.strftime("%d %b %H:%M", time.localtime(last))
                                             if last else ""), "grey"), {"action": "music_scan"}, False, icon="scan",
        plot="StashBox only goes looking for music when you ask - here, or Settings > Music > Look for music now. "
             "(To have it look on its own every so often, change 'Look for new music' in Settings > Music.)")
    add(color("Music folders / where it looks", "grey"), {"action": "folders"}, True, icon="folder")
    end(cache=False)


def scan_now():
    request("scan", json.dumps({"by": "you", "sections": ["music"]}))
    notify("Looking for music in the background...")


def artists():
    for r in music.artists():
        li = _li("%s  %s" % (r["name"], color("(%d album%s)" % (r["albums"], "" if r["albums"] == 1 else "s"), "grey")),
                 r["art"], info={"mediatype": "artist", "artist": r["name"]})
        li.addContextMenuItems([("Shuffle %s" % r["name"], run(action="m_shuffle", a=r["name"]))])
        xbmcplugin.addDirectoryItem(handle(), url(action="m_artist", a=r["name"]), li, isFolder=True)
    end("artists", cache=False)


def artist(name):
    fan = music.artist_picture(name)
    add(color("Shuffle %s" % name, "deepskyblue"), {"action": "m_shuffle", "a": name}, False, icon="continue",
        fanart=fan)
    _album_rows(music.albums(artist=name, order="year"), fanart=fan, show_artist=False)
    end("albums", cache=False)


def albums(order="title", genre=None):
    rows = music.albums(genre=genre, order=order, limit=200 if order == "recent" else None)
    _album_rows(rows)
    end("albums", cache=False)


def _album_rows(rows, fanart="", show_artist=True):
    fetched = 0
    for r in rows:
        art = r["art"]
        if not art and fetched < 25:  # look a few missing covers up each time (they're cached)
            art = music.album_cover(r["artist"], r["album"])
            fetched += 1
        lab = r["album"] + (" (%d)" % r["year"] if r["year"] else "")
        if show_artist:
            lab = "%s  %s" % (lab, color(r["artist"], "grey"))
        li = _li(lab, art, fanart, {"mediatype": "album", "album": r["album"], "artist": r["artist"],
                                    "year": r["year"]})
        li.addContextMenuItems([("Play album", run(action="m_play_album", k=r["akey"])),
                                ("Shuffle album", run(action="m_play_album", k=r["akey"], s="1"))])
        xbmcplugin.addDirectoryItem(handle(), url(action="m_album", k=r["akey"]), li, isFolder=True)


def album(key):
    rows = music.album_tracks(key)
    if not rows:
        return end()
    first = rows[0]
    art = first["art"] or music.album_cover(first["albumartist"], first["album"])
    add(color("Play album", "deepskyblue"), {"action": "m_play_album", "k": key}, False, icon=art or "continue",
        fanart=music.artist_picture(first["albumartist"]))
    multi = len(set(r["disc"] or 1 for r in rows)) > 1
    for r in rows:
        _track_item(r, art, multi)
    end("songs", cache=False)


def _track_item(r, art="", multi=False, with_artist=False):
    num = ("%d-%02d " % (r["disc"] or 1, r["track"]) if multi else "%02d " % r["track"]) if r["track"] else ""
    lab = num + (r["title"] or vfs.basename(r["path"]))
    if with_artist:
        lab += "  " + color("%s - %s" % (r["artist"], r["album"]), "grey")
    elif r["artist"] and r["artist"] != r["albumartist"]:
        lab += "  " + color(r["artist"], "grey")
    if r["duration"]:
        lab += "  " + color(music.fmt_dur(r["duration"]), "grey")
    li = _li(lab, art or r["art"], info=_info(r))
    li.setProperty("IsPlayable", "true")
    li.addContextMenuItems([("Where is it?", run(action="m_where", p=r["path"]))])
    xbmcplugin.addDirectoryItem(handle(), r["path"], li, isFolder=False)


def _info(r):
    return {"mediatype": "song", "title": r["title"], "artist": r["artist"], "album": r["album"],
            "albumartist": r["albumartist"], "track": r["track"], "disc": r["disc"], "year": r["year"],
            "genre": r["genre"], "duration": r["duration"]}


def genres():
    for r in music.genres():
        add("%s  %s" % (r["genre"], color("(%d)" % r["n"], "grey")), {"action": "m_albums", "g": r["genre"]},
            icon="genre")
    end(cache=False)


def search(q=None):
    if q is None:
        q = xbmcgui.Dialog().input("Search music (artist, album or song)")
        if not q:
            return end(ok=False)
    arts, albs, songs = music.search(q)
    for r in arts:
        add("%s  %s" % (r["name"], color("artist", "grey")), {"action": "m_artist", "a": r["name"]}, icon="star")
    _album_rows(albs)
    for r in songs:
        _track_item(r, with_artist=True)
    if not (arts or albs or songs):
        add(color("No music matches '%s'" % q, "grey"), {"action": "noop"}, False)
    end("songs", cache=False)


def _play(rows, shuffle=False):
    rows = list(rows)
    if shuffle:
        import random
        random.shuffle(rows)
    if not rows:
        return notify("Nothing to play", "warn")
    pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    pl.clear()
    for r in rows:
        li = _li(r["title"] or vfs.basename(r["path"]), r["art"], info=_info(r))
        pl.add(r["path"], li)
    xbmc.Player().play(pl)


def play_album(key, shuffle=False):
    _play(music.album_tracks(key), shuffle)


def shuffle(artist=None):
    _play(music.random_tracks(300, artist), True)


def where(path):
    r = db.one("SELECT * FROM tracks WHERE path=?", (path,))
    if not r:
        return
    xbmcgui.Dialog().textviewer(NAME, "%s\n%s - %s\n\nFile: %s\nFolder: %s\nSize: %s" % (
        r["title"], r["artist"], r["album"], vfs.basename(path), hide_creds(vfs.parent(path)), fmt_size(r["size"])))


# ---------------------------------------------------------------- tidy into one folder
def tidy():
    d = xbmcgui.Dialog()
    locs = music_locations()
    opts = ["%s  %s" % (x.get("label") or x["path"], color(hide_creds(x["path"]), "grey")) for x in locs]
    opts.append("Choose another folder...")
    i = d.select("Put all your music in which folder?", opts)
    if i < 0:
        return
    if i == len(locs):
        p = d.browse(3, "Your music folder (on the NAS)", "files", "", False, False, "")
        if not p:
            return
        p = npath(p)
        allloc = load_locations()
        ml = allloc.setdefault("music", [])
        if not any(npath(x["path"]) == p for x in ml):
            ml.append({"path": p, "label": vfs.basename(p), "default": not ml})
            save_locations(allloc)
        target = p
    else:
        target = npath(locs[i]["path"])
    j = d.select("File names", ["Rename to '01 - Title.mp3' (from the tags)", "Keep the file names as they are"])
    if j < 0:
        return
    prog = xbmcgui.DialogProgress()
    prog.create(NAME, "Working out where everything goes...")
    try:
        p = music.plan_tidy(target, j == 0)
    finally:
        prog.close()
    tracks = [m for m in p["moves"] if m["video"]]
    if not tracks:
        return d.ok(NAME, "Nothing to move - your music is already tidy in that folder.")
    lines = ["Move %d tracks (%s) into\n%s  as  Artist / Album (Year) / ..." % (
        len(tracks), fmt_size(p["cross_bytes"] + p["same_bytes"]), hide_creds(target)), "", "From:"]
    for src, n in sorted(p["sources"].items(), key=lambda x: -x[1])[:12]:
        lines.append("  %s  - %d track%s" % (hide_creds(src), n, "" if n == 1 else "s"))
    if p["cross_bytes"]:
        lines += ["", "%s is on other drives / shares, so it's copied through this Kodi box, checked, then the "
                      "originals removed (roughly %s over Wi-Fi). The rest moves instantly." % (
                          fmt_size(p["cross_bytes"]), _eta(p["cross_bytes"]))]
    if p["dups"]:
        lines += ["", "%d duplicate%s stay where they are." % (len(p["dups"]), "" if len(p["dups"]) == 1 else "s")]
    d.textviewer(NAME + " - tidy my music", "\n".join(lines))
    if not d.yesno(NAME, "Go ahead and move %d tracks into %s?\n(You can undo it from Downloads.)" % (
            len(tracks), hide_creds(target))):
        return
    jid = downloads.add({"title": "Tidy music into %s" % vfs.basename(target), "section": "music", "root": target,
                         "kind": "music", "source": {"type": "organise"}, "moves": p["moves"], "tidy": p["tidy"],
                         "media": {}, "want": {}})
    log("Music tidy: %d moves into %s (job %s)" % (len(p["moves"]), hide_creds(target), jid))
    notify("Tidying your music in the background - see Downloads", "info", 6000)


def _eta(nbytes):
    secs = nbytes / (8 * 1024 * 1024.0)
    if secs < 90:
        return "a minute"
    if secs < 3600:
        return "%d minutes" % (secs / 60)
    return "%.1f hours" % (secs / 3600)


def refresh_list():
    refresh()
