# -*- coding: utf-8 -*-
"""Small helpers for building Kodi folders and list items."""
import os
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from common import ADDON_ID, PATH, media_icon

S = {"handle": -1, "params": {}}
FANART = os.path.join(PATH, "fanart.jpg")


def init(argv):
    S["handle"] = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
    S["params"] = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
    return S["params"]


def handle():
    return S["handle"]


def url(**kw):
    return "plugin://%s/?%s" % (ADDON_ID, urlencode(dict((k, v) for k, v in kw.items() if v is not None)))


def run(**kw):
    return "RunPlugin(%s)" % url(**kw)


def refresh():
    xbmc.executebuiltin("Container.Refresh")


def set_info(li, d):
    """d: mediatype, title, plot, year, genres(list), rating, votes, duration, mpaa, studio(list), tagline,
    playcount, season, episode, tvshowtitle, originaltitle, premiered, tmdb, imdb, sorttitle."""
    d = dict((k, v) for k, v in d.items() if v not in (None, "", []))
    if hasattr(li, "getVideoInfoTag"):
        t = li.getVideoInfoTag()
        calls = [("mediatype", "setMediaType", str), ("title", "setTitle", str), ("plot", "setPlot", str),
                 ("year", "setYear", int), ("genres", "setGenres", list), ("duration", "setDuration", int),
                 ("mpaa", "setMpaa", str), ("studio", "setStudios", list), ("tagline", "setTagLine", str),
                 ("playcount", "setPlaycount", int), ("season", "setSeason", int), ("episode", "setEpisode", int),
                 ("tvshowtitle", "setTvShowTitle", str), ("originaltitle", "setOriginalTitle", str),
                 ("premiered", "setPremiered", str), ("sorttitle", "setSortTitle", str)]
        for key, fn, cast in calls:
            if key in d and hasattr(t, fn):
                try:
                    getattr(t, fn)(cast(d[key]))
                except Exception:
                    pass
        if "rating" in d:
            try:
                t.setRating(float(d["rating"]), int(d.get("votes") or 0), "tmdb", True)
            except Exception:
                pass
        ids = {}
        if d.get("tmdb"):
            ids["tmdb"] = str(d["tmdb"])
        if d.get("imdb"):
            ids["imdb"] = str(d["imdb"])
        if ids:
            try:
                t.setUniqueIDs(ids, "tmdb" if "tmdb" in ids else "imdb")
            except Exception:
                pass
    else:  # Kodi 19
        info = {}
        for key in ("mediatype", "title", "plot", "year", "duration", "mpaa", "tagline", "playcount", "season",
                    "episode", "tvshowtitle", "originaltitle", "premiered", "rating", "votes", "sorttitle"):
            if key in d:
                info[key] = d[key]
        if "genres" in d:
            info["genre"] = " / ".join(d["genres"])
        if "studio" in d:
            info["studio"] = " / ".join(d["studio"])
        if d.get("imdb"):
            info["imdbnumber"] = d["imdb"]
        li.setInfo("video", info)


def set_music(li, d):
    """d: title, artist, album, albumartist, track, disc, year, genre, duration, mediatype (song/album/artist)."""
    d = dict((k, v) for k, v in d.items() if v not in (None, "", []))
    if hasattr(li, "getMusicInfoTag"):
        t = li.getMusicInfoTag()
        for key, fn, cast in (("mediatype", "setMediaType", str), ("title", "setTitle", str),
                              ("artist", "setArtist", str), ("album", "setAlbum", str),
                              ("albumartist", "setAlbumArtist", str), ("track", "setTrack", int),
                              ("disc", "setDisc", int), ("year", "setYear", int), ("duration", "setDuration", int),
                              ("genre", "setGenres", lambda g: [g]), ("comment", "setComment", str)):
            if key in d and hasattr(t, fn):
                try:
                    getattr(t, fn)(cast(d[key]))
                except Exception:
                    pass
    else:
        info = dict((k, d[k]) for k in ("title", "artist", "album", "tracknumber", "discnumber", "year", "genre",
                                         "duration", "mediatype", "comment") if k in d)
        if "track" in d:
            info["tracknumber"] = d["track"]
        if "disc" in d:
            info["discnumber"] = d["disc"]
        li.setInfo("music", info)


def item(label, icon=None, fanart=None, poster=None, thumb=None, plot=None, label2=None):
    li = xbmcgui.ListItem(label=label, label2=label2 or "")
    ic = icon if (icon and ("://" in icon or os.path.isabs(icon))) else media_icon(icon or "folder")
    art = {"icon": ic, "thumb": thumb or poster or ic, "fanart": fanart or FANART}
    if poster:
        art["poster"] = poster
    li.setArt(art)
    if plot:
        set_info(li, {"plot": plot, "title": label})
    return li


def add(label, params, folder=True, li=None, icon=None, fanart=None, plot=None, ctx=None, playable=False,
        poster=None, thumb=None, label2=None):
    if li is None:
        li = item(label, icon, fanart, poster, thumb, plot, label2)
    if ctx:
        li.addContextMenuItems(ctx)
    if playable:
        li.setProperty("IsPlayable", "true")
    u = url(**params) if isinstance(params, dict) else params
    xbmcplugin.addDirectoryItem(S["handle"], u, li, isFolder=folder)


def end(content=None, sort=None, cache=True, ok=True):
    h = S["handle"]
    if h < 0:
        return
    if content:
        xbmcplugin.setContent(h, content)
    for m in sort or []:
        xbmcplugin.addSortMethod(h, m)
    xbmcplugin.endOfDirectory(h, succeeded=ok, cacheToDisc=cache)


def fail_dir():
    if S["handle"] >= 0:
        xbmcplugin.endOfDirectory(S["handle"], succeeded=False)


def fail_play():
    if S["handle"] >= 0:
        xbmcplugin.setResolvedUrl(S["handle"], False, xbmcgui.ListItem())


def color(text, c):
    return "[COLOR %s]%s[/COLOR]" % (c, text)


SORT_TITLE = xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE if hasattr(xbmcplugin, "SORT_METHOD_LABEL_IGNORE_THE") else 0
