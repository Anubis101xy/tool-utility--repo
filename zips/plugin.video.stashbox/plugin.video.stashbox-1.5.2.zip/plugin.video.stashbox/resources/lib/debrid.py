# -*- coding: utf-8 -*-
"""TorBox, Real-Debrid and Cocoleech, all behind the same small interface:

    h = svc.start(info_hash, name)   -> handle once the torrent has been added
    st = svc.status(h)               -> {"ready", "progress", "state", "name", "files", "error"}
    url = svc.link(h, file_id)       -> direct https link for that file
Files are [{"id", "name", "size"}]. API details as used by ResolveURL and the TorUtilityBox add-on."""
import json
import os
import re
import time

import requests

from common import PROFILE, UA, ensure_profile, log, setting

MEDIA_EXT = (".mkv", ".mp4", ".avi", ".mov", ".ts", ".m4v", ".webm", ".wmv", ".mpg", ".mpeg", ".m2ts", ".srt", ".ass",
             ".ssa", ".sub", ".idx", ".zip", ".rar", ".7z", ".vob", ".iso")
NAMES = {"tb": "TorBox", "rd": "Real-Debrid", "cl": "Cocoleech"}


class DebridError(Exception):
    pass


def _clean(name):
    return re.sub(r"^/+", "", name or "")


# ---------------------------------------------------------------- TorBox
class TorBox(object):
    label = "TorBox"
    API = "https://api.torbox.app/v1/api"
    KINDS = {"torrents": ("torrents", "torrent_id"), "usenet": ("usenet", "usenet_id"), "webdl": ("webdl", "web_id")}

    def __init__(self, key):
        self.key = (key or "").strip()

    def _req(self, method, path, timeout=25, **kw):
        if not self.key:
            raise DebridError("no TorBox API key")
        h = dict(UA, Authorization="Bearer " + self.key)
        try:
            r = requests.request(method, self.API + path, headers=h, timeout=timeout, **kw)
        except requests.RequestException as e:
            raise DebridError("can't reach TorBox (%s)" % e.__class__.__name__)
        try:
            body = r.json()
        except ValueError:
            if r.status_code >= 500:
                raise DebridError("TorBox isn't working right now (HTTP %s) - maybe maintenance" % r.status_code)
            raise DebridError("HTTP %s from TorBox" % r.status_code)
        if r.status_code >= 400 or body.get("success") is False:
            raise DebridError("TorBox: %s" % (body.get("detail") or body.get("error") or "HTTP %s" % r.status_code))
        return body

    def user(self):
        return self._req("GET", "/user/me").get("data") or {}

    def mylist(self, kind="torrents", item_id=None):
        params = {"bypass_cache": "true"}
        if item_id is not None:
            params["id"] = item_id
        data = self._req("GET", "/%s/mylist" % self.KINDS[kind][0], params=params).get("data")
        if item_id is not None:
            if isinstance(data, list):
                return data[0] if data else None
            return data
        return data or []

    def request_dl(self, kind, item_id, file_id):
        seg, idf = self.KINDS[kind]
        d = self._req("GET", "/%s/requestdl" % seg, params={"token": self.key, idf: item_id, "file_id": file_id,
                                                              "zip_link": "false", "redirect": "false"}).get("data")
        if not d:
            raise DebridError("TorBox gave no download link")
        return d

    def check_cached(self, hashes):
        out = set()
        hashes = [h for h in hashes if h]
        for i in range(0, len(hashes), 50):
            chunk = hashes[i:i + 50]
            data = self._req("GET", "/torrents/checkcached", timeout=12,
                             params={"hash": ",".join(chunk), "format": "object"}).get("data") or {}
            if isinstance(data, dict):
                out.update(k.lower() for k in data)
            elif isinstance(data, list):
                out.update((x.get("hash") or "").lower() for x in data if isinstance(x, dict))
        return out

    # -- torrent service face
    def start(self, info_hash, name=""):
        magnet = "magnet:?xt=urn:btih:%s" % info_hash
        if name:
            magnet += "&dn=" + requests.utils.quote(name[:120])
        tid = None
        try:
            d = self._req("POST", "/torrents/createtorrent",
                          files={"magnet": (None, magnet), "allow_zip": (None, "false")}).get("data") or {}
            tid = d.get("torrent_id") or d.get("id")
        except DebridError as e:
            if "already" not in str(e).lower():
                raise
        if not tid:
            for t in self.mylist("torrents"):
                if (t.get("hash") or "").lower() == info_hash.lower():
                    tid = t.get("id")
                    break
        if not tid:
            raise DebridError("TorBox didn't accept the torrent")
        return str(tid)

    def status(self, h, kind="torrents"):
        it = self.mylist(kind, h) or {}
        if not it:
            return {"ready": False, "progress": 0, "state": "not found on TorBox", "name": "", "files": [],
                    "error": "TorBox lost the download (deleted?)"}
        ready = bool(it.get("files") and (it.get("download_finished") or it.get("download_present")))
        state = (it.get("download_state") or "queued").replace("_", " ")
        err = None
        if any(x in state for x in ("error", "failed", "stalled (no seeds)")):
            err = "TorBox says: %s" % state
        if it.get("download_speed") and not ready:
            state = "%s %.1f MB/s" % (state, float(it["download_speed"]) / 1e6)
        return {"ready": ready, "progress": int(float(it.get("progress") or 0) * 100), "state": state,
                "name": it.get("name") or "",
                "files": [{"id": f["id"], "name": _clean(f.get("name")), "size": f.get("size") or 0}
                          for f in it.get("files") or []] if ready else [], "error": err}

    def link(self, h, file_id, kind="torrents"):
        return self.request_dl(kind, h, file_id)

    def delete(self, h, kind="torrents"):
        ctl = {"torrents": ("controltorrent", "torrent_id"), "usenet": ("controlusenetdownload", "usenet_id"),
               "webdl": ("controlwebdownload", "webdl_id")}[kind]
        try:
            self._req("POST", "/%s/%s" % (kind, ctl[0]), json={ctl[1]: int(h), "operation": "delete"})
        except (DebridError, ValueError):
            pass

    def add_webdl(self, link):
        d = self._req("POST", "/webdl/createwebdownload", files={"link": (None, link)}).get("data") or {}
        wid = d.get("webdownload_id") or d.get("id") or d.get("web_id")
        if not wid:
            raise DebridError("TorBox didn't accept the link")
        return str(wid)


# ---------------------------------------------------------------- Real-Debrid
def _rd_file():
    return os.path.join(PROFILE, "rd_auth.json")


def rd_auth():
    try:
        with open(_rd_file(), "r") as f:
            return json.load(f)
    except Exception:
        return {}


def rd_save(a):
    ensure_profile()
    with open(_rd_file(), "w") as f:
        json.dump(a or {}, f)


class RealDebrid(object):
    label = "Real-Debrid"
    REST = "https://api.real-debrid.com/rest/1.0"
    OAUTH = "https://api.real-debrid.com/oauth/v2"
    CLIENT_ID = "X245A4XAIBGVM"  # Real-Debrid's public id for open-source apps (same as ResolveURL)
    STALLED = ("magnet_error", "error", "virus", "dead")

    def __init__(self, auth=None):
        self.auth = dict(auth or rd_auth())

    @classmethod
    def device_start(cls):
        d = requests.get(cls.OAUTH + "/device/code", params={"client_id": cls.CLIENT_ID, "new_credentials": "yes"},
                         headers=UA, timeout=20).json()
        if not d.get("device_code"):
            raise DebridError("Real-Debrid didn't give a login code")
        return d

    @classmethod
    def device_poll(cls, device_code):
        r = requests.get(cls.OAUTH + "/device/credentials", params={"client_id": cls.CLIENT_ID, "code": device_code},
                         headers=UA, timeout=20)
        try:
            c = r.json()
        except ValueError:
            return None
        if not c.get("client_id") or not c.get("client_secret"):
            return None
        t = requests.post(cls.OAUTH + "/token", data={"client_id": c["client_id"], "client_secret": c["client_secret"],
                                                       "code": device_code,
                                                       "grant_type": "http://oauth.net/grant_type/device/1.0"},
                          headers=UA, timeout=20).json()
        if not t.get("access_token"):
            return None
        return {"token": t["access_token"], "refresh": t.get("refresh_token", ""), "client_id": c["client_id"],
                "client_secret": c["client_secret"], "expires": time.time() + int(t.get("expires_in") or 3600)}

    def _refresh(self):
        a = self.auth
        if not (a.get("refresh") and a.get("client_id")):
            raise DebridError("Real-Debrid login has expired - log in again (Tools > Accounts)")
        t = requests.post(self.OAUTH + "/token", data={"client_id": a["client_id"], "client_secret": a["client_secret"],
                                                        "code": a["refresh"],
                                                        "grant_type": "http://oauth.net/grant_type/device/1.0"},
                          headers=UA, timeout=20).json()
        if not t.get("access_token"):
            raise DebridError("Real-Debrid login has expired - log in again (Tools > Accounts)")
        a.update(token=t["access_token"], refresh=t.get("refresh_token") or a["refresh"],
                 expires=time.time() + int(t.get("expires_in") or 3600))
        rd_save(a)

    def _req(self, method, path, retry=True, **kw):
        if not self.auth.get("token"):
            raise DebridError("not logged in to Real-Debrid")
        if self.auth.get("expires") and time.time() > self.auth["expires"] - 60:
            self._refresh()
        h = dict(UA, Authorization="Bearer " + self.auth["token"])
        try:
            r = requests.request(method, self.REST + path, headers=h, timeout=kw.pop("timeout", 25), **kw)
        except requests.RequestException as e:
            raise DebridError("can't reach Real-Debrid (%s)" % e.__class__.__name__)
        if r.status_code == 401 and retry:
            self._refresh()
            return self._req(method, path, retry=False, **kw)
        if r.status_code >= 400:
            try:
                j = r.json()
                msg = j.get("error") or ("error %s" % j.get("error_code"))
            except ValueError:
                msg = "HTTP %s" % r.status_code
            if r.status_code >= 500:
                msg = "Real-Debrid's server isn't working right now (HTTP %s)" % r.status_code
            raise DebridError("Real-Debrid: " + msg.replace("_", " "))
        if r.status_code == 204 or not r.content:
            return {}
        try:
            return r.json()
        except ValueError:
            return {}

    def user(self):
        return self._req("GET", "/user")

    def start(self, info_hash, name=""):
        d = self._req("POST", "/torrents/addMagnet", data={"magnet": "magnet:?xt=urn:btih:%s" % info_hash})
        if not d.get("id"):
            raise DebridError("Real-Debrid didn't accept the torrent")
        return str(d["id"])

    def _info(self, h):
        return self._req("GET", "/torrents/info/%s" % h)

    def status(self, h):
        info = self._info(h)
        st = info.get("status") or "?"
        if st == "waiting_files_selection":
            files = info.get("files") or []
            want = [str(f["id"]) for f in files if (f.get("path") or "").lower().endswith(MEDIA_EXT)]
            self._req("POST", "/torrents/selectFiles/%s" % h, data={"files": ",".join(want) if want else "all"})
            info = self._info(h)
            st = info.get("status") or "?"
        out = {"ready": st == "downloaded", "progress": int(float(info.get("progress") or 0)),
               "state": st.replace("_", " "), "name": info.get("filename") or "", "files": [], "error": None}
        if any(x in st for x in self.STALLED):
            out["error"] = "Real-Debrid says the torrent is %s" % st.replace("_", " ")
        if out["ready"]:
            sel = [f for f in info.get("files") or [] if f.get("selected")]
            links = info.get("links") or []
            out["files"] = [{"id": i, "name": _clean(f.get("path")), "size": f.get("bytes") or 0}
                            for i, f in enumerate(sel) if i < len(links)]
        elif st == "downloading" and info.get("speed"):
            out["state"] = "downloading %.1f MB/s from %s peers" % (float(info["speed"]) / 1e6, info.get("seeders") or "?")
        return out

    def link(self, h, file_id):
        links = self._info(h).get("links") or []
        try:
            return self.unrestrict(links[int(file_id)])
        except IndexError:
            raise DebridError("Real-Debrid lost that file")

    def unrestrict(self, link):
        d = self._req("POST", "/unrestrict/link", data={"link": link})
        if not d.get("download"):
            raise DebridError("Real-Debrid gave no download link")
        return d["download"]

    def delete(self, h):
        try:
            self._req("DELETE", "/torrents/delete/%s" % h)
        except DebridError:
            pass


# ---------------------------------------------------------------- Cocoleech
class Cocoleech(object):
    label = "Cocoleech"
    V2 = "https://members.cocoleech.com/api/v2"
    AUTH = "https://members.cocoleech.com/auth/api"

    def __init__(self, key):
        self.key = (key or "").strip()

    def _get(self, path, **params):
        if not self.key:
            raise DebridError("no Cocoleech API key")
        params["key"] = self.key
        try:
            r = requests.get(self.V2 + path, params=params, headers=UA, timeout=25)
        except requests.RequestException as e:
            raise DebridError("can't reach Cocoleech (%s)" % e.__class__.__name__)
        try:
            j = r.json()
        except ValueError:
            try:
                j = json.loads((r.text or "").strip()[1:])
            except ValueError:
                raise DebridError("bad reply from Cocoleech (HTTP %s)" % r.status_code)
        if isinstance(j, dict) and str(j.get("status")) not in ("200", "None") and j.get("message") and \
                "cached" not in str(j.get("message")).lower():
            raise DebridError("Cocoleech: %s" % j["message"])
        return j

    def cached(self, info_hash):
        try:
            j = self._get("/checkInstant", hash=info_hash)
        except DebridError:
            return False
        return isinstance(j, dict) and str(j.get("status")) == "200" and "torrent cached" in str(j.get("message")).lower()

    def start(self, info_hash, name=""):
        self._get("/add", hash=info_hash)
        return info_hash.lower()

    def _entry(self, h):
        j = self._get("/list", hash=h)
        items = j if isinstance(j, list) else (j.get("data") or j.get("result") or []) if isinstance(j, dict) else []
        for it in items:
            if (it.get("hash") or "").lower() == h.lower():
                return it
        return None

    def _files(self, h):
        j = self._get("/browse", hash=h)
        tors = ((j.get("arguments") or {}).get("torrents") or []) if isinstance(j, dict) else []
        if not tors:
            return []
        return [{"id": i, "name": _clean(f.get("name")), "size": int(f.get("size") or 0), "url": f.get("downloadUrl")}
                for i, f in enumerate(tors[0].get("files") or [])]

    def status(self, h):
        it = self._entry(h) or {}
        done = bool(it.get("isComplete"))
        out = {"ready": done, "progress": int(float(it.get("progress") or (100 if done else 0))),
               "state": it.get("status") or ("ready" if done else "queued"), "name": it.get("name") or "",
               "files": [], "error": None}
        if not it:
            files = self._files(h)
            if files:
                out.update(ready=True, progress=100, state="ready", files=files)
            return out
        if done:
            out["files"] = self._files(h)
            if not out["files"]:
                out["ready"] = False
                out["state"] = "preparing the files"
        elif it.get("rateDownload"):
            out["state"] = "downloading %.1f MB/s" % (float(it["rateDownload"]) / 1e6)
        if "error" in str(it.get("status") or "").lower():
            out["error"] = "Cocoleech: %s" % it.get("status")
        return out

    def link(self, h, file_id):
        for f in self._files(h):
            if f["id"] == int(file_id):
                if not f.get("url"):
                    raise DebridError("Cocoleech gave no link for that file")
                return f["url"]
        raise DebridError("Cocoleech lost that file")

    def delete(self, h):
        try:
            self._get("/delete", hash=h)
        except DebridError:
            pass

    def generate(self, link):
        """File-host link (Rapidgator etc.) -> direct link."""
        try:
            r = requests.get(self.AUTH, params={"key": self.key, "link": link}, headers=UA, timeout=40)
            body = r.json()
        except (requests.RequestException, ValueError) as e:
            raise DebridError("Cocoleech unreachable or bad reply (%s)" % e.__class__.__name__)
        if body.get("message") and not body.get("download"):
            raise DebridError("Cocoleech: %s" % body["message"])
        if not body.get("download"):
            raise DebridError("Cocoleech gave no download link")
        return body["download"]


# ---------------------------------------------------------------- which services are set up
def tb_key():
    return setting("api_key").strip()


def coco_key():
    return setting("cocoleech_key").strip()


def ready(s):
    if s == "tb":
        return bool(tb_key())
    if s == "rd":
        return bool(rd_auth().get("token"))
    if s == "cl":
        return bool(coco_key())
    return False


def available():
    return [s for s in ("tb", "rd", "cl") if ready(s)]


def get(s):
    if s == "tb":
        return TorBox(tb_key())
    if s == "rd":
        if not rd_auth().get("token"):
            raise DebridError("not logged in to Real-Debrid")
        return RealDebrid()
    if s == "cl":
        return Cocoleech(coco_key())
    raise DebridError("unknown service %s" % s)


def unlock(link):
    """A file-host link -> (direct url, service name). Tries Cocoleech, then Real-Debrid."""
    errs = []
    if coco_key():
        try:
            return Cocoleech(coco_key()).generate(link), "Cocoleech"
        except DebridError as e:
            errs.append(str(e))
    if rd_auth().get("token"):
        try:
            return RealDebrid().unrestrict(link), "Real-Debrid"
        except DebridError as e:
            errs.append(str(e))
    if not errs:
        raise DebridError("log in to Cocoleech or Real-Debrid to unlock file-host links")
    log("Unlock failed for %s: %s" % (link[:80], errs), "warn")
    raise DebridError(" | ".join(errs))
