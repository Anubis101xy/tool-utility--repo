# -*- coding: utf-8 -*-
"""Scan the NAS folders into the library: find videos, work out what they are, match them on TMDB."""
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import db
import names
import tmdb
import vfs
from common import (SECTION_KIND, SECTION_LABEL, SECTIONS, all_locations, hide_creds, loc_label, locations, log, npath, rel,
                    save_json, setting, setting_int, under)


# ---------------------------------------------------------------- detailed scan log (scan_detail.txt)
DETAIL = []
_DET = {"on": True, "nest": 0}
DETAIL_FILE = "scan_detail.txt"


def PROFILE_DIR():
    from common import PROFILE
    return PROFILE


def det(line):
    if _DET["on"]:
        DETAIL.append(hide_creds(line))


def _detail_start():
    if _DET["nest"] == 0:
        del DETAIL[:]
        _DET["on"] = setting("detailed_log", "true") != "false"
    _DET["nest"] += 1


def _detail_end(title, overwrite):
    _DET["nest"] -= 1
    if _DET["nest"] > 0 or not _DET["on"] or not DETAIL:
        return
    import os
    from common import PROFILE, ensure_profile
    ensure_profile()
    p = os.path.join(PROFILE, DETAIL_FILE)
    head = "\n%s  %s\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), title, "=" * 78)
    body = head + "\n".join(DETAIL) + "\n"
    try:
        old = ""
        if not overwrite and os.path.exists(p):
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                old = f.read()[-2500000:]
        with open(p, "w", encoding="utf-8") as f:
            f.write(old + body)
    except Exception as e:
        log("Writing the detailed scan log: %s" % e, "warn")
    del DETAIL[:]


class Found(object):
    __slots__ = ("path", "mkey", "title", "year", "hint", "season", "episode", "ep_end", "absolute", "folder", "root",
                 "cat", "coll", "ord", "alt", "stripped", "disc", "label")

    def __init__(self, path, mkey, title, year, folder, hint=None, season=None, episode=None, ep_end=None,
                 absolute=False, root=None, cat="", coll="", ord_=None, alt=None, stripped=False):
        self.path, self.mkey, self.title, self.year, self.folder = path, mkey, title, year, folder
        self.hint, self.season, self.episode, self.ep_end, self.absolute = hint, season, episode, ep_end, absolute
        self.root, self.cat, self.coll, self.ord, self.alt, self.stripped = root, cat, coll, ord_, alt, stripped
        self.disc, self.label = False, None


def _disc_found(f, label):
    f.disc, f.label = True, label
    return f


def tv_like(path, root):
    """Is this an episode / TV disc rather than a film? (Splits a drive that's in both Movies and TV.)"""
    if names.is_disc_path(path):
        chain = [x for x in rel(names.disc_folder(path), root).split("/") if x]
        return any(names.season_from_dir(x) for x in chain) or any(
            re.search(r"(?i)\bcomplete[\s._-]+series\b", x) for x in chain)
    p = names.parse_episode(vfs.basename(path))
    if p and not p["absolute"]:
        return True
    chain = [x for x in rel(vfs.parent(path), root).split("/") if x]
    return any(names.season_from_dir(x) for x in chain if not names.skip_dir(x))


def coll_words():
    return setting("collection_words", names.DEFAULT_COLLECTION_WORDS)


def _coll_of(cat, words):
    """The collection folder (relative path) a title sits in: the deepest 'Collection' / 'Pack' / ... folder."""
    parts = [p for p in (cat or "").split("/") if p]
    for i in range(len(parts) - 1, -1, -1):
        if names.is_collection_name(parts[i], words):
            return "/".join(parts[:i + 1])
    return ""


def _same(a, b):
    return npath(a) == npath(b)


def _hidden(d):
    """System folder, or bonus material (only meaningful inside a title's own folder)."""
    return names.skip_dir(d) or names.system_dir(d)


class Walker(object):
    """Reads folders on the NAS once per scan (cached), counting them and saying where it is."""

    def __init__(self, tick=None):
        self.tick = tick
        self.failed = []
        self.folders = 0
        self.cache = {}
        self.titles = set()  # film folders found so far - their "Extras" etc. aren't walked
        self.reasons = {}
        from common import load_json
        self.rules = load_json("folder_rules.json", {})

    def listdir(self, path):
        k = npath(path)
        if k in self.cache:
            return self.cache[k]
        res = vfs.listdir(path)
        self.folders += 1
        if self.tick:
            try:
                self.tick(path, self.folders)
            except Exception:
                pass
        if res is None:
            self.failed.append(k)
        self.cache[k] = res
        return res

    def walk(self, path, depth=6, inside_title=False, prune=None):
        """inside_title: walking a show's own folder, so bonus folders ('Extras', 'Other', 'Shorts') are skipped.
        Otherwise they're only skipped below a film folder (the caller adds it to self.titles).
        prune: folders not to go into (shows of their own inside this one - they're read separately)."""
        if self.rules.get(npath(path)) == "skip":
            det("   [skip]     %s  - your folder rule" % vfs.basename(path))
            return
        if prune and npath(path) in prune:
            return
        res = self.listdir(path)
        if res is None:
            return
        dirs, files = res
        yield path, dirs, files
        if depth <= 0:
            return
        title = inside_title or npath(path) in self.titles
        for d in sorted(dirs, key=lambda x: x.lower()):
            if names.system_dir(d) or (title and names.skip_dir(d)) or d.lower() in names.DISC_DIRS:
                continue
            for x in self.walk(vfs.join(path, d), depth - 1, inside_title, prune):
                yield x

    # -- shows inside a show's folder ("Star Trek" holding "Star Trek The Next Generation", "Voyager" ...)
    def split_outs(self, show, t):
        """Folders inside a show's folder that are shows of their own -> [(path, why)]: ones you've said are
        ("this is a different show", "split it up", "leave it out"), and ones that plainly hold another show."""
        sp = npath(show)
        ruled = [k for k, v in self.rules.items() if v in ("one", "many", "skip") and under(k, sp) and npath(k) != sp]
        ruled = [k for k in ruled if not any(o != k and under(k, o) for o in ruled)]  # top-most only
        out = [(k, "you said it's a different show" if self.rules[k] == "one" else "your folder rule (%s)" % (
            RULE_WORDS.get(self.rules[k], self.rules[k]))) for k in ruled]
        taken = set(npath(k) for k in ruled)
        res = self.listdir(show)
        for x in sorted(res[0] if res else [], key=lambda s: s.lower()):
            p = vfs.join(show, x)
            if npath(p) in taken or any(under(p, k) for k in taken) or self.rules.get(npath(p)) == "part":
                continue
            if not _could_be_show(x):
                continue
            why = self.other_show(p, t)
            if why:
                out.append((p, why))
        return out

    def other_show(self, p, t, depth=0):
        """Does folder p (inside the show 't') hold a different show? -> why, or None."""
        st = self.show_title(p)[0]
        if not names.norm(st) or same_show(st, t) or category_like(st):
            if depth or not category_like(st):
                return None
        res = self.listdir(p)
        if not res:
            return None
        dirs, files = res
        seasons = [d for d in dirs if names.season_from_dir(d) is not None]
        eps = [f for f in files if names.is_video(f) and not names.is_sample(f) and names.parse_episode(f)]
        if not eps and seasons:
            r2 = self.listdir(vfs.join(p, sorted(seasons)[0]))
            eps = [f for f in (r2[1] if r2 else []) if names.is_video(f) and names.parse_episode(f)]
        owners = [names.file_show_name(f) for f in eps]
        named = [o for o in owners if names.norm(o)]
        if named:
            other = [o for o in named if not same_show(o, t)]
            if len(other) * 2 > len(named):
                return "its episodes are '%s', not '%s'" % (max(set(other), key=other.count), t)
            return None  # "Doctor Who/Christmas Specials/Doctor.Who.S00E01.mkv": still Doctor Who
        if (seasons or eps) and not category_like(st):
            return "'%s' has its own %s" % (st, "seasons" if seasons else "episodes")
        if depth == 0:  # "Star Trek/Spin-offs/Star Trek Voyager/...": a folder of other shows
            inner = [d for d in dirs if _could_be_show(d) and self.other_show(vfs.join(p, d), t, 1)]
            if inner:
                return "it holds other shows (%s)" % ", ".join(sorted(inner)[:3])
        return None

    def show_title(self, d):
        """(title, year) of a show folder. 'Disc 1' / '001-100' / 'Batch' folders take the name from their
        episodes ('Friends.S01E01.mkv' -> Friends); '... 001-100' / 'Box Set' endings come off."""
        name = vfs.basename(d)
        t, y = names.parse_show_name(name)
        st = names.season_title(name)
        if st:  # "Peppa Pig Series 2" -> "Peppa Pig"
            t = st
        t = names.clean_show_title(names.clean_part_title(t))
        if names.part_like(name) or not names.norm(t):
            res = self.listdir(d)
            owners = []
            if res:
                owners = [names.file_show_name(f) for f in res[1] if names.is_video(f)]
                if not any(names.norm(o) for o in owners):
                    for sd in res[0]:
                        if names.season_from_dir(sd) is not None:
                            r2 = self.listdir(vfs.join(d, sd))
                            owners = [names.file_show_name(f) for f in (r2[1] if r2 else []) if names.is_video(f)]
                            if owners:
                                break
            owners = [names.clean_part_title(o) for o in owners if names.norm(o)]
            if owners:
                best = max(set(owners), key=owners.count)
                return best, y
        return t, y

    # -- TV: is this folder a show, or a category holding shows?
    def rule(self, path):
        """Your folder rule for this folder: 'one' (one show / film), 'many' (separate ones), 'skip', or None."""
        return self.rules.get(npath(path))

    def classify(self, d, depth=0):
        k = ("cls", npath(d))
        if k in self.cache:
            return self.cache[k]
        kind, why = self._classify(d, depth)
        self.cache[k] = kind
        self.reasons[npath(d)] = why
        return kind

    def why(self, d):
        return self.reasons.get(npath(d), "")

    def _classify(self, d, depth):
        r = self.rule(d)
        if r in ("one", "many", "skip"):
            return {"one": "show", "many": "category", "skip": "skip"}[r], "your folder rule (%s)" % {
                "one": "one show", "many": "separate shows", "skip": "skip it"}[r]
        res = self.listdir(d)
        if res is None:
            return "unreadable", "couldn't read the folder"
        dirs, files = res
        if names.disc_play_path(d, dirs, files):
            return "disc", "a DVD / Blu-ray rip"
        name = vfs.basename(d)
        t, y = self.show_title(d)
        coll = names.is_collection_name(name, coll_words())
        eps = [f for f in files if names.is_video(f) and not names.is_sample(f) and not names.is_extra_file(f)]
        subs = [x for x in dirs if not _hidden(x)]
        # a folder per episode: "DrWho2005, 2005-03-26, S01E01, Rose (tt0436992)" - all one show
        ep_dirs = [x for x in subs if (lambda p: p is not None and p["season"] is not None)(names.parse_episode(x))]
        if len(ep_dirs) >= 3 and len(ep_dirs) * 2 >= len(subs):
            owners = set(names.norm(names.clean_part_title(names.parse_show_name(x)[0])) for x in ep_dirs)
            ids = set(filter(None, (names.imdb_hint(x) for x in ep_dirs)))
            if len(owners) == 1 or len(ids) == 1:
                return "show", "%d of its sub-folders are single episodes (%s)" % (len(ep_dirs), sorted(ep_dirs)[0][:60])
        # season folders: "Season 1" / "Breaking.Bad.S01" belong to this show; "Bluey S01" in "Kids" doesn't
        strict, titled = [], {}
        for x in subs:
            st = names.season_title(x)
            if st is None:
                continue
            if not names.norm(st) or same_title(st, t):
                strict.append(x)
            else:
                titled.setdefault(names.norm(names.clean_part_title(st)), x)
        if titled and len(titled) >= len(strict) and (len(titled) >= 2 or not strict):
            return "category", "its sub-folders are seasons of other shows (%s)" % ", ".join(
                sorted(titled.values())[:4])
        if eps:
            # "01 - Dance Mode.mkv", "103 - Deadly Maneuvers.avi": an episode number and title, no show name -
            # they belong to this folder's show
            # a scene group's shortened name ("ftp-peppafe01", "excess-xvid-chuggington") says nothing either
            owners = ["" if names.abbreviated(f) or names.shortened(names.stem(f), t) else names.file_show_name(f)
                      for f in eps]
            named = set(names.norm(o) for o in owners if names.norm(o))
            numbered = sum(1 for o in owners if not names.norm(o))
            if coll and len(named) > 1 and not strict and numbered * 2 < len(eps):
                return "category", "episodes of %d different shows in a collection folder" % len(named)
            mine = sum(1 for o in owners if not names.norm(o) or same_title(o, t))
            if mine * 2 >= len(owners) or strict:
                return "show", "%d episode file%s of '%s' in it" % (len(eps), "" if len(eps) == 1 else "s", t)
            return "category", "episodes of different shows (%s)" % ", ".join(sorted(named)[:4])
        if strict:
            return "show", "season folders (%s)" % ", ".join(sorted(strict)[:4])
        if not subs:
            return "empty", "nothing in it"
        if depth >= 3:
            return "show", "deep inside other folders"
        cat_votes = show_votes = 0
        keys = set()
        mine_key = "%s|%s" % (names.norm(t), y or "")
        for x in sorted(subs)[:12]:
            p = vfs.join(d, x)
            c = self.classify(p, depth + 1)
            if c == "show":
                st, sy = self.show_title(p)
                keys.add("%s|%s" % (names.norm(st), sy or ""))
                # "Frieren/Frieren Batch 1-12", "Friends/Disc 1": a slice of this same show
                if same_title(st, t) and (not coll or names.norm(st) == names.norm(t)) and (not sy or not y or sy == y):
                    show_votes += 1
                else:
                    cat_votes += 1
            elif c == "category":
                cat_votes += 1
            elif c == "disc":
                dt = names.parse_show_name(names.clean_disc_label(x))[0]
                if names.generic_disc_name(x) or same_title(dt, t):
                    show_votes += 1  # "Planet Earth/Disc 1", "Friends Box Set/FRIENDS_D3"
                else:
                    cat_votes += 1
        distinct = set(k for k in keys if k != mine_key)
        if len(distinct) >= 2 and (len(set(k.split("|")[0] for k in distinct)) >= 2 or
                                   len(set(k.split("|")[1] for k in distinct)) >= 2):
            return "category", "holds %d different shows (%s)" % (len(distinct), ", ".join(
                sorted(k.split("|")[0] + (" (%s)" % k.split("|")[1] if k.split("|")[1] else "") for k in distinct)[:4]))
        if (y or names.tmdb_id_hint(name)) and not coll:
            return "show", "has a year in its name"
        if coll and len(keys) == 1 and names.norm(t) in [k.split("|")[0] for k in keys]:
            return "show", "a pack of one show in parts"  # "Naruto Shippuden Complete Pack" / "001-100", "101-200"
        if cat_votes > show_votes:
            return "category", "its sub-folders look like their own shows (%d of %d)" % (cat_votes, cat_votes + show_votes)
        return "show", "its sub-folders look like parts of one show"


TRUE_EXTRAS = ("extras", "featurettes", "behind the scenes", "deleted scenes", "interviews", "bonus", "bonus features",
               "special features", "trailers", "sample", "samples")
RULE_WORDS = {"one": "its own show", "many": "separate shows", "skip": "left out", "part": "part of the show above"}
SHOW_PARTS = ("specials", "special", "movies", "films", "ova", "ovas", "oad", "oads", "extras", "bonus", "christmas specials",
              "minisodes", "webisodes", "shorts", "unaired", "pilot", "pilots")


def _could_be_show(x):
    """A sub-folder of a show that might be a show of its own (not 'Season 2', 'Disc 1', 'Specials', 'Extras')."""
    n = (x or "").strip().lower()
    return not (names.system_dir(x) or names.skip_dir(x) or n in names.DISC_DIRS or _hidden(x) or n in SHOW_PARTS or
                names.season_from_dir(x) is not None or names.part_like(x) or names.parse_episode(x) is not None)


def same_show(a, b):
    """Stricter than same_title: 'Star Trek The Next Generation' is NOT 'Star Trek'. Same words (give or take
    'The', a year, US/UK), or one is short for the other ('BB' / 'Breaking Bad')."""
    def k(s):
        s = names.norm(re.sub(r"(?i)\b(?:19|20)\d{2}\b|\b(?:us|uk|usa|the|complete|series|remastered|hd)\b", " ", s or ""))
        return re.sub(r"\s+", " ", s).strip()
    ka, kb = k(a), k(b)
    if not ka or not kb:
        return names.norm(a) == names.norm(b)
    def abbr(x, y):  # "BB" / "TNG" for a longer name - one short word, not "Star Trek" for "Star Trek Voyager"
        return len(x.split()) == 1 and len(x.strip()) <= 8 and names.shortened(x, y)
    return ka == kb or ka.replace(" ", "") == kb.replace(" ", "") or abbr(a, b) or abbr(b, a)


def same_title(a, b):
    """Do two titles look like the same thing? ('Its Always Sunny' ~ 'Its Always Sunny in Philadelphia')"""
    na, nb = names.norm(a), names.norm(b)
    if not na or not nb:
        return False
    if na == nb or na.startswith(nb + " ") or nb.startswith(na + " "):
        return True
    wa, wb = set(na.split()), set(nb.split())
    short = min(len(wa), len(wb))
    both = len(wa & wb)
    return short >= 2 and both >= 2 and both * 2 >= short


_GENERIC = re.compile(r"(?i)^(?:movie|film|video|feature|main(?: feature)?|title[\s_]?t?\d+|t\d+|\d{1,3}|"
                      r"vts[\s_]\d+.*|[a-f0-9]{8,}|untitled|bdmv|index)$")


def _generic(t):
    return not names.norm(t) or bool(_GENERIC.match((t or "").strip()))


CATEGORY_WORDS = set("""tv shows show series seres serie kids kid children childrens family families comedy comady comedies
action sifi scifi sci fi fantasy anime animation animated cartoon cartoons documentary documentry documentaries factual
drama dramas horror thriller christmas xmas specials special marvel dc disney films film movies movie new old classic
classics british uk us usa misc other others collection collections box sets set and the a of my best all complete
backup back up bkup serv server nas media video videos stuff to watch watched archive hd sd 4k uhd adult adults teen
teens netflix bbc itv channel crime war western westerns mystery sport sports music musicals reality game games""".split())


def category_like(name):
    """'FAMILY', 'Anime , Animation', 'Si-Fi - Action - Fantasy', 'Marvel TV': a folder of things, not a title."""
    words = names.norm(names.tidy(name or "")).split()
    return not words or all(x in CATEGORY_WORDS or x.isdigit() for x in words)


# ---------------------------------------------------------------- collecting
def collect_movies(root, w, only=None):
    out = []
    words = coll_words()
    for top in (only or [root]):
        for folder, dirs_, files in w.walk(top):
            dp = names.disc_play_path(folder, dirs_, files)
            film_dir = folder
            if not _same(folder, root) and re.match(r"(?i)^(?:cd|disc|disk|dvd|part|pt)[\s._-]*\d{1,2}$",
                                                    vfs.basename(folder)) and not _same(vfs.parent(folder), root):
                film_dir = vfs.parent(folder)  # "Jurassic.Park.1993.DVDRip/CD1/ewdp-jurassic a.avi": the film's folder
            if dp and not _same(folder, root):
                f = _movie_disc(dp, folder, root, w, words)
                if f is not None:
                    det("   [disc]     %s  - %s rip -> '%s'%s" % (rel(folder, root), names.disc_kind(dp), f.title,
                                                                " (%s)" % f.year if f.year else ""))
                    out.append(f)
                continue
            vids = [f for f in files if names.is_video(f) and not names.is_sample(f) and not names.is_extra_file(f)]
            if not vids:
                continue
            at_root = _same(folder, root)
            fname = vfs.basename(film_dir)
            is_coll = not at_root and names.is_collection_name(fname, words)
            # "01 Harry Potter and the Philosopher's Stone.mkv" -> title without the order number
            so = names.strip_orders(vids, is_coll)
            sy = names.strip_years([f for f in vids if f not in so])  # "1979 The Muppet Movie", "1981 ..."
            parsed = []
            for f in vids:
                if f in so:
                    t, y = names.parse_movie(so[f][1])
                    parsed.append((f, t, y, so[f][0], names.parse_movie(f)[0]))
                elif f in sy:
                    t, y = names.parse_movie(sy[f][1])
                    parsed.append((f, t, y or sy[f][0], None, names.parse_movie(f)[0]))
                else:
                    t, y = names.parse_movie(f)
                    parsed.append((f, t, y, None, None))
            if len(parsed) >= 2:  # "Jerry Lewis - Cinderfella", "Jerry Lewis - The Bellboy": drop the shared part
                ts = names.strip_common_segments([p[1] for p in parsed])
                parsed = [(f, ts[i], y, o, a if ts[i] == t else (a or t)) for i, (f, t, y, o, a) in enumerate(parsed)]
            use_folder, ft, fy, hint_f, ford, falt = False, None, None, None, None, None
            if not at_root:
                hint_f = names.tmdb_id_hint(fname)
                # numbered film folders: "Pixar Pack/1 Toy Story/", "2 Toy Story 2/"
                par = vfs.parent(film_dir)
                sib = w.listdir(par) if not _same(film_dir, root) else None
                sibs = [x for x in (sib[0] if sib else [fname]) if not names.system_dir(x)]
                fo = names.strip_orders(sibs, names.is_collection_name(vfs.basename(par), words) and
                                        not _same(par, root) or False)
                if fname in fo:
                    ford = fo[fname][0]
                    ft, fy = names.parse_movie(fo[fname][1])
                    falt = names.parse_movie(fname)[0]
                else:
                    ft, fy = names.parse_movie(fname)
                real = [(t, y) for _f, t, y, _o, _a in parsed if not _generic(t)]
                one_title = len(set(names.norm(t) for t, _y in real)) <= 1  # versions / parts of one film
                why = "different films loose in a folder"
                r = w.rule(folder)
                if r == "one":
                    use_folder, why = True, "your folder rule (one film)"
                elif r == "many":
                    why = "your folder rule (separate films)"
                elif is_coll and not (one_title and names.single_year(fname)):
                    why = "a collection folder"  # "Harry Potter Collection" holds several films - never one itself
                elif ft and len(vids) <= 3 and not category_like(ft) and not _generic(ft) and (
                        all(names.abbreviated(f) or names.shortened(t_, ft) for f, t_, _y, _o, _a in parsed)):
                    # "Knocked.Up.UNRATED.DVDRip.XviD-DiAMOND/dmd-knockedup.avi", "Alice In Wonderland (2010)/
                    # Alc n Wndld.avi", "The Longest Yard/tly.avi": a shortened file name - the folder names the film
                    use_folder, why = True, "the file is only called '%s' - the folder says which film" % parsed[0][1]
                elif one_title and ft:
                    if not real or hint_f:
                        use_folder, why = True, "the file name says nothing, so the folder name is used"
                    elif ford is not None and len(vids) <= 4:
                        use_folder, why = True, "a numbered film folder"  # "Pixar Pack/2 Toy Story 2/ts2.mkv"
                    else:
                        t, y = real[0]
                        op = names.order_prefix(t)
                        if op:  # "'Carry on Constable' (1960)/04 - Carry On Constable.avi"
                            t = op[1]
                        if names.norm(t) == names.norm(ft):
                            use_folder, why = True, "file and folder names match"
                        elif fy and (not y or y == fy) and same_title(t, ft):
                            use_folder, why = True, "file and folder names match"
                        elif fy and not y:
                            use_folder, why = True, "the folder has a year"  # "Die Hard (1988)/dh-bluray.mkv"
                        else:
                            why = "the file is called '%s', not '%s'" % (t, ft)
                # anything else - "Action/Die.Hard.1988.mkv", "Kids/" full of films - is a category folder
                if use_folder:
                    det("   [film]     %s  - %s -> '%s'%s" % (rel(folder, root), why, ft, " (%s)" % fy if fy else ""))
                else:
                    det("   [films]    %s  - %s: %s" % (rel(folder, root), why, ", ".join(
                        "'%s'%s" % (t_, " (%s)" % y_ if y_ else "") for _f, t_, y_, _o, _a in parsed[:5]) +
                        (" +%d more" % (len(parsed) - 5) if len(parsed) > 5 else "")))
            else:
                det("   [loose]    %d film file%s straight in the folder" % (len(vids), "" if len(vids) == 1 else "s"))
            if use_folder:
                w.titles.add(npath(folder))  # don't walk this film's "Extras" / "Featurettes"
                w.titles.add(npath(film_dir))
            container = vfs.parent(film_dir) if use_folder else folder
            cat = "" if _same(container, root) else rel(container, root)
            coll = _coll_of(cat, words)
            for f, t, y, o, alt in parsed:
                p = vfs.join(folder, f)
                if use_folder:
                    out.append(Found(p, "movie:" + film_dir, ft, fy or y, film_dir, hint_f or names.tmdb_id_hint(f),
                                     root=root, cat=cat, coll=coll, ord_=ford, alt=falt, stripped=ford is not None))
                else:
                    out.append(Found(p, "movie:%s|%s|%s" % (folder, names.norm(t), y or ""), t, y, folder,
                                     names.tmdb_id_hint(f), root=root, cat=cat, coll=coll, ord_=o, alt=alt,
                                     stripped=o is not None))
    return out


def _movie_disc(dp, folder, root, w, words):
    """A DVD / Blu-ray rip in the films: 'The Matrix (1999)/VIDEO_TS', 'THE_MATRIX_SE/VIDEO_TS',
    'Lord of the Rings/Disc 2/VIDEO_TS' (named from the folder above), '01 Harry Potter.../VIDEO_TS'."""
    name = vfs.basename(folder)
    title_folder = folder
    if names.generic_disc_name(name) and not _same(vfs.parent(folder), root):
        title_folder = vfs.parent(folder)
    tname = vfs.basename(title_folder)
    par = vfs.parent(title_folder)
    ordn, alt = None, None
    if not _same(title_folder, root):
        sib = w.listdir(par)
        sibs = [x for x in (sib[0] if sib else [tname]) if not names.system_dir(x)]
        so = names.strip_orders(sibs, names.is_collection_name(vfs.basename(par), words) and not _same(par, root))
        if tname in so:
            ordn, alt = so[tname][0], names.parse_movie(names.clean_disc_label(tname))[0]
            tname = so[tname][1]
    t, y = names.parse_movie(names.clean_disc_label(tname))
    w.titles.add(npath(title_folder))
    cat = "" if _same(par, root) else rel(par, root)
    disc = names.disc_number(name) or (names.disc_number(tname) if title_folder == folder else None)
    label = "%s%s (%s)" % (names.clean_disc_label(vfs.basename(title_folder)), " - Disc %d" % disc if disc else "",
                           names.disc_kind(dp))
    return _disc_found(Found(dp, "movie:" + title_folder, t, y, title_folder, names.tmdb_id_hint(tname), root=root,
                             cat=cat, coll=_coll_of(cat, words), ord_=ordn, alt=alt, stripped=ordn is not None),
                       label)


def disc_size(play_path):
    """A disc rip's size: its .VOB / .m2ts files added up."""
    base = vfs.parent(play_path)
    if play_path.lower().endswith("index.bdmv"):
        base = vfs.join(base, "STREAM")
    res = vfs.listdir(base)
    if not res:
        return 0
    return sum(vfs.stat(vfs.join(base, f))[0] for f in res[1] if names.ext(f) in (".vob", ".m2ts"))


def _episode_info(fname, season_dir):
    ep = names.parse_episode(fname)
    if ep is None:
        p = names.episode_prefix(fname)  # "Season 1/01 - Pilot.mkv", "Knight Rider/103 - Deadly Maneuvers.avi"
        if p:
            se, n, end = p
            if season_dir is not None:
                if se is None or se == season_dir:
                    return season_dir, n, end, False
                return season_dir, se * 100 + n, None, True  # "Season 2/112 - ...": an absolute number
            if se is not None:
                return se, n, end, False
            return None, n, end, True  # "07 - Merry Christmas.avi" loose in the show: TMDB's season sizes place it
        m = re.search(r"(?i)(?:^|[\s._-])specials?[\s._-]*(\d{1,3})(?:\D|$)", names.stem(fname))
        if m:  # "The Raccoons - Special 1 - The Christmas Raccoons.avi"
            return 0, int(m.group(1)), None, False
        return season_dir if season_dir is not None else 0, None, None, False
    if ep["season"] is not None:
        return ep["season"], ep["episode"], ep["ep_end"], False
    if season_dir is not None:
        n = ep["episode"]
        if season_dir > 0 and n >= 100 and n // 100 == season_dir and 0 < n % 100:
            return season_dir, n % 100, None, False  # "Season 2/201.mkv" -> S02E01
        # "Season 2/05.mkv" -> S02E05 (checked against TMDB later in case it's really absolute numbering)
        return season_dir, n, ep["ep_end"], True
    return None, ep["episode"], ep["ep_end"], True


def _show_files(show, root, w, out, prune=None, only_files=None, split=True, parent_title=None):
    """One show's files. Folders inside it that are shows of their own are left out of it and read on their own
    (split=False: the caller deals with the rest of the folder)."""
    name = vfs.basename(show)
    t0, y = names.parse_show_name(name)
    t, y2 = w.show_title(show)  # "Friends Box Set" -> "Friends", "Naruto 001-100" -> "Naruto"
    y = y or y2
    hint = names.tmdb_id_hint(name) or names.imdb_hint(name)
    if not hint:  # "DrWho2005, 2005-03-26, S01E01, Rose (tt0436992)" sub-folders: the show's IMDb id
        res = w.listdir(show)
        ids = [names.imdb_hint(x) for x in (res[0] if res else []) if names.parse_episode(x)]
        ids = [i for i in ids if i]
        if ids and len(set(ids)) == 1 and len(ids) >= 2:
            hint = ids[0]
    cat = "" if _same(vfs.parent(show), root) else rel(vfs.parent(show), root)
    alts = [t0] if t0 != t else []
    both = _with_parent(t, parent_title)
    if both:  # a show inside a show's folder: "Stargate/Atlantis" is looked up as "Stargate Atlantis" first
        alts.insert(0, (both, True, True))
    par = vfs.parent(show)
    if not _same(par, root) and under(par, root):
        # "Mr Bean/1990 - Live Action and Movies Complete": if its own name finds nothing, the folder above is
        # tried - only when TMDB's title matches it exactly, and never a category ("FAMILY", "Kids", "Marvel TV")
        pt = w.show_title(par)[0]
        if names.norm(pt) and not category_like(pt) and names.norm(pt) not in (names.norm(t), names.norm(t0)):
            alts.append((pt, True))
    apart = w.split_outs(show, t) if split else []
    pr = set(prune or ()) | set(npath(p) for p, _w in apart)
    n0 = len(out)
    _show_walk(show, root, w, out, t, y, hint, cat, alts or None, pr, only_files)
    mine = out[n0:]
    seasons = sorted(set(f.season for f in mine if f.season is not None and f.episode is not None))
    nonum = [vfs.basename(f.path) for f in mine if f.episode is None and not f.disc]
    det("              -> one show '%s'%s: %d file%s%s%s%s" % (
        t, " (%s)" % y if y else "", len(mine), "" if len(mine) == 1 else "s",
        ", seasons %s" % ", ".join(str(s) for s in seasons) if seasons else "",
        ", %d DVD/Blu-ray disc%s" % (sum(1 for f in mine if f.disc), "" if sum(1 for f in mine if f.disc) == 1 else "s")
        if any(f.disc for f in mine) else "",
        "; no episode number: %s" % ", ".join(nonum[:6]) + (" +%d more" % (len(nonum) - 6) if len(nonum) > 6 else "")
        if nonum else ""))
    for p, why in apart:
        c = w.classify(p)
        det("   [own show] %s  - %s" % (rel(p, root), why))
        if c == "category":
            _container(p, root, w, out, 1, parent_title=t)
        elif c in ("show", "disc", "empty"):
            _show_files(p, root, w, out, parent_title=t)


def _with_parent(t, parent):
    """'Voyager' inside 'Star Trek' -> 'Star Trek Voyager'; 'Star Trek Voyager' stays as it is."""
    if not parent or not names.norm(t) or names.norm(t).startswith(names.norm(parent)) or category_like(parent):
        return None
    return "%s %s" % (parent, t)


def _show_walk(show, root, w, out, t, y, hint, cat, alts, prune=None, only_files=None):
    own = names.season_from_dir(vfs.basename(show)) if names.season_title(vfs.basename(show)) else None
    for folder, dirs, files in w.walk(show, inside_title=True, prune=prune):
        # "Bluey S02/01 - Dance Mode.mkv": the show folder's own name says which season
        sdir = own if _same(folder, show) else names.season_from_dir(vfs.basename(folder))
        # "S01E01, Rose (tt0436992)/video.avi": an episode's own folder says which episode
        fep = None if _same(folder, show) else names.parse_episode(vfs.basename(folder))
        if fep is not None and fep["season"] is None:
            fep = None
        dp = names.disc_play_path(folder, dirs, files)
        if dp:  # a DVD / Blu-ray of this show: season from the folder names, no episode numbers
            out.append(_tv_disc(dp, folder, show, root, "show:" + show, t, y, hint, cat))
            continue
        for f in files:
            if not names.is_video(f) or names.is_sample(f) or names.is_extra_file(f):
                continue
            if only_files is not None and _same(folder, show) and f not in only_files:
                continue
            se, ep, end, ab = _episode_info(f, sdir)
            if fep is not None and (ep is None or (ab and se is None)):
                se, ep, end, ab = fep["season"], fep["episode"], fep["ep_end"], False
            out.append(Found(vfs.join(folder, f), "show:" + show, t, y, show, hint, se, ep, end, ab, root, cat,
                             alt=alts, stripped=bool(alts and any(not isinstance(a, tuple) for a in alts))))


def _tv_disc(dp, folder, top, root, mkey, t, y, hint, cat):
    chain = [x for x in rel(folder, top).split("/") if x] if not _same(folder, top) else []
    chain = [vfs.basename(top)] + chain
    season = None
    for x in reversed(chain):
        season = names.season_from_dir(names.clean_disc_label(x)) or names.season_from_dir(x)
        if season is not None:
            break
    disc = names.disc_number(vfs.basename(folder))
    if season is None:
        season = 1
    label = "Season %d%s (%s)" % (season, " Disc %d" % disc if disc else "", names.disc_kind(dp))
    return _disc_found(Found(dp, mkey, t, y, top, hint, season, None, None, False, root, cat, ord_=disc), label)


def _container(d, root, w, out, depth=0, parent_title=None):
    """A section folder or a category folder: loose episodes + shows (+ deeper categories) inside.
    parent_title: it's inside a show's folder ('Star Trek/Spin-offs') - its shows are looked up with that name too."""
    res = w.listdir(d)
    if res is None:
        return
    dirs, files = res
    cat = "" if _same(d, root) else rel(d, root)
    taken_dirs, taken_files = set(), set()
    if w.rule(d) == "many" and not _same(d, root):
        # "split it up": the folder's own "Season 1".."Season 3" and its own episodes stay ONE show (it);
        # every other sub-folder is read on its own
        td = w.show_title(d)[0]
        seasons = [x for x in dirs if (lambda st: st is not None and (not names.norm(st) or same_show(st, td)))(
            names.season_title(x))]
        mine = [f for f in files if names.is_video(f) and not names.is_sample(f) and not names.is_extra_file(f) and
                (not names.norm(names.file_show_name(f)) or same_show(names.file_show_name(f), td))]
        if seasons or mine:
            det("   %s[show]     %s  - its own seasons / episodes (%s)" % ("  " * depth, rel(d, root) or ".", ", ".join(
                (sorted(seasons) + mine)[:3])))
            _show_files(d, root, w, out, prune=set(npath(vfs.join(d, x)) for x in dirs if x not in seasons),
                        only_files=set(mine), split=False)
            taken_dirs, taken_files = set(seasons), set(mine)
    for f in files:
        if f in taken_files:
            continue
        if names.is_video(f) and not names.is_sample(f) and not names.is_extra_file(f):
            t, y = names.file_show_name(f), names.parse_show_name(f)[1]
            if not names.norm(t):  # "103 - Deadly Maneuvers.avi" loose in a folder: the folder's show
                t, y = w.show_title(d) if not _same(d, root) else (vfs.basename(d), None)
            se, ep, end, ab = _episode_info(f, None)
            out.append(Found(vfs.join(d, f), "show:%s|%s" % (d, names.norm(t)), t, y, d, None, se, ep, end, ab,
                             root, cat))
    for x in sorted(dirs, key=lambda s: s.lower()):
        if names.system_dir(x) or x.strip().lower() in TRUE_EXTRAS or x in taken_dirs:  # "Other" can be a category
            continue
        p = vfs.join(d, x)
        c = w.classify(p)
        det("   %s%-10s %s  - %s" % ("  " * depth, "[%s]" % {"category": "category", "show": "show", "disc": "disc",
                                                             "skip": "skip", "empty": "empty",
                                                             "unreadable": "can't read"}.get(c, c),
                                    rel(p, root), w.why(p)))
        if c == "category" and depth < 4:
            _container(p, root, w, out, depth + 1, parent_title)
        elif c == "show":
            _show_files(p, root, w, out, parent_title=parent_title)
        elif c == "disc":  # "FRIENDS_S1_D2/VIDEO_TS" loose in a category: named from the folder
            r2 = w.listdir(p)
            dp = names.disc_play_path(p, r2[0], r2[1]) if r2 else None
            if dp:
                t = names.clean_part_title(names.parse_show_name(names.clean_disc_label(x))[0])
                out.append(_tv_disc(dp, p, p, root, "show:%s|%s" % (d, names.norm(t)), t, None, None, cat))


def collect_shows(root, w, only=None):
    out = []
    for p in (only or [root]):
        if _same(p, root):
            _container(p, root, w, out)
            continue
        c = w.classify(p)
        det("   %-10s %s  - %s" % ("[%s]" % c, rel(p, root), w.why(p)))
        if c == "category":
            _container(p, root, w, out)
        elif c in ("show", "disc", "empty"):
            _show_files(p, root, w, out)
    return out


# ---------------------------------------------------------------- matching
def qkey(title, year):
    return "%s|%s" % (names.norm(title), year or "")


def resolve(mkey, kind, title, year, hint, alt=None, max_season=None):
    """-> tmdb id or 0 (looked up, nothing found) or None (couldn't look it up now).
    alt: the name as it was before an order number / 'Box Set' was taken off - tried if the clean one finds nothing
    (a list: later ones - like the folder above - only count if TMDB's title really matches).
    max_season: the highest season on the NAS, to tell same-name shows apart."""
    m = db.match_get(mkey)
    if m is not None:
        return m["tmdb"] or 0
    if not tmdb.have_key():
        return None
    alts = [a for a in (alt if isinstance(alt, (list, tuple)) else [alt]) if a]

    def find(t, y, exact=False):
        if kind == "movie":
            return tmdb.search_movie(t, y, exact=exact)
        return tmdb.search_tv(t, y, exact=exact, max_season=max_season)
    try:
        if hint and isinstance(hint, str) and hint.startswith("tt"):
            d = tmdb.find_imdb(hint)
            hits = (d.get("movie_results") if kind == "movie" else d.get("tv_results")) or []
            tid = hits[0]["id"] if hits else None
            if tid:
                det("   ('%s' found by its IMDb id %s)" % (title, hint))
            hint = None if not tid else hint
        else:
            tid = None
        if hint:
            tid = tid or hint
        else:
            tid = None
            tried = set()
            for a in alts:  # (name, True, True): tried FIRST, and only an exact title match counts
                if isinstance(a, tuple) and len(a) > 2 and a[2] and not tid:
                    tried.add(names.norm(a[0]))
                    tid = find(a[0], year, exact=True)
                    if tid:
                        det("   ('%s' found as '%s')" % (title, a[0]))
            if not tid and title:
                tid = find(title, year)
            tried.add(names.norm(title))
            for a in alts:
                if tid:
                    break
                a, ex = (a[0], a[1]) if isinstance(a, tuple) else (a, False)  # (name, True): only an exact match
                if names.norm(a) not in tried:
                    tried.add(names.norm(a))
                    tid = find(a, year, exact=ex)
            # other ways to read the name: without '02 ', '1979 ', ' - Fantasy', 'Jerry Lewis - '
            for t2, y2 in names.fallback_titles(title, year) if not tid and title else []:
                if names.norm(t2) in tried:
                    continue
                tried.add(names.norm(t2))
                tid = find(t2, y2, exact=True)
                if tid:
                    det("   ('%s' found nothing - '%s'%s did)" % (title, t2, " (%s)" % y2 if y2 else ""))
                    break
    except tmdb.TMDBError as e:
        tmdb.log_err(e)
        return None
    db.match_set(mkey, tid or 0, kind, q=qkey(title, year))
    return tid or 0


def get_item(section, kind, tid, title, year, folder):
    if tid:
        ukey = "%s|%s|%s" % (section, kind, tid)
    else:
        ukey = "%s|%s|u:%s:%s" % (section, kind, names.norm(title), year or "")
    r = db.one("SELECT id, folder FROM items WHERE ukey=?", (ukey,))
    if r:
        if not r["folder"] and folder:
            db.run("UPDATE items SET folder=? WHERE id=?", (folder, r["id"]), commit=False)
        return r["id"]
    d = None
    if tid:
        try:
            d = tmdb.details(kind, tid)
        except tmdb.TMDBError as e:
            tmdb.log_err(e)
    now = time.time()
    if d:
        cols = ["ukey", "section", "kind", "folder", "added", "updated", "matched"] + list(d.keys())
        vals = [ukey, section, kind, folder, now, now, 1] + list(d.values())
        cols.append("sorttitle")
        vals.append(_sort(d.get("title")))
    else:
        cols = ["ukey", "section", "kind", "tmdb", "title", "sorttitle", "year", "folder", "added", "updated",
                "matched", "seasons"]
        vals = [ukey, section, kind, tid or None, title or "Unknown", _sort(title), year, folder, now, now, 0, "[]"]
    cur = db.run("INSERT INTO items(%s) VALUES(%s)" % (",".join(cols), ",".join("?" * len(cols))), vals, commit=False)
    return cur.lastrowid


def _sort(t):
    t = (t or "").strip()
    low = t.lower()
    for a in ("the ", "a ", "an "):
        if low.startswith(a):
            return t[len(a):]
    return t


def _map_absolute(item_row, f):
    """Turn anime absolute numbering into season/episode using TMDB's season sizes."""
    if not f.absolute or f.episode is None:
        return f.season, f.episode, f.ep_end
    seasons = db.seasons_of(item_row) if item_row else []
    if not seasons:
        return (f.season if f.season is not None else 1), f.episode, f.ep_end
    if f.season is not None:
        cnt = dict((s["n"], s.get("count") or 0) for s in seasons)
        if f.season == 0 or not cnt.get(f.season) or f.episode <= cnt[f.season]:
            return f.season, f.episode, f.ep_end
    se, ep = tmdb.absolute_to_se(seasons, f.episode)
    end = None
    if f.ep_end:
        end = ep + (f.ep_end - f.episode)
    return se, ep, end


# ---------------------------------------------------------------- scanning
LOCK = threading.RLock()


def _root_of(path, roots):
    best = None
    for r in roots:
        if under(path, r) and (best is None or len(r) > len(best)):
            best = r
    return best


def scan_section(sec, progress=None, only=None):
    """progress(fraction 0-1, heading, where). only: just these folders (a title folder, a category or a whole
    NAS folder). -> dict(new, gone, error, added_titles, locations=[per-folder report])."""
    with LOCK:
        _detail_start()
        try:
            return _scan_section(sec, progress, only)
        finally:
            _detail_end("Quick scan: %s" % ", ".join(only or []) if only else "Scan: %s" % sec, overwrite=False)


def _scan_section(sec, progress=None, only=None):
    kind = SECTION_KIND[sec]
    locs = locations(sec)
    out = {"section": sec, "new": 0, "gone": 0, "error": None, "added_titles": [], "locations": []}
    if not locs:
        return out
    def P(frac, head, where):
        if progress:
            try:
                progress(frac, head, where)
            except Exception as e:  # a progress display problem must never stop a scan
                log("Scan progress display: %s" % e, "debug")
    label_s = SECTION_LABEL[sec]
    w = Walker()
    found, reached, reps = [], [], {}
    todo = []
    for loc in locs:
        root = npath(loc["path"])
        targets = None
        if only is not None:
            targets = [p for p in only if under(p, root) and _root_of(p, [npath(x["path"]) for x in locs]) == root]
            if not targets:
                continue
        todo.append((loc, root, targets))
    for i, (loc, root, targets) in enumerate(todo):
        label = loc_label(loc)
        head = "%s - folder %d of %d" % (label_s, i + 1, len(todo)) if len(todo) > 1 else label_s
        rep = {"path": hide_creds(root), "label": label, "status": "ok", "found": 0, "new": 0, "gone": 0,
               "folders": 0, "secs": 0.0, "new_titles": [], "unreadable": [], "partial": only is not None}
        reps[root] = rep
        det("")
        det("== %s: %s  (%s)%s" % (label_s, label, hide_creds(root), "  - just: %s" % ", ".join(
            rel(x, root) or "(all of it)" for x in targets) if targets else ""))
        out["locations"].append(rep)
        t0, f0, fails0 = time.time(), w.folders, len(w.failed)
        base, span = 0.6 * i / len(todo), 0.6 / len(todo)

        def tick(path, n, base=base, span=span, head=head, label=label, root=root, f0=f0):
            k = n - f0
            where = rel(path, root)
            P(base + span * min(0.95, k / (k + 60.0)), head,
              "%s > %s" % (label, where.replace("/", " > ")) if where else label)
        w.tick = tick
        if w.listdir(root) is None:
            rep["status"] = "unreachable"
            det("   COULDN'T REACH IT - skipped, nothing removed from the library")
            log("Scan %s: can't reach %s (%s) - skipped, nothing removed from the library" % (
                sec, label, hide_creds(root)), "warn")
            continue
        reached.append(root)
        part = collect_movies(root, w, targets) if kind == "movie" else collect_shows(root, w, targets)
        shared = any(npath(x["path"]) == root for s2, x in all_locations()
                     if s2 != sec and SECTION_KIND.get(s2) != kind)
        if kind == "movie":
            def episode_named(f):
                p = names.parse_episode(vfs.basename(f.path))
                return bool(p and not p["absolute"])
            tvp = [f for f in part if (tv_like(f.path, root) and (f.disc or shared)) or episode_named(f)]
            if tvp:
                part = [f for f in part if f not in tvp]
                rep["tv_skipped"] = len(tvp)  # TV box-set discs / episodes: those belong in a TV section
                det("   left out of Movies (they're TV): %s" % ", ".join(rel(f.path, root) for f in tvp[:8]) +
                    (" +%d more" % (len(tvp) - 8) if len(tvp) > 8 else ""))
        elif shared:
            n_before = len(part)
            part = [f for f in part if tv_like(f.path, root)]  # the films on this drive are Movies' job
            if n_before != len(part):
                det("   %d film file%s left to Movies (this folder is in both)" % (
                    n_before - len(part), "" if n_before - len(part) == 1 else "s"))
        found.extend(part)
        rep.update(found=len(part), folders=w.folders - f0, secs=round(time.time() - t0, 1),
                   unreadable=[hide_creds(x) for x in w.failed[fails0:]][:10])
        for x in w.failed[fails0:][:20]:
            det("   couldn't read: %s (kept what was there)" % rel(x, root))
        det("   %d video file%s in %d folders (%.1fs)" % (len(part), "" if len(part) == 1 else "s", rep["folders"],
                                                       rep["secs"]))
        log("Scan %s: %s - %d videos in %d folders (%.1fs)%s" % (
            sec, label, len(part), rep["folders"], rep["secs"],
            ", couldn't read %d sub-folders" % len(rep["unreadable"]) if rep["unreadable"] else ""))
    w.tick = None
    if todo and not reached:
        out["error"] = "couldn't reach any %s folder" % label_s
    roots = [npath(x["path"]) for x in locs]

    # what the library already knows about
    if only is None:
        rows = db.q("SELECT path, mkey, item_id, root, cat, coll, ord, added FROM files WHERE section=?", (sec,))
    else:
        rows = []
        for o in only:
            rows += db.q("SELECT path, mkey, item_id, root, cat, coll, ord, added FROM files WHERE section=? AND (path=? OR substr(path, 1, ?) "
                         "IN (?, ?))", (sec, npath(o), len(npath(o)) + 1, npath(o) + "/", npath(o) + "\\"))
    known = dict((r["path"], r) for r in rows)
    found_map = dict((f.path, f) for f in found)
    had_files = set(_root_of(p, roots) for p in known)
    if only is not None:
        had_files = set(roots)  # quick scans aren't a first look at a drive

    # gone: only from folders we could read; a whole NAS folder removed from StashBox takes its files with it
    gone = []
    for p in known:
        if p in found_map:
            continue
        r = _root_of(p, roots)
        if r is None:
            if only is None:
                gone.append(p)
            continue
        if r not in reached or any(under(p, fd) for fd in w.failed):
            continue
        if only is not None and not any(under(p, o) for o in only):
            continue
        gone.append(p)
        reps[r]["gone"] += 1
    for p in gone:
        db.run("DELETE FROM files WHERE path=?", (p,), commit=False)
    out["gone"] = len(gone)
    for p in gone[:40]:
        det("   gone from the NAS: %s" % p)

    # files we know whose drive / category / collection wasn't recorded yet (older libraries) or has changed
    for p, f in found_map.items():
        k = known.get(p)
        if k is not None and (k["root"] != f.root or (k["cat"] or "") != f.cat or (k["coll"] or "") != f.coll or
                              k["ord"] != f.ord):
            db.run("UPDATE files SET root=?, cat=?, coll=?, ord=? WHERE path=?", (f.root, f.cat, f.coll, f.ord, p),
                   commit=False)

    # titles looked up under another name before (e.g. with "01 " still on the front): look them up again
    rematch, seen = set(), set()
    for f in found:
        if f.mkey in seen or f.path not in known or known[f.path]["mkey"] != f.mkey:
            continue
        seen.add(f.mkey)
        m = db.match_get(f.mkey)
        if m is None:  # its lookup was forgotten (you sorted its folder out): look it up again
            if known[f.path]["item_id"] and (db.item(known[f.path]["item_id"]) or {"matched": 0})["matched"]:
                rematch.add(f.mkey)
            continue
        if m["manual"]:
            continue
        if (m["q"] is not None and m["q"] != qkey(f.title, f.year)) or (m["q"] is None and f.stripped):
            rematch.add(f.mkey)
            db.run("DELETE FROM matches WHERE mkey=?", (f.mkey,), commit=False)
    if rematch:
        log("Scan %s: looking %d title%s up again with tidier names" % (sec, len(rematch),
                                                                       "" if len(rematch) == 1 else "s"))

    # unmatched items whose lookup never happened (no key / TMDB down last time) get another go
    retry = set(r["mkey"] for r in db.q(
        "SELECT DISTINCT f.mkey FROM files f JOIN items i ON i.id=f.item_id WHERE f.section=? AND i.matched=0", (sec,))
        if db.match_get(r["mkey"]) is None) if tmdb.have_key() else set()
    new = []
    for p, f in found_map.items():
        k = known.get(p)
        if k is None:
            new.append(f)
        elif k["mkey"] != f.mkey or f.mkey in retry or f.mkey in rematch:  # re-grouped / another lookup
            db.run("DELETE FROM files WHERE path=?", (p,), commit=False)
            new.append(f)
    db.commit()
    if not new:
        db.drop_empty_items()
        return out

    # look up each distinct title once, a few at a time
    groups = {}
    for f in new:
        groups.setdefault(f.mkey, f)
    keys = list(groups)
    results = {}
    total = len(keys)
    done = [0]

    top_season = {}
    for f in new:
        if f.season and f.episode is not None and not f.absolute:
            top_season[f.mkey] = max(top_season.get(f.mkey, 0), f.season)

    def work(k):
        f = groups[k]
        try:
            return k, resolve(k, kind, f.title, f.year, f.hint, f.alt, top_season.get(k))
        finally:
            done[0] += 1

    with ThreadPoolExecutor(max_workers=6) as ex:
        for k, tid in ex.map(work, keys):
            results[k] = tid
            g = groups[k]
            det("   look up '%s'%s on TMDB -> %s   [%s]" % (
                g.title, " (%s)" % g.year if g.year else "", tid if tid else "not found" if tid == 0 else
                "couldn't look it up now", k.split(":", 1)[1].split("|")[0]))
            P(0.6 + 0.35 * done[0] / max(1, total), "%s - matching %d of %d" % (label_s, done[0], total),
              groups[k].title + (" (%s)" % groups[k].year if groups[k].year else ""))
    min_bytes = setting_int("min_movie_mb", 100) * 1024 * 1024
    if kind != "movie":
        min_bytes //= 5  # episodes can be small (anime, sitcoms)
    now = time.time()
    items_cache, titles = {}, {}
    for i, f in enumerate(new):
        size, mtime = vfs.stat(f.path)
        if f.disc:
            size = disc_size(f.path) or size
        elif size and size < min_bytes:
            det("   skipped (only %d MB - under the %d MB size limit): %s" % (
                size // 1048576, min_bytes // 1048576, f.path))
            continue
        tid = results.get(f.mkey)
        key = (f.mkey, tid)
        if key not in items_cache:
            items_cache[key] = get_item(sec, kind, tid, f.title, f.year, f.folder)
            it = db.item(items_cache[key])
            titles[items_cache[key]] = (it["title"] + (" (%s)" % it["year"] if it["year"] else "")) if it else f.title
            det("   -> in the library as '%s'%s" % (titles[items_cache[key]],
                                                   "" if it and it["matched"] else " (NOT MATCHED on TMDB)"))
        item_id = items_cache[key]
        season, episode, ep_end = f.season, f.episode, f.ep_end
        if kind == "show" and f.absolute:
            season, episode, ep_end = _map_absolute(db.item(item_id), f)
        first_look = f.root not in had_files  # a drive's first scan: date things by the files, not "today"
        before = known.get(f.path)
        added = (before["added"] or now) if before is not None else (mtime or now) if first_look else now
        db.run("INSERT OR REPLACE INTO files(path, item_id, section, mkey, season, episode, ep_end, absolute, size, "
               "mtime, added, label, root, cat, coll, ord) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
               (f.path, item_id, sec, f.mkey, season, episode, ep_end, 1 if f.absolute else 0, size, mtime, added,
                f.label or vfs.basename(f.path), f.root, f.cat, f.coll, f.ord), commit=False)
        rep = reps.get(f.root)
        if before is not None:  # only re-grouped / re-matched, not new
            out["rematched"] = out.get("rematched", 0) + 1
            if rep is not None:
                rep["rematched"] = rep.get("rematched", 0) + 1
            continue
        out["new"] += 1
        if rep is not None:
            rep["new"] += 1
            tt = titles[item_id]
            if tt not in rep["new_titles"] and len(rep["new_titles"]) < 25:
                rep["new_titles"].append(tt)
        if i % 20 == 0:
            P(0.95 + 0.05 * i / max(1, len(new)), "%s - adding to the library" % label_s,
              "%d of %d files" % (i, len(new)))
    db.commit()
    db.drop_empty_items()
    # keep the "added" date of an item as its newest file, for Recently Added
    db.run("UPDATE items SET added=(SELECT MAX(added) FROM files WHERE item_id=items.id) WHERE section=?", (sec,))
    out["added_titles"] = sorted(set(t for r in reps.values() for t in r["new_titles"]))[:8]
    return out


REPORT = "scan_report.json"
MATCH_VERSION = 2  # bump when name reading improves: unmatched titles get looked up again on the next scan


def scan(sections=None, progress=None, only=None, by="you"):
    """Scan everything (or some sections / some NAS folders). progress(percent, heading, where)."""
    from common import load_locations
    import music
    allloc = load_locations()
    secs = [s[0] for s in SECTIONS if allloc.get(s[0]) and (not sections or s[0] in sections)]
    if only:
        secs = [s for s in secs if any(under(o, x["path"]) for x in allloc[s] for o in only)]
    weights = [len(allloc[s]) if not only else 1 for s in secs]
    only_music = [o for o in only if any(under(o, x["path"]) for x in allloc.get("music", []))] if only else None
    try:  # 1.5.2: looking for music across the drives only happens when you ask for it (Music > Look for music)
        if db.meta_get("music_on_request") != "1":
            from common import set_setting
            set_setting("music_every", "0")
            db.meta_set("music_on_request", "1")
    except Exception as e:
        log("Switching the music search to 'only when I ask': %s" % e, "warn")
    if sections and "music" in sections:
        do_music = music.due(None, force=True)  # you asked for music
    elif only:
        do_music = bool(only_music) and music.due(only_music)
    else:
        do_music = music.due(None)  # only if you've set "Look for new music" to every few hours / a day
    if do_music:
        secs.append("music")
        weights.append(max(2, len(weights)) if not only else 1)
    tot = float(sum(weights)) or 1.0
    res = []
    started = time.time()
    try:
        if int(db.meta_get("match_version") or 1) < MATCH_VERSION:
            n = db.run("DELETE FROM matches WHERE tmdb=0 AND manual=0").rowcount
            db.meta_set("match_version", MATCH_VERSION)
            log("Names are read better now - looking up %d unmatched title%s again" % (n, "" if n == 1 else "s"))
    except Exception as e:
        log("Resetting old lookups: %s" % e, "warn")
    acc = 0.0
    _detail_start()
    for sid, wgt in zip(secs, weights):
        base, span = acc / tot, wgt / tot

        def prog(frac, head, where, base=base, span=span):
            if progress:
                progress(int(100 * (base + span * max(0.0, min(1.0, frac)))), head, where)
        try:
            if sid == "music":
                res.append(music.scan(prog, only_music or None, force=True))
                acc += wgt
                continue
            only_here = [o for o in only if any(under(o, x["path"]) for x in allloc[sid])] if only else None
            res.append(scan_section(sid, prog, only_here))
        except Exception as e:
            import traceback
            log("Scan %s crashed: %s\n%s" % (sid, e, traceback.format_exc()), "error")
            res.append({"section": sid, "new": 0, "gone": 0, "error": str(e), "locations": []})
        acc += wgt
    if not only:
        db.meta_set("last_scan", time.time())
    try:
        db.cache_trim()
    except Exception:
        pass
    _detail_end("%s scan (started by %s)" % ("Partial" if (only or sections) else "Full", by),
                overwrite=not (only or sections))
    report = {"started": started, "finished": time.time(), "by": by, "partial": bool(only or sections),
              "sections": res}
    try:
        save_json(REPORT, report)
    except Exception as e:
        log("Saving the scan report: %s" % e, "warn")
    return res


def scan_folder(sec, folder):
    """Quick scan of one movie / show folder (after a download lands)."""
    return scan_section(sec, None, [folder])


def summary(res):
    """-> (new, gone, [unreachable folder labels])."""
    new = sum(r.get("new", 0) for r in res)
    gone = sum(r.get("gone", 0) for r in res)
    bad = [l["label"] for r in res for l in r.get("locations", []) if l.get("status") == "unreachable"]
    return new, gone, bad


# ---------------------------------------------------------------- fixing matches
def forget_lookups(path):
    """Folder rules changed for 'path': what's in it - and the show folder above it - is looked up on TMDB
    again on the next scan (lookups you made by hand are kept)."""
    p = npath(path)
    keys = []
    for base in (p, npath(vfs.parent(p))):
        for kind in ("show:", "movie:"):
            k = kind + base
            keys.append(k)
    n = 0
    for k in keys:
        n += db.run("DELETE FROM matches WHERE manual=0 AND (mkey=? OR mkey LIKE ? ESCAPE '\\')",
                    (k, k.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "|%")).rowcount
    for kind in ("show:", "movie:"):
        k = kind + p
        n += db.run("DELETE FROM matches WHERE manual=0 AND substr(mkey, 1, ?) IN (?, ?)",
                    (len(k) + 1, k + "/", k + "\\")).rowcount
    return n


def item_mkeys(item_id):
    return [r["mkey"] for r in db.q("SELECT DISTINCT mkey FROM files WHERE item_id=?", (item_id,))]


def relink(item_id, new_tmdb):
    """Fix match: point all of this item's folders at another TMDB title and re-add its files."""
    it = db.item(item_id)
    if not it:
        return False
    sec, kind = it["section"], it["kind"]
    mkeys = item_mkeys(item_id)
    for mk in mkeys:
        db.match_set(mk, new_tmdb, kind, manual=1)
    db.run("DELETE FROM files WHERE item_id=?", (item_id,))
    db.drop_empty_items()
    folders = sorted(set(mk.split(":", 1)[1].split("|", 1)[0] for mk in mkeys))
    if folders:
        scan_section(sec, None, folders)
    return True


def refresh(item_id):
    it = db.item(item_id)
    if not it or not it["tmdb"]:
        return False
    db.run("DELETE FROM cache WHERE k LIKE ?", ("/%s/%s%%" % ("movie" if it["kind"] == "movie" else "tv", it["tmdb"]),))
    d = tmdb.details(it["kind"], it["tmdb"])
    if not d:
        return False
    sets = ", ".join("%s=?" % k for k in d) + ", sorttitle=?, updated=?, matched=1"
    db.run("UPDATE items SET %s WHERE id=?" % sets, list(d.values()) + [_sort(d.get("title")), time.time(), item_id])
    return True
