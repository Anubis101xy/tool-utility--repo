# -*- coding: utf-8 -*-
"""Works out which screen or action a plugin:// URL is asking for."""
import xbmc
import xbmcaddon
import xbmcgui

import kodiui
from common import ADDON_ID, NAME, log_exc, notify, setting, set_setting


def first_run():
    """Offer to bring keys over from TorUtilityBox the first time."""
    if setting("first_run_done") == "true":
        return
    set_setting("first_run_done", "true")
    try:
        xbmcaddon.Addon("plugin.video.torutilitybox")
        has_tub = True
    except Exception:
        has_tub = False
    if has_tub and xbmcgui.Dialog().yesno(NAME, "TorUtilityBox is installed. Copy its TorBox, Real-Debrid, "
                                                "Cocoleech and TMDB keys into StashBox?"):
        import ui
        ui.import_keys()


def main(argv):
    p = kodiui.init(argv)
    a = p.get("action", "")
    try:
        route(a, p)
    except Exception as e:
        log_exc("Screen '%s'" % (a or "home"))
        notify("Something went wrong: %s (see Tools > Error log)" % e, "error", 7000)
        if kodiui.handle() >= 0 and a in ("play", "play_item"):
            kodiui.fail_play()
        elif kodiui.handle() >= 0:
            kodiui.fail_dir()


def route_music(a, p):
    import musicui as m
    if a == "music":
        return m.home()
    if a == "music_scan":
        return m.scan_now()
    if a == "m_artists":
        return m.artists()
    if a == "m_artist":
        return m.artist(p["a"])
    if a == "m_albums":
        return m.albums(p.get("o", "title"), p.get("g"))
    if a == "m_album":
        return m.album(p["k"])
    if a == "m_genres":
        return m.genres()
    if a == "m_search":
        return m.search(p.get("q"))
    if a == "m_play_album":
        return m.play_album(p["k"], p.get("s") == "1")
    if a == "m_shuffle":
        return m.shuffle(p.get("a"))
    if a == "m_where":
        return m.where(p["p"])
    if a == "m_tidy":
        return m.tidy()
    kodiui.fail_dir()


def route(a, p):
    import ui
    if a == "":
        first_run()
        if p.get("content_type") == "audio":  # opened from Music > Add-ons
            import musicui
            return musicui.home()
        return ui.home()
    if a.startswith("m_") or a == "music" or a == "music_scan":
        return route_music(a, p)
    if a == "section":
        return ui.section(p["s"])
    if a == "list":
        return ui.list_items(p["s"], p.get("f"), p.get("o", "title"), p.get("g"), p.get("y"), p.get("c"), p.get("fr"),
                             p.get("fc"))
    if a == "genres":
        return ui.genres(p["s"])
    if a == "years":
        return ui.years(p["s"])
    if a == "collections":
        return ui.collections(p["s"])
    if a == "show":
        return ui.show(int(p["id"]))
    if a == "season":
        return ui.season(int(p["id"]), p["n"])
    if a == "continue":
        return ui.continue_watching(p.get("s"))
    if a == "nextup":
        return ui.next_up(p.get("s"))
    if a == "recent":
        return ui.recent(p.get("s"))
    if a == "lib_search":
        return ui.lib_search(p.get("q"))
    if a == "play":
        return ui.play(p["f"], p.get("resume"), p.get("auto") == "1")
    if a == "play_item":
        return ui.play_item(int(p["id"]))
    if a == "mark":
        return ui.mark(item_id=int(p["id"]), watched=p.get("w") == "1", season_n=p.get("n"))
    if a == "markf":
        return ui.mark(path=p["f"], watched=p.get("w") == "1")
    if a == "fixmatch":
        return ui.fix_match(int(p["id"]))
    if a == "unmatched":
        return ui.unmatched(p.get("s"))
    if a == "refresh_item":
        return ui.refresh_item(int(p["id"]))
    if a == "delete":
        return ui.delete_item(int(p["id"]))
    if a == "deletef":
        return ui.delete_file(p["f"])
    if a == "fileinfo":
        return ui.file_info(p["f"])
    if a == "tools":
        return ui.tools()
    if a == "setup":
        return ui.setup()
    if a == "folders":
        return ui.folders()
    if a == "loc_add":
        return ui.loc_add(p["s"])
    if a == "loc_menu":
        return ui.loc_menu(p["s"], p["p"], p.get("do"))
    if a == "scan_loc":
        return ui.scan_loc(p["p"])
    if a == "scan_report":
        return ui.scan_report()
    if a == "where":
        return ui.where(int(p["id"]))
    if a == "where_folder":
        return ui.where_folder(int(p["id"]), p["h"])
    if a == "where_dups":
        return ui.where_dups(int(p["id"]))
    if a == "merge":
        return ui.merge(int(p["id"]), int(p["o"]))
    if a == "many_places":
        return ui.shows_in_many_places()
    if a == "organise":
        return ui.organise(int(p["id"]))
    if a == "hunt":
        return ui.hunt_start(p.get("id"))
    if a == "hunt_results":
        return ui.hunt_results()
    if a == "hunt_move":
        return ui.hunt_move(p["id"], p.get("p"))
    if a == "hunt_small":
        return ui.hunt_small()
    if a == "split":
        return ui.split(int(p["id"]), p.get("menu") == "1")
    if a == "folder_rule":
        return ui.folder_rule(p["p"], p.get("do"))
    if a == "folder_rules":
        return ui.folder_rules()
    if a == "shows_in":
        return ui.shows_in(p["p"])
    if a == "export":
        return ui.export_report()
    if a == "play_any":
        return ui.play_any(p["f"])
    if a == "browse":
        return ui.browse(p["s"], p.get("r"), p.get("c", ""))
    if a == "scan":
        return ui.scan(p.get("full") == "1")
    if a == "accounts":
        return ui.accounts()
    if a == "rd_login":
        return ui.rd_login()
    if a == "import_keys":
        return ui.import_keys()
    if a == "log":
        return ui.view_log()
    if a == "scan_detail":
        return ui.view_scan_detail()
    if a == "settings":
        return xbmcaddon.Addon(ADDON_ID).openSettings()
    if a == "refresh":
        return kodiui.refresh()
    if a == "noop":
        return
    import getmedia as g
    if a == "get":
        return g.menu()
    if a == "get_menu":
        return g.section_menu(p["k"])
    if a == "get_search":
        return g.search(p["k"], p.get("q"))
    if a == "get_results":
        return g.results(p["k"], p["q"], p.get("page", 1))
    if a == "get_list":
        return g.tmdb_list(p["k"], p["l"], p.get("page", 1))
    if a == "get_title":
        return g.title(p["k"], p.get("tmdb"), p.get("lib"))
    if a == "get_season":
        return g.get_season(p["k"], p["tmdb"], p["n"])
    if a == "missing_shows":
        return g.missing_shows(p["k"])
    if a == "sources":
        return g.sources(p["k"], p["tmdb"], p.get("n"), p.get("e"), p.get("pack") == "1")
    if a == "pick":
        return g.pick(p)
    if a == "stream":
        return g.stream(p)
    if a == "autoget":
        return g.autoget(p["k"], p["tmdb"], p.get("n"))
    if a == "paste":
        return g.paste()
    if a == "cloud":
        return g.cloud(p.get("kind", "torrents"))
    if a == "cloud_item":
        return g.cloud_item(p["kind"], p["id"], p.get("nm", ""))
    if a == "downloads":
        return g.downloads_screen()
    if a == "dl_job":
        return g.job_menu(p["id"])
    if a == "dl_clear":
        return g.clear_finished()
    if a == "test_sources":
        return g.test_sources()
    xbmc.log("[StashBox] unknown action %s" % a, xbmc.LOGWARNING)
    kodiui.fail_dir()
