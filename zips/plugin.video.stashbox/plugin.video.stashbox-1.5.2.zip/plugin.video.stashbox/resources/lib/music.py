# -*- coding: utf-8 -*-
"""Music: find audio anywhere on the NAS (or just your music folders), read the tags, browse by artist / album,
fetch missing covers, and tidy it all into Artist / Album (Year) / 01 - Title in one folder."""
import random
import re
import time
from concurrent.futures import ThreadPoolExecutor

import requests

import db
import names
import tags
import vfs
from common import (UA, all_locations, hide_creds, log, music_locations, npath, rel, setting, setting_bool,
                    setting_int, under)

ART_NAMES = ("cover", "folder", "front", "album", "albumart", "albumartsmall", "thumb", "artwork")
SIDE_EXT = (".jpg", ".jpeg", ".png", ".gif", ".cue", ".log", ".m3u", ".m3u8", ".nfo", ".txt", ".sfv", ".md5")


def enabled():
    return setting_bool("music_enable", True)


def akey(albumartist, album):
    return "%s|%s" % (names.norm(albumartist or "") or "unknown", names.norm(album or "") or "unknown")


# ---------------------------------------------------------------- where to look
def roots():
    """-> [(path, label, is_music_folder)] - your music folders, plus every share on the NAS if set to search it all."""
    out = [(npath(x["path"]), x.get("label") or x["path"], True) for x in music_locations()]
    if setting("music_scope", "0") == "0":
        hosts = set()
        for p in [x[0] for x in out] + [npath(loc["path"]) for _s, loc in all_locations()]:
            h = vfs.host_root(p)
            if h:
                hosts.add(h)
        for h in sorted(hosts):
            res = vfs.listdir(h)
            for sh in (res[0] if res else []):
                if sh.endswith("$") or names.system_dir(sh):
                    continue
                p = npath(vfs.join(h, sh))
                out.append((p, "%s (whole share)" % sh, False))
        if not hosts:  # local paths: the drive each music / video folder is on
            for p in [x[0] for x in out] + [npath(loc["path"]) for _s, loc in all_locations()]:
                out.append((npath(vfs.share_root(p)), vfs.basename(vfs.share_root(p)), False))
    res, seen = [], []
    for p, lab, mine in sorted(out, key=lambda x: len(x[0])):
        if any(under(p, s) for s in seen):
            continue
        seen.append(p)
        res.append((p, lab, mine))
    return res


def _video_folders():
    return [npath(loc["path"]) for _s, loc in all_locations()]


def root_of(path):
    best = None
    for r, _l, _m in roots():
        if under(path, r) and (best is None or len(r) > len(best)):
            best = r
    return best or vfs.share_root(path)


# ---------------------------------------------------------------- scanning
def due(only=None, force=False):
    if not enabled():
        return False
    if only is not None or force:
        return True
    every = setting_int("music_every", 24)  # hours; 0 = only when asked
    last = float(db.meta_get("last_music_scan") or 0)
    return every > 0 and time.time() - last >= every * 3600


def scan(progress=None, only=None, force=False):
    """progress(fraction, heading, where). -> report dict like the video sections'."""
    from scanner import Walker, det
    out = {"section": "music", "new": 0, "gone": 0, "error": None, "added_titles": [], "locations": []}
    if not due(only, force):
        out["skipped"] = True
        return out
    P = progress or (lambda f, h, w: None)
    skip_video = [] if setting_bool("music_in_video", False) else _video_folders()
    min_bytes = setting_int("music_min_kb", 300) * 1024
    rts = roots()
    if only:
        rts = [(o, vfs.basename(o), True) for o in only]
    if not rts:
        out["error"] = "no music folders yet - add one, or a film / TV folder so I know where the NAS is"
        return out
    w = Walker()
    found, reached, reps = {}, [], {}
    for i, (root, label, _mine) in enumerate(rts):
        rep = {"path": hide_creds(root), "label": label, "status": "ok", "found": 0, "new": 0, "gone": 0,
               "folders": 0, "secs": 0.0, "new_titles": [], "unreadable": [], "partial": only is not None}
        reps[root] = rep
        out["locations"].append(rep)
        t0, f0, fails0 = time.time(), w.folders, len(w.failed)
        base, span = 0.6 * i / len(rts), 0.6 / len(rts)

        def tick(path, n, base=base, span=span, label=label, root=root, f0=f0, i=i):
            k = n - f0
            where = rel(path, root)
            P(base + span * min(0.95, k / (k + 200.0)), "Music - looking in %d of %d places" % (i + 1, len(rts)),
              "%s > %s" % (label, where.replace("/", " > ")) if where else label)
        w.tick = tick
        det("")
        det("== Music: %s  (%s)" % (label, hide_creds(root)))
        if w.listdir(root) is None:
            rep["status"] = "unreachable"
            det("   COULDN'T REACH IT - skipped, nothing removed from the library")
            continue
        reached.append(root)
        n = 0
        for folder, _dirs, files in w.walk(root, depth=12):
            if any(under(folder, v) for v in skip_video):
                continue
            for f in files:
                if names.is_audio(f):
                    found[vfs.join(folder, f)] = (root, folder, files)
                    n += 1
        rep.update(found=n, folders=w.folders - f0, secs=round(time.time() - t0, 1),
                   unreadable=[hide_creds(x) for x in w.failed[fails0:]][:10])
        det("   %d audio file%s in %d folders (%.1fs)%s" % (n, "" if n == 1 else "s", rep["folders"], rep["secs"],
                                                         ", couldn't read: %s" % ", ".join(
                                                             rel(x, root) for x in w.failed[fails0:][:8])
                                                         if len(w.failed) > fails0 else ""))
    w.tick = None
    known = dict((r["path"], r) for r in db.q("SELECT path, root, mtime FROM tracks"))
    gone = []
    for p in known:
        if p in found:
            continue
        r = next((x for x in reached if under(p, x)), None)
        if r is None or any(under(p, fd) for fd in w.failed) or (only and not any(under(p, o) for o in only)):
            continue
        gone.append(p)
        reps[r]["gone"] += 1
    for p in gone:
        db.run("DELETE FROM tracks WHERE path=?", (p,), commit=False)
    out["gone"] = len(gone)
    db.commit()
    new = [p for p in found if p not in known]
    first = not known
    done = [0]
    sizes = {}

    def work(p):
        try:
            size, mtime = vfs.stat(p)
            sizes[p] = (size, mtime)
            if size and size < min_bytes:
                return p, None
            return p, tags.read(p, found[p][0])
        except Exception as e:
            log("Reading tags of %s: %s" % (hide_creds(p), e), "debug")
            return p, None
        finally:
            done[0] += 1
    now = time.time()
    arts = {}
    with ThreadPoolExecutor(max_workers=6) as ex:
        for p, t in ex.map(work, new):
            if done[0] % 10 == 0:
                P(0.6 + 0.38 * done[0] / max(1, len(new)), "Music - reading tags %d of %d" % (done[0], len(new)),
                  vfs.basename(p))
            if t is None:
                continue
            root, folder, files = found[p]
            if folder not in arts:
                arts[folder] = _folder_art(folder, files)
            aa = t["albumartist"] or (None if t["compilation"] else t["artist"]) or \
                ("Various Artists" if t["compilation"] else "Unknown Artist")
            album = t["album"] or vfs.basename(folder)
            size, mtime = sizes.get(p, (0, 0))
            db.run("INSERT OR REPLACE INTO tracks(path, root, folder, artist, albumartist, album, title, track, disc, "
                   "year, genre, duration, size, mtime, added, art, akey) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (p, root, folder, t["artist"] or aa, aa, album, t["title"] or names.stem(vfs.basename(p)),
                    t["track"], t["disc"], t["year"], t["genre"], t["duration"], size, mtime,
                    (mtime or now) if first else now, arts[folder], akey(aa, album)), commit=False)
            out["new"] += 1
            rep = reps.get(root)
            if rep is not None:
                rep["new"] += 1
                lab = "%s - %s" % (aa, album)
                if lab not in rep["new_titles"] and len(rep["new_titles"]) < 25:
                    rep["new_titles"].append(lab)
    db.commit()
    if only is None:
        db.meta_set("last_music_scan", time.time())
    out["added_titles"] = sorted(set(t for r in reps.values() for t in r["new_titles"]))[:8]
    log("Music scan: %d tracks found, %d new, %d gone (%d places)" % (len(found), out["new"], out["gone"], len(rts)))
    return out


def _folder_art(folder, files):
    imgs = [f for f in files if names.ext(f) in (".jpg", ".jpeg", ".png")]
    for want in ART_NAMES:
        for f in imgs:
            if names.stem(f).lower() == want or names.stem(f).lower().startswith(want + "_"):
                return vfs.join(folder, f)
    return vfs.join(folder, imgs[0]) if len(imgs) == 1 else ""


# ---------------------------------------------------------------- library queries
def counts():
    r = db.one("SELECT COUNT(*) n, COUNT(DISTINCT akey) a, COUNT(DISTINCT albumartist) ar FROM tracks")
    return (r["n"], r["a"], r["ar"]) if r else (0, 0, 0)


def artists():
    return db.q("SELECT albumartist name, COUNT(DISTINCT akey) albums, COUNT(*) n, MAX(art) art FROM tracks "
                "GROUP BY lower(albumartist) ORDER BY lower(albumartist)")


def albums(artist=None, genre=None, order="title", limit=None):
    sql = ("SELECT akey, MAX(albumartist) artist, MAX(album) album, MAX(year) year, COUNT(*) n, MAX(art) art, "
           "MAX(added) added, MAX(genre) genre FROM tracks")
    where, args = [], []
    if artist is not None:
        where.append("lower(albumartist)=lower(?)")
        args.append(artist)
    if genre is not None:
        where.append("genre=?")
        args.append(genre)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " GROUP BY akey ORDER BY " + {"title": "lower(MAX(album))", "recent": "MAX(added) DESC",
                                         "year": "MAX(year), lower(MAX(album))"}[order]
    if limit:
        sql += " LIMIT %d" % int(limit)
    return db.q(sql, args)


def album_tracks(key):
    return db.q("SELECT * FROM tracks WHERE akey=? ORDER BY COALESCE(disc, 1), COALESCE(track, 999), path", (key,))


def artist_tracks(name):
    return db.q("SELECT * FROM tracks WHERE lower(albumartist)=lower(?) OR lower(artist)=lower(?) ORDER BY year, "
                "akey, COALESCE(disc, 1), track", (name, name))


def genres():
    return db.q("SELECT genre, COUNT(DISTINCT akey) n FROM tracks WHERE genre IS NOT NULL AND genre<>'' GROUP BY genre "
                "ORDER BY genre")


def search(text):
    t = "%" + text.strip() + "%"
    return (db.q("SELECT albumartist name, COUNT(DISTINCT akey) albums FROM tracks WHERE albumartist LIKE ? OR "
                 "artist LIKE ? GROUP BY lower(albumartist) ORDER BY name LIMIT 50", (t, t)),
            albums_like(t), db.q("SELECT * FROM tracks WHERE title LIKE ? ORDER BY title LIMIT 200", (t,)))


def albums_like(t):
    return db.q("SELECT akey, MAX(albumartist) artist, MAX(album) album, MAX(year) year, COUNT(*) n, MAX(art) art "
                "FROM tracks WHERE album LIKE ? GROUP BY akey ORDER BY album LIMIT 100", (t,))


def random_tracks(n=300, artist=None):
    if artist:
        rows = artist_tracks(artist)
    else:
        rows = db.q("SELECT * FROM tracks ORDER BY RANDOM() LIMIT ?", (n,))
    rows = list(rows)
    random.shuffle(rows)
    return rows[:n]


# ---------------------------------------------------------------- pictures (Deezer, free, no key)
def _deezer(path, **params):
    ck = "deezer:%s:%s" % (path, sorted(params.items()))
    hit = db.cache_get(ck, 30 * 86400)
    if hit is not None:
        return hit
    try:
        r = requests.get("https://api.deezer.com" + path, params=params, headers=UA, timeout=8)
        d = r.json()
    except Exception:
        return {}
    db.cache_put(ck, d)
    return d


def artist_picture(name):
    if not name or not setting_bool("music_art", True) or name in ("Unknown Artist", "Various Artists"):
        return ""
    for a in (_deezer("/search/artist", q=name).get("data") or [])[:3]:
        if names.norm(a.get("name")) == names.norm(name):
            return a.get("picture_xl") or a.get("picture_big") or ""
    return ""


def album_cover(artist, album):
    if not setting_bool("music_art", True) or not album:
        return ""
    q = 'artist:"%s" album:"%s"' % (artist, album) if artist and artist != "Unknown Artist" else album
    for a in (_deezer("/search/album", q=q).get("data") or [])[:5]:
        if names.norm(a.get("title")) == names.norm(album) or names.norm(a.get("title")).startswith(names.norm(album)):
            return a.get("cover_xl") or a.get("cover_big") or ""
    return ""


def album_art(row, fetch=True):
    """A local cover (folder.jpg ...) or one from Deezer (cached)."""
    if row["art"]:
        return row["art"]
    return album_cover(row["artist"], row["album"]) if fetch else ""


# ---------------------------------------------------------------- moving / forgetting
def move_track(old, new):
    c = db.conn()
    c.execute("UPDATE OR REPLACE tracks SET path=?, folder=?, root=? WHERE path=?",
              (new, vfs.parent(new), root_of(new), old))
    c.commit()


def forget(path):
    p = npath(path)
    for r in db.q("SELECT path FROM tracks WHERE path=? OR substr(path, 1, ?) IN (?, ?)",
                  (p, len(p) + 1, p + "/", p + "\\")):
        db.run("DELETE FROM tracks WHERE path=?", (r["path"],), commit=False)
    db.commit()


def remap(old, new):
    old, new = npath(old), npath(new)
    n = len(old)
    c = db.conn()
    for r in c.execute("SELECT path, folder FROM tracks WHERE substr(path, 1, ?) IN (?, ?)",
                       (n + 1, old + "/", old + "\\")).fetchall():
        c.execute("UPDATE OR REPLACE tracks SET path=?, folder=?, root=? WHERE path=?",
                  (new + r[0][n:], new + r[1][n:], new, r[0]))
    c.commit()


# ---------------------------------------------------------------- tidy into one folder
def _fname(t, multi_disc, rename):
    e = names.ext(t["path"])
    if not rename:
        return vfs.basename(t["path"])
    title = names.safe(t["title"] or names.stem(vfs.basename(t["path"])), 100)
    if t["track"]:
        num = ("%d-%02d" % (t["disc"] or 1, t["track"])) if multi_disc else "%02d" % t["track"]
        return "%s - %s%s" % (num, title, e)
    return title + e


def plan_tidy(target, rename=True):
    """Every track not already in its place under target -> Artist / Album (Year) / 01 - Title.ext.
    -> dict(moves, dups, cross_bytes, same_bytes, sources)"""
    tgt = npath(target)
    rows = db.q("SELECT * FROM tracks ORDER BY akey, COALESCE(disc, 1), track, path")
    discs = {}
    for t in rows:
        discs.setdefault(t["akey"], set()).add(t["disc"] or 1)
    moves, dups, planned = [], [], set()
    by_folder = {}
    for t in rows:
        artist = names.safe(t["albumartist"] or t["artist"] or "Unknown Artist", 80)
        album = names.safe(t["album"] or "Unknown Album", 100) + (" (%d)" % t["year"] if t["year"] else "")
        dest_dir = vfs.join(tgt, artist, album)
        dest = vfs.join(dest_dir, _fname(t, len(discs.get(t["akey"]) or ()) > 1, rename))
        if npath(dest) == npath(t["path"]):
            continue  # already tidy
        if dest.lower() in planned or vfs.exists(dest):
            dups.append(t["path"])
            continue
        planned.add(dest.lower())
        moves.append({"src": t["path"], "dst": dest, "size": t["size"] or 0, "video": True})
        by_folder.setdefault(t["folder"], set()).add(dest_dir)
    # covers / .cue / .log go with their album when the whole folder moves to one place
    left = set(r["folder"] for r in rows if r["path"] in dups)
    for folder, dests in by_folder.items():
        if len(dests) != 1 or folder in left:
            continue
        dest_dir = next(iter(dests))
        res = vfs.listdir(folder)
        for f in (res[1] if res else []):
            if names.ext(f) in SIDE_EXT:
                d2 = vfs.join(dest_dir, f)
                if d2.lower() not in planned and not vfs.exists(d2):
                    planned.add(d2.lower())
                    moves.append({"src": vfs.join(folder, f), "dst": d2, "size": 0, "video": False})
    sources = {}
    for m in moves:
        if m["video"]:
            sr = vfs.share_root(m["src"])
            sources[sr] = sources.get(sr, 0) + 1
    cross = sum(m["size"] for m in moves if not vfs.same_share(m["src"], m["dst"]))
    same = sum(m["size"] for m in moves if vfs.same_share(m["src"], m["dst"]))
    tidy = sorted(set(npath(vfs.parent(m["src"])) for m in moves))
    return {"moves": moves, "dups": dups, "cross_bytes": cross, "same_bytes": same, "sources": sources,
            "tidy": tidy, "target": tgt}


def fmt_dur(s):
    s = int(s or 0)
    return "%d:%02d" % divmod(s, 60) if s else ""


def clean(s):
    return re.sub(r"\s+", " ", s or "").strip()
