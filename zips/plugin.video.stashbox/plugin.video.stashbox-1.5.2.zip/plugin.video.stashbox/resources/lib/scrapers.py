# -*- coding: utf-8 -*-
"""Torrent scrapers: Torrentio (Stremio), Knaben, The Pirate Bay (apibay), Nyaa, and CocoScrapers if installed.

Each returns [{"name", "hash", "size", "seeds", "source", "file"}]."""
import re
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, wait

import requests

import names
from common import UA, log, setting, setting_bool, setting_int

RES_RANK = {"2160p": 4, "1080p": 3, "720p": 2, "480p": 1, "SD?": 0}
BTIH = re.compile(r"(?i)btih:([a-f0-9]{40}|[a-z2-7]{32})")


def _size(txt):
    m = re.search(r"([\d.,]+)\s*(TiB|GiB|MiB|KiB|TB|GB|MB|KB)", txt or "", re.I)
    if not m:
        return 0
    n = float(m.group(1).replace(",", ""))
    mult = {"t": 1024 ** 4, "g": 1024 ** 3, "m": 1024 ** 2, "k": 1024}[m.group(2)[0].lower()]
    return int(n * mult)


def _hash_from_magnet(m):
    x = BTIH.search(m or "")
    if not x:
        return ""
    h = x.group(1)
    if len(h) == 32:  # base32 -> hex
        import base64
        try:
            h = base64.b16encode(base64.b32decode(h.upper())).decode()
        except Exception:
            return ""
    return h.lower()


def _host(key, default):
    h = (setting(key) or default).strip().rstrip("/")
    if not h.startswith("http"):
        h = "https://" + h
    return h


# ---------------------------------------------------------------- scrapers
def torrentio(ctx):
    if not ctx.get("imdb"):
        return None
    base = _host("torrentio_url", "https://torrentio.strem.fun")
    base = re.sub(r"/manifest\.json$", "", base)
    if ctx["kind"] == "movie":
        url = "%s/stream/movie/%s.json" % (base, ctx["imdb"])
    else:
        url = "%s/stream/series/%s:%s:%s.json" % (base, ctx["imdb"], ctx["season"], ctx.get("episode") or 1)
    r = requests.get(url, headers=UA, timeout=ctx["timeout"])
    r.raise_for_status()
    out = []
    for st in r.json().get("streams") or []:
        h = (st.get("infoHash") or "").lower()
        if not h:
            continue
        title = st.get("title") or st.get("description") or ""
        lines = title.split("\n")
        seeds = re.search(r"\U0001F464\s*(\d+)", title)
        src = re.search(r"⚙️?\s*(\S+)", title)
        fname = (st.get("behaviorHints") or {}).get("filename") or ""
        out.append({"name": lines[0].strip(), "hash": h, "size": _size(title), "seeds": int(seeds.group(1)) if seeds else 0,
                    "source": "Torrentio" + ("/" + src.group(1) if src else ""), "file": fname})
    return out


def knaben(ctx):
    out = []
    for q in ctx["queries"][:2]:
        body = {"search_type": "100%", "search_field": "title", "query": q, "order_by": "seeders",
                "order_direction": "desc", "size": 60, "hide_unsafe": True, "hide_xxx": True}
        r = requests.post("https://api.knaben.org/v1", json=body, headers=UA, timeout=ctx["timeout"])
        r.raise_for_status()
        for h in r.json().get("hits") or []:
            hh = (h.get("hash") or "").lower() or _hash_from_magnet(h.get("magnetUrl"))
            if hh:
                out.append({"name": h.get("title") or "", "hash": hh, "size": int(h.get("bytes") or 0),
                            "seeds": int(h.get("seeders") or 0), "source": "Knaben"})
    return out


def piratebay(ctx):
    base = _host("tpb_host", "apibay.org")
    out = []
    for q in ctx["queries"][:2]:
        r = requests.get(base + "/q.php", params={"q": q, "cat": "200"}, headers=UA, timeout=ctx["timeout"])
        r.raise_for_status()
        for it in r.json() or []:
            h = (it.get("info_hash") or "").lower()
            if not h or set(h) == {"0"}:
                continue
            out.append({"name": it.get("name") or "", "hash": h, "size": int(it.get("size") or 0),
                        "seeds": int(it.get("seeders") or 0), "source": "PirateBay"})
    return out


def nyaa(ctx):
    if not ctx.get("anime"):
        return None
    base = _host("nyaa_host", "nyaa.si")
    out = []
    ns = {"nyaa": "https://nyaa.si/xmlns/nyaa"}
    for q in ctx["anime_queries"][:3]:
        r = requests.get(base + "/", params={"page": "rss", "q": q, "c": "1_0", "f": "0"}, headers=UA,
                         timeout=ctx["timeout"])
        r.raise_for_status()
        root = ET.fromstring(r.content)
        for it in root.iter("item"):
            h = (it.findtext("nyaa:infoHash", "", ns) or "").lower()
            if not h:
                continue
            out.append({"name": it.findtext("title", ""), "hash": h, "size": _size(it.findtext("nyaa:size", "", ns)),
                        "seeds": int(it.findtext("nyaa:seeders", "0", ns) or 0), "source": "Nyaa"})
    return out


def coco(ctx):
    if not ctx.get("imdb") or not ctx.get("year"):
        return None
    try:
        from cocoscrapers import sources as coco_sources
    except ImportError:
        raise RuntimeError("CocoScrapers isn't installed (script.module.cocoscrapers)")
    data = {"title": ctx["title"], "year": str(ctx["year"]), "imdb": ctx["imdb"], "aliases": [ctx["title"]]}
    if ctx["kind"] != "movie":
        data.update({"tvshowtitle": ctx["title"], "title": "", "season": str(ctx["season"]),
                     "episode": str(ctx.get("episode") or 1)})
    providers = coco_sources()
    if not providers:
        raise RuntimeError("no CocoScrapers providers turned on (in its own settings)")
    ex = ThreadPoolExecutor(max_workers=min(12, len(providers)))
    futs = dict((ex.submit(lambda m=mod: m().sources(dict(data), []) or []), n) for n, mod in providers)
    done, _ = wait(list(futs), timeout=ctx["timeout"])
    ex.shutdown(wait=False)
    out = []
    for f in done:
        try:
            for r in f.result():
                h = (r.get("hash") or "").lower()
                if h:
                    out.append({"name": r.get("name") or "?", "hash": h, "size": int(float(r.get("size") or 0) * 1024 ** 3),
                                "seeds": int(r.get("seeders") or 0), "source": "Coco:" + futs[f]})
        except Exception:
            continue
    return out


SCRAPERS = [("Torrentio", "torrentio_enable", torrentio, True), ("Knaben", "knaben_enable", knaben, True),
            ("PirateBay", "tpb_enable", piratebay, True), ("Nyaa", "nyaa_enable", nyaa, True),
            ("CocoScrapers", "coco_enable", coco, False)]


# ---------------------------------------------------------------- relevance
def _covers(name, ctx):
    """Is this release relevant to what we're after? -> (keep, is_pack)."""
    if ctx["kind"] == "movie":
        p = names.parse_episode(name)
        if p and not p["absolute"]:
            return False, False
        return True, False
    season, ep = ctx["season"], ctx.get("episode")
    seasons = names.pack_seasons(name)
    anime_range = re.search(r"[\[\(\s](\d{1,4})\s*[-~]\s*(\d{1,4})[\]\)\s]", name)
    is_pack = bool(seasons) or bool(anime_range and ctx.get("anime")) or bool(re.search(r"(?i)\bbatch\b", name))
    if is_pack:
        if seasons and "all" not in seasons and season not in seasons:
            return False, True
        if anime_range and ctx.get("anime") and ctx.get("abs") and ep:
            a, b = int(anime_range.group(1)), int(anime_range.group(2))
            if not (a <= ctx["abs"] <= b or a <= ep <= b):
                return False, True
        return True, True
    if ctx.get("pack"):
        return False, False
    hit = names.episode_for(name, season, ep, ctx.get("abs"))
    return hit is not False, False


def _short(title):
    """'Frieren: Beyond Journey's End' -> 'Frieren' (release names often use the short form)."""
    s = re.split(r"\s*[:\u2013\u2014]\s*|\s+-\s+", title or "")[0]
    return s if len(names.norm(s)) >= 3 else title


def _q(title):
    return re.sub(r"\s+", " ", re.sub(r"[:'\u2019!?,.()]", " ", title or "")).strip()


def _relevant_title(name, ctx):
    n = names.norm(names.tidy(name))
    for t in [ctx["title"], _short(ctx["title"])] + list(ctx.get("alt_titles") or []):
        tt = names.norm(t)
        if tt and all(w in n.split() or w in n for w in tt.split()[:6]):
            return True
    return False


def run(ctx):
    """ctx: kind, title, year, imdb, season, episode, pack, anime, abs, alt_titles. -> (results, report)."""
    ctx = dict(ctx)
    ctx["timeout"] = max(5, setting_int("scrape_timeout", 20))
    t = _q(ctx["title"])
    if ctx["kind"] == "movie":
        ctx["queries"] = ["%s %s" % (t, ctx["year"]) if ctx.get("year") else t]
    elif ctx.get("pack"):
        ctx["queries"] = ["%s S%02d" % (t, ctx["season"]), "%s Season %d" % (t, ctx["season"])]
    else:
        ctx["queries"] = ["%s S%02dE%02d" % (t, ctx["season"], ctx["episode"])]
    if ctx.get("anime"):
        base = [_q(_short(ctx["title"]))] + [_q(a) for a in (ctx.get("alt_titles") or [])
                                             if names.norm(a) != names.norm(t)][:1]
        if names.norm(base[0]) != names.norm(t):
            base.append(t)
        if ctx.get("pack"):
            ctx["anime_queries"] = ["%s batch" % b for b in base] + base[:1]
        else:
            n = ctx.get("abs") or ctx.get("episode")
            ctx["anime_queries"] = ["%s %02d" % (b, n) for b in base]
            if ctx.get("abs") and ctx["abs"] != ctx.get("episode"):
                ctx["anime_queries"].append("%s S%02dE%02d" % (t, ctx["season"], ctx["episode"]))
    jobs = [(label, fn) for label, key, fn, default in SCRAPERS if setting_bool(key, default)]
    report = []

    def one(job):
        label, fn = job
        t0 = time.time()
        try:
            res = fn(ctx)
            return label, res, None, time.time() - t0
        except Exception as e:
            return label, None, "%s: %s" % (e.__class__.__name__, str(e)[:120]), time.time() - t0

    ex = ThreadPoolExecutor(max_workers=max(1, len(jobs)))
    futs = [ex.submit(one, j) for j in jobs]
    wait(futs, timeout=ctx["timeout"] + 8)
    ex.shutdown(wait=False)
    raw = []
    for j, f in zip(jobs, futs):
        label, res, err, secs = f.result() if f.done() else (j[0], None, "timed out", ctx["timeout"])
        if res is None and err is None:
            continue  # not applicable (no IMDb id, not anime...)
        report.append((label, len(res or []), err, secs))
        if err:
            log("Scraper %s: %s" % (label, err), "warn")
        raw.extend(res or [])

    hide_cam = setting_bool("hide_cam", True)
    max_res = {"1": 4, "2": 3, "3": 2}.get(setting("max_res", "0"), 9)
    min_seeds = setting_int("min_seeders", 1)
    best = {}
    for r in raw:
        h = r["hash"]
        if not re.match(r"^[a-f0-9]{40}$", h):
            continue
        if not r["source"].startswith(("Torrentio", "Coco")) and not _relevant_title(r["name"], ctx):
            continue
        keep, pack = _covers(r["name"], ctx)
        if not keep:
            continue
        if hide_cam and names.is_cam(r["name"]):
            continue
        res = names.resolution(r["name"] + " " + (r.get("file") or ""))
        if RES_RANK[res] > max_res:
            continue
        if r["seeds"] < min_seeds and not r["source"].startswith("Torrentio"):
            continue
        r["res"], r["pack"] = res, pack
        old = best.get(h)
        if old is None:
            best[h] = r
        else:
            old["seeds"] = max(old["seeds"], r["seeds"])
            old["size"] = old["size"] or r["size"]
            if r["source"].split("/")[0] not in old["source"]:
                old["source"] += ", " + r["source"].split("/")[0]
    out = sorted(best.values(), key=lambda r: (-RES_RANK[r["res"]], -r["seeds"]))
    return out, report
