# -*- coding: utf-8 -*-
"""The library database (SQLite in the add-on's profile folder)."""
import json
import os
import sqlite3
import threading
import time

from common import PROFILE, ensure_profile

SCHEMA = 3
_local = threading.local()

TABLES = """
CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ukey TEXT UNIQUE,            -- section|kind|tmdb  or  section|kind|u:<title>:<year>
  section TEXT, kind TEXT,     -- kind: movie / show
  tmdb INTEGER, imdb TEXT,
  title TEXT, sorttitle TEXT, original TEXT, year INTEGER,
  plot TEXT, tagline TEXT, poster TEXT, fanart TEXT, logo TEXT,
  rating REAL, votes INTEGER, genres TEXT, runtime INTEGER, mpaa TEXT, studio TEXT, status TEXT,
  collection_id INTEGER, collection TEXT,
  seasons TEXT,                -- json [{n, count, name, poster, air}]
  folder TEXT,                 -- main folder on the NAS
  added REAL, updated REAL, matched INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS items_section ON items(section, kind);
CREATE INDEX IF NOT EXISTS items_tmdb ON items(tmdb);
CREATE TABLE IF NOT EXISTS files (
  path TEXT PRIMARY KEY,
  item_id INTEGER, section TEXT, mkey TEXT,
  season INTEGER, episode INTEGER, ep_end INTEGER, absolute INTEGER,
  size INTEGER, mtime REAL, added REAL, label TEXT,
  root TEXT,                   -- which of your NAS folders it's in
  cat TEXT,                    -- category folders between that and the title ("Kids/Disney"), '' at the top
  coll TEXT,                   -- the collection folder it's in ("Harry Potter Collection"), '' if none
  ord INTEGER                  -- your order number in that collection ("01 Harry Potter..." -> 1)
);
CREATE INDEX IF NOT EXISTS files_item ON files(item_id, season, episode);
CREATE INDEX IF NOT EXISTS files_mkey ON files(mkey);
CREATE INDEX IF NOT EXISTS files_added ON files(added);
CREATE TABLE IF NOT EXISTS matches (
  mkey TEXT PRIMARY KEY, tmdb INTEGER, kind TEXT, manual INTEGER DEFAULT 0, ts REAL,
  q TEXT                       -- the title + year it was looked up as (re-looked-up if that changes)
);
CREATE TABLE IF NOT EXISTS progress (
  path TEXT PRIMARY KEY, pos REAL, total REAL, watched INTEGER DEFAULT 0, last REAL, plays INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tracks (
  path TEXT PRIMARY KEY, root TEXT, folder TEXT,
  artist TEXT, albumartist TEXT, album TEXT, title TEXT, track INTEGER, disc INTEGER, year INTEGER, genre TEXT,
  duration INTEGER, size INTEGER, mtime REAL, added REAL, art TEXT,
  akey TEXT                    -- album: album artist | album, lower-case
);
CREATE INDEX IF NOT EXISTS tracks_akey ON tracks(akey);
CREATE INDEX IF NOT EXISTS tracks_artist ON tracks(albumartist);
CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, ts REAL, body TEXT);
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
"""


def path():
    return os.path.join(PROFILE, "library.db")


def conn():
    c = getattr(_local, "c", None)
    if c is None:
        ensure_profile()
        c = sqlite3.connect(path(), timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        try:
            c.execute("PRAGMA journal_mode=WAL")
        except sqlite3.DatabaseError:
            pass
        c.executescript(TABLES)
        cols = [r[1] for r in c.execute("PRAGMA table_info(files)")]
        for col, typ in (("root", "TEXT"), ("cat", "TEXT"), ("coll", "TEXT"), ("ord", "INTEGER")):  # older libraries
            if col not in cols:
                c.execute("ALTER TABLE files ADD COLUMN %s %s" % (col, typ))
        if "q" not in [r[1] for r in c.execute("PRAGMA table_info(matches)")]:
            c.execute("ALTER TABLE matches ADD COLUMN q TEXT")
        c.execute("CREATE INDEX IF NOT EXISTS files_root ON files(root, cat)")
        c.commit()
        _local.c = c
    return c


def q(sql, args=()):
    return conn().execute(sql, args).fetchall()


def one(sql, args=()):
    return conn().execute(sql, args).fetchone()


def run(sql, args=(), commit=True):
    c = conn()
    cur = c.execute(sql, args)
    if commit:
        c.commit()
    return cur


def commit():
    conn().commit()


def meta_get(k, default=None):
    r = one("SELECT v FROM meta WHERE k=?", (k,))
    return r["v"] if r else default


def meta_set(k, v):
    run("INSERT OR REPLACE INTO meta(k, v) VALUES(?, ?)", (k, str(v)))


# ---------------------------------------------------------------- http cache (TMDB etc.)
def cache_get(k, ttl):
    r = one("SELECT ts, body FROM cache WHERE k=?", (k,))
    if r and time.time() - r["ts"] < ttl:
        try:
            return json.loads(r["body"])
        except ValueError:
            return None
    return None


def cache_put(k, obj):
    run("INSERT OR REPLACE INTO cache(k, ts, body) VALUES(?, ?, ?)", (k, time.time(), json.dumps(obj)))


def cache_trim(days=30):
    run("DELETE FROM cache WHERE ts < ?", (time.time() - days * 86400,))


# ---------------------------------------------------------------- matches
def match_get(mkey):
    return one("SELECT * FROM matches WHERE mkey=?", (mkey,))


def match_set(mkey, tmdb, kind, manual=0, q=None):
    run("INSERT OR REPLACE INTO matches(mkey, tmdb, kind, manual, ts, q) VALUES(?, ?, ?, ?, ?, ?)",
        (mkey, tmdb or 0, kind, manual, time.time(), q))


# ---------------------------------------------------------------- progress
def progress(path_):
    return one("SELECT * FROM progress WHERE path=?", (path_,))


def progress_map(paths):
    out = {}
    paths = list(paths)
    for i in range(0, len(paths), 400):
        chunk = paths[i:i + 400]
        for r in q("SELECT * FROM progress WHERE path IN (%s)" % ",".join("?" * len(chunk)), chunk):
            out[r["path"]] = r
    return out


def save_progress(path_, pos, total, watched=None):
    r = progress(path_)
    now = time.time()
    if r is None:
        run("INSERT INTO progress(path, pos, total, watched, last, plays) VALUES(?, ?, ?, ?, ?, 0)",
            (path_, pos, total, 1 if watched else 0, now))
    else:
        w = r["watched"] if watched is None else (1 if watched else 0)
        run("UPDATE progress SET pos=?, total=?, watched=?, last=? WHERE path=?", (pos, total or r["total"], w, now, path_))


def mark_watched(paths, watched=True):
    now = time.time()
    c = conn()
    for p in paths:
        r = c.execute("SELECT plays FROM progress WHERE path=?", (p,)).fetchone()
        if r is None:
            c.execute("INSERT INTO progress(path, pos, total, watched, last, plays) VALUES(?, 0, 0, ?, ?, ?)",
                      (p, 1 if watched else 0, now, 1 if watched else 0))
        else:
            c.execute("UPDATE progress SET pos=0, watched=?, last=?, plays=plays+? WHERE path=?",
                      (1 if watched else 0, now, 1 if watched else 0, p))
    c.commit()


# ---------------------------------------------------------------- items
def item(item_id):
    return one("SELECT * FROM items WHERE id=?", (item_id,))


def item_files(item_id):
    return q("SELECT * FROM files WHERE item_id=? ORDER BY season, episode, path", (item_id,))


def seasons_of(row):
    try:
        return json.loads(row["seasons"] or "[]")
    except (ValueError, TypeError):
        return []


def drop_empty_items():
    run("DELETE FROM items WHERE id NOT IN (SELECT DISTINCT item_id FROM files WHERE item_id IS NOT NULL)")


def _prefix_rows(table, col, old):
    old = old.rstrip("/\\")
    return [r[0] for r in conn().execute(
        "SELECT %s FROM %s WHERE %s=? OR substr(%s, 1, ?) IN (?, ?)" % (col, table, col, col),
        (old, len(old) + 1, old + "/", old + "\\")).fetchall()]


def remap_prefix(old, new):
    """A NAS folder moved (new share name / IP): point everything at the new address, keeping watched history."""
    old, new = old.rstrip("/\\"), new.rstrip("/\\")
    c = conn()
    n = len(old)
    for p in _prefix_rows("progress", "path", old):
        c.execute("UPDATE OR REPLACE progress SET path=? WHERE path=?", (new + p[n:], p))
    for p in _prefix_rows("files", "path", old):
        c.execute("UPDATE OR REPLACE files SET path=? WHERE path=?", (new + p[n:], p))
    for r in c.execute("SELECT DISTINCT root FROM files WHERE root IS NOT NULL").fetchall():
        if r[0] == old or r[0].startswith(old + "/") or r[0].startswith(old + "\\"):
            c.execute("UPDATE files SET root=? WHERE root=?", (new + r[0][n:], r[0]))
    for p in _prefix_rows("items", "folder", old):
        c.execute("UPDATE items SET folder=? WHERE folder=?", (new + p[n:], p))
    for kind in ("movie:", "show:"):
        for mk in [r[0] for r in c.execute("SELECT mkey FROM matches WHERE substr(mkey, 1, ?)=?",
                                           (len(kind) + n, kind + old)).fetchall()]:
            c.execute("UPDATE OR REPLACE matches SET mkey=? WHERE mkey=?", (kind + new + mk[len(kind) + n:], mk))
        for mk in [r[0] for r in c.execute("SELECT DISTINCT mkey FROM files WHERE substr(mkey, 1, ?)=?",
                                           (len(kind) + n, kind + old)).fetchall()]:
            c.execute("UPDATE files SET mkey=? WHERE mkey=?", (kind + new + mk[len(kind) + n:], mk))
    c.commit()


def move_path(old, new):
    """A file was moved on the NAS: its watched history and library entry go with it."""
    c = conn()
    c.execute("UPDATE OR REPLACE progress SET path=? WHERE path=?", (new, old))
    c.execute("UPDATE OR REPLACE files SET path=?, label=? WHERE path=?",
              (new, new.replace("\\", "/").rsplit("/", 1)[-1], old))
    c.commit()


def forget_folder(path, section=None):
    """A NAS folder was removed from StashBox: its files leave the library (nothing on the NAS is touched)."""
    for p in _prefix_rows("files", "path", path):
        if section:
            run("DELETE FROM files WHERE path=? AND section=?", (p, section), commit=False)
        else:
            run("DELETE FROM files WHERE path=?", (p,), commit=False)
    commit()
    drop_empty_items()


def folder_stats(path, section=None):
    if section:
        r = one("SELECT COUNT(*) n, COUNT(DISTINCT item_id) t FROM files WHERE root=? AND section=?",
                (path.rstrip("/\\"), section))
    else:
        r = one("SELECT COUNT(*) n, COUNT(DISTINCT item_id) t FROM files WHERE root=?", (path.rstrip("/\\"),))
    return (r["n"], r["t"]) if r else (0, 0)


def counts():
    out = {}
    for r in q("SELECT section, kind, COUNT(*) n FROM items GROUP BY section, kind"):
        out[r["section"]] = r["n"]
    return out
