# -*- coding: utf-8 -*-
"""Music tags: ID3v2 / ID3v1 (MP3), FLAC, MP4 / M4A, Ogg Vorbis / Opus - read straight off the NAS.
Uses mutagen (script.module.mutagen) when it's installed, otherwise this small built-in reader. Anything the tags
don't say is filled in from the folder and file names (Artist / Album (Year) / 01 - Title.mp3)."""
import re
import struct

import names
import vfs

FIELDS = ("title", "artist", "albumartist", "album", "track", "disc", "year", "genre", "duration", "compilation")
_GENRES = ["Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal",
           "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative",
           "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
           "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise",
           "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock",
           "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream",
           "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle",
           "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal",
           "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock"]


def _num(v):
    m = re.match(r"\s*(\d+)", str(v or ""))
    return int(m.group(1)) if m else None


def _genre(g):
    g = (g or "").strip()
    m = re.match(r"^\(?(\d{1,3})\)?$", g) or re.match(r"^\((\d{1,3})\)", g)
    if m:
        i = int(m.group(1))
        rest = g[m.end():].strip()
        return rest or (_GENRES[i] if i < len(_GENRES) else "")
    return g


def _clean(d):
    out = {}
    for k in FIELDS:
        v = d.get(k)
        if isinstance(v, (list, tuple)):
            v = v[0] if v else None
        if isinstance(v, bytes):
            v = v.decode("utf-8", "replace")
        if isinstance(v, str):
            v = v.replace("\x00", "").strip()
            if not v:
                v = None
        out[k] = v
    for k in ("track", "disc", "year"):
        out[k] = _num(out[k]) if out[k] is not None else None
    if out["year"] and not (1000 < out["year"] < 3000):
        out["year"] = None
    out["genre"] = _genre(out["genre"]) if out["genre"] else None
    try:
        out["duration"] = int(float(out["duration"] or 0))
    except (TypeError, ValueError):
        out["duration"] = 0
    out["compilation"] = str(out["compilation"] or "").strip().lower() in ("1", "true", "yes")
    return out


# ---------------------------------------------------------------- built-in readers
def _dec(enc, b):
    try:
        if enc == 0:
            return b.decode("latin-1")
        if enc == 1:
            return b.decode("utf-16")
        if enc == 2:
            return b.decode("utf-16-be")
        return b.decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        return b.decode("latin-1", "replace")


def _synchsafe(b):
    return (b[0] << 21) | (b[1] << 14) | (b[2] << 7) | b[3]


_ID3_MAP = {"TIT2": "title", "TT2": "title", "TPE1": "artist", "TP1": "artist", "TPE2": "albumartist",
            "TP2": "albumartist", "TALB": "album", "TAL": "album", "TRCK": "track", "TRK": "track", "TPOS": "disc",
            "TPA": "disc", "TYER": "year", "TYE": "year", "TDRC": "year", "TORY": "year", "TCON": "genre",
            "TCO": "genre", "TCMP": "compilation", "TCP": "compilation", "TLEN": "_len"}


def _id3v2(f):
    """-> (tags dict, bytes taken by the tag) or (None, 0)."""
    f.seek(0)
    h = f.read(10)
    if len(h) < 10 or h[:3] != b"ID3":
        return None, 0
    ver, flags = h[3], h[5]
    size = _synchsafe(h[6:10])
    data = f.read(size)
    pos, out = 0, {}
    if flags & 0x40 and ver >= 3:  # extended header
        if ver == 3:
            pos = 4 + struct.unpack(">I", data[:4])[0]
        else:
            pos = _synchsafe(data[:4])
    idlen, hdr = (3, 6) if ver == 2 else (4, 10)
    while pos + hdr <= len(data):
        fid = data[pos:pos + idlen]
        if not fid.strip(b"\x00") or not re.match(rb"^[A-Z0-9]+$", fid):
            break
        if ver == 2:
            fsize = int.from_bytes(data[pos + 3:pos + 6], "big")
        elif ver == 4:
            fsize = _synchsafe(data[pos + 4:pos + 8])
        else:
            fsize = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        body = data[pos + hdr:pos + hdr + fsize]
        pos += hdr + fsize
        key = _ID3_MAP.get(fid.decode("ascii", "replace"))
        if not key or not body or key in out:
            continue
        txt = _dec(body[0], body[1:])
        txt = txt.split("\x00")[0].strip()
        if key == "_len":
            out["duration"] = (_num(txt) or 0) / 1000.0
        else:
            out[key] = txt
    return out, 10 + size


def _id3v1(f, size):
    if size < 128:
        return {}
    f.seek(size - 128)
    b = f.read(128)
    if b[:3] != b"TAG":
        return {}
    s = lambda x: x.split(b"\x00")[0].decode("latin-1").strip()  # noqa: E731
    out = {"title": s(b[3:33]), "artist": s(b[33:63]), "album": s(b[63:93]), "year": s(b[93:97])}
    if b[125] == 0 and b[126]:
        out["track"] = str(b[126])
    if b[127] < len(_GENRES):
        out["genre"] = _GENRES[b[127]]
    return out


def _vorbis_comments(b, pos=0):
    out = {}
    try:
        vlen = struct.unpack("<I", b[pos:pos + 4])[0]
        pos += 4 + vlen
        n = struct.unpack("<I", b[pos:pos + 4])[0]
        pos += 4
        for _ in range(min(n, 500)):
            ln = struct.unpack("<I", b[pos:pos + 4])[0]
            pos += 4
            c = b[pos:pos + ln].decode("utf-8", "replace")
            pos += ln
            if "=" in c:
                k, v = c.split("=", 1)
                k = k.lower()
                k = {"tracknumber": "track", "discnumber": "disc", "date": "year", "album artist": "albumartist",
                     "album_artist": "albumartist"}.get(k, k)
                if k in FIELDS and k not in out:
                    out[k] = v
    except (struct.error, IndexError):
        pass
    return out


def _flac(f, start):
    f.seek(start)
    if f.read(4) != b"fLaC":
        return None
    out = {}
    for _ in range(64):
        h = f.read(4)
        if len(h) < 4:
            break
        last, btype, blen = h[0] & 0x80, h[0] & 0x7F, int.from_bytes(h[1:4], "big")
        if btype == 0:  # STREAMINFO: length of the track
            si = f.read(blen)
            if len(si) >= 18:
                rate = (si[10] << 12) | (si[11] << 4) | (si[12] >> 4)
                total = ((si[13] & 0x0F) << 32) | struct.unpack(">I", si[14:18])[0]
                if rate:
                    out["duration"] = total / float(rate)
        elif btype == 4:
            out.update(_vorbis_comments(f.read(blen)))
        else:
            f.seek(blen, 1)
        if last:
            break
    return out


def _mp4(f, size):
    out = {}

    def atoms(start, end):
        pos = start
        while pos + 8 <= end:
            f.seek(pos)
            h = f.read(8)
            if len(h) < 8:
                return
            sz, typ = struct.unpack(">I", h[:4])[0], h[4:8]
            hl = 8
            if sz == 1:
                sz = struct.unpack(">Q", f.read(8))[0]
                hl = 16
            elif sz == 0:
                sz = end - pos
            if sz < hl:
                return
            yield typ, pos + hl, pos + sz
            pos += sz

    def find(start, end, path):
        for typ, s, e in atoms(start, end):
            if typ == path[0]:
                if len(path) == 1:
                    return s, e
                skip = 4 if typ == b"meta" else 0
                return find(s + skip, e, path[1:])
        return None
    moov = find(0, size, [b"moov"])
    if not moov:
        return None
    mvhd = find(moov[0], moov[1], [b"mvhd"])
    if mvhd:
        f.seek(mvhd[0])
        b = f.read(32)
        if b and b[0] == 1 and len(b) >= 32:
            scale, dur = struct.unpack(">I", b[20:24])[0], struct.unpack(">Q", b[24:32])[0]
        elif len(b) >= 20:
            scale, dur = struct.unpack(">I", b[12:16])[0], struct.unpack(">I", b[16:20])[0]
        else:
            scale, dur = 0, 0
        if scale:
            out["duration"] = dur / float(scale)
    ilst = find(moov[0], moov[1], [b"udta", b"meta", b"ilst"])
    if not ilst:
        return out
    keys = {b"\xa9nam": "title", b"\xa9ART": "artist", b"aART": "albumartist", b"\xa9alb": "album",
            b"trkn": "track", b"disk": "disc", b"\xa9day": "year", b"\xa9gen": "genre", b"gnre": "genre",
            b"cpil": "compilation"}
    for typ, s, e in atoms(ilst[0], ilst[1]):
        k = keys.get(typ)
        if not k:
            continue
        for dt, ds, de in atoms(s, e):
            if dt != b"data":
                continue
            f.seek(ds)
            b = f.read(min(de - ds, 4096))
            val = b[8:]
            if k in ("track", "disc"):
                out[k] = str(struct.unpack(">H", val[2:4])[0]) if len(val) >= 4 else None
            elif typ == b"gnre":
                i = struct.unpack(">H", val[:2])[0] - 1 if len(val) >= 2 else -1
                out[k] = _GENRES[i] if 0 <= i < len(_GENRES) else None
            elif k == "compilation":
                out[k] = "1" if val[:1] == b"\x01" else ""
            else:
                out[k] = val.decode("utf-8", "replace")
            break
    return out


def _ogg(f):
    f.seek(0)
    b = f.read(65536)
    if b[:4] != b"OggS":
        return None
    i = b.find(b"\x03vorbis")
    if i >= 0:
        return _vorbis_comments(b, i + 7)
    i = b.find(b"OpusTags")
    if i >= 0:
        return _vorbis_comments(b, i + 8)
    return {}


def _builtin(path):
    f = vfs.Reader(path)
    try:
        size = f._size
        t, start = _id3v2(f)
        e = names.ext(path)
        if e == ".flac":
            return _flac(f, start) or t or {}
        if e in (".m4a", ".mp4", ".aac", ".alac", ".m4b"):
            return _mp4(f, size) or {}
        if e in (".ogg", ".oga", ".opus"):
            return _ogg(f) or {}
        if t:
            return t
        return _id3v1(f, size)
    finally:
        f.close()


def _mutagen(path):
    try:
        import mutagen
    except ImportError:
        return None
    f = vfs.Reader(path)
    f.name = path.rsplit("/", 1)[-1]
    try:
        m = mutagen.File(f, easy=True)
        if m is None:
            return None
        g = lambda k: (m.get(k) or [None])[0]  # noqa: E731
        return {"title": g("title"), "artist": g("artist"), "albumartist": g("albumartist") or g("album artist"),
                "album": g("album"), "track": g("tracknumber"), "disc": g("discnumber"), "year": g("date"),
                "genre": g("genre"), "compilation": g("compilation"),
                "duration": getattr(getattr(m, "info", None), "length", 0)}
    except Exception:
        return None
    finally:
        f.close()


# ---------------------------------------------------------------- folder / file names
_DISC_DIR = re.compile(r"(?i)^(?:cd|disc|disk)[\s._-]*(\d{1,2})$")
_TRACK = re.compile(r"^\s*(?:(\d)[-.](\d{2})|(\d{1,3}))(?:\s*[-._)]\s*|\s+)(.+)$")
_ALBUM_YEAR = re.compile(r"^(?:\(?\[?((?:19|20)\d{2})\]?\)?\s*[-.]?\s*)?(.*?)(?:\s*[\[(]((?:19|20)\d{2})[\])])?$")


def from_names(path, root=None):
    """Artist / Album (Year) / 01 - Title.mp3 -> tags (used where the file's own tags say nothing)."""
    parts = [p for p in re.split(r"[/\\]", path) if p]
    fname = names.stem(parts[-1])
    folders = parts[:-1]
    if root:
        depth = len([p for p in re.split(r"[/\\]", root) if p])
        folders = parts[depth:-1] if len(parts) > depth else []
    out = {}
    if folders and _DISC_DIR.match(folders[-1]):
        out["disc"] = int(_DISC_DIR.match(folders[-1]).group(1))
        folders = folders[:-1]
    m = _TRACK.match(fname.replace("_", " "))
    title = fname.replace("_", " ")
    if m:
        if m.group(1):
            out["disc"], out["track"] = int(m.group(1)), int(m.group(2))
        else:
            out["track"] = int(m.group(3))
        title = m.group(4)
    if " - " in title:
        a, b = title.split(" - ", 1)
        if not out.get("artist"):
            out["artist"] = a.strip()
        title = b
    out["title"] = title.strip()
    if folders:
        alb = folders[-1]
        if " - " in alb:
            a, alb = alb.split(" - ", 1)
            out.setdefault("artist", a.strip())
            out["albumartist"] = a.strip()
        m = _ALBUM_YEAR.match(alb.strip())
        if m:
            out["album"] = (m.group(2) or alb).strip()
            y = m.group(1) or m.group(3)
            if y:
                out["year"] = y
        if len(folders) >= 2 and "albumartist" not in out:
            out["albumartist"] = folders[-2]
            out.setdefault("artist", folders[-2])
    return out


def read(path, root=None):
    """-> dict(title, artist, albumartist, album, track, disc, year, genre, duration, compilation)."""
    got = _mutagen(path)
    if got is None:
        try:
            got = _builtin(path)
        except Exception:
            got = {}
    got = dict((k, v) for k, v in (got or {}).items() if v not in (None, "", []))
    for k, v in from_names(path, root).items():
        got.setdefault(k, v)
    return _clean(got)
