# -*- coding: utf-8 -*-
"""Shared helpers: settings, paths, log, notifications, small JSON stores."""
import json
import os
import re
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.stashbox"
NAME = "StashBox"
_A = xbmcaddon.Addon(ADDON_ID)
VERSION = _A.getAddonInfo("version")
PATH = _A.getAddonInfo("path")
PROFILE = xbmcvfs.translatePath(_A.getAddonInfo("profile"))
MEDIA = os.path.join(PATH, "resources", "media")
UA = {"User-Agent": "StashBox/%s (Kodi add-on)" % VERSION}
HOME = xbmcgui.Window(10000)

SECTIONS = [  # id, label, setting, kind
    ("movies", "Movies", "movies_path", "movie"),
    ("tv", "TV Shows", "tv_path", "show"),
    ("anime", "Anime", "anime_path", "show"),
    ("kdrama", "K-Dramas", "kdrama_path", "show"),
]
SECTION_LABEL = dict((s[0], s[1]) for s in SECTIONS)
SECTION_KIND = dict((s[0], s[3]) for s in SECTIONS)
SECTION_LABEL["music"] = "Music"  # music has its own folders + scanner (not one of the video SECTIONS)
SECTION_KIND["music"] = "music"


def addon():
    """A fresh Addon object, so the background service sees settings changed since it started."""
    return xbmcaddon.Addon(ADDON_ID)


def setting(k, default=""):
    try:
        v = addon().getSetting(k)
    except Exception:
        v = ""
    return v if v != "" else default


def setting_bool(k, default=False):
    v = setting(k, "")
    return default if v == "" else v.lower() == "true"


def setting_int(k, default=0):
    try:
        return int(float(setting(k, str(default))))
    except ValueError:
        return default


def set_setting(k, v):
    addon().setSetting(k, v if isinstance(v, str) else str(v).lower() if isinstance(v, bool) else str(v))


# ---------------------------------------------------------------- NAS folders ("locations"), several per section
LOC_FILE = "locations.json"


def npath(p):
    return (p or "").strip().rstrip("/\\")


def under(path, root):
    """Is path the root folder itself or somewhere inside it? (No 'Movies2' matching 'Movies'.)"""
    p = npath(path).replace("\\", "/")
    r = npath(root).replace("\\", "/")
    return bool(r) and (p == r or p.startswith(r + "/"))


def rel(path, root):
    """Path below root, with / separators ('' for the root itself)."""
    return npath(path)[len(npath(root)):].strip("/\\").replace("\\", "/")


def auto_label(p):
    parts = [x for x in re.split(r"[/\\]+", hide_creds(npath(p)).split("://", 1)[-1]) if x and x != "***@"]
    parts = [re.sub(r"^\*\*\*@", "", x) for x in parts]
    return " > ".join(parts[-2:]) if len(parts) >= 2 else (parts[0] if parts else p)


def loc_label(loc):
    return loc.get("label") or auto_label(loc.get("path", ""))


def load_locations():
    """{section: [{"path", "label", "default"}]}. First run: moves the old one-folder-per-section settings over."""
    if os.path.exists(os.path.join(PROFILE, LOC_FILE)):
        d = load_json(LOC_FILE, {})
    else:
        d = {}
        for sid, _l, key, _k in SECTIONS:
            p = npath(setting(key))
            if p:
                d[sid] = [{"path": p, "label": auto_label(p), "default": True}]
        if d:
            save_json(LOC_FILE, d)
    for sid in list(d):
        locs = [x for x in d[sid] if x.get("path")]
        if locs and not any(x.get("default") for x in locs):
            locs[0]["default"] = True
        # default first, then the order they were added
        d[sid] = sorted(locs, key=lambda x: not x.get("default"))
    return d


def save_locations(d):
    save_json(LOC_FILE, d)


def locations(sec):
    return load_locations().get(sec, [])


def all_locations():
    """[(section, location)] for every folder."""
    d = load_locations()
    return [(s[0], x) for s in SECTIONS for x in d.get(s[0], [])]


def music_locations():
    return load_locations().get("music", [])


RULES_FILE = "folder_rules.json"
RULE_TEXT = {"one": "one show / film (its own)", "many": "separate shows / films", "skip": "skipped",
             "part": "part of the show above"}


def load_rules():
    return load_json(RULES_FILE, {})


def set_rule(path, kind):
    """kind: 'one', 'many', 'skip' or None (back to automatic)."""
    r = load_rules()
    if kind:
        r[npath(path)] = kind
    else:
        r.pop(npath(path), None)
    save_json(RULES_FILE, r)


def remap_rules(old, new):
    r = load_rules()
    old, new = npath(old), npath(new)
    changed = {}
    for k, v in r.items():
        if under(k, old):
            changed[new + k[len(old):]] = v
        else:
            changed[k] = v
    save_json(RULES_FILE, changed)


def location_for(path):
    """-> (section, location) whose folder holds this path (the deepest match), or (None, None)."""
    best = (None, None)
    for sec, loc in all_locations():
        if under(path, loc["path"]) and (best[1] is None or len(loc["path"]) > len(best[1]["path"])):
            best = (sec, loc)
    return best


def section_path(sec):
    """The section's default folder (where brand-new downloads go unless you pick another)."""
    locs = locations(sec)
    return locs[0]["path"] if locs else ""


def sections_set_up():
    d = load_locations()
    return [s for s in SECTIONS if d.get(s[0])]


def ensure_profile():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE, exist_ok=True)
    return PROFILE


def hide_creds(s):
    """smb://user:pass@host/share -> smb://***@host/share (for logs and screens)."""
    return re.sub(r"(://)[^/@\s]+@", r"\1***@", str(s))


# ---------------------------------------------------------------- log
LOG_FILE = os.path.join(PROFILE, "log.txt")


def log(msg, level="info"):
    msg = hide_creds(msg)
    lvl = {"debug": xbmc.LOGDEBUG, "info": xbmc.LOGINFO, "warn": xbmc.LOGWARNING, "error": xbmc.LOGERROR}.get(level,
                                                                                                           xbmc.LOGINFO)
    try:
        xbmc.log("[%s] %s" % (NAME, msg), lvl)
    except Exception:
        pass
    if level == "debug" and not setting_bool("debug_log"):
        return
    try:
        ensure_profile()
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 400000:
            with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                keep = f.read()[-200000:]
            with open(LOG_FILE, "w", encoding="utf-8") as f:
                f.write(keep)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write("%s %-5s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), level.upper(), msg))
    except Exception:
        pass


def log_exc(where):
    log("%s crashed:\n%s" % (where, traceback.format_exc()), "error")


def notify(msg, kind="info", ms=4000):
    icon = {"info": xbmcgui.NOTIFICATION_INFO, "warn": xbmcgui.NOTIFICATION_WARNING,
            "error": xbmcgui.NOTIFICATION_ERROR}.get(kind, xbmcgui.NOTIFICATION_INFO)
    try:
        xbmcgui.Dialog().notification(NAME, hide_creds(msg)[:250], icon, ms)
    except Exception:
        pass


# ---------------------------------------------------------------- JSON stores
def load_json(name, default=None):
    p = os.path.join(PROFILE, name)
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def replace_file(tmp, p):
    """os.replace(tmp, p) that copes with Windows: it refuses ('Access is denied', WinError 5 / 32) while another
    process - the Kodi window reading the Downloads list, a virus scanner - has p open. Wait and try again, then
    write the contents straight into p."""
    last = None
    for i in range(15):
        try:
            os.replace(tmp, p)
            return
        except OSError as e:  # PermissionError on Windows
            last = e
            if not isinstance(e, PermissionError) and getattr(e, "winerror", None) not in (5, 32, 33):
                raise
            time.sleep(0.04 * (i + 1))
    try:
        with open(tmp, "rb") as s:
            data = s.read()
        with open(p, "wb") as f:
            f.write(data)
    except OSError:
        raise last
    try:
        os.remove(tmp)
    except OSError:
        pass
    log("Saving %s: Windows kept it locked, so it was written in place" % os.path.basename(p), "debug")


def save_json(name, obj):
    ensure_profile()
    p = os.path.join(PROFILE, name)
    tmp = p + ".tmp%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    replace_file(tmp, p)


# ---------------------------------------------------------------- formatting
def fmt_size(n):
    try:
        n = float(n or 0)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%.0f %s" if unit in ("B", "KB", "MB") else "%.2f %s") % (n, unit)
        n /= 1024.0


def fmt_time(sec):
    sec = int(sec or 0)
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def fmt_speed(bps):
    return "%s/s" % fmt_size(bps) if bps else ""


def media_icon(name):
    p = os.path.join(MEDIA, name + ".png")
    return p if os.path.exists(p) else os.path.join(PATH, "icon.png")


# ---------------------------------------------------------------- service <-> plugin signals
def request(name, value="1"):
    """Ask the background service to do something (scan, wake the download queue)."""
    HOME.setProperty("stashbox.req." + name, value if isinstance(value, str) else json.dumps(value))


def take_request(name):
    v = HOME.getProperty("stashbox.req." + name)
    if v:
        HOME.clearProperty("stashbox.req." + name)
    return v
