# -*- coding: utf-8 -*-
"""File-name parsing (release names, Plex-style names, anime numbering) and Plex-style naming for new files."""
import re

VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".m2ts", ".wmv", ".webm", ".mpg", ".mpeg", ".vob",
             ".iso", ".divx", ".flv", ".3gp", ".ogm", ".rmvb")
SUB_EXT = (".srt", ".ass", ".ssa", ".sub", ".idx", ".vtt")
ARCHIVE_EXT = (".zip", ".rar", ".7z", ".tar", ".gz")
# never media: NAS system folders
SYSTEM_DIRS = ("@eadir", "#recycle", ".recycle", "$recycle.bin", ".trash", "lost+found", ".actors", "metadata",
               ".deletedbytmm", "#snapshot", "@recycle", ".@__thumb", "@tmp", "system volume information")
# bonus material - only skipped INSIDE a film / show's own folder ("Other" or "Shorts" can be your categories)
EXTRAS_DIRS = ("extras", "featurettes", "behind the scenes", "deleted scenes", "interviews", "scenes", "shorts",
               "trailers", "sample", "samples", "other", "bonus", "bonus features", "special features")
SKIP_DIRS = SYSTEM_DIRS + EXTRAS_DIRS

# words that end a title in a release name
_STOP = re.compile(
    r"(?i)(?:^|[\s\[\(])(?:2160p|1080p|1080i|720p|576p|480p|4k|uhd|hdr10?\+?|dv|dovi|bluray|blu-ray|bdrip|brrip|"
    r"web[\s-]?dl|webrip|web|hdtv|hdrip|dvdrip|dvdscr|dvd|remux|x26[45]|h\.?26[45]|hevc|avc|xvid|divx|10bit|8bit|"
    r"aac|ac3|dts|ddp?5|atmos|truehd|flac|proper|repack|extended|unrated|remastered|directors[\s.]cut|"
    r"imax|internal|limited|multi|dual[\s-]audio|subbed|dubbed|complete|batch|cam|hdcam|ts|telesync|"
    r"amzn|nf|dsnp|hmax|atvp|pcok|hulu|criterion|ppvrip|ppv|tvrip|satrip|vhsrip|dsr|pdtv|r5|workprint|ntsc|pal|"
    r"untouched|dvd5|dvd9|dvdr|uncut|xxx|bd|dsny)(?=$|[\s\]\)\-\[\(])")
# only at the very end of a title: "Deck The Halls WS", "The Chronicles of Riddick DC", "... eng ita"
_TAIL_TAGS = re.compile(r"(?i)(?:[\s(\[]+(?:ws|fs|dc|se|int|full|eng|ita|hin|por|fre|fra|ger|deu|spa|esp|rus|jap|kor|dub|subs?|"
                        r"multi|dual|vostfr|nordic|super duper cut|directors? cut|special edition|the series|"
                        r"(?:the )?(?:completes?|definitive|original)(?: tv)? (?:series|collection))[\])]*)+\s*$")
GENRES = ("action", "adventure", "animation", "animated", "anime", "cartoon", "comedy", "crime", "documentary",
          "drama", "family", "fantasy", "history", "horror", "kids", "music", "musical", "mystery", "romance",
          "sci-fi", "scifi", "sci fi", "science fiction", "thriller", "war", "western", "christmas", "disney")
_GENRE_TAIL = re.compile(r"(?i)(?:\s+-\s*|\s*\(\s*)(?:%s)(?:\s*[,/&]\s*(?:%s))*\s*\)?\s*$" % (
    "|".join(re.escape(g) for g in GENRES), "|".join(re.escape(g) for g in GENRES)))
_YEAR = re.compile(r"(?<![0-9])((?:19|20)\d{2})(?![0-9])")
_SE = re.compile(r"(?i)\bS(\d{1,2})[\s._-]?E(\d{1,3})(?:[\s._-]?(?:-|E)[\s._-]?E?(\d{1,3}))?\b")
_X = re.compile(r"(?i)(?<![0-9a-z])(\d{1,2})x(\d{2,3})(?:-(\d{2,3}))?(?![0-9])")
_SEASON_EP_WORDS = re.compile(r"(?i)season[\s._-]*(\d{1,2})[\s._-]*(?:episode|ep)[\s._-]*(\d{1,3})")
_EP_ONLY = re.compile(r"(?i)(?:^|[\s._\-\[])(?:ep|episode|e)[\s._-]?(\d{1,4})(?:v\d)?(?=$|[\s._\-\]\(])")
_ANIME_DASH = re.compile(r"(?:^|\s)-\s*(\d{1,4})(?:v\d)?(?:\s*-\s*(\d{1,4}))?(?=$|\s|\[|\()")
_SEASON_DIR = re.compile(r"(?i)^(?:season|series|staffel|saison|temporada|book)[\s._-]*(\d{1,3})\b|^s(\d{1,2})$")
_WORD_NUM = dict((w, i) for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen "
    "eighteen nineteen twenty".split()))
_SEASON_WORD = re.compile(r"(?i)^(?:season|series|book)[\s._-]+(%s)\b" % "|".join(_WORD_NUM))
_PART_LIKE = re.compile(r"(?i)^(?:(?:disc|disk|dvd|cd|bd|blu-?ray|part|pt|vol|volume|batch|episodes?|eps?|complete|"
                        r"collection|pack)[\s._-]*(?:[\d\s._-]*|(?:%s)(?:\s+of\s+\w+)?)|\d{1,4}(?:\s*-\s*\d{1,4})?)$"
                        % "|".join(_WORD_NUM))
_PART_TAIL = re.compile(r"(?i)\s+(?:\d{1,4}\s*[-~]\s*\d{1,4}|(?:disc|disk|dvd|cd|part|pt|vol|volume|batch|eps?|episodes?)"
                        r"\s*\d{0,4}(?:\s*[-~]\s*\d{1,4})?)\s*$")
_SPECIALS_DIR = re.compile(r"(?i)^(?:specials?|season[\s._-]*0+|extras?)$")
_PACK = re.compile(r"(?i)\b(?:S(\d{1,2})(?![\dE])(?:[\s._-]*-[\s._-]*S?(\d{1,2}))?|season[\s._-]*(\d{1,2})"
                   r"(?:[\s._-]*(?:-|to)[\s._-]*(\d{1,2}))?|complete|batch|collection)\b")
_RES = [("2160p", re.compile(r"(?i)2160p|\b4k\b|\buhd\b")), ("1080p", re.compile(r"(?i)1080[pi]")),
        ("720p", re.compile(r"(?i)720p")), ("480p", re.compile(r"(?i)480p|576p|\bsd\b|dvdrip|xvid"))]
_CAM = re.compile(r"(?i)\b(?:cam|hdcam|camrip|ts|hdts|telesync|telecine|tc|hdtc|scr|screener|dvdscr)\b")
_GROUP_LEAD = re.compile(r"^\s*(?:\[[^\]]*\]\s*|\([^\)]*\)\s*)+")
_BAD_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def ext(name):
    m = re.search(r"\.[A-Za-z0-9]{2,5}$", name or "")
    return m.group(0).lower() if m else ""


def is_video(name):
    return ext(name) in VIDEO_EXT


AUDIO_EXT = (".mp3", ".flac", ".m4a", ".aac", ".ogg", ".oga", ".opus", ".wav", ".wma", ".alac", ".ape", ".wv", ".aiff",
             ".aif", ".dsf", ".dff", ".mka", ".mpc")


def is_audio(name):
    return ext(name) in AUDIO_EXT


def is_sub(name):
    return ext(name) in SUB_EXT


def is_archive(name):
    n = (name or "").lower()
    return ext(n) in ARCHIVE_EXT or bool(re.search(r"\.r\d\d$|\.part\d+\.rar$|\.7z\.\d{3}$|\.zip\.\d{3}$", n))


# ---------------------------------------------------------------- DVD / Blu-ray folder rips
DISC_DIRS = ("video_ts", "bdmv", "audio_ts", "certificate", "jar", "aacs", "bdsvm")
_DVD_JUNK = re.compile(
    r"(?i)(?:[\s_.-]+(?:d|disc|disk|dvd|cd|bd)[\s_.-]?\d{1,2}|[\s_.-]+(?:se|ce|ws|fs|pal|ntsc|r[1-6]|uk|us|eu|dvd\d?|"
    r"dvd[\s_.-]?(?:5|9|r)|special[\s_.-]+edition|collectors?[\s_.-]+edition|widescreen|full[\s_.-]?screen|"
    r"extended|directors[\s_.-]+cut|final[\s_.-]+cut|theatrical|unrated|ultimate[\s_.-]+edition|bluray|"
    r"blu[\s_.-]?ray|bd25|bd50|remastered))+$")
_GENERIC_DISC = re.compile(r"(?i)^(?:video_ts|bdmv|dvd|bluray|blu-ray|bd|disc|disk|cd|d|dvd[\s_.-]?video|"
                           r"(?:disc|disk|dvd|cd|bd|d)[\s_.-]?\d{1,2}|\d{1,2})$")


def disc_play_path(folder, dirs, files):
    """If this folder is a DVD / Blu-ray rip, the file Kodi plays it from (menus and all), else None."""
    low_d = dict((d.lower(), d) for d in dirs)
    low_f = set(f.lower() for f in files)
    if "video_ts" in low_d:
        return _join(folder, low_d["video_ts"], "VIDEO_TS.IFO")
    if "bdmv" in low_d:
        return _join(folder, low_d["bdmv"], "index.bdmv")
    if "video_ts.ifo" in low_f:  # the VOBs straight in the folder
        return _join(folder, next(f for f in files if f.lower() == "video_ts.ifo"))
    if "index.bdmv" in low_f and "stream" in low_d:
        return _join(folder, next(f for f in files if f.lower() == "index.bdmv"))
    return None


def _join(base, *parts):
    s = "\\" if ("\\" in base and "://" not in base) else "/"
    return base.rstrip("/\\") + s + s.join(parts)


def is_disc_path(path):
    p = (path or "").lower()
    return p.endswith("video_ts.ifo") or p.endswith("index.bdmv")


def disc_folder(path):
    """…/Film/VIDEO_TS/VIDEO_TS.IFO -> …/Film (the folder named after the disc)."""
    parts = re.split(r"[/\\]", (path or "").rstrip("/\\"))
    parts = parts[:-1]  # the IFO / index.bdmv
    if parts and parts[-1].lower() in ("video_ts", "bdmv"):
        parts = parts[:-1]
    sep = "\\" if ("\\" in path and "://" not in path) else "/"
    return sep.join(parts)


def disc_kind(path):
    return "Blu-ray" if (path or "").lower().endswith("index.bdmv") else "DVD"


def generic_disc_name(name):
    """'VIDEO_TS', 'DVD', 'Disc 1', 'D2' - a folder name that doesn't say which disc it is."""
    return bool(_GENERIC_DISC.match((name or "").strip()))


def clean_disc_label(name):
    """'THE_MATRIX_SE' -> 'The Matrix', 'LOTR_FOTR_D1' -> 'Lotr Fotr', 'Gladiator (2000) [DVD]' -> 'Gladiator (2000)'."""
    s = re.sub(r"[\[(](?:dvd|pal|ntsc|r[1-6]|dvd5|dvd9|bluray|bd)[\])]", " ", name or "", flags=re.I)
    s = s.replace("_", " ").strip()
    prev = None
    while prev != s:
        prev = s
        s = _DVD_JUNK.sub("", s).strip(" .-_")
    if s.isupper() and len(s) > 3:
        s = " ".join(w.capitalize() if len(w) > 2 or not w.isalpha() else w.lower() for w in s.split())
        s = s[:1].upper() + s[1:]
    return s or name


def disc_number(name):
    m = re.search(r"(?i)(?:^|[\s_.-])(?:disc|disk|dvd|cd|bd|d)[\s_.-]?(\d{1,2})\b", name or "")
    return int(m.group(1)) if m else None


def is_sample(name):
    n = (name or "").lower()
    if re.match(r"^(?:rarbg(?:\.com)?|etrg|www\.[a-z0-9-]+\.[a-z]+|yts\.[a-z]+)(?:[._ -].*)?\.[a-z0-9]+$", n):
        return True  # a release group's advert clip ("RARBG.mp4", "www.YTS.MX.mp4")
    return bool(re.search(r"(?:^|[\s._\-\[\(])(?:sample|trailer|teaser)(?:[\s._\-\]\)]|$)", n)) or "-sample." in n


def skip_dir(name):
    """Bonus-material folder (inside a title's folder)."""
    return (name or "").strip().lower() in EXTRAS_DIRS


def system_dir(name):
    n = (name or "").strip().lower()
    return n in SYSTEM_DIRS or n.startswith((".", "@", "#", "$"))


def stem(name):
    n = name.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    e = ext(n)
    return n[:-len(e)] if e else n


def tidy(s):
    """Release-name separators to spaces, collapse whitespace."""
    s = re.sub(r"(?<=[A-Za-z0-9'!])\.(?=[A-Za-z0-9])|_", " ", s or "")
    s = re.sub(r"\.(?=\s|$)|(?<=\s)\.", " ", s)
    return re.sub(r"\s+", " ", s).strip(" -._")


def clean_title(s):
    s = re.sub(r"[\[\(]\s*[\]\)]", " ", s)
    s = re.sub(r"\s+", " ", s).strip(" -._[(+,")
    if len(s) > 2 and s[0] in "'\"" and s[-1] == s[0]:
        s = s[1:-1].strip()  # "'Carry on Constable'"
    return s


def dehyphen(s):
    """'10-Rules-for-Sleeping-Around---ENG' -> '10 Rules for Sleeping Around ENG', 'CBeebies-Tinga-Tinga-Tales  Season 1'
    -> 'CBeebies Tinga Tinga Tales  Season 1' (hyphens used as spaces; 'Spider-Man' keeps its one)."""
    s = s or ""
    if " " not in s.strip() and s.count("-") >= 2:
        return re.sub(r"\s+", " ", re.sub(r"-+", " ", s)).strip()
    return re.sub(r"(?<!\S)[^\s-]+(?:-+[^\s-]+){2,}(?!\S)", lambda m: re.sub(r"-+", " ", m.group(0)), s)


def clean_tail(t):
    """Take '- Fantasy', '(Comedy)', 'WS', 'DC', 'eng ita' off the end of a title."""
    prev = None
    while prev != t and t:
        prev = t
        t2 = _GENRE_TAIL.sub("", t).strip(" -")
        t2 = _TAIL_TAGS.sub("", t2).strip(" -")
        if names_ok(t2):
            t = t2
    return t


def norm(s):
    """For comparing titles: lowercase ascii-ish words only."""
    s = (s or "").lower().replace("&", " and ")
    s = re.sub(r"[’']", "", s)
    s = re.sub(r"[^a-z0-9À-￿]+", " ", s)
    s = re.sub(r"^(?:the|a|an) ", "", s.strip())
    return s.strip()


def resolution(name):
    for label, rx in _RES:
        if rx.search(name or ""):
            return label
    return "SD?"


def is_cam(name):
    return bool(_CAM.search(tidy(name or "")))


def _cut_title(s):
    """Text before the first quality word / year."""
    m = _STOP.search(s)
    if m and m.start() > 0:
        s = s[:m.start()]
    return s


def parse_movie(name):
    """'The.Matrix.1999.1080p.BluRay' / 'The Matrix (1999)' -> ('The Matrix', 1999). year may be None."""
    s = tidy(dehyphen(_GROUP_LEAD.sub("", stem(name))))
    s = re.sub(r"(?i)\{(?:tmdb|imdb|tvdb)[-=][^}]*\}|\[(?:tmdbid|imdbid)[-=][^\]]*\]", " ", s)
    import time as _t
    this_year = _t.localtime().tm_year
    # "Blade Runner 2049" - a number past next year isn't a release year
    years = [m for m in _YEAR.finditer(s) if m.start() > 0 and int(m.group(1)) <= this_year + 1]
    year = None
    if years:
        # the last year that isn't the whole title ("1917 (2019)", "2001 A Space Odyssey 1968")
        m = years[-1]
        year = int(m.group(1))
        title = s[:m.start()]
    else:
        title = _cut_title(s)
    title = _cut_title(title)
    title = re.sub(r"(?i)\b(?:cd|disc|part|pt)[\s._-]?\d\b.*$", "", title)
    title = clean_tail(clean_title(title))
    return clean_title(title) or clean_title(s), year


def tmdb_id_hint(name):
    m = re.search(r"(?i)[\{\[](?:tmdb|tmdbid)[-=](\d+)[\}\]]", name or "")
    return int(m.group(1)) if m else None


def imdb_hint(name):
    """'DrWho2005, 2005-03-26, S01E01, Rose (tt0436992)' -> 'tt0436992'."""
    m = re.search(r"(?<![a-z0-9])(tt\d{7,9})(?![0-9])", name or "")
    return m.group(1) if m else None


def is_extra_file(name):
    """'extra - My Maiden Voyage - An Interview...', 'Featurette - Making Of.mkv': bonus material, not an episode."""
    return bool(re.match(r"(?i)^\s*(?:extras?|bonus|featurette|interview|behind the scenes|deleted scenes?|making of|"
                         r"trailer|promo)\s*[-:_]\s", stem(name or "")))


def parse_episode(name):
    """-> dict(season, episode, ep_end, absolute) from a file name; season None when only an absolute number."""
    s = tidy(stem(name))
    m = _SE.search(s) or _SEASON_EP_WORDS.search(s)
    if m:
        se, ep = int(m.group(1)), int(m.group(2))
        end = int(m.group(3)) if m.lastindex and m.lastindex >= 3 and m.group(3) else None
        return {"season": se, "episode": ep, "ep_end": end if end and end > ep else None, "absolute": False}
    m = _X.search(s)
    if m:  # "19x01" is season 19 - _X can't match "1920x1080" (no digit may come before the season)
        se, ep = int(m.group(1)), int(m.group(2))
        end = int(m.group(3)) if m.group(3) else None
        return {"season": se, "episode": ep, "ep_end": end if end and end > ep else None, "absolute": False}
    raw = stem(name)
    s2 = _GROUP_LEAD.sub("", raw).replace("_", " ")
    s2 = re.sub(r"[\[\(][^\]\)]*[\]\)]", " ", s2)  # drop [1080p] (CRC) etc.
    m = _ANIME_DASH.search(s2)
    if m:
        ep = int(m.group(1))
        end = int(m.group(2)) if m.group(2) else None
        if not (1900 <= ep <= 2099):
            return {"season": None, "episode": ep, "ep_end": end if end and end > ep else None, "absolute": True}
    m = _EP_ONLY.search(s2)
    if m:
        ep = int(m.group(1))
        if not (1900 <= ep <= 2099):
            return {"season": None, "episode": ep, "ep_end": None, "absolute": True}
    # bare "05.mkv" / "Show 05.mkv" inside a season folder
    m = re.search(r"(?:^|\s)(\d{1,3})(?:v\d)?\s*$", re.sub(r"[\[\(].*?[\]\)]", " ", tidy(raw)))
    if m:
        return {"season": None, "episode": int(m.group(1)), "ep_end": None, "absolute": True}
    return None


_SEASON_TOKEN = None


def season_title(name):
    """The show name in front of a season marker: 'Bluey S01' -> 'Bluey', 'Breaking.Bad.S01.1080p' -> 'Breaking Bad',
    'Season 1' / 'S02' / 'Specials' -> ''. None if it isn't a season folder at all."""
    global _SEASON_TOKEN
    if season_from_dir(name) is None:
        return None
    if _SEASON_TOKEN is None:
        _SEASON_TOKEN = re.compile(r"(?i)(?:^|[\s(\[])(?:S\d{1,2}(?![\dE])|(?:season|series|staffel|saison|temporada|book)"
                                   r"[\s._-]*(?:\d{1,3}|%s)\b|specials?\b)" % "|".join(_WORD_NUM))
    t = tidy(name)
    m = _SEASON_TOKEN.search(t)
    if not m or m.start() == 0:
        return ""
    return parse_show_name(t[:m.start()].rstrip(" -([")) [0]


def part_like(name):
    """'Disc 1', 'Vol 2', '001-100', 'Batch' - a folder that's a slice of a show, not a show's name."""
    return bool(_PART_LIKE.match(tidy(name or "")))


_PART_TAIL2 = re.compile(r"(?i)\s*-?\s+(?:part|pt|p|vol|volume|disc|disk|d|cd)\.?\s*(?:\d{1,3}|%s)\b"
                         r"(?:\s*of\s*\d+)?(?:\s.*)?$" % "|".join(_WORD_NUM))


def clean_part_title(t):
    """'Naruto Shippuden 001-100' -> 'Naruto Shippuden', 'Friends Disc 2' -> 'Friends', 'Ducktales - Part 1 of 7' /
    'Ducktales P6 + fixed ep 65' -> 'Ducktales', 'DRAGONS RIDERS OF BERK PT1 D1' -> 'DRAGONS RIDERS OF BERK'.
    ('The 100' stays.)"""
    prev = None
    while prev != t:
        prev = t
        t2 = _PART_TAIL.sub("", t or "").strip(" -")
        t2 = _PART_TAIL2.sub("", t2).strip(" -+")
        t = t2 if names_ok(t2) else t
    return t


def names_ok(t):
    return bool(re.search(r"[A-Za-z\u00c0-\uffff]", t or ""))


def season_from_dir(dirname):
    d = (dirname or "").strip()
    if _SPECIALS_DIR.match(d):
        return 0
    m = _SEASON_WORD.match(tidy(d))
    if m:
        return _WORD_NUM[m.group(1).lower()]
    m = _SEASON_DIR.match(d)
    if m:
        return int(m.group(1) or m.group(2))
    m = re.search(r"(?i)\bS(\d{1,2})(?![\dE])|\b(?:season|series)[\s._-]*(\d{1,2})\b", tidy(d))
    if m:
        return int(m.group(1) or m.group(2))
    return None


_SEASON_MARK = re.compile(r"(?i)\b(?:S\d{1,2}(?![\dE])|(?:seasons?|series)[\s._-]*(?:\d{1,3}|%s)\b|"
                          r"(?:the\s+)?(?:first|second|third|fourth|fifth|1st|2nd|3rd|4th|5th)(?:\s+(?:and|&)\s+\w+)?"
                          r"\s+seasons?\b|mini[\s-]?series\b|tv\s+series\b|\+\s*specials?\b|"
                          r"(?:-\s*)?specials?\s+\d{1,2}\b)" % "|".join(_WORD_NUM))
_YEAR_SPAN = re.compile(r"[\(\[]?(?<![0-9])((?:19|20)\d{2})\s*[-\u2013\u2014~]\s*(?:(?:19|20)\d{2}|\d{2})?(?![0-9])\s*[\)\]]?")
_DANGLING = re.compile(r"(?i)(?:\s+(?:the|a|an|and|of|&|\+|-|,))+\s*$")


def parse_show_name(name):
    """Show title (+year) from a folder name or a loose episode file name. Copes with pack names:
    'The 4400 (2004-2007) - Complete TV Series, Season 1,2,3,4 S01-S04 - 720p' -> ('The 4400', 2004),
    'Doctor Who Seasons 1 to 26' -> 'Doctor Who', 'Dinosaurs The Complete First And Second Seasons' -> 'Dinosaurs'."""
    s = tidy(dehyphen(_GROUP_LEAD.sub("", stem(name) if is_video(name) else name)))
    s = re.sub(r"(?i)\{(?:tmdb|imdb|tvdb)[-=][^}]*\}|\[(?:tmdbid|imdbid|tvdbid)[-=][^\]]*\]", " ", s)
    whole = s
    m = _SE.search(s) or _X.search(s) or _SEASON_EP_WORDS.search(s)
    if m:
        s = s[:m.start()]
    else:
        cuts = [x for x in (_ANIME_DASH.search(s), _SEASON_MARK.search(s)) if x and x.start() > 0]
        if cuts:  # whichever comes first: "Stargate SG1 Season 1 -10" is cut at "Season", not at "-10"
            s = s[:min(x.start() for x in cuts)]
    s = _cut_title(s)
    year = None
    m = _YEAR_SPAN.search(s)  # "(2004-2007)", "1981-2003", "(1979–1981)"
    if m and m.start() > 0:
        year = int(m.group(1))
        s = s[:m.start()]
    m = re.search(r"[\(\[]((?:19|20)\d{2})[\)\]]", s)  # "Dinotopia (2002) Mini-Series"
    if m and m.start() > 0:
        year = year or int(m.group(1))
        s = s[:m.start()]
    m = re.search(r"[\s\(\[]((?:19|20)\d{2})[\)\]]?\s*$", s)
    if m and m.start() > 0:
        year = year or int(m.group(1))
        s = s[:m.start()]
    m = re.match(r"^((?:19|20)\d{2})\s+-\s+(?=\S*[A-Za-z])", s)  # "1990 - Live Action ..."
    if m:
        year = year or int(m.group(1))
        s = s[m.end():]
    if year is None and not is_video(name):  # "George of the Jungle Season One 2007 NTSC"
        rest = whole[len(s):]
        m = _YEAR_SPAN.search(rest) or re.search(r"(?<![0-9])((?:19|20)\d{2})(?![0-9])", rest)
        if m and not re.search(r"\d{3,4}[pi]\b", rest[max(0, m.start() - 1):m.end() + 2]):
            year = int(m.group(1))
    s = re.sub(r"\s*[\(\[][^\)\]]*$", "", s) if re.search(r"[\(\[][^\)\]]*$", s) and \
        names_ok(re.sub(r"\s*[\(\[][^\)\]]*$", "", s)) else s  # "Its a Sin (TV" -> "Its a Sin"
    s = _DANGLING.sub("", clean_tail(clean_title(s)))
    return clean_title(s), year


_EP_PREFIX = re.compile(r"^\s*(\d{1,3})(?:\s*-\s*(\d{1,3}))?(?:\s*[-._)]\s*|\s+(?=[^\d\s]))(?=.*[A-Za-z\u00c0-\uffff])")


def episode_prefix(name):
    """A file that starts with its episode number and then the episode's title (no show name):
    '07 - Merry Christmas, Mr Bean' -> (None, 7, None); '103 - Deadly Maneuvers' -> (1, 3, None) (season 1, episode 3);
    '101-102 - Knight Of The Phoenix' -> (1, 1, 2). None otherwise ('1997 Mr Bean The Movie' is a year)."""
    s = stem(name) if is_video(name) else (name or "")
    m = _EP_PREFIX.match(s)
    if not m:
        return None
    a, b = m.group(1), m.group(2)
    n = int(a)
    if len(a) == 3:
        if n % 100 == 0:
            return None
        se, ep = n // 100, n % 100
        end = None
        if b and len(b) == 3 and int(b) // 100 == se and int(b) % 100 > ep:
            end = int(b) % 100
        return se, ep, end
    end = int(b) if b and int(b) > n else None
    return None, n, end


def fallback_titles(title, year=None):
    """Other ways to read a name TMDB found nothing for -> [(title, year)]:
    '02 Clash Of The Titans' -> 'Clash Of The Titans', '1979 The Muppet Movie' -> ('The Muppet Movie', 1979),
    '1960 - Jerry Lewis - Cinderfella' -> ('Cinderfella', 1960), 'Despicable Me - Kids' -> 'Despicable Me'."""
    out = []
    t = clean_tail(dehyphen(title or "")).strip()
    y = year
    m = re.match(r"^((?:19|20)\d{2})\s*(?:-\s*|\s+)(?=\S*[A-Za-z])", t)
    if m:
        y = y or int(m.group(1))
        t = t[m.end():].strip()
        out.append((t, y))
    p = order_prefix(t)
    if p and not re.search(r"(?<![0-9])%d(?![0-9])" % p[0], p[1]):
        t = p[1].strip()
        out.append((t, y))
    segs = [x.strip() for x in re.split(r"\s+-\s+", t) if names_ok(x)]
    if len(segs) > 1:
        out.append((segs[-1], y))  # "Jerry Lewis - Cinderfella" -> "Cinderfella"
    m = re.match(r"^(.+?[A-Za-z].*?)\s+\d{1,2}\s+(.*[A-Za-z].*)$", t)
    if m:  # "A Fixer Upper Mystery 01 Framed For Murder" -> "Framed For Murder", "A Fixer Upper Mystery Framed..."
        out.append((m.group(2), y))
        out.append(("%s %s" % (m.group(1), m.group(2)), y))
    if re.search(r"\s1$", t):  # "Revenge Of The Nerds 1"
        out.append((t[:-2], y))
    if "[" in t:  # "The Savage Five [720 HD"
        out.append((t.split("[", 1)[0], y))
    m = re.match(r"^((?:[^\s-]+\s+){1,4}[^\s-]+)-(?=[A-Za-z])", t)
    if m and " - " not in t:  # "Peppa Pig-champion Daddy Pig" -> "Peppa Pig"
        out.append((m.group(1), y))
    m = re.match(r"(?i)^(?:cbeebies|cbbc|disney(?:'?s)?|dsny|nick(?:elodeon)?(?: jr)?|hanna[\s-]?barbera(?:'?s)?|bbc|itv|"
                 r"pbs(?: kids)?|dreamworks(?:'?s)?|pixar(?:'?s)?|marvel(?:'?s)?)\s+(?=\S)", t)
    if m:  # "CBeebies Tinga Tinga Tales" -> "Tinga Tinga Tales", "Hanna Barberas Inch High..." -> "Inch High..."
        out.append((t[m.end():], y))
    if re.search(r"\b[A-Z] [A-Z]\b", t):  # "Born in East L A" -> "Born in East LA"
        out.append((re.sub(r"\b([A-Z]) (?=[A-Z]\b)", r"\1", t), y))
    res, seen = [], set([norm(title)])
    for a, b in out:
        a = clean_tail(clean_title(a))
        if names_ok(a) and len(norm(a)) > 1 and norm(a) not in seen:
            seen.add(norm(a))
            res.append((a, b))
    return res[:5]


def shortened(short, full):
    """'Alc n Wndld' / 'tgnd' / 'gb ii' / 'FHD' - letters taken from 'Alice In Wonderland' / 'The girl next door' /
    'Ghostbusters II' / 'FIREHOUSE DOG', in order: a shortened name of that title."""
    a = re.sub(r"[^a-z0-9]", "", (short or "").lower())
    b = re.sub(r"[^a-z0-9]", "", (full or "").lower())
    if len(a) < 2 or len(b) < 4 or len(a) > 0.75 * len(b) or a[0] != b[0]:
        return False
    it = iter(b)
    return all(ch in it for ch in a)


def file_show_name(fname):
    """The show a loose episode file is named after - '' for '103 - Deadly Maneuvers.avi' / '01 - Pilot.mkv'
    (just an episode number and its title: the folder says which show it is)."""
    if parse_episode(fname) is None and episode_prefix(fname):
        return ""
    t = clean_part_title(parse_show_name(fname)[0])
    if re.match(r"(?i)^(?:episode|ep|e)\s*\d", t):  # "Episode 01 - Pilot.mkv"
        return ""
    return t


def pack_seasons(name):
    """Which seasons a pack covers: set of ints, {'all'} for complete/batch, or empty set if it's not a pack."""
    s = tidy(name)
    if _SE.search(s) or _X.search(s):
        # "S01E01-E10" style ranges are still single-season episode bundles
        m = _SE.search(s)
        if m and m.group(3):
            return {int(m.group(1))}
        return set()
    out = set()
    for m in _PACK.finditer(s):
        a = m.group(1) or m.group(3)
        b = m.group(2) or m.group(4)
        if a:
            a = int(a)
            b = int(b) if b else a
            out.update(range(a, max(a, b) + 1))
        elif m.group(0):
            out.add("all")
    if len(out) > 1:
        out.discard("all")  # "Season 1 [Batch]" is season 1, not everything
    return out


def episode_for(name, season, episode, anime_abs=None):
    """Does this release / file name hold this episode? True / False / None (can't tell)."""
    p = parse_episode(name)
    if p is None:
        return None
    if p["absolute"]:
        if anime_abs is not None:
            end = p["ep_end"] or p["episode"]
            return p["episode"] <= anime_abs <= end or p["episode"] <= episode <= end
        return None
    end = p["ep_end"] or p["episode"]
    return p["season"] == season and p["episode"] <= episode <= end


# ---------------------------------------------------------------- naming new files
def safe(s, limit=120):
    s = re.sub(r"\s*:\s*", " - ", s or "")
    s = _BAD_CHARS.sub(" ", s).replace("..", ".")
    s = re.sub(r"\s+", " ", s).strip(" .")
    return s[:limit].rstrip(" .") or "Unknown"


def title_year(title, year):
    title = safe(title)
    return "%s (%s)" % (title, year) if year else title


def movie_relpath(title, year, extension, part=None):
    base = title_year(title, year)
    p = (" - part%d" % part) if part else ""
    return [base, base + p + extension]


def season_dirname(season):
    return "Specials" if season == 0 else "Season %02d" % season


def episode_filename(show, year, season, episode, extension, ep_end=None):
    se = "S%02dE%02d" % (season, episode)
    if ep_end and ep_end > episode:
        se += "-E%02d" % ep_end
    return "%s - %s%s" % (title_year(show, year), se, extension)


def sub_suffix(name):
    n = tidy(stem(name)).lower()
    for code, words in (("en", ("english", "eng", "en")), ("es", ("spanish", "spa", "esp")),
                        ("fr", ("french", "fre", "fra")), ("de", ("german", "ger", "deu"))):
        if any(re.search(r"(?:^|[\s\]\[\(\)-])%s(?:$|[\s\]\[\(\)-])" % w, n) for w in words):
            return "." + code
    return ""


# ---------------------------------------------------------------- collections and order numbers
DEFAULT_COLLECTION_WORDS = ("collection, pack, box set, boxset, saga, trilogy, duology, quadrilogy, anthology, "
                            "franchise, bundle, complete")
_ORDER = re.compile(r"^\s*([\[(]?)(\d{1,2})([\])]?)(\s*[-._)]\s*|\s+)(?=\S)")
_RANGE = re.compile(r"(?<![0-9])(?:(?:19|20)\d{2}\s*-\s*(?:19|20)\d{2}|\d{1,2}\s*-\s*\d{1,2})(?![0-9])")
_RX_CACHE = {}


def _words_rx(words):
    rx = _RX_CACHE.get(words)
    if rx is None:
        parts = [re.escape(w.strip()).replace(r"\ ", r"\s*") for w in (words or "").split(",") if w.strip()]
        rx = re.compile(r"(?i)(?:^|\s)(?:%s)s?(?:$|\s)" % "|".join(parts)) if parts else None
        _RX_CACHE[words] = rx
    return rx


def is_collection_name(name, words=DEFAULT_COLLECTION_WORDS):
    """'Harry Potter Collection', 'Pixar Pack', 'Bond 1-3', 'Alien Quadrilogy (1979-1997)' -> True."""
    t = tidy(name or "")
    rx = _words_rx(words)
    return bool((rx and rx.search(t)) or _RANGE.search(t))


def single_year(name):
    """A folder name with one year in it (a film), not a range like 2001-2011 (a collection)."""
    t = tidy(name or "")
    return bool(_YEAR.search(t)) and not _RANGE.search(t)


def order_prefix(name):
    """'01 Harry Potter...' / '1. Harry Potter' / '[02] ...' / '3 - ...' -> (3, 'Harry Potter...', '01 ') or None."""
    s = stem(name) if is_video(name) or is_sub(name) else name
    m = _ORDER.match(s or "")
    if not m:
        return None
    rest = s[m.end():]
    if not re.search(r"[A-Za-zÀ-￿]", rest):
        return None  # '9 (2009)' is a film called 9
    return int(m.group(2)), rest, s[:m.end()]


def strip_orders(names_list, in_collection):
    """Which of these (sibling files or folders) start with an order number that isn't part of the title?
    -> {name: (number, name without it)}. Safe with '21 Jump Street' / '22 Jump Street' and '12 Angry Men'."""
    found = {}
    for n in names_list:
        p = order_prefix(n)
        if p:
            found[n] = p
    if not found:
        return {}
    if len(found) >= 2:
        nums = [p[0] for p in found.values()]
        # the year counts: "01 Clash Of The Titans (1981)" and "02 Clash Of The Titans (2010)" are two films
        rests = ["%s|%s" % (norm(parse_movie(p[1])[0]), parse_movie(p[1])[1] or "") for p in found.values()]
        if len(set(nums)) == len(nums) and len(set(rests)) == len(rests) and min(nums) <= 9:
            return dict((n, (p[0], p[1])) for n, p in found.items())
        return {}
    (n, p), = found.items()
    if re.search(r"(?<![0-9])%d(?![0-9])" % p[0], p[1]):
        return {}  # '2 Fast 2 Furious' - the number is part of the title
    if in_collection and (p[0] <= 9 or p[2].lstrip("[( ").startswith("0")):
        return {n: (p[0], p[1])}
    return {}


_LEAD_YEAR = re.compile(r"^\s*[\[(]?((?:19|20)\d{2})[\])]?(?:\s*[-._]\s*|\s+)(?=\S*[A-Za-z\u00c0-\uffff])")


def strip_years(names_list):
    """Sibling files that all start with a year: '1979 The Muppet Movie', '1981 The Great Muppet Caper',
    '1960 - Jerry Lewis - Cinderfella' -> {name: (year, rest)}. A lone '2001 A Space Odyssey' is left alone."""
    found = {}
    for n in names_list:
        s = stem(n) if is_video(n) else n
        m = _LEAD_YEAR.match(s)
        if m:
            found[n] = (int(m.group(1)), s[m.end():])
    if len(found) < 2 or len(set(norm(r) for _y, r in found.values())) < len(found):
        return {}
    return found


def strip_common_segments(titles):
    """'Jerry Lewis - Cinderfella', 'Jerry Lewis - The Bellboy' -> 'Cinderfella', 'The Bellboy': a ' - ' part that
    every title in the folder shares is the folder's label, not part of the film's name."""
    split = [re.split(r"\s+-\s+", t or "") for t in titles]
    if len(titles) < 2 or any(len(p) < 2 for p in split):
        return titles
    n = min(len(p) for p in split)
    drop = [i for i in range(n - 1) if len(set(norm(p[i]) for p in split)) == 1]  # never a title's last part
    if not drop:
        return titles
    out = []
    for p in split:
        keep = [x for i, x in enumerate(p) if i not in drop]
        out.append(" - ".join(keep) if keep and names_ok(" ".join(keep)) else " - ".join(p))
    return out


_SCENE_TAG = re.compile(r"(?i)(?:^|[\s.\[(\])_-])(?:dvdrip|bdrip|brrip|bluray|xvid|divx|x264|x265|h264|hevc|web-?dl|webrip|hdtv|"
                        r"720p|1080p|2160p|ppvrip|dvdscr|r5|ac3|aac|hdrip|cam|telesync|ts)(?=$|[\s.\])_-])")


def release_like(folder_name):
    """'Knocked.Up.UNRATED.DVDRip.XviD-DiAMOND', 'Cougar.Hunting.2011.DVDRip.XviD-aAF': named after one release."""
    s = folder_name or ""
    return bool(_SCENE_TAG.search(s)) or bool(re.search(r"[.\s](?:19|20)\d{2}[.\s)\]]", s + " ") and
                                              re.search(r"-[A-Za-z0-9]{2,}$", s))


def abbreviated(file_name):
    """A scene group's short file name that says little: 'dmd-knockedup', 'aaf-cougar hunting', 'hls-cwtc',
    'M O 34 S BR TCM', 'coatdq'."""
    s = stem(file_name) if is_video(file_name) else (file_name or "")
    s = re.sub(r"(?i)[-._ ]?(?:cd|disc|part|pt)[-._ ]?\d$", "", s)
    if re.match(r"^[a-z0-9]{1,10}-[a-z0-9]", s):  # lower-case group prefix
        return True
    if re.match(r"^[a-z0-9]{2,12}$", s) and not _YEAR.search(s):
        return True
    words = tidy(s).split()
    return len(words) >= 3 and sum(1 for w in words if len(w) <= 2) * 10 >= len(words) * 6


_SHOW_PACK = re.compile(r"(?i)\s+(?:the\s+)?(?:complete\s+)?(?:series\s+)?(?:collection|pack|box\s*set|boxset|"
                        r"anthology|bundle)\s*$")


def clean_show_title(t):
    """'Friends Box Set' -> 'Friends', 'Naruto Shippuden Pack' -> 'Naruto Shippuden'."""
    out = _SHOW_PACK.sub("", t or "").strip()
    return out or t
