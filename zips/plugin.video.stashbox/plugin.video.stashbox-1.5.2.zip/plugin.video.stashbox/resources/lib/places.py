# -*- coding: utf-8 -*-
"""Where things are on the NAS: the folders a title lives in, duplicates, look-alike entries, finding missing
episodes elsewhere, and planning moves to put a show in one place."""
import re
import time

import db
import names
import tmdb
import vfs
from common import (all_locations, fmt_size, hide_creds, loc_label, location_for, log, npath, rel, setting_int,
                    under)


# ---------------------------------------------------------------- a title's folders
def home_of(f):
    """The folder a library file 'belongs' to: its show / film folder, or the folder it sits loose in."""
    mk = f["mkey"] or ""
    body = mk.split(":", 1)[1] if ":" in mk else vfs.parent(f["path"])
    return body.split("|", 1)[0], "|" not in body


def place_label(path):
    """'USB 1 - Films > Sci-Fi > Dune (2021)' for a folder on the NAS."""
    _sec, loc = location_for(path)
    if loc is None:
        return hide_creds(path)
    r = rel(path, loc["path"])
    return loc_label(loc) + (" > " + r.replace("/", " > ") if r else "")


def _season_text(seasons):
    """{0, 1, 2, 3, 5} -> 'Seasons 1-3, 5 + specials'."""
    s = sorted(x for x in seasons if x is not None)
    if not s:
        return ""
    specials = 0 in s
    s = [x for x in s if x > 0]
    if not s:
        return "Specials"
    runs, start, prev = [], s[0], s[0]
    for x in s[1:]:
        if x == prev + 1:
            prev = x
            continue
        runs.append((start, prev))
        start = prev = x
    runs.append((start, prev))
    txt = ", ".join(("%d" % a) if a == b else "%d-%d" % (a, b) for a, b in runs)
    return ("Season " if len(s) == 1 else "Seasons ") + txt + (" + specials" if specials else "")


def homes(item_id):
    """-> [{"folder", "label", "own", "files", "count", "size", "seasons"}], biggest first."""
    out = {}
    for f in db.item_files(item_id):
        h, own = home_of(f)
        d = out.setdefault(h, {"folder": h, "label": place_label(h), "own": own, "files": [], "size": 0,
                               "seasons": set(), "eps": set()})
        d["files"].append(f)
        d["size"] += f["size"] or 0
        if f["episode"] is not None:
            d["seasons"].add(f["season"])
            for e in range(f["episode"], (f["ep_end"] or f["episode"]) + 1):
                d["eps"].add((f["season"], e))
    res = []
    for d in out.values():
        d["count"] = len(d["eps"]) or len(d["files"])
        d["season_text"] = _season_text(d["seasons"])
        res.append(d)
    defaults = set(npath(loc["path"]) for _s, loc in all_locations() if loc.get("default"))
    # most episodes first; on a tie, the one in a section's main (default) folder
    return sorted(res, key=lambda d: (-d["count"], not any(under(d["folder"], r) for r in defaults), d["label"]))


def duplicates(item_id):
    """Episodes (or films) with more than one copy. -> [((season, ep) or None, [file rows])]"""
    it = db.item(item_id)
    files = db.item_files(item_id)
    if it and it["kind"] == "movie":
        return [(None, files)] if len(files) > 1 else []
    by = {}
    for f in files:
        if f["episode"] is None:
            continue
        by.setdefault((f["season"], f["episode"]), []).append(f)
    return [(k, v) for k, v in sorted(by.items()) if len(v) > 1]


def other_sections(item):
    """The same title (by TMDB id) filed in another section, e.g. a show half in TV, half in Anime."""
    if not item["tmdb"]:
        return []
    return db.q("SELECT i.*, (SELECT COUNT(*) FROM files f WHERE f.item_id=i.id) n FROM items i WHERE i.kind=? AND "
                "i.tmdb=? AND i.id<>?", (item["kind"], item["tmdb"], item["id"]))


def lookalikes(item):
    """Other entries that are probably the same title split off (unmatched / matched to something else)."""
    from scanner import same_title
    me = names.norm(item["title"])
    out = []
    for r in db.q("SELECT i.*, (SELECT COUNT(*) FROM files f WHERE f.item_id=i.id) n FROM items i WHERE i.kind=? "
                  "AND i.id<>? AND (i.tmdb IS NULL OR i.tmdb=0 OR i.tmdb<>?)", (item["kind"], item["id"],
                                                                                 item["tmdb"] or -1)):
        t = names.clean_show_title(names.clean_part_title(r["title"] or ""))
        if not names.norm(t):
            continue
        if names.norm(t) == me or (not r["matched"] and same_title(t, item["title"])):
            out.append(r)
    return out


def suspicious(item):
    """Signs a 'show' is really several shows lumped together. -> [reasons]"""
    if not item or item["kind"] != "show":
        return []
    files = db.item_files(item["id"])
    eps = [f for f in files if f["episode"] is not None and f["season"]]
    seasons = sorted(set(f["season"] for f in eps))
    out = []
    tm = set(s["n"] for s in db.seasons_of(item) if s.get("n"))
    if item["matched"] and tm:
        extra = [s for s in seasons if s not in tm]
        if extra:
            out.append("season%s %s on the NAS but TMDB only has %d" % (
                "s" if len(extra) > 1 else "", ", ".join(str(s) for s in extra[:8]), len(tm)))
    elif not item["matched"] and len(seasons) >= 3:
        out.append("not matched on TMDB and has %d seasons" % len(seasons))
    # the same episode twice inside ONE folder (copies on a backup drive are just backups)
    copies = {}
    for f in eps:
        k = (home_of(f)[0], f["season"], f["episode"])
        copies[k] = copies.get(k, 0) + 1
    many = sum(1 for n in copies.values() if n > 1)
    if many >= 5 and many * 5 >= len(copies):
        out.append("%d episodes appear more than once in the same folder" % many)
    return out


def summary(item_id, short=False):
    """'NAS > TV > Breaking Bad (2008) (33 eps); USB 1 > TV > Breaking Bad (24 eps)'."""
    hs = homes(item_id)
    if not hs:
        return ""
    it = db.item(item_id)
    unit = "eps" if it and it["kind"] == "show" else "files"
    parts = ["%s (%d %s)" % (h["label"], h["count"], unit) if len(hs) > 1 else h["label"] for h in hs]
    if short and len(parts) > 2:
        parts = parts[:2] + ["+%d more" % (len(parts) - 2)]
    return "; ".join(parts)


def summaries(item_ids):
    """Bulk version for lists: item_id -> 'On: ...' text."""
    ids = [int(i) for i in item_ids]
    if not ids:
        return {}
    homes_ = {}
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        for r in db.q("SELECT item_id, mkey, path, COUNT(*) n FROM files WHERE item_id IN (%s) GROUP BY item_id, "
                      "mkey" % ",".join(str(x) for x in chunk)):
            h, _own = home_of(r)
            d = homes_.setdefault(r["item_id"], {})
            d[h] = d.get(h, 0) + r["n"]
    out = {}
    for iid, hs in homes_.items():
        labels = sorted(hs.items(), key=lambda x: -x[1])
        if len(labels) == 1:
            out[iid] = place_label(labels[0][0])
        else:
            out[iid] = "%d places: " % len(labels) + "; ".join("%s (%d)" % (place_label(h), n) for h, n in labels[:3])
    return out


# ---------------------------------------------------------------- planning moves ("put it all in one place")
SIDECAR = names.SUB_EXT + (".nfo", ".jpg", ".png", ".txt")


def _season_dir_name(n, style):
    if n == 0:
        return "Specials"
    if style:
        m = re.search(r"\d+", style)
        if m:
            digits = m.group(0)
            num = str(n).zfill(len(digits)) if digits.startswith("0") else str(n)
            return style[:m.start()] + num + style[m.end():]
    return "Season %02d" % n


def in_pack(folder):
    """Is this show folder inside a pack / collection of other things ('Disney Christmas (Mega Pack 2020)')?"""
    from scanner import coll_words
    par = vfs.parent(folder)
    _s, loc = location_for(folder)
    if loc is None or npath(par) == npath(loc["path"]) or not under(par, loc["path"]):
        return False
    return names.is_collection_name(vfs.basename(par), coll_words())


def target_choices(item_id):
    """Folders this show could be gathered into: its own show folders, most episodes first - but a folder that's
    only one entry in a pack of other shows goes last (that's not where a whole show should end up)."""
    hs = [h for h in homes(item_id) if h["own"]]
    for h in hs:
        h["in_pack"] = in_pack(h["folder"])
    return sorted(hs, key=lambda h: h["in_pack"])


def plan(item_id, target, rename=False, only_paths=None, extra=None):
    """Moves to gather a show into one folder. extra: files from outside the library to bring in
    ([{"path", "season", "episode", "size"}]). -> dict(moves, dups, cross_bytes, same_bytes)"""
    it = db.item(item_id)
    tgt = npath(target)
    res = vfs.listdir(tgt)
    sdirs = {}
    style = None
    for d in (res[0] if res else []):
        s = names.season_from_dir(d)
        if s is not None:
            sdirs.setdefault(s, d)
            if s > 0 and style is None:
                style = d
    files = [dict(f) for f in db.item_files(item_id)]
    have = set()
    for f in files:
        if under(f["path"], tgt) and f["episode"] is not None:
            for e in range(f["episode"], (f["ep_end"] or f["episode"]) + 1):
                have.add((f["season"], e))
    todo = [f for f in files if not under(f["path"], tgt) and not names.is_disc_path(f["path"])]  # discs stay put
    if only_paths is not None:
        todo = [f for f in todo if f["path"] in only_paths]
    for x in extra or []:
        todo.append({"path": x["path"], "season": x["season"], "episode": x["episode"], "ep_end": None,
                     "size": x.get("size") or 0})
    moves, dups, planned = [], [], set()
    listings = {}
    for f in sorted(todo, key=lambda f: (f["season"] if f["season"] is not None else 999, f["episode"] or 0)):
        s, e = f["season"], f["episode"]
        if e is not None and (s, e) in have:
            dups.append(f)
            continue
        if e is not None and s is not None:
            sd = sdirs.get(s) or _season_dir_name(s, style)
            sdirs.setdefault(s, sd)
            dest_dir = vfs.join(tgt, sd)
        else:
            dest_dir = tgt
        base = vfs.basename(f["path"])
        ext = names.ext(base)
        if rename and e is not None and s is not None:
            new_stem = names.stem(names.episode_filename(it["title"], it["year"], s, e, ext, f.get("ep_end")))
        else:
            new_stem = names.stem(base)
        dest = vfs.join(dest_dir, new_stem + ext)
        if dest in planned or vfs.exists(dest):
            dups.append(f)
            continue
        planned.add(dest)
        moves.append({"src": f["path"], "dst": dest, "size": f["size"] or 0, "video": True})
        if e is not None:
            for x in range(e, (f.get("ep_end") or e) + 1):
                have.add((s, x))
        # subtitles / .nfo with the same name go too
        src_dir = vfs.parent(f["path"])
        if src_dir not in listings:
            listings[src_dir] = (vfs.listdir(src_dir) or ([], []))[1]
        old_stem = names.stem(base)
        for side in listings[src_dir]:
            if side != base and side.startswith(old_stem) and names.ext(side) in SIDECAR:
                d2 = vfs.join(dest_dir, new_stem + side[len(old_stem):])
                if d2 not in planned and not vfs.exists(d2):
                    planned.add(d2)
                    moves.append({"src": vfs.join(src_dir, side), "dst": d2, "size": 0, "video": False})
    cross = sum(m["size"] for m in moves if not vfs.same_share(m["src"], m["dst"]))
    same = sum(m["size"] for m in moves if vfs.same_share(m["src"], m["dst"]))
    return {"moves": moves, "dups": dups, "cross_bytes": cross, "same_bytes": same, "target": tgt}


def new_show_folder(item):
    """Somewhere to gather a show that's only ever been loose files: 'Title (Year)' next to them."""
    hs = homes(item["id"])
    base = ""
    for h in hs:
        b = vfs.parent(h["folder"]) if h["own"] else h["folder"]
        if not (h["own"] and in_pack(h["folder"])) and not in_pack(vfs.join(b, "x")):
            base = b
            break
    if not base:  # only ever seen inside packs of other shows: the section's main folder
        from common import section_path
        base = section_path(item["section"]) or (vfs.parent(hs[0]["folder"]) if hs else item["folder"] or "")
    return vfs.join(base, names.title_year(item["title"], item["year"]))


# ---------------------------------------------------------------- finding missing episodes elsewhere
class Cancelled(Exception):
    pass


def hunt_roots(scope):
    """scope: 'folders' (your StashBox folders), 'shares' (+ the rest of the shares/drives they're on),
    'nas' (+ every other share on the same NAS). -> [paths], nothing nested inside another."""
    roots = [npath(loc["path"]) for _s, loc in all_locations()]
    if scope in ("shares", "nas"):
        roots += [npath(vfs.share_root(r)) for r in list(roots)]
    if scope == "nas":
        for host in set(filter(None, (vfs.host_root(r) for r in roots))):
            res = vfs.listdir(host)
            for sh in (res[0] if res else []):
                if not sh.endswith("$") and not names.system_dir(sh):
                    roots.append(npath(vfs.join(host, sh)))
    roots = sorted(set(roots), key=len)
    out = []
    for r in roots:
        if not any(under(r, o) for o in out):
            out.append(r)
    return out


def _owner(path, root):
    """Which show a stray episode file is from: its name, else the folders above it.
    -> (title, year or None, the show-level folder it sits in)"""
    parts = rel(vfs.parent(path), root).split("/") if not under(root, vfs.parent(path)) else []
    folder, year = vfs.parent(path), None
    # the show-level folder: up past "Season 2" / "Disc 1" / "s01e01 An Unearthly Child" folders
    names_up = [p for p in parts if p]
    k = len(names_up)
    while k > 0 and (names.season_from_dir(names_up[k - 1]) is not None or names.part_like(names_up[k - 1])
                     or names.parse_episode(names_up[k - 1]) is not None):
        k -= 1
        folder = vfs.parent(folder)
    if k > 0:
        year = names.parse_show_name(names_up[k - 1])[1]
    t = names.file_show_name(vfs.basename(path))
    if names.norm(t):
        return t, year, folder
    for d in reversed(names_up[:k]):
        t = names.clean_show_title(names.clean_part_title(names.parse_show_name(d)[0]))
        if names.norm(t):
            return t, year, folder
    return "", year, folder


def _fits(seasons, s, e):
    """Is SxxEyy an episode TMDB knows this show has? (Season 0 / specials always fit.)"""
    if not seasons or s == 0:
        return True
    for x in seasons:
        if x["n"] == s:
            return e <= (x.get("count") or 0) + 2  # a little slack for a season still airing
    return False


def hunt(item_ids=None, scope="shares", progress=None, max_folders=25000):
    """Look through the NAS for episodes of these shows (all shows if None) that the library hasn't counted.
    progress(percent, line) -> True to cancel. -> results dict (saved by the caller)."""
    from scanner import Walker, _episode_info, same_title
    t0 = time.time()
    if item_ids is None:
        shows = db.q("SELECT * FROM items WHERE kind='show' AND matched=1")
    else:
        shows = [db.item(int(i)) for i in item_ids]
        shows = [s for s in shows if s]
    index, first_word, info = {}, {}, {}
    for s in shows:
        have = set()
        for f in db.item_files(s["id"]):
            if f["episode"] is not None:
                for e in range(f["episode"], (f["ep_end"] or f["episode"]) + 1):
                    have.add((f["season"], e))
        info[s["id"]] = {"item": s, "have": have, "seasons": db.seasons_of(s), "found": {}, "spare": 0, "groups": {}}
        keys = {names.norm(s["title"]), names.norm(s["original"] or "")}
        for h in homes(s["id"]):
            if h["own"]:
                keys.add(names.norm(names.clean_show_title(names.clean_part_title(
                    names.parse_show_name(vfs.basename(h["folder"]))[0]))))
        for k in keys:
            if k:
                index.setdefault(k, set()).add(s["id"])
                first_word.setdefault(k.split()[0], set()).add(s["id"])
    lib = dict((r["path"], (r["item_id"], r["section"])) for r in db.q("SELECT path, item_id, section FROM files"))
    locs = [npath(loc["path"]) for _s, loc in all_locations()]
    min_bytes = setting_int("min_movie_mb", 100) * 1024 * 1024 // 5
    roots = hunt_roots(scope)
    w = Walker()
    state = {"n": 0, "t": 0.0}

    def tick(path, n):
        state["n"] = n
        if progress and time.time() - state["t"] > 0.25:
            state["t"] = time.time()
            if progress(min(99, int(100 * n / (n + 400.0))), "%d folders - %s" % (n, place_label(path))):
                raise Cancelled()
        if n > max_folders:
            raise Cancelled()
    w.tick = tick
    cancelled = False
    try:
        for root in roots:
            for folder, _dirs, files in w.walk(root, depth=10):
                sdir = names.season_from_dir(vfs.basename(folder))
                for fn in files:
                    if not names.is_video(fn):
                        continue
                    path = vfs.join(folder, fn)
                    s, e, end, ab = _episode_info(fn, sdir)
                    if e is None:
                        continue
                    owner, oyear, ofolder = _owner(path, root)
                    no = names.norm(owner)
                    if not no:
                        continue
                    ids = index.get(no)
                    if not ids:
                        ids = set(i for i in first_word.get(no.split()[0], ()) if same_title(owner, info[i]["item"]["title"]))
                    if len(ids) != 1:
                        continue  # not one of these shows, or can't tell which
                    sid = next(iter(ids))
                    sh = info[sid]
                    sy = sh["item"]["year"]
                    if oyear and sy and abs(int(oyear) - int(sy)) > 1:
                        continue  # "Doctor Who (1963)" isn't Doctor Who (2005)
                    if ab and sh["seasons"] and (s is None or not any(x["n"] == s and e <= (x.get("count") or 0)
                                                                      for x in sh["seasons"])):
                        s, e = tmdb.absolute_to_se(sh["seasons"], e)
                    if s is None:
                        s = 1
                    where = lib.get(path)
                    if where and where[0] == sid:
                        continue  # counted already
                    grp = ("item:%d" % where[0]) if where else "dir:" + npath(ofolder)
                    g = sh["groups"].setdefault(grp, {"fit": 0, "nofit": 0})
                    if not _fits(sh["seasons"], s, e):
                        g["nofit"] += 1  # e.g. S01E30 or Season 20 of a show TMDB says has 13 short seasons
                        continue
                    g["fit"] += 1
                    if (s, e) in sh["have"]:
                        sh["spare"] += 1
                        continue
                    size = vfs.stat(path)[0]
                    if where:
                        other = db.item(where[0])
                        if other is None:
                            continue
                        if other["tmdb"] == sh["item"]["tmdb"]:
                            kind = "section"  # the same show, filed in another section
                        elif other["matched"] and other["tmdb"]:
                            continue  # really is another show with a similar name
                        else:
                            kind = "misfiled"
                        rec = {"kind": kind, "other": other["id"], "other_title": other["title"],
                               "other_section": other["section"]}
                    elif not any(under(path, l) for l in locs):
                        rec = {"kind": "outside"}
                    elif names.is_sample(fn):
                        rec = {"kind": "sample"}
                    elif size and size < min_bytes:
                        rec = {"kind": "small"}
                    else:
                        rec = {"kind": "uncounted"}
                    rec.update(path=path, season=s, episode=e, size=size, place=place_label(folder), group=grp,
                               home=ofolder)
                    key = "%d|%d" % (s, e)
                    if key in sh["found"]:
                        sh["spare"] += 1
                    else:
                        sh["found"][key] = rec
    except Cancelled:
        cancelled = True
    out = {"when": time.time(), "secs": round(time.time() - t0, 1), "scope": scope, "folders": state["n"],
           "roots": [hide_creds(r) for r in roots], "cancelled": cancelled, "limit_hit": state["n"] > max_folders,
           "shows": []}
    for sid, sh in info.items():
        # a whole folder (or library entry) where many episodes don't fit this show's seasons is another show
        # with the same name - classic Doctor Who (26 seasons of 6-42 parts) isn't Doctor Who (2005)
        bad = set(k for k, g in sh["groups"].items() if g["nofit"] >= 3 and g["nofit"] * 4 > g["fit"])
        if bad:
            n0 = len(sh["found"])
            sh["found"] = dict((k, r) for k, r in sh["found"].items() if r.get("group") not in bad)
            sh["other_show"] = [k.split(":", 1)[1] for k in bad]
            log("Missing-episode search: %s - left out %d episode%s in %d place%s that look like a different show "
                "with the same name (%s)" % (
                    sh["item"]["title"], n0 - len(sh["found"]), "" if n0 - len(sh["found"]) == 1 else "s",
                    len(bad), "" if len(bad) == 1 else "s", "; ".join(
                        place_label(k[4:]) if k.startswith("dir:") else (db.item(int(k[5:])) or {"title": "?"})["title"]
                        for k in sorted(bad))[:300]))
        if sh["found"] or (item_ids is not None):
            out["shows"].append({"id": sid, "title": sh["item"]["title"], "section": sh["item"]["section"],
                                 "found": sorted(sh["found"].values(), key=lambda r: (r["season"], r["episode"])),
                                 "spare": sh["spare"]})
    out["shows"].sort(key=lambda s: (-len(s["found"]), s["title"].lower()))
    log("Missing-episode search (%s): %d folders, %.0fs, found %d episodes for %d shows%s" % (
        scope, state["n"], out["secs"], sum(len(s["found"]) for s in out["shows"]),
        sum(1 for s in out["shows"] if s["found"]), " (stopped early)" if cancelled else ""))
    return out


KIND_TEXT = {"outside": "outside your StashBox folders", "uncounted": "in your folders but wasn't counted",
             "small": "skipped - smaller than your size limit", "sample": "looks like a sample clip",
             "misfiled": "counted under another entry", "section": "filed in another section"}


def fmt_found(r):
    txt = KIND_TEXT.get(r["kind"], r["kind"])
    if r["kind"] in ("misfiled", "section"):
        txt += " ('%s')" % r.get("other_title", "?")
    return "S%02dE%02d  %s  %s" % (r["season"], r["episode"], txt, fmt_size(r.get("size")))
