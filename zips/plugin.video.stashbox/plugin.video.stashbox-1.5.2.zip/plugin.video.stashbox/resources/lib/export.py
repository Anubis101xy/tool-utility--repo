# -*- coding: utf-8 -*-
"""'Send a report to Claude': everything needed to see why the library looks the way it does, in one zip.
Folder and file names are in it; passwords in NAS addresses and API keys are not."""
import io
import os
import re
import time
import zipfile

import xbmc

import db
import places
import downloads
from common import (LOG_FILE, PATH, PROFILE, SECTIONS, VERSION, hide_creds, load_json, load_locations, load_rules,
                    music_locations, setting)

SECRET = ("tmdb_key", "api_key", "cocoleech_key")
ADDRESS = ("torrentio_url",)  # a Torrentio address can carry a debrid key inside it


def _secret_values():
    vals = [setting(k) for k in SECRET]
    try:
        import debrid
        a = debrid.rd_auth()
        vals += [str(v) for k, v in a.items() if k not in ("expires", "obtained") and isinstance(v, str)]
    except Exception:
        pass
    return sorted(set(v for v in vals if v and len(v) >= 6), key=len, reverse=True)


def scrub(text, secrets=None):
    """No passwords, keys or tokens: user:pass@ in addresses, every key StashBox holds, token= / apikey= in links,
    Bearer headers, and debrid keys inside Torrentio-style addresses."""
    text = hide_creds(text)
    for v in (_secret_values() if secrets is None else secrets):
        text = text.replace(v, "***")
    text = re.sub(r"(?i)\b((?:access_|refresh_)?token|api_?key|apikey|key|secret|password|pass|auth)=([^&\s\"'<>]+)",
                  r"\1=***", text)
    text = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+", r"\1***", text)
    text = re.sub(r"(?i)\b(realdebrid|torbox|alldebrid|premiumize|debridlink|offcloud|putio|easydebrid)=[^/|&\s]+",
                  r"\1=***", text)
    return text


def _settings():
    out = []
    try:
        x = open(os.path.join(PATH, "resources", "settings.xml"), encoding="utf-8").read()
    except IOError:
        return out
    for sid in re.findall(r'<setting id="([^"]+)"', x):
        if sid.endswith("_btn") or sid in ("scan_now",):
            continue
        v = setting(sid)
        if sid in SECRET:
            v = "set" if v else "not set"
        elif sid in ADDRESS and v:
            v = "custom address" if re.search(r"=|[A-Za-z0-9]{20,}", v.split("://", 1)[-1]) else v
        out.append("  %s = %s" % (sid, hide_creds(v)))
    return out


def _kodi():
    plat = next((p for p in ("Android", "Windows", "Linux", "OSX", "IOS", "TVOS", "Darwin")
                 if xbmc.getCondVisibility("System.Platform.%s" % p)), "?")
    return "%s on %s" % (xbmc.getInfoLabel("System.BuildVersion") or "?", plat)


def report_text():
    L = ["StashBox report - %s" % time.strftime("%Y-%m-%d %H:%M"),
         "StashBox %s, Kodi %s" % (VERSION, _kodi()), ""]
    L.append("== Settings (API keys hidden)")
    L += _settings()
    L += ["", "== Your NAS folders"]
    for sec, locs in load_locations().items():
        for x in locs:
            L.append("  %-8s %s%s  %s" % (sec, "* " if x.get("default") else "", x.get("label", ""), hide_creds(x["path"])))
    rules = load_rules()
    L += ["", "== Folder rules (%d)" % len(rules)]
    for k, v in sorted(rules.items()):
        L.append("  %-10s %s" % (v, hide_creds(k)))
    rep = load_json("scan_report.json", {})
    L += ["", "== Last scan: %s, %.0fs, by %s" % (
        time.strftime("%Y-%m-%d %H:%M", time.localtime(rep.get("finished", 0))) if rep.get("finished") else "never",
        (rep.get("finished", 0) - rep.get("started", 0)) if rep.get("finished") else 0, rep.get("by", "?"))]
    for r in rep.get("sections") or []:
        for l in r.get("locations") or []:
            L.append("  %-8s %-28s %-11s %5d videos %5d folders  +%d -%d%s" % (
                r["section"], l.get("label", "")[:28], l.get("status"), l.get("found", 0), l.get("folders", 0),
                l.get("new", 0), l.get("gone", 0), "  tv-left-out=%d" % l["tv_skipped"] if l.get("tv_skipped") else ""))
    problems = []
    for sid, label, _k, kind in SECTIONS:
        rows = db.q("SELECT * FROM items WHERE section=? ORDER BY COALESCE(sorttitle, title) COLLATE NOCASE", (sid,))
        if not rows:
            continue
        L += ["", "== %s: %d %s" % (label, len(rows), "shows" if kind == "show" else "films")]
        for it in rows:
            hs = places.homes(it["id"])
            n = sum(len(h["files"]) for h in hs)
            flags = places.suspicious(it)
            tag = "TMDB %s" % it["tmdb"] if it["matched"] else "NOT MATCHED"
            L.append("  %s%s (%s) [%s] %d file%s" % ("!! " if flags else "", it["title"], it["year"] or "?", tag, n,
                                                    "" if n == 1 else "s"))
            for h in hs:
                L.append("        %s: %s%s" % (hide_creds(h["label"]), h["season_text"] + ", " if h["season_text"] else "",
                                               "%d file%s" % (len(h["files"]), "" if len(h["files"]) == 1 else "s")))
            for fl in flags:
                L.append("        !! %s" % fl)
                problems.append("%s / %s: %s" % (label, it["title"], fl))
            if not it["matched"]:
                problems.append("%s / %s: not matched on TMDB" % (label, it["title"]))
    n, albums, artists = (db.one("SELECT COUNT(*) n, COUNT(DISTINCT akey) a, COUNT(DISTINCT albumartist) ar FROM tracks")
                          or (0, 0, 0))
    L += ["", "== Music: %d tracks, %d albums, %d artists; music folders: %s" % (
        n, albums, artists, ", ".join(hide_creds(x["path"]) for x in music_locations()) or "none")]
    jobs = []
    for j in downloads.all_jobs()[-40:]:
        jobs.append("  %s  %-10s %-8s %-45s %s" % (time.strftime("%m-%d %H:%M", time.localtime(j.get("created", 0))),
                                                   j.get("status"), j.get("kind") or "download",
                                                   (j.get("title") or "")[:45], j.get("msg") or ""))
    L += ["", "== Downloads / moves (last %d)" % len(jobs)] + jobs
    L = L[:3] + ["== Possible problems (%d)" % len(problems)] + ["  " + p for p in problems[:200]] + [""] + L[3:]
    return "\n".join(L) + "\n"


def build():
    """-> zip bytes."""
    sec = _secret_values()
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("report.txt", scrub(report_text(), sec))
        for name in ("log.txt", "scan_detail.txt"):
            p = LOG_FILE if name == "log.txt" else os.path.join(PROFILE, name)
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    z.writestr(name, scrub(f.read()[-3000000:], sec))
        for name in ("scan_report.json", "hunt.json", "locations.json", "folder_rules.json"):
            p = os.path.join(PROFILE, name)
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    z.writestr(name, scrub(f.read(), sec))
        z.writestr("README.txt", "StashBox problem report, made %s.\nreport.txt - settings (keys hidden), your folders, "
                                 "folder rules, the last scan and every title in the library with where it is.\n"
                                 "scan_detail.txt - every folder each scan looked at, what it was read as and why.\n"
                                 "log.txt - the StashBox log.\nPasswords in NAS addresses, API keys and tokens "
                                 "have been replaced with ***.\n" % time.strftime("%Y-%m-%d %H:%M"))
    return bio.getvalue()


def save(folder):
    import xbmcvfs
    import vfs
    name = "StashBox-report-%s.zip" % time.strftime("%Y%m%d-%H%M")
    path = vfs.join(folder, name)
    data = build()
    f = xbmcvfs.File(path, "w")
    try:
        ok = f.write(bytearray(data))
    finally:
        f.close()
    if ok is False or not vfs.exists(path):
        raise IOError("couldn't write to %s" % hide_creds(folder))
    return path, len(data)
